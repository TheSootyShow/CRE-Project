function layout_fcn = GuiLayoutFunction(fig_tag)
% function layout_fcn = GuiLayoutFunction(fig_tag)
% this function is designed to replace the standard loading of a gui,
% so I can make it load a resized figure

% this process / save resized and load with the gui layout function
% isn't currently working for deployed applications
% and I don't know why, hence its disabled for now
% if isdeployed()
%     layout_fcn = [];
%     return; 
% end

% msgbox('In layout fcn');

% create a directory to store resized figures
CRE_figure_directory = CreateFigureResourceDir();

% msgbox(sprintf('Fig Dir: %s', CRE_figure_directory));

% can we access it?
if numel(CRE_figure_directory)
    
    % current version
    version_str = CRE_version();
    
    % file name from the tag
    file = [fig_tag, '_', version_str, '.fig'];
    
    % msgbox(sprintf('Fig File: %s', file));
    
    % does a resized copy exist?
    resized_file = fullfile(CRE_figure_directory, file);
    if (exist(resized_file, 'file') == 2) && (~IsDeveloper())
        layout_fcn = @(gui_SingletonOpt)CustomLoadGui(resized_file, gui_SingletonOpt);
    else
        layout_fcn = [];
    end
    
else
    layout_fcn = [];  % just load it normally
end



function gui_hFigure = CustomLoadGui(fig_name, gui_SingletonOpt)
% function hFig = CustomLoadGui(fig_name, gui_SingletonOpt)
% function to load the gui

% ensure all callbacks are on the path
% msgbox('in layout function');
added_paths = {};
if ~(isdeployed)
    added_paths = AddCREDirs();
    pause(.1);  % give it time
end

% msgbox(sprintf('Layout Function: %s', fig_name));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% All code below is stolen straight from gui_mainfcn
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gui_hFigure = local_openfig(fig_name, gui_SingletonOpt, 'invisible');

% If the figure has InGUIInitialization it was not completely created
% on the last pass.  Delete this handle and try again.
% if isappdata(gui_hFigure, 'InGUIInitialization')
%     delete(gui_hFigure);
%     gui_hFigure = local_openfig(fig_name, gui_SingletonOpt, 'invisible');
% end

% restore tab system if needed
try
    tab_info = modUserData(gui_hFigure, 'get', 'TabInfo');
    if numel(tab_info)
        
        modUserData(gui_hFigure, 'remove', 'TabInfo');
        RestoreFigureTabs(gui_hFigure, guidata(gui_hFigure), tab_info);
        
        
        % in the undeployed version, tabs are generally restored during a call to the figure's
        % create function.  Since this doesn't appear to be the case in the
        % deployed version, do an extra check now
    elseif (~HasTabs(gui_hFigure))  % check this because tabs may have been restored by the create function
        
%         % check if a tab file exists
%         tabFile = regexprep(fig_name, '\.fig$', '_TabData.mat');  % ensure this naming scheme matches GuiLayoutFunction.m
%         if exist(tabFile, 'file')
%             
%             % check what handles exist
%             handles = guidata(gui_hFigure);
%             fnames = fieldnames(handles);
%             str = fnames{1};
%             for i = 2:numel(fnames)
%                 str = sprintf('%s\n%s', str, fnames{i});
%             end
%             
%             % load it
%             tab_info = load(tabFile, '-mat');
%             fnames = fieldnames(tab_info);
%             tab_info = tab_info.(fnames{1});
%             
%             % and restore
%             RestoreFigureTabs(gui_hFigure, guidata(gui_hFigure), tab_info);
%         end
        
    end
catch ME
    errordlg(ME.message);
end


% can't actually trust the above in the dployed version (I'm unsure why)
% check if there's an ancillary version


% If the resize function was saved in the userdata, restore it now
resize_fcn = modUserData(gui_hFigure, 'get', 'ResizeFcn');
if numel(resize_fcn)
    set(gui_hFigure, 'ResizeFcn', resize_fcn);
    modUserData(gui_hFigure, 'remove', 'ResizeFcn');
end

% add "added_paths" to the cache
handles = guidata(gui_hFigure);

% msgbox(sprintf('Layout fcn: %s\nnum handles fields = %i\nFigure tag %s', fig_name, numel(fieldnames(handles)), get(gui_hFigure, 'tag')));

handles.(get(gui_hFigure, 'tag')) = gui_hFigure;  % this is the figure handle
handles.added_paths = added_paths;
guidata(gui_hFigure, handles);

% trigger the resize function while its invisible
use_java = GetPreferredSize();
resizeFcn = get(gui_hFigure, 'ResizeFcn');
if (~use_java) && (numel(resizeFcn) > 0)  % the figure is not visible, so we cant use java placement
    feval(resizeFcn, gui_hFigure, []);
end

% I've been having problems with visablity, so make sure visibilty is set
% now
set(gui_hFigure, 'visible', 'on');
% msgbox('exit layout function');




function gui_hFigure = local_openfig(name, singleton, visible)

% openfig with three arguments was new from R13. Try to call that first, if
% failed, try the old openfig.
if nargin('openfig') == 2
    % OPENFIG did not accept 3rd input argument until R13,
    % toggle default figure visible to prevent the figure
    % from showing up too soon.
    gui_OldDefaultVisible = get(0,'defaultFigureVisible');
    set(0,'defaultFigureVisible','off');
    %gui_hFigure = openfig(name, singleton);
    gui_hFigure = open(name);
    %msgbox(sprintf('local_openfig: %s\nFigure tag: %s', name, get(gui_hFigure, 'tag')));
    set(0,'defaultFigureVisible',gui_OldDefaultVisible);
else
    %gui_hFigure = openfig(name, singleton, visible);  
    gui_hFigure = open(name);
    %msgbox(sprintf('local_openfig: %s\nFigure tag: %s', name, get(gui_hFigure, 'tag')));
    %workaround for CreateFcn not called to create ActiveX
    if feature('HGUsingMATLABClasses')
        peers=findobj(findall(allchild(gui_hFigure)),'type','uicontrol','style','text');    
        for i=1:length(peers)
            if isappdata(peers(i),'Control')
                actxproxy(peers(i));
            end            
        end
    end
end