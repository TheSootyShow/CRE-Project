function [features, obs_warn] = ParseFeatures(features, min_obs)
% function [features, obs_warn] = ParseFeatures(features)
% function [features, obs_warn] = ParseFeatures(features, min_obs)
% this function parses the features structure and adds all necessary
% pre-requisite functions, as well as ensuring the features are calculated
% in the correct order
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% features - structure with an entry for each feature to be calculated. See
%            CREFeatures.m
%
% min_obs  - the minimum number of observations used to calculate the
%            feature (only required to generate obs_warn)
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% features - the parsed feature structure
%
% obs_warn - a string expressing if there are too few observations
%            for any of the features



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Insert prerequisites and order them
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% make it a column vector for this
is_row = size(features, 2) > 1;
features = features(:);

% note - we will order the displayed features alphabetically
prereq_inds = cell(numel(features),1);     % the prerequisite indices for each

% build an array of the name of all functions
feat_names = {features.name};
feat_names = feat_names(:);

% now go through looking for prerequisites and finding indices
i = 0;
while (i < numel(features))
    
    i = i + 1;  % next one
    
    % does it have pre-reqs?
    if numel(features(i).prereq_name)
    
        % find required prerequisites that aren't already in the list
        [in_list, idx] = ismember(features(i).prereq_name, feat_names);
        
        % create the ones not in the list
        if any(~in_list)
            new_names = features(i).prereq_name(~in_list);
            new_features = CREFeatures(new_names);
            [new_features.prereq_only] = deal(true);  % mark them as prerequsiite only
            
            % add the to the list
            n = numel(features);  % current number of features
            features = [features; new_features(:)]; %#ok<*AGROW>
            idx(~in_list) = n+1:n+numel(new_names);
            feat_names = [feat_names; new_names(:)];
            prereq_inds = [prereq_inds; cell(numel(new_names),1)];
        end
        
        % assign indices of prerequisites
        prereq_inds{i} = idx;
    end
end

% now build the order of them
order = zeros(size(features));
prereq_only = [features.prereq_only];
prereq_only = prereq_only(:);
n_prereqs = cellfun(@numel, prereq_inds);
needs_disp = cellfun(@(x)(any(~prereq_only(x))), prereq_inds);  % function that rely on other displayed functions

% put all the prereqs only ones that have no prerequisites first
stage1 = prereq_only & (n_prereqs == 0);
inds = find(stage1);
% sort alphabetically
[pst, stage_order] = sort(feat_names(inds));
inds = inds(stage_order);
order(inds) = 1:numel(inds);
order_max = numel(inds);  % current max assigned to order

% now systematically do all of the other pre-reqs only that don't rely on a
% displayed pre-req
cstage = prereq_only & ~needs_disp & (order == 0);
while any(cstage)
    
    % get indices
    inds = find(cstage);
    
    % only do the ones that have all of their prereqs included
    inds = inds(cellfun(@(x)(all(order(x) > 0)), prereq_inds(inds)));
    
    % sanity check
    if (numel(inds) == 0)
        error('Can''t devise an order!');
    end
    
    % sort alphabetically
    [pst, stage_order] = sort(feat_names(inds));
    inds = inds(stage_order);
    order(inds) = order_max + (1:numel(inds));
    order_max = numel(inds) + order_max;
    
    % get ready for the next pass
    cstage = prereq_only & ~needs_disp & (order == 0);
end

% now systematically do the rest
cstage = (order == 0);
while any(cstage)
    
    % get indices
    inds = find(cstage);
    
    % only do the ones that have all of their prereqs included
    inds = inds(cellfun(@(x)(all(order(x) > 0)), prereq_inds(inds)));
    
    % sanity check
    if (numel(inds) == 0)
        error('Can''t devise an order!');
    end
    
    % sort alphabetically
    [pst, stage_order] = sort(feat_names(inds));
    inds = inds(stage_order);
    order(inds) = order_max + (1:numel(inds));
    order_max = numel(inds) + order_max;
    
    % get ready for the next pass
    cstage = (order == 0);
    
end    
    
% and apply the order
features(order) = features;

% redim features to match the input
if (is_row)
    features = reshape(features, 1, numel(features));
end
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Check the minimimum number of oberservations criteria is met
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin > 1)
    
    % get how many each feature needs
    feat_min_obs = [features.min_obs];
    
    % ignore minimum obs for CRE fft when its only a pre-req for
    % autocorrelation
%     fftIndex = find(strcmpi(feat_names, 'fft'));
%     if numel(fftIndex)
%         hasAcorr = any(strcmpi(feat_names, 'auto correlation'));
%         hasOther = false;
%         for i = 1:numel(features)
%         
%         end
%         aCorrOnly = hasAcorr && (~hasOther);
%     end
    
   
    % the indices of the features that don't have enough
    inds = find(feat_min_obs > min_obs);
    
    if (numel(inds))
        
        if (min_obs >= 1)
            min_obs_str = num2str(floor(min_obs));
        elseif (min_obs >= .1)
            min_obs_str = ' < 1';
        else
            min_obs_str = '  << 1';
        end
        
        obs_warn = sprintf('There may not be enough data points in each bin (%s observations) to reliably calculate the following features:\n', min_obs_str);
        for i = 1:numel(inds)
            obs_warn = sprintf('%s\t%s\n', obs_warn, features(inds(i)).name);
        end
    else
        obs_warn = '';
    end
    
end

    

