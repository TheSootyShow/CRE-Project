function features = MapFeaturesToDataSet(features, data_set)
% function features = MapFeaturesToDataSet(features, data_set)
% function to transfer features from one data set to another

% go through each feature
for i = 1:numel(features)

    % anything that use an fft as a prereq needs its fs input adjusted
    if (IsFreqDependentFeature(features(i)))
        
        % the final input is always fs
        features(i).input_args{end} = data_set.fs;
        
        % the two inputs before are fl and fh
        % make sure they don't exceed fs/2
        features(i).input_args{end-1} = min(features(i).input_args{end-1}, data_set.fs/2);
        features(i).input_args{end-2} = min(features(i).input_args{end-2}, data_set.fs/2);
        
    end
    
    % The fft function also needs its sampling rate adjusted
    if strcmpi(features(i).name, 'fft')
        features(i).input_args{1} = data_set.fs;  % its first arg
    end
end

        


           

