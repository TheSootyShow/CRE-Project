function featSettings = InitFeatSettingsStruct(data_set)
% function featSettings = InitFeatSettingsStruct()
% function featSettings = InitFeatSettingsStruct(data_set)
% function to initialise the feature settings structure


% Initialise the overarching structure
featSettings = struct( 'timeRange',     [],  ... % has the time to start and stop the analysis (see InitTimeRangeStruct.m)
                       'freqRange',     [],  ... % frequency range to analyse for frequency domain features
                       'dimInfo',       [],  ... % which dimensions to build features from (see InitDimStruct)
                       'exportInfo',    [],  ... % export information
                       'binInfo',       [],  ... % information relating to data "binning"
                       'features',      [],  ... % the features to calculate
                       'postFeatures',  [],  ... % structure containing post processing instructions for other features
                       'dsName',        [],  ... % the data set name (for auto-naming)
                       'aliases',       []); ... % known aliases for features
                   
                           

% and each sub stucture
if (nargin == 0)
    featSettings.timeRange = InitTimeRangeStruct();
    featSettings.binInfo = InitBinInfoStruct();
    featSettings.dimInfo = InitDimStruct();
    featSettings.freqRange = InitFreqRangeStruct();
    featSettings.exportInfo = InitExportStruct();
else
    featSettings.dsName = data_set.name;
    featSettings.timeRange = InitTimeRangeStruct(data_set);
    featSettings.binInfo = InitBinInfoStruct(data_set);
    featSettings.dimInfo = InitDimStruct(data_set);
    featSettings.freqRange = InitFreqRangeStruct(data_set);
    featSettings.exportInfo = InitExportStruct(data_set, featSettings);
end
featSettings.features = CREFeatures(0);
featSettings.postFeatures = InitDerivedFeature(0);
featSettings.aliases = cell(0,2);

                            

