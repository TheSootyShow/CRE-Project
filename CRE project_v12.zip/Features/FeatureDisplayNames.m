function [feat_names, display] = FeatureDisplayNames(featSettings, apply_aliases)
% function [feat_names, display] = FeatureDisplayNames(featSettings)
% function [feat_names, display] = FeatureDisplayNames(featSettings, apply_aliases)
% this function builds a list of names to display for each featSettings.features
% input arguments are added to function where they're applicable

if (nargin < 2) || (numel(apply_aliases) == 0)
    apply_aliases = true;
end
    

% this is the list of what to add to what feature
list = {'auto correlation',                   @(args)(sprintf('(%gms)', args{1})); ...
        'percentile',                         @(args)(sprintf('(%g%%)', args{1})); ...
        'dominant frequency',                 @(args)(sprintf('(%i,%g,%g)', args{1}, args{2}, args{3})); ...
        'dominant frequency magnitude',       @(args)(sprintf('(%i,%g,%g)', args{1}, args{2}, args{3})); ...
        'entropy',                            @(args)(sprintf('(%g,%g)', args{1}, args{2}))};  
    
% the "standard" names
feat_names = {featSettings.features.name};

% modify any that need chagning
[change, idx] = ismember(feat_names, list(:, 1));
for i = find(change)
    feat_names{i} = [feat_names{i}, feval(list{idx(i),2}, featSettings.features(i).input_args)];
end

% the derived ones
post_names = {featSettings.postFeatures.name};
if (apply_aliases)
    post_names = ApplyKnownDimAliases(post_names, featSettings.dimInfo.aliases);
end


% combine them
feat_names = [feat_names(:); post_names(:)];

% display which ones?
display_feats = ~[featSettings.features.prereq_only];
display_post = logical([featSettings.postFeatures.display]);
display = [display_feats(:); display_post(:)];

% apply aliases if desired
if (apply_aliases)
    feat_names = ApplyKnownFeatAliases(feat_names, featSettings.aliases);
end

% sort them
[feat_names, order] = sort(feat_names(:));
display = display(order);

% if only one output, remove undisplayed names
if (nargout == 1)
    feat_names = feat_names(display);
end





