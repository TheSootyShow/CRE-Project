function varargout = CREFeatureGui(varargin)
% function [response, featSettings] = CREFeatureGui(data_set, view_time, view_hhmmss, start_relative)
% function [response, featSettings] = CREFeatureGui(data_set, view_time, view_hhmmss, start_relative, feature settings)
%
%CREFEATUREGUI M-file for CREFeatureGui.fig
%      CREFEATUREGUI, by itself, creates a new CREFEATUREGUI or raises the existing
%      singleton*.
%
%      H = CREFEATUREGUI returns the handle to a new CREFEATUREGUI or the handle to
%      the existing singleton*.
%
%      CREFEATUREGUI('Property','Value',...) creates a new CREFEATUREGUI using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to CREFeatureGui_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      CREFEATUREGUI('CALLBACK') and CREFEATUREGUI('CALLBACK',hObject,...) call the
%      local function named CALLBACK in CREFEATUREGUI.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CREFeatureGui

% Last Modified by GUIDE v2.5 04-Sep-2014 14:15:11

% use this to try and load a version that's already been resized
layout_fcn = GuiLayoutFunction('CREFeatureGui');

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREFeatureGui_OpeningFcn, ...
                   'gui_OutputFcn',  @CREFeatureGui_OutputFcn, ...
                   'gui_LayoutFcn',  layout_fcn, ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

% ensure guis's always load visible
if (nargin == 0)
    varargin = {'visible', 'on'};
end

if 1 || (~IsDeveloper)
    try % AWBS - well this can't be a good idea....
        if nargout
            [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
        else
            gui_mainfcn(gui_State, varargin{:});
        end
    catch ME
        
        % check this error wasn't caused by the error handler trying to do
        % something
        stack = {ME.stack(:).name};
        if ~any(strcmpi(stack, 'ProcessFeatureGuiError'))
        
            % deal with the error
            ProcessFeatureGuiError(ME);
            
        else
           
            % send the error back to the handler
            rethrow(ME);
            
        end
    end
else
    % use actual errors in developer mode
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
end

% End initialization code - DO NOT EDIT

% --- Executes just before CREFeatureGui is made visible.
function CREFeatureGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

try

%msgbox('In feature gui opening function');
    
% ensure the parent directory is on the path
added_paths = {};
if ~(isdeployed)
    
    % where is this file?
    this_dir = fileparts(mfilename('fullpath'));
    
    % the add paths function is up one level from this
    [parts, tmp] = regexp(this_dir, filesep, 'split');
    CRE_dir = this_dir(1:tmp(end)-1);
    cp = pwd;
    cd(CRE_dir);
    added_paths = AddCREDirs();
    cd(cp);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Migrated keypress functions to a single file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hCheck = findobj(hObject, 'style', 'edit');
% set(hCheck, 'keypressfcn', @(hObject,eventdata)Default_KeyPressFcn(hObject,eventdata,guidata(hObject)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ensure the GUI is up to date visually
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% restore tab system if needed
% tab_info = modUserData(hObject, 'get', 'TabInfo');
% if numel(tab_info)
%     modUserData(hObject, 'remove', 'TabInfo');
%     handles = RestoreFigureTabs(hObject, handles, tab_info);
% elseif (numel(findobj(hObject, 'type', 'uitab')) == 0)
%     error('Tabs are lost!')
% end

% commit it now
handles.added_paths = added_paths;

% update the time range panel if needed
if (~isdeployed && IsDeveloper())
    
    % cover it to prevent epillepsy
    hCover = CoverFig(hObject);

    handles = CopyRangeTemplateToFigure(hObject, handles);
    
    % update the dimensions panel if needed
    handles = CopyDimTemplateToFigure(hObject, handles);
    
    % update the feature panel if needed
    handles = CopyFeatTemplateToFigure(hObject, handles);
    
    % and the post processing pane
    handles = CopyPostTemplateToFigure(hObject, handles);
    
    % and the export processing pane
    handles = CopyExportTemplateToFigure(hObject, handles);
    
    % delete the cover
    delete(hCover);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the input data set
%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (numel(varargin) >= 1)
    handles.data_set = varargin{1};
    if ~isstruct(handles.data_set)
        error('The first input to CREFeatureGui should be a data set structure');
    end
    
elseif ~isfield(handles, 'data_set') || (numel(handles.data_set) == 0)
    handles.data_set = VirtualDataSet();  % use a fake
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Marry the input features to the input data set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

feats_built = false;
handles.warn_fig = [];
if (numel(varargin) >= 5) && (numel(varargin{5}) > 0) && isstruct(varargin{5})
   
    copy_features = varargin{5};
    
    feats_built = false;
    same_data = strcmpi(copy_features.dsName, handles.data_set.name);
    if (~same_data)

        % ask the user if they want to try same settings
        dlg_title = sprintf('Attempt to use the previous feature settings from data set: %s on data set %s?', copy_features.dsName, handles.data_set.name);
        response = questdlg(dlg_title, 'Feature matching options', 'Yes', 'No', 'Yes'); 
        rebuild = strcmpi(response, 'Yes');
    else
        rebuild = true;
    end
    
    % attempt to pass the features to the new data set
    if (rebuild)
        [handles.featSettings, feats_built, warnings] = PassFeaturesToDataSet(copy_features, handles.data_set);
        if numel(warnings) && (feats_built)
            handles.warn_fig = CreateMsgBox('Features settings transfered with warnings:', regexp(warnings, sprintf('\n'), 'split'));
        elseif ~(feats_built)
            warn_cell = regexp(warnings, sprintf('\n'), 'split');
            
            % highlight all errors
            for i = 1:numel(warn_cell)
                if numel(regexpi(warn_cell{i}, 'error', 'match', 'once'))
                    warn_cell{i} = sprintf('<b>%s</b>', warn_cell{i});
                end
            end
            
            % and generate
            CreateMsgBox('Failed to transfer feature settings, with errors and warnings:', warn_cell, true);
        end
    end
end

% store default settings
handles.inputSettings = InitFeatSettingsStruct(handles.data_set);

if ~(feats_built)
    
    % initialise the data set
    handles.featSettings = handles.inputSettings;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Update with user specific viewing options
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% how to display times
if (numel(varargin) >= 2) && (numel(varargin{2}) > 0)
    handles.featSettings.timeRange.is_time = varargin{2};
end


if (numel(varargin) >= 3) && (numel(varargin{3}) > 0)
    handles.featSettings.timeRange.is_hhmmss = varargin{3};
end

% show times as relative to the recordings start?
if (numel(varargin) >= 4) && (numel(varargin{4}) > 0) && (handles.featSettings.timeRange.is_hhmmss)
    handles.featSettings.timeRange.is_relative = varargin{4};
end

% allocate a blocking list for the "OK" button.  This list contains handles
% to objects who's value cant be sensibly interpreted
handles.block_list = [];

% Choose default command line output for CREFeatureGui
handles.output = {'Cancel', handles.featSettings};


% initialise key press robot
handles = KeyPressInit(hObject, eventdata, handles);

% stop keypress callbacks on these - they're not helpping
% set([handles.ebMaxFreq1, handles.ebMinFreq1], 'KeyPressFcn', []);
%set(findobj(hObject, 'style', 'edit'), 'KeyPressFcn', []);
hEdit = findobj(hObject, 'style', 'edit');
set([hObject(:); hEdit], 'Interruptible', 'off');
set([hObject(:); hEdit], 'BusyAction', 'queue');

% Resize the figure now
handles = CREFeatureGui_ResizeFcn(hObject,[], handles);

% Initialise the gui                     
handles = InitialiseGui(handles);

% Update handles structure
guidata(hObject, handles);


% UIWAIT makes CREFeatureGui wait for user response (see UIRESUME)
uiwait(handles.CREFeatureGui);

catch ME
    errordlg(ME.message);
end
    



% --- Executes during object creation, after setting all properties.
function CREFeatureGui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CREFeatureGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% msgbox('in create function');

% remember handles will be empty here
tab_info = modUserData(hObject, 'get', 'TabInfo');
if numel(tab_info)
    modUserData(hObject, 'remove', 'TabInfo');
    visible = get(hObject, 'visible');
    set(hObject, 'visible', 'off');
    drawnow();
    RestoreFigureTabs(hObject, handles, tab_info);
    % msgbox('added tabs (create)');
    set(hObject, 'visible', visible);
    drawnow();
end

% msgbox('exit create function');


% --- Outputs from this function are returned to the command line.
function varargout = CREFeatureGui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if ~iscell(handles.output) || (numel(handles.output) ~= 2)  % not sure how this happens
    handles.output = {'Cancel', []};
end

% Get default command line output from handles structure
varargout{1} = handles.output{1};
varargout{2} = handles.output{2};
delete(hObject);


% --- Executes when user attempts to close CREFeatureGui.
function CREFeatureGui_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CREFeatureGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes during object creation, after setting all properties.
function Default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to object being created
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Null_Callback(hObject, eventdata, handles)
% hObject    handle to current object
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes when CREFeatureGui is resized.
function handles = CREFeatureGui_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to CREFeatureGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% call the feature layout function
if (RunResizeFcn(hObject, handles))
    
	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);
    
	% and resize
	handles = CREFeatureGuiLayout(hObject, eventdata, handles);
end

% now turn off the resize option
set(hObject, 'resize', 'off');
drawnow();

function handles = RestoreDefaultFeatures(handles)
% function handles = RestoreDefaultFeatures(handles)
% function to build the default feature options


% go back to the original 
handles.featSettings = handles.inputSettings;

% change the structure used by the time pane to reflect this
if isfield(handles, 'timeInfo')  % It way not have been initialized yet
    handles.timeInfo = UpdateStruct(handles.timeInfo, handles.featSettings.timeRange, false);
end

% Choose default command line output for CREFeatureGui
handles.output = {'Cancel', handles.featSettings};

% and reintialise
handles = InitialiseGui(handles);



function handles = InitialiseGui(handles)
% function InitialiseGui(handles)
% function to update the gui based on the current selection

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set dimensions selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set up the list boxes
InitialiseDimPane(handles.featSettings.dimInfo, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the bins status
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set appropriate check boxes
set(handles.rbGlobal, 'value', ~handles.featSettings.binInfo.use_bins);
set(handles.rbBinData, 'value', handles.featSettings.binInfo.use_bins);
set(handles.ebBinDuration, 'string', FsString(handles.featSettings.binInfo.bin_duration));    % printf full precision
set(handles.txtBinPoints, 'string', num2str(handles.data_set.fs * handles.featSettings.binInfo.bin_duration));    % printf full precision
set(handles.pmBinTime, 'value', find( handles.featSettings.binInfo.time_align(1) == 'sce'));
on_off = {'off', 'on'};
set(handles.ebBinDuration, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
set(handles.pmBinTime, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set data range selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

handles = InitTimePanel(handles, handles.data_set, handles.featSettings.timeRange.is_time, handles.featSettings.timeRange.is_hhmmss, ...
    handles.featSettings.timeRange.is_relative);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set any used features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[handles, handles.featSettings.freqRange] = InitialiseFeatPane(handles.featSettings, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now set the post features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

InitialisePostPane(handles.featSettings, handles);    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up the export options
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

InitialiseExportPane(handles.featSettings.exportInfo, handles);

    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set the string for all of the features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% finally, update the featuire list
[handles.featSettings, aliasList, display, idx, featList] = ProcessFeatures(handles.featSettings, handles.data_set, true);
handles.featSettings = UpdateFeatListControl(handles.lbAllFeats, handles.featSettings, aliasList, display, idx, featList);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% And set OK status
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

EnableDisableOutput(handles);

% update handles
if (nargout < 1)
    guidata(handles.CREFeatureGui, handles);
end












function ebBinDuration_Callback(hObject, eventdata, handles)
% hObject    handle to ebFileName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebFileName as text
%        str2double(get(hObject,'String')) returns contents of ebFileName as a double

% get the bin duration
bin_str = get(hObject, 'string');
bin_dur = str2double(bin_str);

if isfinite(bin_dur) && (bin_dur > 0) && (bin_dur <= ((handles.data_set.num_points - 1) / handles.data_set.fs))
    
    % its valid
    handles.featSettings.binInfo.bin_duration = bin_dur;
    handles.block_list = handles.block_list(handles.block_list ~= hObject);  % ensure its not in the block list
    
    % update the points per bin
    set(handles.txtBinPoints, 'string', num2str(handles.data_set.fs * handles.featSettings.binInfo.bin_duration));   
    
    % update the minimum possible resolution
    binSamps = floor(bin_dur * handles.data_set.fs);
    minRes = handles.data_set.fs / binSamps;
    set(handles.txtMinFFTres, 'string', num2str(minRes));
    
    % the new  / updated name
    handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings, handles.featSettings.exportInfo.auto_name, handles.featSettings.exportInfo.file_name);
    
    % update with the new name
    handles = ExportPaneCallbacks(handles.ebFileName, handles.featSettings.exportInfo.file_name, handles);  
    
elseif ~any(handles.block_list == hObject)
    
    % block the "OK" output
    handles.block_list(end+1) = hObject;
end

% enable or disable "OK"
EnableDisableOutput(handles)

% and update the handles
guidata(hObject, handles);


% --- Executes on selection change in pmBinTime.
function pmBinTime_Callback(hObject, eventdata, handles)
% hObject    handle to pmBinTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmBinTime contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmBinTime

options = cellstr(get(hObject,'String'));
selected = get(hObject,'Value');
handles.featSettings.binInfo.time_align = lower(options{selected}(1));

% update the name automatically if desired
if (handles.featSettings.exportInfo.auto_name)
    
    % the new name
    handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings);
    handles = ExportPaneCallbacks(handles.ebFileName, 1, handles);  % use this to check validity
end

% and update the handles
guidata(hObject, handles);



% --- Executes on button press in rbGlobal.
function rbGlobal_Callback(hObject, eventdata, handles)
% hObject    handle to rbGlobal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rbGlobal
% set appropriate check boxes

% grab the present value
handles.featSettings.binInfo.use_bins = get(hObject, 'value') == 0;

% and update associated unicontrols
on_off = {'off', 'on'};
set(handles.rbBinData, 'value', handles.featSettings.binInfo.use_bins);
set(handles.txtBinPoints, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
% set(handles.txtBinPointsLabel, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
set(handles.ebBinDuration, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
set(handles.pmBinTime, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});

% Update blocking caused by the bin duration value
if (~handles.featSettings.binInfo.use_bins)
    
    % bin duration can't block any loner
    handles.block_list = handles.block_list(handles.block_list ~= handles.ebBinDuration);  
    
    % for fft resolution
    binSamps = SamplesFromTimeRange(handles.timeInfo);
    
    if (handles.featSettings.exportInfo.auto_name)
        
        % the new name
        handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings);
        
        % test validity of the file name
        handles = ExportPaneCallbacks(handles.ebFileName, 1, handles);  % use this to check validity
        
    end
    
else
    % for fft resolution
    binSamps = floor(handles.featSettings.binInfo.bin_duration * handles.data_set.fs);
    
end

% update minimum fft resolution
minRes = handles.data_set.fs / binSamps;
set(handles.txtMinFFTres, 'string', num2str(minRes));

% enable or disable "OK"
EnableDisableOutput(handles)

% and update the handles
guidata(hObject, handles);



% --- Executes on button press in rbBinData.
function rbBinData_Callback(hObject, eventdata, handles)
% hObject    handle to rbBinData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rbBinData
% grab the present value
handles.featSettings.binInfo.use_bins = get(hObject, 'value') ~= 0;

% and update associated unicontrols
on_off = {'off', 'on'};
set(handles.rbGlobal, 'value', ~handles.featSettings.binInfo.use_bins);
set(handles.txtBinPoints, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
% set(handles.txtBinPointsLabel, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
set(handles.ebBinDuration, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});
set(handles.pmBinTime, 'enable', on_off{1+handles.featSettings.binInfo.use_bins});

% Update blocking caused by the bin duration value
if (~handles.featSettings.binInfo.use_bins)
    
    % bin duration can't block any loner
    handles.block_list = handles.block_list(handles.block_list ~= handles.ebBinDuration);  
    
    % for fft resolution
    binSamps = SamplesFromTimeRange(handles.timeInfo);
    
    if (handles.featSettings.exportInfo.auto_name)
        
        % the new name
        handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings);
        
        % test validity of the file name
        handles = ExportPaneCallbacks(handles.ebFileName, 1, handles);  % use this to check validity
        
    end
else
    % for fft resolution
    binSamps = floor(handles.featSettings.binInfo.bin_duration * handles.data_set.fs);
end

% update minimum fft resolution
minRes = handles.data_set.fs / binSamps;
set(handles.txtMinFFTres, 'string', num2str(minRes));


% enable or disable "OK"
EnableDisableOutput(handles)

% and update the handles
guidata(hObject, handles);


% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% add to timing info to the featuer settings
handles.featSettings.timeRange = UpdateStruct(handles.featSettings.timeRange, handles.timeInfo, false);

% warn the user if there are no features
if (numel(handles.featSettings.features) == 0)
    resp = questdlg(sprintf('No features have been selected\nContinue anyway?'), 'Warning!', 'Yes', 'No', 'No');
    if (numel(resp) && strcmpi(resp, 'No'))
        return;  % dont proceed
    end
end


% parse the output features
[handles.featSettings.features, obs_warn] = ParseFeatures(handles.featSettings.features, ...
    handles.data_set.fs * handles.featSettings.binInfo.bin_duration);

% warn the user if there are too few observations
if (numel(obs_warn))
    resp = questdlg(sprintf('%s\n\nContinue anyway?', obs_warn), 'Warning!', 'Yes', 'No', 'No');
    if (numel(resp) && strcmpi(resp, 'No'))
        return;  % dont proceed
    end
end

% indicate OK
handles.output = {'OK', handles.featSettings};
guidata(hObject, handles);

% and close the gui
CREFeatureGui_CloseRequestFcn(handles.CREFeatureGui, eventdata, handles);




% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% add to timing info to the featuer settings
handles.featSettings.timeRange = UpdateStruct(handles.featSettings.timeRange, handles.timeInfo, false);

% indicate OK
handles.output = {'Cancel', handles.featSettings};
guidata(hObject, handles);

% and close the gui
CREFeatureGui_CloseRequestFcn(handles.CREFeatureGui, eventdata, handles);










% --------------------------------------------------------------------
function miDescrip_Callback(hObject, eventdata, handles)
% hObject    handle to miDescrip (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% bring up a help screen
FeatureGuiAbout();


% --------------------------------------------------------------------
function miLoad_Callback(hObject, eventdata, handles)
% hObject    handle to miLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_file;

% function to load previously saved features
if (numel(last_file) == 0) || (~ischar(last_file))
    last_file = DataLoadDir();
end
[file, path] = uigetfile('*.mat', 'Load Feature Settings File', last_file);
if ~ischar(path) || (numel(path) == 0)
    return;
end

% load it
last_file = fullfile(path, file);
tmp = load(last_file, '-mat');
fnames = fieldnames(tmp);
load_features = tmp.(fnames{1});

% and try to apply it?
try
    
    % try to pass it
    [handles.featSettings, feats_built, warnings] = PassFeaturesToDataSet(load_features, handles.data_set, true);
    
    if numel(warnings) && (feats_built)
        handles.warn_fig = CreateMsgBox('Features loaded with warnings:', regexp(warnings, sprintf('\n'), 'split'));
    elseif ~(feats_built)
        
        % highlight all errors
        warn_cell = regexp(warnings, sprintf('\n'), 'split');
        for i = 1:numel(warn_cell)
            warn_cell{i} = sprintf('<b>%s</b>', warn_cell{i});
        end
        
        % and generate
        [warn_fig, txt_h] = CreateMsgBox('Failed to load feature settings, with errors and warnings:', warn_cell);
        
    end
        
    % Update the gui to reflect the loaded features
    if (feats_built)
        handles = InitialiseGui(handles);
        guidata(hObject, handles);
    end
    
catch ME
    errordlg(sprintf('Unabled to apply the feature settings to the data set:\n%s', ME.getReport('extended', 'hyperlinks','off')), 'Feature Settings Error', 'modal');
end

% --------------------------------------------------------------------
function miSave_Callback(hObject, eventdata, handles)
% hObject    handle to miSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_name
persistent last_ds

% save this where?
if (numel(last_name) == 0) || (~strcmpi(last_ds, handles.data_set.file_name));
    def_name = fullfile(fileparts(handles.data_set.file_name), 'featSettings.mat');
else
    def_name = last_name;
end

% shortcut
featSettings = handles.featSettings;

% grab the time range info
featSettings.timeRange = UpdateStruct(featSettings.timeRange, handles.timeInfo, false);

% grab the feature options
featSettings.export_time = get(handles.cbTimeCol, 'value');

% get the various frequency ranges of interest
freqRanges = FreqRangesFromFeatures(featSettings.features);
if (numel(freqRanges) == 0)
    freqRanges = [0, handles.data_set.fs/2];
end
featSettings.freqRange.fbounds = freqRanges;

% warn the user if there are no features
if (numel(featSettings.features) == 0) && (numel(eventdata) == 0)
    resp = questdlg(sprintf('No features have been selected\nContinue anyway?'), 'Warning!', 'Yes', 'No', 'No');
    if (numel(resp) && strcmpi(resp, 'No'))
        return;  % dont proceed
    end
end

% parse the output features
[tmp, obs_warn] = ParseFeatures(featSettings.features, handles.data_set.fs * featSettings.binInfo.bin_duration);

% warn the user if there are too few observations
if (numel(obs_warn))
    resp = questdlg(sprintf('%s\n\nContinue anyway?', obs_warn), 'Warning!', 'Yes', 'No', 'No');
    if (numel(resp) && strcmpi(resp, 'No'))
        return;  % dont proceed
    end
end

% open a save file dialog
if (numel(eventdata) == 0)
    [save_file, save_path] = uiputfile('*.mat', 'Save Feature Settings:', def_name);
else
    [save_path, save_file, ext] = fileparts(eventdata);
    save_file = [save_file, ext];
end

% proceed?
if ischar(save_file) && numel(save_file)
    
    % record save location
    last_ds = handles.data_set.file_name;
    last_name = fullfile(save_path, save_file);
    
    % and save
    save(last_name, 'featSettings', '-MAT');
    
    if ~isdeployed && 0
        fprintf('Save feature settings as: %s\n', last_name);
    elseif (numel(eventdata) == 0)
        msgbox(sprintf('Feature settings saved as:\n%s', last_name), 'Saved as'); 
    end
end


% --------------------------------------------------------------------
function miReset_Callback(hObject, eventdata, handles)
% hObject    handle to miReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% create a default set of features
handles = RestoreDefaultFeatures(handles);

% Update handles structure
guidata(hObject, handles);


% --- Executes on selection change in lbAllFeats.
function lbAllFeats_Callback(hObject, eventdata, handles)
% hObject    handle to lbAllFeats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbAllFeats contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbAllFeats

% get the user data first
udata = get(hObject, 'userdata');  % first cell of udata is the feature name (un aliased), second is the index
idx = udata{2};
selected = false(size(idx,1),1);
selected(get(hObject, 'value')) = true;

% now go through and set whether its display
% find them in the current list
for i = 1:size(idx,1)
    if (idx(i, 1) == 1)
        handles.featSettings.features(idx(i, 2)).output_disp(idx(i, 3)) = selected(i);
    else
        handles.featSettings.postFeatures(idx(i, 2)).display = selected(i);
    end
end
    
guidata(hObject, handles);




