function handles = AddTabsToCREFeatureGui(handles)
% function handles = AddTabsToCREFeatureGui(handles)
% function to perfrom the change from the old gui layout into the newer tab
% based system

% the figure
hFig = handles.CREFeatureGui;
set(hFig, 'visible', 'on');

% default gaps bewteen UI components
[smallGap, normGap, largeGap] = DefaultPaneGaps();

% run the old layout function
% handles = CREFeatureGuiLayoutOLD(hFig, [], handles);

% get the default pane border
[paneGap, paneBorder, figBorder] = DefaultGuiBorders();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Group the time and data bins panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% stick the time range and bin panes together
hMerge = [handles.uiRangePane; handles.uiBins];
[sizes, extents] = GetObjectSizes(hMerge);
panelPos = zeros(1,4);
panelPos(1) = min(extents(:,1)) - paneBorder(1);
panelPos(2) = min(extents(:,2)) - paneBorder(2);
panelPos(3) = max(extents(:,3)) + paneBorder(3) - panelPos(1);
panelPos(4) = max(extents(:,4)) + paneBorder(4) - panelPos(2);
panelPos(1) = max(panelPos(1), paneBorder(1));

% create it
handles.uiTimings = uipanel(get(hMerge(1), 'parent'), 'tag', 'uiTimings', 'units', 'pixels', 'position', panelPos);

% make the two other panes children of it
set(hMerge, 'parent', handles.uiTimings);

% and update their positions
pos = zeros(1,4);
for i = 1:numel(hMerge)
    pos(1) = paneBorder(1);
    pos(2) = extents(i,2) - panelPos(2);
    pos(3:4) = sizes(i, 1:2);
    set(hMerge(i), 'position', pos);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove pane titles since the tab is now used
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(handles.uiFeatureGui, 'title', '');  
set(handles.uiDims, 'title', '');  
set(handles.uiFeatures, 'title', '');  
set(handles.uiPostProcessing, 'title', ''); 
set(handles.uiOutput, 'title', ''); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix the orientation of the dimensions panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% reshape the old dimensions pane
DefaultDimPaneLayout(handles, smallGap, normGap, largeGap);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fix the orientation of the post processing panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% reshape the old dimensions pane
DefaultPostPaneLayout(handles, smallGap, normGap, largeGap);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now create the tabs system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% handles of all of the tab panels
tabPanels = [handles.uiTimings; handles.uiDims; handles.uiFeatures; handles.uiPostProcessing; handles.uiOutput];
tabSizes =  GetObjectSizes(tabPanels);

% create the tab group
handles.tgMainTab = uitabgroup('parent', handles.uiFeatureGui, 'tag', 'tgMainTab', 'visible', 'on', 'units', 'pixels');

% create a tab for time
handles.tmTimeTab = uitab(handles.tgMainTab, 'tag', 'tmTimeTab', 'title', 'Timing Options', 'units', 'pixels');
set(handles.uiTimings, 'parent', handles.tmTimeTab);

% create a tab for dimensions
handles.tmDimTab = uitab(handles.tgMainTab, 'tag', 'tmDimTab', 'title', 'Dimensions', 'units', 'pixels');
set(handles.uiDims, 'parent', handles.tmDimTab);

% create a tab for features
handles.tmFeatTab = uitab(handles.tgMainTab, 'tag', 'tmFeatTab', 'title', 'Features', 'units', 'pixels');
set(handles.uiFeatures, 'parent', handles.tmFeatTab);

% create a tab for post processing
handles.tmPostTab = uitab(handles.tgMainTab, 'tag', 'tmPostTab', 'title', 'Post Processing', 'units', 'pixels');
set(handles.uiPostProcessing, 'parent', handles.tmPostTab); % strangely

% create a tab for the output
handles.tmOutputTab = uitab(handles.tgMainTab, 'tag', 'tmOutputTab', 'title', 'Output', 'units', 'pixels');
set(handles.uiOutput, 'parent', handles.tmOutputTab);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now layout the tabs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hTabs = [handles.tmTimeTab; handles.tmDimTab; handles.tmFeatTab; handles.tmPostTab; handles.tmOutputTab];

% and set sizes
setTabGroupSize(hTabs, tabSizes);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now call the reize function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

handles = CREFeatureGuiLayout(hFig, [], handles);




function [sizes, extents] = GetObjectSizes(hObjects)
% function sizes = GetObjectSize(hObject)
% get the size of the object

sizes = zeros(numel(hObjects), 2);
extents = zeros(numel(hObjects), 4);
set(hObjects, 'units', 'pixels');

for i = 1:numel(hObjects)
    pos = get(hObjects(i), 'position');
    sizes(i,:) = pos(3:4);
    extents(i,:) = [pos(1:2), pos(1:2) + pos(3:4)];
end


    
function paneSize = DefaultDimPaneLayout(handles, smallGap, normGap, largeGap)
% function  paneSize = DefaultDimPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the dimensions pane


hGrid = {handles.txtPrimDims; ...
         handles.lbDims;      ...
         handles.txtPrimary;  ...
         handles.txtCompDims; ...
         handles.lbCompDims;  ...
         handles.txtDerived;  ...
         handles.pbRelabelDims};

% default spacing     
hGap = repmat(largeGap, size(hGrid,1), size(hGrid,2) - 1);
vGap = repmat(smallGap, size(hGrid,1)-1, size(hGrid,2));
vGap(3, :) =normGap;
vGap(end, :) =normGap;

% and get sizes
sizes = PaneSizesFromGrid(hGrid);

% keep the list boxes the same heights and widths
list_sizes = max(sizes{2,1}, sizes{4,1});
sizes{2,1} = list_sizes;
sizes{4,1} = list_sizes;
 
% and resize it
[hPane, paneSize] = ResizePaneFromGrid(hGrid, hGap, vGap, sizes);



function paneSize = DefaultPostPaneLayout(handles, smallGap, normGap, largeGap)
% function paneSize = DefaultProcessingPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the layout for the data bin pane

% set up the matrix of handles
hGrid = cell(4,1);
hGrid(1,1) = {handles.txtPostProcess};
hGrid(2,1) = {handles.lbPostProcess};
hGrid(3,1) = {handles.txtNumPostProcess};
hGrid(4,1) = {handles.pbRelabelFeatures};

% gaps between components horizontally
hGap = repmat(normGap, size(hGrid,1), size(hGrid,2) - 1);

% gaps between components vertically
vGap = repmat(smallGap, size(hGrid,1)-1, size(hGrid,2));

% and resize it
[hPane, paneSize] = ResizePaneFromGrid(hGrid, hGap, vGap);








