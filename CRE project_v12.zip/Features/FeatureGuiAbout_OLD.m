function FeatureGuiAbout()
% function FeatureGuiAbout()
% function to create descriptions of dimenensions
% in the feature gui

% for formatting
fig_width = 21;    % A4 is 21 cm wide
fig_height = 29.7; % A4 is this high
margin    = 2.5;   % use a 2.5 cm margin
para_sep  = .5;    % 0.5cm between paragraphs
sec_sep  =   1;    % 1 cm between sections
descrip_width = 5; % feature description column should be 5 cm


pix_cm = (get(0, 'ScreenPixelsPerInch')) / 2.54;      % pixels per centimeter
text_width = floor((fig_width - 2*margin) * pix_cm);  % now in pixels
para_sep  = ceil(para_sep * pix_cm);                  % now in pixels
sec_sep  = ceil(sec_sep * pix_cm);                    % now in pixels
descrip_width = floor(descrip_width * pix_cm);        % now in pixels

% limit the figure height to the size of the screen
screen_pos = get(0, 'ScreenSize');
screen_pos = screen_pos / pix_cm;   % now in cm
fig_height = min(fig_height, floor(screen_pos(4)));

 


% load the text file with the help
if ~isdeployed()
    fpath = fileparts(mfilename('fullpath'));
else
    fpath = '';
end
file_name = fullfile(fpath, 'AboutFeatureGui.txt');
fid = fopen(file_name, 'r');
if (fid <= 0)
    error('Failed to open: %s', file_name);
end
str = fread(fid, inf, 'char=>char');
str= reshape(str, 1, numel(str));  % for debugging
fclose(fid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% find the section labels
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[sec_labels, sec_start, sec_end] = regexpi(str, '\/SectionLabel[^\n]*', 'match');
n_sections = numel(sec_labels);
sec_start(end+1) = numel(str) + 1;  % convenient

% strip the "section label" tag form the headers
sec_labels = cellfun(@(str)strtrim(regexprep(str, '\/SectionLabel','','preservecase')), sec_labels, 'uniformoutput', false);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% break it into sections
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sections = cell(1, n_sections);
for i = 1:n_sections
   
    % extract it
    sections{i} = strtrim(str(sec_end(i)+1:sec_start(i+1)-1));
    
    % remove formatting I dont use
    sections{i} = regexprep(sections{i}, '[\f\r\v]', '','preservecase');
    
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% find the feature list -  should be in the final section 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% now find the feature list
[list, list_start, list_end] = regexpi(sections{end}, '\s*\/(start|end)featlist\s*', 'match');

if (numel(list_start) ~= 2)
    error('Could not find the feature list in: %s', file_name);
end

% grab it
list_str = strtrim(sections{end}(list_end(1)+1:list_start(2)-1));

% for text after the list
post_text = strtrim(sections{end}(list_end(2)+1:end));

% for text preceding the list
sections{end} = strtrim(sections{end}(1:list_start(1)-1));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parse the feature list into table form
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% split based on lines
list_cell = regexp(list_str, '[\n]+', 'split');  % ignore blank lines
list_cell = list_cell(:);

for i = 1:size(list_cell,1)
    
    % columns are tab delimited
    entries = regexp(list_cell{i,1}, '\t', 'split');
    list_cell(i, 1:numel(entries)) = entries;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now create the figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fh = figure;
set(fh, 'units', 'centimeters', 'visible', 'off');
f_pos = get(fh, 'position');
extra = (fig_width - f_pos(3)) / 2;
f_pos(1) = f_pos(1) - extra;  % keep the center in the same spot
f_pos(3) = fig_width;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Get default formatting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[tmp_h, tmp_hg] = javacomponent({'javax.swing.JLabel', 'hello'}, [], fh);
def_font = tmp_h.getFont();
headerRule = ['body { font-family: ', def_font.getFamily().char(), '; font-size: ', num2str(def_font.getSize()+2), 'pt; }'];  % make headings 2 pts bigger
bodyRule = ['body { font-family: ', def_font.getFamily().char(), '; font-size: ', num2str(def_font.getSize()), 'pt; }'];
delete(tmp_h);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now create text boxes for section
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

java_h = cell(n_sections, 1);
hg_h = cell(n_sections, 1);
widths = cell(n_sections, 1);
heights = cell(n_sections, 1);
n_paraseps = 0;                 % keep track of the numebr of paragragh seperators
for i = 1:n_sections
    
    % break the section into parargraphs
    paras = regexp(sections{i}, '[\n]+', 'split');  % ignore blank lines
    n_paraseps = n_paraseps + numel(paras);         % remember the break from the section title
    
    % if this is the feature section, add the feature table as well as post text
    if (i == n_sections)
        post_text = regexp(post_text, '[\n]+', 'split');  % ignore blank lines
        paras = [sec_labels{i}; paras(:); list_cell(:); post_text(:)];
        table_rows = [1 + numel(paras), numel(paras) + numel(list_cell)];         % inclusive
        n_paraseps = n_paraseps + 1 + numel(post_text);
    else
        paras = [sec_labels{i}; paras(:)];
        table_rows = [-1,-1];
    end
    
    % allocate space for test box handles
    java_h{i} = cell(numel(paras), 1);
    hg_h{i} = cell(numel(paras), 1);
    widths{i} = cell(numel(paras), 1);
    heights{i} = cell(numel(paras), 1);
    
    % create text boxes for them all
    for j = 1:numel(java_h)
        
        % use JTextPane's so we can have html formatting
        [java_h{i}{j}, hg_h{i,2}] = javacomponent('javax.swing.JTextPane', [], fh);
        java_h{i}{j}.setContentType('text/html');
        java_h{i}{j}.setText(paras{j});
        java_h{i}{j}.setEditable(false);
        java_h{i}{j}.setOpaque(false);
        java_h{i}{j}.setBorder('');
        if (j == 1)
            java_h{i}{j}.getDocument().getStyleSheet.addRule(headerRule);
        else
            java_h{i}{j}.getDocument().getStyleSheet.addRule(bodyRule);
        end
        java_h{i}{j}.setFont(def_font);
        
        % if this isn't part of the table, we know the width to use
        if (j < table_rows(1)) || (j > table_rows(2))
            widths{i}{j}  = text_width;
            heights{i}{j} = preferredHeightForFixedWidth(java_h{i}{j}, text_width);
        else
            heights{i}{j} = java_h{i}{j}.getPreferredSize.height;    % and the height
            widths{i}{j} = java_h{i}{j}.getPreferredSize.width;     % record preferredSize
        end
    end
    
    % if this is the section with the feature table, sort its size now
    if (table_rows(1) > -1)
        
        % re-arrange
        table_heights = cell2mat(reshape(heights{i}(table_rows(1):table_rows(2)), size(list_cell,1), size(list_cell,2)));
        table_widths = cell2mat(reshape(heights{i}(table_rows(1):table_rows(2)), size(list_cell,1), size(list_cell,2)));
        table_widths(:, end) = min(descrip_width, max_widths(:, end));  % no need to have it wider that the widest entry
        
        % remove size outliers 
        table_widths = RemoveWidthOutliers
        
        % get the maximum widths of everything
        max_widths = max(table_widths, [], 1);
        max_widths(end) = 
        
        % does it fit "naturally?"
        while (sum(max_widths) > text_width)
            
            
            
            vals = sort(table_widths(1:end-1), 'descend');
            idx = find(vals(1:end-1) ~= vals(2:end))
            
            
        
        end
        
        % replace the final width
        table_widths(end) = descrip_width;
    
    end
    
end


function height = preferredHeightForFixedWidth(jObj, fixed_width)
% function height = preferredHeightForFixedWidth(jObj, fixed_width)
% function to calculate the preferred height of a java ui object
% given its width is fixed

% no idea yet
height = jObj.getPreferredSize.height;




