function [hCell,  hGap, vGap, sizes] = DefaultPostPaneLayout(handles, smallGap, normGap, largeGap)
% function  [hCell,  hGap, vGap, sizes] = DefaultPostPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the default dimension pane layout


if (nargin < 2)

    % build default gaps
   [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
end

% build it
hCell = cell(7,3);
hCell(1,:) = {handles.txtAvailPostProcess, [],                      handles.txtSelPostProcess};
hCell(2,:) = {handles.lbAvailPostProcess,  [],                      handles.lbSelPostProcess};
hCell(3,:) = {handles.lbAvailPostProcess,  handles.pbSelPostFeat,   handles.lbSelPostProcess};
hCell(4,:) = {handles.lbAvailPostProcess,  handles.pbUnSelPostFeat, handles.lbSelPostProcess};
hCell(5,:) = {handles.lbAvailPostProcess,  [],                      handles.lbSelPostProcess};
hCell(6,:) = {[],                          [],                      handles.txtNumPostProcess};
hCell(7,:) = {handles.pbExtraFeatures,     [],                      handles.pbRelabelFeatures};

% gaps between components horizontally
hGap = repmat(normGap, size(hCell,1), size(hCell,2) - 1);

% gaps between components vertically
vGap = repmat(smallGap, size(hCell,1)-1, size(hCell,2));
vGap(end,:) = normGap;

% get component sizes
sizes = PaneSizesFromGrid(hCell);





