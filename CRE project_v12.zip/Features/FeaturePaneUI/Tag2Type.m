function type = Tag2Type(tag)
% function type = Tag2Type(tag)
% this function tries to extract the feature type 
% from a uicontrol's tag

type = regexpi(tag, '(?<=^[rl]b)(\D|(\d*\D))+(?=\d*$)', 'match', 'once');


% map tags to feature names for one where the handle isnt the name
map = {'DomFreq',    'dominantfrequency';            ...
       'DomFreqMag', 'dominantfrequencymagnitude';   ...
       'DomFreqRat', 'dominantfrequencypowerratio'}; 

index = find(strcmpi(type, map(:,1)));
if numel(index)
    type = map{index,2};
end