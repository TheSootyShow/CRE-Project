function PostPaneCallbacks(hObject, eventdata, handles)
% function PostPaneCallbacks(hObject, eventdata, handles)
% this function has the callbacks for the ui components of the time pane

try
    
    % disable the figure while this executes
    % hFig = ancestor(hObject,'figure');  % make sure hFig is a figure
    % EnableDisableFig(hFig, 'off');


    % ensure handles are available
    if (nargin < 3)
        handles = guidata(hObject);
    end
    
    % this style is only OK for CREfeatureGui
    featSettings = handles.featSettings;  % make sure to reassign it at the end
    
    % and its style
    tag = get(hObject, 'tag');
    type = get(hObject, 'type');
    if strcmpi(type, 'uicontrol')
        type = get(hObject, 'style');  % if we're in a callback its a uicontrol
    end
    
    if strcmpi(type, 'uiMenu')
        
        % add the specified feature
        type_str = regexp(tag, '(?<=miFeatAdd)\w+', 'match', 'once');
        featSettings = AddDerivedFeature(featSettings, type_str, handles);
        
        
    elseif strcmpi(tag, 'pbSelPostFeat')
        
        % make primary dimensions visible
        featSettings = SetFeatVisible(featSettings, handles.lbAvailPostProcess, handles.lbSelPostProcess, true);
        
    elseif strcmpi(tag, 'pbUnSelPostFeat')
        
        % make primary dimensions invisible
        featSettings = SetFeatVisible(featSettings, handles.lbSelPostProcess, handles.lbAvailPostProcess, false);
        
        
    elseif strcmpi(tag, 'pbExtrafeatures')
        
        % add extra dimensions, prompt the user for what type
        featSettings = AddDerivedFeature(featSettings, [], handles);
        
    elseif strcmpi(tag, 'pbRelabelFeatures')
        
        % add aliases for existing dimensions
        featSettings = RelabelFeats(featSettings, handles);
        
    else
        
        % Probably list box selection
        return;
        
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % specific to CREfeatureGui
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % reassign to handles
    handles.featSettings = featSettings;
    
    % update the full feature list
    if (numel(handles.featSettings.features) > 0) || (numel(handles.featSettings.postFeatures) > 0)
        
        % process all of the features
        [handles.featSettings, aliasList, display, idx, featList] = ProcessFeatures(handles.featSettings, handles.data_set, true);
        
        % update the control
        handles.featSettings = UpdateFeatListControl(handles.lbAllFeats, handles.featSettings, aliasList, display, idx, featList);
    end
    
    % set gui output availability
    EnableDisableOutput(handles);
    
    % and save in the gui
    guidata(hObject, handles);
    
catch ME
    
    % re-enable for the next callback
    % EnableDisableFig(hFig, 'on');
    
    % what's the current figure?
    hFig = ancestor(hObject, 'figure');
    if numel(hFig) && strcmpi(get(hFig, 'tag'), 'CREFeatureGui')
        
        % It has a dedicated error handler
        ProcessFeatureGuiError(ME);
    
    else
        
        if (~IsDeveloper)
            errordlg('Unable to process requested post feature option', 'Error', 'modal');
        else
            rethrow(ME);
        end
    end
    
end
    

function featSettings = SetFeatVisible(featSettings, hBefore, hAfter, display)
% function featSettings = SetFeatVisible(featSettings, hBefore, hAfter, display) 
% function to transfer diemnions from the display box to the other box

% the move from list box
bStrings = get(hBefore, 'string');
bData = get(hBefore, 'userdata');

% the move to list box
aStrings = get(hAfter, 'string');
aData = get(hAfter, 'userdata');

% what to transfer?
tValues = get(hBefore, 'value');
if (numel(tValues) == 0)
    return;  % nothing to do
end

tStrings = bStrings(tValues);
tData = bData(tValues, :);

% the new before list box
bStrings(tValues) = [];
bData(tValues,:) = [];

% the new after box (gets sorted by the set function)
aStrings = [aStrings(:); tStrings];
aValues = size(aData,1)+1:size(tData,1);
aData = [aData; tData];

% set both list boxes
SetListBox(hBefore, bStrings, bData, []);
SetListBox(hAfter, aStrings, aData, aValues);

% now change visiblity for each entry in tNames
allNames = {featSettings.postFeatures.name};
[found, idx] = ismember(tData(:,1), allNames);  % N.B. idx should match tData(:,2)
if ~all(found)
    error('Unable to find post processing features: %s', tNames(find(~found, 1, 'first')));
end
for i = 1:numel(idx)
    featSettings.postFeatures(idx(i)).display = display;
end



function SetListBox(hList, string, data, values)
% function SetListBox(hList, string, data, values)
% function to set values for a list box

[tmp, order] = sort(string);

set(hList, 'string', string(order));
set(hList, 'userdata', data(order, :));
set(hList, 'Min', 0);
set(hList, 'Max', max(numel(string),2));  % ensure its not in single selection mode
set(hList, 'ListboxTop', 1); 

% have to match the values to the sorted order
[tmp, idx] = ismember(values, order);
set(hList, 'value', idx); 


function featSettings = RelabelFeats(featSettings, handles)
% function featSettings = RelabelFeats(featSettings, handles)
% function to rename features

% get the names of the features
[feat_tags, featSettings.features] = CompleteFeatureList(featSettings);

% and call the gui
[resp, new_aliases] = CreateAliasesGUI(feat_tags, featSettings.aliases, 'features');

% how did the user respond?
if strcmpi(resp, 'OK')
    
    % update the aliases
    featSettings.aliases = new_aliases;
    
    % and update the names in the display list boxes
    InitialisePostPane(featSettings, handles);
    
end


function featSettings = AddDerivedFeature(featSettings, type_str, handles)
% function handles = AddDerivedFeature(featSettings, type_str, handles)
% function to respond to a call to add a derived dimension

% get a long version of the dimension names
uiMenus = get(handles.uiAddFeat, 'children');
labels = get(uiMenus, 'Label');

% drop the add from the front of them
labels = strrep(labels, 'Add ', '');
labels = flipud(labels);  % match displayed order

% call a third party gui to get the user to choose
[featSettings, new_names] = DerivedFeatureUI(featSettings, type_str, labels);
    
% now update the list boxes if the user said yes
if (numel(new_names))
    
    % and update the names in the display list boxes
    InitialisePostPane(featSettings, handles);
    
end




