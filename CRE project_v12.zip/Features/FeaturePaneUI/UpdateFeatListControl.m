function featSettings = UpdateFeatListControl(hList, featSettings, aliasList, display, idx, featList)
% function featSettings = UpdateFeatListControl(hList, featSettings, aliasList, display, idx, featList)
% function to update the feature display list for CREFeatureGui

% first find any that weren't selected last time
last = get(hList, 'userdata');

% first usage?
if iscell(last) && (numel(last) == 2)
    
    % remove which ones from display?
    lastFeats = last{1};
    values = get(hList, 'value');
    selected = false(size(lastFeats));
    selected(values) = true;
    
    % ones not to display
    noDisp = lastFeats(~selected);
    
    % find them in the current list
    for i = 1:numel(noDisp)
        
        % match with anything?
        index = find(strcmpi(featList, noDisp{i}));
        
        % turn it off here
        display(index) = false;
        
        % turn it off
        for j = 1:numel(index)
            if (idx(index(j), 1) == 1)
                featSettings.features(idx(index(j), 2)).output_disp(idx(index(j), 3)) = false;
            else
                featSettings.postFeatures(idx(index(j), 2)).display = false;
            end
        end
    end
end

% keep the diplayed features sorted
[aliasList, order] = sort(aliasList);
    
% now update with new data
set(hList, 'min', 0);
set(hList, 'max', numel(featList)+2);
set(hList, 'string', aliasList);
set(hList, 'value', find(display));
set(hList, 'userdata', {featList(order), idx(order, :)});

% if the current object in the gui isn't a text box, set focus on this list
hCurrent = gcbo();
hFig = ancestor(hList, 'figure');
cFig = get(0, 'CurrentFigure');
type = get(hCurrent, 'type');
if (~(strcmpi(type, 'uicontrol') && strcmpi(get(hCurrent, 'style'), 'edit'))) && (numel(cFig)> 0) && (hFig == cFig)
    uicontrol(hList);
end




