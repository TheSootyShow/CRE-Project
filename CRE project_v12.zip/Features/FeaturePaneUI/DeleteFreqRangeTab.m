function handles = DeleteFreqRangeTab(handles, delete_indexs)
% function handles = DeleteFreqRangeTab(handles, delete_indexs)
% function to delete frequency range tabs

% get them all
allTabs = get(handles.tgFreqTabs, 'children');
types = get(allTabs, 'type');
allTabs = allTabs(strcmpi(types, 'uitab'));

% get all of their ID's
tags = get(allTabs, 'tag');
IDs = regexp(tags, '(?<=tabFrange)\d+', 'match', 'once');
isrange = cellfun(@(x)(numel(x)>0), IDs);  % not the new tab
newTab = allTabs(~isrange);
allTabs = allTabs(isrange);
IDs = IDs(isrange);
numIDs = cellfun(@str2double, IDs);
[numIDs, order] = sort(numIDs);
allTabs = allTabs(order);

% the ones we'll need to copy
copy_objs = RecurseChildren(handles.tabFrange1);
copy_tags = get(copy_objs, 'tag');
copy_tags = regexpi(copy_tags, '[a-zA-Z_]+(?=\d+)', 'match', 'once');

% now shift everything forward
alloc = 0;
for i = 1:numel(numIDs)
    
    if ~any(numIDs(i) == delete_indexs)
        alloc = alloc + 1;
        if (alloc ~= numIDs(i))
            
            % set the new title
            set(handles.(sprintf('tabFrange%i', alloc)), 'title', get(handles.(sprintf('tabFrange%i', i)), 'title'));
            
            % and copy all the child data
            for j = 1:numel(copy_tags)
                
                % which property to copy?
                copy_props = {};
                if strcmpi(get(copy_objs, 'style'), 'radiobutton')
                    copy_props = {'value'};
                elseif strcmpi(get(copy_objs, 'style'), 'edit')
                    copy_props = {'string'};
                elseif strcmpi(get(copy_objs, 'style'), 'listbox')
                    copy_props = {'string', 'value', 'min', 'max'};
                end
                
                % and copy them
                tag_alloc = sprintf('%s%i', copy_tags{j}, alloc);
                tag_i = sprintf('%s%i', copy_tags{j}, i);
                for k = 1:numel(copy_props)
                    set(handles.(tag_alloc), copy_props{k}, get(handles.(tag_i), copy_props{k}));
                end
            end
        end
    end
end

% now delete the ones at the end
newNumber = numel(numIDs) - numel(delete_indexs);
for i = newNumber+1 : numel(numIDs)
        
    % delete the tab
    tag = sprintf('tabFrange%i', i);
    delete(handles.(tag));
    handles = rmfield(handles, tag);
    
    % remove from the handles as well
    for j = 1:numel(copy_tags)
        if numel(copy_tags{j})
            handles = rmfield(handles, sprintf('%s%i', copy_tags{j}, i));
        end
    end
end

% make sure we remove these to fbounds
retain_indexs = numIDs(~ismember(numIDs, delete_indexs));
handles.featSettings.freqRange.fbounds = handles.featSettings.freqRange.fbounds(retain_indexs, :);

% make sure the current tab is not the "new tab"
if (get(handles.tgFreqTabs, 'selectedindex') > newNumber)
    set(handles.tgFreqTabs, 'selectedindex', newNumber);
end



% if there's more than 1 range tab, ensure the user can delete them
% actTabs = allTabs(1:newNumber);
% jTabGroup = getappdata(handle(handles.tgFreqTabs),'JTabbedPane');
% if (numel(actTabs) > 1)
%     set(actTabs, 'uicontextmenu', handles.uiFreqTabs);
%     for i = 0:numel(actTabs)-1
%         jTabGroup.setToolTipTextAt(i, 'Right click to remove');
%     end
%     jTabGroup.setToolTipTextAt(numel(actTabs), '');  % now tooltip for the "new" tab
% else
%     set(actTabs, 'uicontextmenu', []);
%     jTabGroup.setToolTipTextAt(0, '');
%     jTabGroup.setToolTipTextAt(1, '');
% end
