function featStruct = AddButtonFeature(hObject, featStruct, params)
% function featStruct = AddButtonFeature(hObject, featStruct, params)
% function to add a feature to the structure

% get its tag
tag = get(hObject, 'tag');

% convert the tag to a type
type = Tag2Type(tag);

% any extra parameters?
new_params = get(hObject, 'userdata');
if ~iscell(new_params)
    new_params = {};
end
params = [new_params, params];

% and create it
featStruct(end+1,1) = CREFeatures(type, params{:});
