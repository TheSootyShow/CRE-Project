function [hCell,  hGap, vGap, sizes] = DefaultFeatPaneLayout(handles, smallGap, normGap, largeGap)
% function  [hCell,  hGap, vGap, sizes] = DefaultFeatPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the default dimension pane layout


if (nargin < 2)

    % build default gaps
   [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
end


% the time domain pane
[time_h, time_h_gap, time_v_gap, time_sizes] = DefaultTimeDomainPaneLayout(handles, smallGap, normGap, largeGap);

% the frequency domain pane
[freq_h, freq_h_gap, freq_v_gap, freq_sizes] = DefaultFreqDomainPaneLayout(handles, smallGap, normGap, largeGap);

% the ranking pane
[rank_h, rank_h_gap, rank_v_gap, rank_sizes] = DefaultRankPaneLayout(handles, smallGap, normGap, largeGap);


% assemble it all
hCell = {'b',       freq_h; ...
         time_h,    rank_h};
     
hGap = {[],         freq_h_gap; ...
        time_h_gap, rank_h_gap};     
    
vGap = {[],         freq_v_gap; ...
        time_v_gap, rank_v_gap};    
    
sizes = {[],         freq_sizes; ...
        time_sizes,  rank_sizes};






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for time domain pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, hGap, vGap, sizes] = DefaultTimeDomainPaneLayout(handles, smallGap, normGap, largeGap)
% function [hGrid, h_gap, v_gap, sizes] = DefaultTimeDomainPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the layout for the time domain pane

% turn constants into units in pixels
ppi = get(0, 'ScreenPixelsPerInch');                     % pixels per inch
ppcm = ppi / 2.54;                                       % pixels per centimeter
indent = .5 * ppcm;

% set up the matrix of handles
hGrid = cell(10,2);
hGrid(1,:) = {handles.rbMin, handles.rbMean};
hGrid(2,:) = {handles.rbMax, handles.rbStd};
hGrid(3,:) = {handles.rbSum, handles.rbCV};
hGrid(4,:) = {handles.rbPower, handles.rbSkew};
hGrid(5,:) = {handles.rbLogEnergy, handles.rbKurtosis};
hGrid{6,1} = handles.rbp2p;
hGrid{7,1} = handles.rbPeakOccurances;
hGrid{8,1} = handles.rbXCorr;

% to accomodate auto correlation, replicate the first column (ie make it
% three columns wide)
hGrid =[hGrid(:,1), hGrid(:,1), hGrid(:,2)];
hGrid(9,1:2) = {sprintf('h=%g', indent), handles.txtAutoCorr};
hGrid(10,:) = {sprintf('h=%g', indent), handles.lbACorr, handles.pmACorrUnits};

% gaps between components horizontally
hGap = repmat(normGap, size(hGrid,1), size(hGrid,2)-1);

% gaps between components vertically
vGap = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));
vGap(end,:) = smallGap;

% get component sizes
sizes = PaneSizesFromGrid(hGrid);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for rank pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, hGap, vGap, sizes] = DefaultRankPaneLayout(handles, smallGap, normGap, largeGap)
% function [hGrid, hGap, vGap, sizes] = DefaultRankPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the layout for the time domain pane

hGrid = cell(4,2);
hGrid(1:3,1) = {handles.lbPercentile}; 
hGrid{4,1} = handles.txtPercentiles;
hGrid{1,2} = handles.rbXMedian;
hGrid{2,2} = handles.rbXzero;
hGrid{3,2} = handles.rbIQR;

% gaps between components horizontally
hGap = repmat(normGap, size(hGrid,1), size(hGrid,2) - 1);

% gaps between components vertically
vGap = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));
vGap(end,1) = smallGap;  % small gap from the list to it txt description

% get component sizes
sizes = PaneSizesFromGrid(hGrid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for frequency domain pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, hGap, vGap, sizes] = DefaultFreqDomainPaneLayout(handles, smallGap, normGap, largeGap)
% function [hGrid, h_gap, v_gap, sizes] = DefaultFreqDomainPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the layout for the frequency domain pane

% notes:
% 'tgFreqTabs'   is the tabgroup
% 'tabFrange%i'  are the tab panes
% 'uiTabPane%i' is a frame for the tab pane

% start by doing the pane of the first uitab
hTabGrid = cell(4,6);
hTabGrid(1,:) = {handles.rbEntropy1};
hTabGrid(2,1:2) = {handles.txtDomFreq1};
hTabGrid(2,4:5) = {handles.txtDomFreqMag1};
hTabGrid(2,6) = {handles.txtDomFreqRat1};
hTabGrid(3,1:2) = {handles.lbDomFreq1};
hTabGrid(3,4:5) = {handles.lbDomFreqMag1};
hTabGrid(3,6) = {handles.lbDomFreqRat1};
hTabGrid(4, 1:5) = {handles.txtFreqStart1, handles.ebMinFreq1, handles.txtFreqMid1, handles.ebMaxFreq1, handles.txtFreqEnd1};

% tab hgap
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
ppcm = ppi / 2.54;                                          % pixels per centimeter

tab_hGap = repmat(normGap, size(hTabGrid,1), size(hTabGrid,2) - 1);
tab_hGap(:, end) = ceil(1 * ppcm);

% gaps between components vertically
tab_vGap = repmat(normGap, size(hTabGrid,1)-1, size(hTabGrid,2));
tab_vGap(1,:) = largeGap;
tab_vGap(2,:) = smallGap;

% size this
[hTabPanel, panelSize] = ResizePaneFromGrid(hTabGrid, tab_hGap, tab_vGap, false, [false, false], false);
hTab = get(hTabPanel, 'parent');

% set the tab group size
groupSize = setTabGroupSize(hTab, panelSize);

% now put it in with the parts of the frequency pane that dont vary
hGrid = cell(4,3);
hGrid(1,:) = {handles.tgFreqTabs};
hGrid(2, :) = {handles.txtFFTres1, handles.ebFFTres, handles.txtFFTres2};
hGrid(3, :) = {handles.txtMinFFTresLabel, handles.txtMinFFTres, handles.txtMinFsUnits};
hGrid(4, :) = {handles.txtFsLabel, handles.txtFs, handles.txtFsUnit};
set(cell2mat(hGrid), 'parent', handles.uiFreqDomain);

% build spacings
hGap = repmat(normGap, size(hGrid,1), size(hGrid,2) - 1);
vGap = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));

% get component sizes
sizes = PaneSizesFromGrid(hGrid);

