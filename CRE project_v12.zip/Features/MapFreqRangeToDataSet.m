function [freqRange, success, warning_list] = MapFreqRangeToDataSet(input_range, data_set, input_features)
% function [freqRange, success, warning_list] = MapFreqRangeToDataSet(input_range, data_set, input_features)
% function to map frequency info from a features set onto the frequency range of another data set

% default outputs
freqRange = InitFreqRangeStruct(data_set);
success = true;
warning_list = '';

% staright copy resolution
freqRange.fres = input_range.fres;

% only worry about it if we're using frequency based approaches
if (nargin > 2) && isstruct(input_features)
    prereqs = {input_features(:).prereq_name};
    feat_names = {input_features(:).name};
    if any(strcmpi(prereqs, 'fft')) || any(strcmpi(feat_names, 'fft'))
        
        % get default bounds from the structure constructor
        def_bounds = freqRange.fbounds;
        
        % replicate defaults
        freqRange.fbounds = repmat(def_bounds, size(input_range.fbounds, 1), 1);
        
        % check what's in bounds
        obound = (input_range.fbounds > data_set.fs/2);
        
        % go through each bound set individually
        for i = 1:size(input_range.fbounds, 1)
            
            if all(obound(i, 1:2))
                % cant do much in this case
                warning_list = sprintf('%sError: Analysis frequency range %02.f : %0.2f Hz is above the nyquist frequnecy (%0.2f Hz) for data set: %s)\n', ...
                    warning_list, input_range.fbounds(i,1), input_range.fbounds(i,2), data_set.fs/2, data_set.name);
                success = false;
            elseif obound(i,2)
                % adjust the upper bounds in this case
                warning_list = sprintf('%s\nWarning: Analysis frequency range has been truncated from %02.f : %0.2f Hz to %02.f : %0.2f Hz', warning_list, ...
                    input_range.fbounds(i,1), input_range.fbounds(i,2), input_range.fbounds(i,1), def_bounds(2));
                freqRange.fbounds(i,1) = input_range.fbounds(i,1);  % only update the lower bound
            else
                % if the upper limit is in range the lower limit must be as well
                freqRange.fbounds(i,:) = input_range.fbounds(i,:);
            end
        end
        
        % trim back to only the unique values
        freqRange.fbounds = unique(freqRange.fbounds, 'rows');
        
    end
end
