function open = IsRopen()
% function open = IsRopen()
% function to test if the R link is open

global R_lInK_hANdle
open = (numel(R_lInK_hANdle) > 0);
