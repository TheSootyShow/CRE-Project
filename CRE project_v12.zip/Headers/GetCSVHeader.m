function [data_set, line_chars] = GetCSVHeader(data_set, csv_file, options)
% function [data_set, line_chars] = GetCSVHeader(data_set, csv_file, options)
% this function updates the inputs data_set with information in the header
% of file csv_file
% line_chars is the expected number of character per row of data

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parse inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% are the number of lines to read supplied?
if (nargin < 3) || (numel(options) == 0)
    options.max_header_lines = 500;  % headers should be larger than this (over allocate to judge dimensions)
end

% was a data set supplied?
if (nargin == 0) || (numel(data_set) == 0)
    data_set = InitDataStruct();
end

% use the file from the data set if none was supplied
if (nargin < 2) || (numel(csv_file) == 0)
    csv_file = data_set.file_name;  
end

% If no file was specified, prompt the user
if (numel(csv_file) == 0)
    
	last_dir = DataLoadDir();
    [csv_file, dir_name] = uigetfile('*.csv', 'Select a CSV file to import', last_dir);
    
    % successful
    if ischar(csv_file)
		DataLoadDir(dir_name);
        csv_file = fullfile(dir_name, csv_file);
    else
        error('No file selected');
    end
elseif (numel(fileparts(csv_file)) == 0)  % add directory if its not there
    csv_file = fullfile(pwd, csv_file);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% is it a new file for the data set?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (numel(data_set.file_name))

    % check the data set isnt associated with anything 
    if ~strcmpi(data_set.file_name, csv_file) 
    
        % make sure to close the last file from the dataset
        if (data_set.file_ptr > 0)
            fclose(data_set.file_ptr);
            data_set.file_ptr = -1;
        end
        data_set.data = [];
        data_set.lookup = [];
        data_set.lookgap = [];
        data_set.num_points = [];
        data_set.dim_names = {};
    end
end
data_set.file_name = csv_file;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Open the file and read the first 
% options.max_header_lines lines
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file_opened = false;
if (numel(data_set.file_ptr) == 0) || (data_set.file_ptr <= 0)
    data_set.file_ptr = fopen(csv_file, 'r');
    if (data_set.file_ptr <= 0)
        error('Could not open file: %s', csv_file);
    end
    file_opened = true;
else
    % go back to the beginning of the file
    fseek(data_set.file_ptr, 0, 'bof');
end
data_set.type     = 'ASCII';  % CSV's are ascii

try

    % allocate space for the first max_header_lines lines
    header_str = cell(options.max_header_lines, 1);
    
    % and read them
    num_lines = 0;
    while ~feof(data_set.file_ptr) && (num_lines < options.max_header_lines)
        num_lines = num_lines + 1;
        header_str{num_lines} = fgetl(data_set.file_ptr);  % use fgetl to skip consecutinve new lines
    end
    
    % prune off empties at the beginning
    empty_lines = 0;
    while (empty_lines < num_lines) && (numel(header_str{empty_lines+1}) == 0)
        empty_lines = empty_lines + 1;
    end
    
    % and prune it back
    header_str = header_str(empty_lines+1:num_lines);
    if (numel(header_str) == 0)
        error('No data in csv file: %s', csv_file);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Can we read the header directly
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (numel(strfind(lower(header_str{1}), 'actigraph')) || numel(strfind(lower(header_str{1}), 'actilife')))
        
        % invoke the header from ACTI CSV function
        data_set = GetACTIHeader(data_set, header_str);
        
    elseif (numel(strfind(lower(header_str{1}), 'geneactiv')))
        
        % invoke the header from GENE function
        data_set = GetGeneACTIHeader(data_set, header_str);
        
    elseif (numel(strfind(lower(header_str{1}), lower('CRE Custom'))))
        
        % invoke the header from CSV export from this program
        data_set = GetCREHeader(data_set, header_str);
        
    else
    
        % Indicate no known header
        data_set.hlines = 0;
    
    end
    
    % check it has data
    if (numel(header_str) < options.max_header_lines) && (data_set.hlines == numel(header_str))
        error('A header but no data was found in csv file: %s', csv_file);
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Compare the extracted header to the file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % use this function to get dimensionality and header info
    header_hlines = data_set.hlines;
    data_set = HeaderInfFromLines(data_set, header_str);
    
    % check the found header lines matches what's expected
    if (header_hlines < data_set.hlines)
        
        % this case may be due to column labels.  Check if that's what's going on
        [data_set, header_hlines] = CheckForColumnLabels(data_set, header_str, header_hlines);
        
    end
    
    if (numel(header_hlines) > 0) && (header_hlines ~= data_set.hlines)
        error('Disagreement between the number of header lines detected and what was reported in file: %s', csv_file);
    end

    % add stripped lines to the header line count
    data_set.hlines = data_set.hlines + empty_lines;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Count the header bytes
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fseek(data_set.file_ptr, 0, 'bof');
    for i = 1:data_set.hlines
        tmp = fgetl(data_set.file_ptr);  % grab the line
    end
    if (numel(data_set.hbytes) == 0)
        data_set.hbytes = ftell(data_set.file_ptr);   
    elseif ((data_set.hbytes) ~= ftell(data_set.file_ptr))
        error('Disagreement between the number of header bytes detected and what was reported in file: %s', csv_file);
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build a string for reading a line of data
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    data_set.ASCII_read = BuildReadString(header_str{data_set.hlines+1}, data_set.delim);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % now forget that this file has a time dimension
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (data_set.time_col)
        
        % if column labels appear to include the time, remove it
        if (numel(data_set.dim_names) == data_set.dims)
            data_set.dim_names = data_set.dim_names(2:end);
        end
        
        % remove a dimension
        data_set.dims = data_set.dims - 1;
        
        % update the read string
        first_var = find(data_set.ASCII_read == '%', 1, 'first');
        if (data_set.ASCII_read(first_var + 1) ~= '*')  % its already skipped
            data_set.ASCII_read = [data_set.ASCII_read(1:first_var), '*', data_set.ASCII_read(first_var+1:end)];
        end
        
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % look at the column labels
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (numel(data_set.dim_names) && (numel(data_set.dim_names) ~= data_set.dims))
        error('Disagreement between the number of dimension labels and dimensions in: %s', csv_file);
    elseif (numel(data_set.dim_names) == 0)
        data_set = InsertDefaultDimNames(data_set);
    else
        data_set.dim_names = cellfun(@strtrim, data_set.dim_names, 'uniformoutput', false);
    end
    
    % if they have the form Axis1 Axis2 Axis3, rename them to X, Y, Z
    def_labels = 'XYZ';
    for i = 1:numel(data_set.dim_names)
        axis_str = regexpi(data_set.dim_names{i}, 'Axis\W*\d+', 'match', 'once');
        if numel(axis_str)
            axis_num = str2double(axis_str(isstrprop(axis_str, 'digit')));
            if isfinite(axis_num) && (axis_num >= 1) && (axis_num <= 3)        
                data_set.dim_names{i} = regexprep(data_set.dim_names{i}, axis_str, def_labels(axis_num), 'ignorecase');
            end
        end
    end
        
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Check we have a time stamp
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (numel(data_set.tstamp) == 0)
        
        % prompt the user
        time_format = 'yyyy-mm-dd HH:MM:SS';
        resp = inputdlg(sprintf('Please enter the data collection date (%s)', time_format), 'Missing Data Set Timestamp', 1, {datestr(now, time_format)});
        if numel(resp)
            try
                data_set.tstamp = AmbigTimeStr(resp{1}, true);
            end
        end
        if (numel(data_set.tstamp) == 0)
            error('No timestamp for data set: %s', csv_file);
        end
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Is this actually a features set?
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (numel(data_set.set_type) == 0)
        data_set.set_type = 'data'; % no
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Name the data set
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (numel(data_set.name) == 0)
        [tmp, data_set.name, ext] = fileparts(data_set.file_name);
    end
    
    
    % close the file pointer if this function opened it
    if (file_opened)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    
    % set the view style to header only
    data_set.view_type = 0;
    
    
catch ME % catch

    data_set.file_ptr = -1;
    if (file_opened)
        fclose(data_set.file_ptr);
    end
    
    if isdeployed()
        error('An error occurred reading %s -> %s', csv_file, ME.message);
    else
        rethrow(ME);
    end
end


function [data_set, header_hlines] = CheckForColumnLabels(data_set, header_str, header_hlines)
% function [data_set, header_hlines] = CheckForColumnLabels(data_set, header_str, header_hlines)
% function to check for column titles between the header end and the sata
% start

if numel(data_set.delim)
    delim = data_set.delim;
else
    delim = ',';
end



i = data_set.hlines;
found = false;
while (~found && (i > header_hlines))

    % try to parse the line.  First, ignore delimiters wrapped in ""
    [tokens, wrap_start, wrap_end] = regexp(header_str{i}, '".*?"', 'match');
    
    % now try to split the string
    [col_titles, sec_start, sec_end] = regexp(header_str{i}, ['(?<=[^\\])[', delim, ']'], 'split');  % unix uses \, to not treat the comma as a delimiter
    sec_end(end+1) = numel(header_str{i}) + 1;
    
    % if the were wrapped section rejoin the split within it
    if numel(tokens)

        % merge them back together
        ct = 0;   % current token to fill
        append_next = [];
        for j = 1:numel(col_titles)
            
            if numel(append_next)
                % add to the last one
                col_titles{ct} = sprintf('%s%s%s', col_titles{ct}, ',', col_titles{j});
                col_titles{ct} = regexprep(col_titles{ct}, '"', '');  % strip the quotes
            else
                % start a fresh one
                ct = ct + 1;
                col_titles{ct} = col_titles{j};
            end
            
            % add the next one to the current token?
            append_next = find((sec_end(j) > wrap_start) & (sec_end(j) < wrap_end));

        end
        col_titles = col_titles(1:ct);
    end
    
    % record the dimension names
    if (numel(col_titles) == data_set.dims)
        
        % replace all \, with straight  ","'s
        col_titles = regexprep(col_titles, ['\\', delim], ',');
        
        % remove all quotes
        col_titles = regexprep(col_titles, '"', '');
    
        % and remove all spaces that are follow by formatting chars
        col_titles = regexprep(col_titles, '\s(?=\W)', '');
        
        found = true;
        data_set.dim_names = col_titles;
        header_hlines = data_set.hlines;
    end
    
end
    

    

function read_str = BuildReadString(line, delim)
% function read_str = BuildReadString(line, delim)
% this function builds a read string compatible with functions like
% sscanf and fscanf

% first parse using the delimiter because one or more values may be strings
[tokens, format] = regexp(line, delim, 'split', 'match');
values = cellfun(@str2double, tokens);

% and build it
read_str = '';
values_act = zeros(numel(tokens),1);  % use this to check the read string is working
n_els = 0;
for i = 1:numel(tokens)
    if (numel(tokens{i}))
        
        % trim the token back to it "shortest" form
        [prefix, token, suffix] = TrimToken(tokens{i}, delim);
        read_str = sprintf('%s%s%s%s', read_str, prefix, token, suffix);
    end
    if (numel(format) >= i) && numel(format{i})
        read_str = sprintf('%s%s', read_str, format{i});
    end
    
    % the actual line
    values_act(n_els+1) = str2double(tokens{i});
    if ~isnan(values_act(n_els+1)) || numel(regexpi(token, '^\s*((NaN)|(-*Inf))\s*$', 'match', 'once'))
        n_els = n_els + 1;
    end
end
values_act = values_act(1:n_els); % trim it


% test it!
values = sscanf(line, read_str);
if (numel(values) ~= numel(values_act)) || any((values(:) ~= values_act(:)) & (~isnan(values) | ~isnan(values_act)))
    error('Failed to create a read string for line: %s', line);
end



function [prefix, token, suffix] = TrimToken(token, delim)
% function [prefix, token, sufix] = TrimToken(tokens{i})
% function to split formating chars of the token


if isfinite(str2double(token)) 
    
    % split it using the number
    [format, number] = regexp(token, '[-\d.e]+', 'split', 'match');
    if (numel(number) ~= 1)
        error('Unexpected error trying to build tokens');
    else
        prefix = format{1};
        suffix = format{2};
        token = '%g';  % represent the number
    end
    
% is it a non-finite number (NaN or Inf)?    
elseif (numel(regexpi(token, '^\s*((NaN)|(-*Inf))\s*$', 'match', 'once')) > 0)
    
    [format, number] = regexpi(token, '(NaN)|(-*Inf)', 'split', 'match');
    if (numel(number) ~= 1)
        error('Unexpected error trying to build a NaN token');
    else
        prefix = format{1};
        suffix = format{2};
        token = '%g';  % represent the number
    end    
    
else
    
    % its a string - dont read any of it, just fast forward to the delimiter
    prefix = '';
    suffix = '';
    token = ['%*[^', delim, ']'];
    
    
%     valid_inds = regexp(token, '[\w-.\\/]');  % the indices of valid members of the string
%     prefix = token(1:valid_inds(1)-1);
%     suffix = token(valid_inds(end)+1:end);
%     
%     % scanf reads characters unitl it finds white space, so find instances of white space
%     token_short = token(valid_inds(1):valid_inds(end));
%     [str, format] = regexp(token_short, ' ', 'split', 'match');
%     token = ''; %rebuild
%     for i = 1:numel(str)
%         if (numel(str{i}))
%             token = sprintf('%s%%s', token);
%         end
%         if (numel(format) >= i) && numel(format{i})
%             token = sprintf('%s%s', token, format{i});
%         end
%     end
%     
%     % if the delimiter is not a space and there's no space before the
%     % delimiter, need to tell fscanf not to read the delimiter
%     full = [token, suffix];
%     if all(full(end-1:end) == '%s')
%         full(end-1:end+4) = ['%[\w' ,delim, ']']; 
%         token = full;
%         suffix = '';
%     end
    
    
end
        
   
    
    


    



















