function data_set = ExportHeader(data_set, exportInfo, hold_open)
% function data_set = ExportHeader(data_set, exportInfo, hold_open)
% this function exports the header of the data set
% the file_ptr will remain open if its open on input or hold_open == true

np_space = 10;        % add some space to the number of points in case the number of points was mis-reported
lookup_space = 10000; % add some space for extra element in the lookup table


if (nargin < 3)
    hold_open = false;  % keep the file pointer open
end

% current version of this export
version = CRE_version();  

% dont export these fields
ignore_fields = {'file_name', 'file_ptr', 'data', 'dtype', 'ds_headers', 'view_type', 'type', 'ASCII_read', 'ASCII_dec', 'dtype', 'delim', 'lookgap', 'lookup'};

% export these fields in special form (add addition ones as extra rows)
spec_fields = {'num_points', @(n)(sprintf('%i%s',n, repmat(' ', 1, np_space)));  
               'lookup',     @(n)(sprintf('%s%s',mat2str(n), repmat(' ', 1, lookup_space)));
               'tstamp',     @(t)ConvertTime(0, t, 1, true); ...
               'fs',         @(fs)([FsString(fs), ' Hz'])};

% now build the header as a string
header = '';
hlines = 0;

% write the header info if the user desires
if (exportInfo.header)

    % output an identifying line first
    dashes = repmat('-', 1, 15);
    header = sprintf('%s%s CRE Custom %s\n', header, dashes, dashes);
    title_els = numel(header) - 1;
    
    % insert a place hold for the header bytes / lines
    hbyte_placecard = '??????byte?????';
    hline_placecard = '??????lines?????';
    data_set.hbytes = hbyte_placecard;
    data_set.hlines = hline_placecard;
    
    % get all the fields
    field_names = fieldnames(data_set);
    
    % and go through them (wrap all lines in quotes for excel)
    for i = 1:numel(field_names)
        
        % the raw value in this field
        raw_value = data_set.(field_names{i});
        
        if ~any(strcmpi(field_names{i}, ignore_fields)) && (numel(raw_value) > 0) % a non export field or unfilled field?
            
            % is it a special format export field?
            ind = find(strcmpi(field_names{i}, spec_fields(:,1)));
            
            if (numel(ind) == 0)
                
                % a "normal" field
                if ischar(raw_value)
                    value_str = raw_value;
                elseif isnumeric(raw_value) || islogical(raw_value)
                    value_str = mat2str(raw_value);
                elseif iscell(raw_value)
                    value_str = cell2str(raw_value);
                else
                    error('Haven''t been programmed to export fields of type %s', class(raw_value));
                end
            else
                
                % its a special one, use the supplied function handle to generate the string
                value_str = feval(spec_fields{ind, 2}, raw_value);
            end
            
            % and add it
            header = sprintf('%s"%s = %s"\n', header, field_names{i}, value_str);
            hlines = hlines + 1;
            
        end
        
    end
    
    % add a version indicator
    header = sprintf('%sversion = %s\n', header, version);
    hlines = hlines + 1;
    
    % add a marker at the end
    header = sprintf('%s%s\n', header, repmat('-', 1, title_els));
    hlines = hlines + 1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% write lines for the classifier classes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(data_set.class_info)
    class_str = ExportClasses(data_set);
    header = sprintf('%s%s', header, class_str);
    hlines = hlines + sum(class_str == sprintf('\n'));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now write column titles
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(data_set.dim_names)
    
    % sanitize dimensions names?
    if (exportInfo.sanitize_dims)
        for i = 1:numel(data_set.dim_names)
            
            % swap
            data_set.dim_names{i} = regexprep(data_set.dim_names{i}, '\W+', '_');
            
            % but remove trailing underscores
            data_set.dim_names{i} = regexprep(data_set.dim_names{i}, '_+$', '');
        end
    end

    if ispc()
        
        % Print a column header line as well
        % wrap commas in double " these with quotes and hope excel "gets" it
        encap_str = '"';
        if (data_set.time_col)
            [tmp, format] = ConvertTime(0, 0, 2, true);
            header = sprintf('%s%sTime (%s)%s,', header, encap_str, format, encap_str);
        end
        for i = 1:numel(data_set.dim_names)
            header = sprintf('%s%s%s%s,', header, encap_str, data_set.dim_names{i}, encap_str);
        end
        header(end) = sprintf('\n');  % replace the last comma with a new line
        
        
    else
        
        % ensure commas in column titles aren't treated as csv delimiters
        comma_rep = '\,';
        
        if (data_set.time_col)
            header = sprintf('%sTime, ', header);
        end
        for i = 1:numel(data_set.dim_names)
            header = sprintf('%s%s, ', header, strrep(data_set.dim_names{i}, ',', comma_rep));
        end
        header(end-1:end) = [];  % get rid of the last comma space pair
        header = sprintf('%s\n', header);
    end
    hlines = hlines + 1;
end


data_set.hlines = hlines;

% now replace the '?' marks we originally inserted for header lines with the actual value
if (exportInfo.header)
    
    % replace the paced card
    header = strrep(header, hline_placecard, num2str(data_set.hlines));
    
    % now replace the '?' marks we originally inserted for header size with the actual value
    data_set.hbytes = numel(header);  % record this
    qinds = strfind(header, hbyte_placecard);
    value_str = num2str(data_set.hbytes);
    header(qinds:qinds+numel(hbyte_placecard)-1) = [value_str, repmat(' ', 1, numel(hbyte_placecard) - numel(value_str))];
else
    data_set.hbytes = numel(header);  % record this
end

% open the file and write the header
open = data_set.file_ptr > 0;
if (~open)
    data_set.file_ptr = fopen(data_set.file_name, 'w');
    if (data_set.file_ptr <= 0) 
        
        % check the directory exists
        path = fileparts(data_set.file_name);
        if ~exist(path, 'dir')
            mkdir(path);
            data_set.file_ptr = fopen(data_set.file_name, 'w');
            if (data_set.file_ptr <= 0) 
                error('Could not open %s\nIs the file in use?', data_set.file_name);
            end
        else
            error('Could not open %s\nIs the file in use?', data_set.file_name);
        end
    end
else
    frewind(data_set.file_ptr);  % the header goes at the start
end

% and write the header
fprintf(data_set.file_ptr, '%s', header);

% sanity check
if (ftell(data_set.file_ptr) ~= data_set.hbytes)
    error('The header is an unexpected size');
end

% restore previous state of the file identifier
if (~open) && (~hold_open)
    fclose(data_set.file_ptr);
    data_set.file_ptr = -1;
end
    
    
function str = mat2str(data)
% function str = mat2str(data)
% function to convert a matrix to a string

if (ndims(data) > 3)
    error('ExportHeader::Not programmed to output %id matrices', ndims(data));
end

if (numel(data) == 1)
    str = num2str(data);
elseif (numel(data) == 0)
    str = '[]';
else
    str = '[';
    for i = 1:size(data,1)
        for j = 1:size(data,2)
            str = sprintf('%s %s,', str, num2str(data(i,j)));
        end
        str(end) = ';';  % replace final comma with a semi colon
    end
    str(end) = ']'; % replace final semi-colon with a square bracket
end


function str = cell2str(data)
% function str = cell2str(data)
% function to convert a cell array to a string

if (ndims(data) > 3)
    error('ExportHeader::Not programmed to output %id cell arrays', ndims(data));
end

str = '{';
for i = 1:size(data,1)
    for j = 1:size(data,2)
        
        if ischar(data{i,j})
            value_str = data{i,j};
        elseif isnumeric(data{i,j}) || islogical(data{i,j})
            value_str = mat2str(data{i,j});
        elseif iscell(data{i,j})
            value_str = cell2str(data{i,j});
        else
            error('Haven''t been programmed to export fields of type %s', class(data{i,j}));
        end
        str = sprintf('%s %s,', str, value_str);
    end
    str(end) = ';';  % replace final comma with a semi colon
end
str(end) = '}'; % replace final semi-colon with a square bracket

