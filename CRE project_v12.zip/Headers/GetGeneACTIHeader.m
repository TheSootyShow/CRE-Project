function data_set = GetGeneACTIHeader(data_set, hlines)
% function data_set = GetGeneACTIHeader(data_set, hlines)
% function to fill header data from a gene active CSV
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set - the data set structure to fill with meta data (see InitDataStruct.m)
%
% h_lines  - a cell array containing the first n lines of the csv file
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set     - the data set structure with filled meta data
%
% header_lines - the number of lines in the header (data starts at
%                line header_line + 1)


if ~(numel(strfind(lower(hlines{1}), 'geneactiv')))
    error('File does not appear to be a gene active csv');
end

                 
% the first column is what its called in the header, the second the field
% of dataset, the 3rd is a processing function to convert
conversions = {'device type',                   'device_type',              @(str, data_set)(str); ...
               'device unique serial code',     'device_serial',            @(str, data_set)(str); ...
               'start time',                    'tstamp',                   @(str, data_set)(AmbigTimeStr(str, true)); ...
               'measurement frequency',         'fs',                       @(str, data_set)(ParseFsStr(str)); ...  
               };

% now retrieve what we can
cline = 0;
while (cline < numel(hlines)) && (~all(hlines{cline+1} == '-') || (numel(hlines{cline+1}) == 0))
    
    % move one forward
    cline = cline+1;
    
    % try each possibility
    for i = 1:size(conversions, 1)
        
        % do we see this keyword?
        value_str = GetHeaderValue(hlines{cline}, conversions{i,1}, ',', true);
        
        % and assign
        if (numel(value_str))
        
            data_set.(conversions{i,2}) = feval(conversions{i,3}, value_str, data_set);
            break;  % no need to check the other conversions
            
        end
    end
end

% now look for column labels
sensor_rows = find(cellfun(@(str)(0 < numel(strfind(lower(str), 'sensor type'))), hlines));

% extract them
if numel(sensor_rows)
    
    % allocate space
    data_set.dim_names = cell(1, numel(sensor_rows));
    
    % and grab the names
    for i = 1:numel(sensor_rows)
        
        % tokenize the line
        [tokens, other] = regexp(hlines{sensor_rows(i)}, ',', 'split', 'match');
        if (numel(tokens) >= 2) && strcmpi(tokens{1}, 'sensor type')
            
            % if its the long way of writing x, y, or z, replace it with 'X', 'Y', or 'Z'
            label_str = GetHeaderValue(tokens{2}, 'mems accelerometer', '\W', true);
            if (numel(label_str) == 1)
                data_set.dim_names{i} = upper(label_str);  % if its a single letter make it upper case
            elseif (numel(label_str) > 0)
                data_set.dim_names{i} = label_str;
            else
                data_set.dim_names{i} = tokens{2};  % no idea
            end
        end
    end
end

















