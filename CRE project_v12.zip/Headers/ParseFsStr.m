function fs = ParseFsStr(fs_str)
% function fs = ParseFsStr(fs_str)
% this function parses an string that represent the sampling frequency
% returns fs in Hz

prefix =      'pumkMRGT';                               % possible prefixes to 'Hz'
prefix_pow =  [1e-9, 1e-6, 1e-3, 1e3, 1e6, 1e9, 1e12];  % multipliers for each prefix

% if there is no input, assume the uses wants a list of allowable prefixs
if (nargin == 0)
    fs = prefix;
    return;
end

% if no prefix
mult = 1;

% extract Hz if its there
[Hz, ind] = regexp(fs_str, sprintf('[%s]*[hH][zZ]', prefix), 'match', 'once');

if (numel(Hz))
    
    % does it have a prefix?
    if (numel(Hz) > 2)
        pref_ind = find(prefix == Hz(1), 1, 'first');
        if (numel(pref_ind) == 0)
            error('Unknow to prefix to Hz: %s', Hz);
        end
        mult = prefix_pow(pref_ind);
    end
    
    % strip it from the string
    fs_str = regexprep(fs_str, Hz, '');
end

% now convert to a numeric
fs = str2double(fs_str) * mult;
if (isnan(fs))
    error('Failed to parse sampling frequency string: %s', fs_str);
end