function added_paths = AddCREDirs()
% function added_paths = AddCREDirs()
% function to add all required directories in the CRE project

% operate in developer mode? yes if the the calling worksspce is the base
global dev_mode
if (numel(dev_mode) == 0)
    dev_mode = (~isdeployed) && (numel(dbstack) == 1);  % set true is this is being called from the base
    if (dev_mode)
        % assign the variable to the base workspace for clarity
        evalin('base', 'global dev_mode;')
        assignin('base', 'dev_mode', dev_mode);
        fprintf('Working in developer mode\n');
    end
end

% where is this file?
CRE_dir = fileparts(mfilename('fullpath'));

% get folder in the current path
cp = path();
[folders, tmp] = regexp(cp, ';', 'split', 'match');

% directory with header reading functions
header_dir = fullfile(CRE_dir, 'Headers');

% directory with gui functions
guifuncs_dir = fullfile(CRE_dir, 'GuiFuncs');

% directory with external links
externals_dir = fullfile(CRE_dir, 'RInterface');

% directory with the dimensions
dim_dir = fullfile(CRE_dir, 'Dimensions');

% directory with dimensions UI functions
dimUI_dir = fullfile(dim_dir, 'DimensionPaneUI');

% directory with the features
feature_dir = fullfile(CRE_dir, 'Features');

% directory with features UI functions
featUI_dir = fullfile(feature_dir, 'FeaturePaneUI');

% directory with frequency functions
freq_dir = fullfile(CRE_dir, 'FreqFcns');

% directory with frequency functions
freqUI_dir = fullfile(freq_dir, 'FreqPaneUI');

% directory with time functions
time_dir = fullfile(CRE_dir, 'TimeFcns');

% directory with time range UI functions
timeUI_dir = fullfile(time_dir, 'TimePaneUI');

% directory with export functions
export_dir = fullfile(CRE_dir, 'ExportFcns');

% batch set creation 
batch_dir = fullfile(CRE_dir, 'BatchSet');

% directory with export UI functions
exportUI_dir = fullfile(export_dir, 'ExportPaneUI');

% directory with wavelets
wave_dir = fullfile(CRE_dir, 'Wavelets');

% direcotry with classifiers
class_dir = fullfile(CRE_dir, 'Classifiers');

% directory with link to R
Rlink_dir = fullfile(externals_dir, 'Rlink');

% put them all together
check_dirs = {Rlink_dir, exportUI_dir, batch_dir, export_dir, freqUI_dir, freq_dir, timeUI_dir, dimUI_dir, featUI_dir, wave_dir, externals_dir, header_dir, dim_dir, feature_dir, guifuncs_dir, time_dir, CRE_dir};

% include all subdirectories of the classfiers
check_dirs = [check_dirs(:); RecurseDir(class_dir)];

added_paths = cell(size(check_dirs));
n_added = 0;


% and add them as neccessary
for i = 1:numel(check_dirs)
    if exist(check_dirs{i}, 'dir') && ~any(strcmpi(folders, check_dirs{i}))
        n_added = n_added + 1;
        added_paths{n_added} =check_dirs{i};
        addpath(check_dirs{i}, '-begin');
        pause(.01);  % give matlab some time to check it
    end
end
added_paths = added_paths(1:n_added);

