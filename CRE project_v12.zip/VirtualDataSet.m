function data_set = VirtualDataSet(f, fs, duration, dims)
% function data_set = VirtualDataSet(f, fs, duration, dims)
% this function creates a virtual data set cotaining sinusoids at teh
% frequency listed in f

if (nargin < 4) || (numel(dims) == 0)
    dims = 3;
end

if (nargin < 3) || (numel(duration) == 0)
    duration = 5;  % seconds
end

if (nargin < 2) || (numel(fs) == 0)
    fs = 30;       % Hz
end

if (nargin < 1) || (numel(f) == 0)
    f = 3;         % Hz
end

% build the virtual data set
data_set = InitDataStruct();
data_set.file_name = fullfile(pwd, 'virtual.csv');
data_set.file_ptr = -1;
data_set.dims = dims;
data_set = InsertDefaultDimNames(data_set);
data_set.fs = fs;
data_set.num_points = 1 + floor(fs * duration);
data_set.time_col = false;
data_set.tstamp = datevec(now());
data_set.set_type = 'data';

% allocate room for the data
data_set.data = zeros(data_set.num_points, 1);
t = 0:1/fs:duration; t = t(:);

% create sinusoids
for i = 1:numel(f)
    data_set.data = data_set.data + sin(2*pi*f(i)*t);
end

% % view it (crude)
% y = abs(fft(data_set.data));
% y = y(1 : ceil(numel(y)/2));
% fy = linspace(0, fs/2, numel(y));
% figure; plot(fy, y);


if (dims > 1)
    data_set.data = repmat(data_set.data, 1, dims);
end
data_set.data(:,end) = 0;  % for fun


