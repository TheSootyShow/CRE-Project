function UpdateDSHeader(data_set)
% function UpdateDSHeader(data_set)
% function to update the file's header in a data set
% currently num_points and lookup are updated

update_list = {'num_points', 'lookup'};

% open the pointer to the data sets file
ds_open = data_set.file_ptr > 0;
if (ds_open)
    
    % be able to restore this
    fPosInput = ftell(data_set.file_ptr);
    
    % close and reopen in r+b mode
    fclose(data_set.file_ptr);
    data_set.file_ptr = -1;
end
  
    
% open the data pointer
data_set.file_ptr = fopen(data_set.file_name, 'r+b');
if (data_set.file_ptr <= 0)
    error('Could not read %s\nIs the file in use?', data_set.file_name);
end

% read the whole header
fseek(data_set.file_ptr, 0, 'bof');
for i = 1:data_set.hlines
    fPos = ftell(data_set.file_ptr);  % store
    line = fgetl(data_set.file_ptr);
    for j = 1:numel(update_list)
        
        % does it match something to replace?
        if numel(regexp(line, ['^\s*"*\s*', update_list{j}]))

            % generate the value
            raw_value = data_set.(update_list{j});
            if ischar(raw_value)
                value_str = raw_value;
            elseif isnumeric(raw_value) || islogical(raw_value)
                value_str = mat2str(raw_value);
            elseif iscell(raw_value)
                value_str = cell2str(raw_value);
            end
            
            % create the new line
            newline = sprintf('%s = %s', update_list{j}, value_str);
            
            % in case its too long
            if (numel(newline) > numel(line))
                newline = repmat(' ', 1, numel(line));  % leave it blank
            else
                newline = [newline, repmat(' ', 1, numel(line) - numel(newline))];
            end
            
            % now rewind the file pointer
            fseek(data_set.file_ptr, fPos, 'bof');
            
            % and print the line
            fprintf(data_set.file_ptr, '%s', newline);
            break;  % go to the next line
                
        end
    end
end




% restore the data pointer to its location
if (~ds_open)
    fclose(data_set.file_ptr);
    data_set.file_ptr = -1;
else
    
    % reopen in "w" mode
    fclose(data_set.file_ptr);
    data_set.file_ptr = fopen(data_set.file_name, 'a+');
    
    % restore this
    fseek(data_set.file_ptr, fPosInput, 'bof');
end