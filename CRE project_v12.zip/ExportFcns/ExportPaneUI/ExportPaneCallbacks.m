function handles = ExportPaneCallbacks(hObject, eventdata, handles)
% function DimPaneCallbacks(hObject, eventdata, handles)
% this function has the callbacks for the ui components of the time pane

% ensure handles are available
if (nargin < 3)
    handles = guidata(hObject);
end

% this style is only OK for CREfeatureGui
exportInfo = handles.featSettings.exportInfo;  % make sure to reassign it at the end


% get which ui componenent it is from the tag
tag = get(hObject, 'tag');
type = get(hObject, 'type');
if strcmpi(type, 'uicontrol')
    type = get(hObject, 'style');  % if we're in a callback its a uicontrol
end

if strcmpi(tag, 'ebFileName')    
   
    % update the name of the export file
    [exportInfo, handles] = ChangeFileName(exportInfo, eventdata, handles);
    
elseif strcmpi(tag, 'pbGetFile')
    
    % update the name of the export file
    [exportInfo, handles] = SelectExportFile(exportInfo, handles);
    
elseif strcmpi(tag, 'cbTimeCol')
    
    exportInfo.time_col = get(hObject, 'value');
    
elseif strcmpi(tag, 'cbExportHeader')
    
    exportInfo.header = get(hObject, 'value');    
    
elseif strcmpi(tag, 'cbSanitizeDims')    
    
    exportInfo.sanitize_dims = get(hObject, 'value');    
    
end
 
  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% specific to CREfeatureGui
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% reassign to handles )
handles.featSettings.exportInfo = exportInfo;    

% set gui output availability
EnableDisableOutput(handles);

% update
if (nargout < 1)

    guidata(hObject, handles);
    
end






function [exportInfo, handles] = ChangeFileName(exportInfo, eventdata, handles)
% function [exportInfo, handles] = ChangeFileName(exportInfo, eventdata, handles)
% function to execute on change to the export file name

% is this call from user interaction or is it systematic?
usercall = (numel(eventdata) == 0);

% get the currently entered file name
if (usercall)
    file_name = get(handles.ebFileName, 'string');
    if (size(file_name,1) > 1)
        file_name = cellstr(file_name);
    end
    if iscell(file_name)
        tmp = file_name;
        file_name = '';
        for i = 1:numel(tmp)
            file_name = sprintf('%s%s', file_name, strtrim(tmp{i}));
        end
    end
else
    file_name = eventdata;
end
[path, name, ext] = fileparts(file_name);

% if the path is empty grab the current path
if (numel(path) == 0)
   path = fileparts(handles.data_set.file_name); 
end

% reassemble
file_name = fullfile(path, [name, ext]);

% if its in batch mode, the file name must include the token $ds_name$
if strcmpi(handles.data_set.set_type, 'batch') && (numel(strfind(file_name, '$ds_name$')) == 0)
        
    % insert it into the name
    warndlg(sprintf('File name must include the token $ds_name$ for batch sets.\nThis token has been automatically added to the file name.'), 'File Name:', 'modal');
    [path, name, ext] = fileparts(file_name);
    name = sprintf('$ds_name$%s', name);
    file_name = fullfile(path, [name, ext]);
    set(handles.ebFileName, 'string', file_name);
end


% ensure its valid
if numel(name) && numel(ext)
    [file_name, is_valid] = SanitizeFileName(file_name, true, usercall);
else
    is_valid = false;
end

if (is_valid)

    % remove it form the block list if its in there
    exportInfo.file_name = file_name;
    handles.block_list = handles.block_list(handles.block_list ~= handles.ebFileName);
    
    % make sure the text box is updated
    if (~usercall)
        set(handles.ebFileName, 'string', file_name);
    end
    
elseif ~any(handles.block_list == handles.ebFileName)
    
    % add it to the block list if its not in there
    handles.block_list(end+1) = handles.ebFileName;
    
end

if (usercall)  % i.e. this callback was triggered directly by the user
    exportInfo.auto_name = false;
end



function [exportInfo, handles] = SelectExportFile(exportInfo, handles)
% function [exportInfo, handles] = SelectExportFile(exportInfo, handles);
% function for the user to select an export file

% prompt the user
[file_name, path_name] = uiputfile('*.csv', 'Choose a destination csv file', exportInfo.file_name);

% a valid response?
if numel(file_name) && ischar(file_name)
    
    file_name = fullfile(path_name, file_name);
    exportInfo.auto_name = false;  % stick with the users name - dont auto generate
    
    % call the filename editbox callback
    set(handles.ebFileName, 'string', file_name);
    [exportInfo, handles] = ChangeFileName(exportInfo, file_name, handles);

end

