function [export_set, write_format] = AddExportColumnInfo(export_set, column_names)
% function [export_set, write_format] = AddExportColumnInfo(export_set, column_names)
% function to add column names to an export set of data
% N.B. write string does not include the date

% add the names
export_set.dim_names = reshape(column_names, 1, numel(column_names));
export_set.dims = numel(column_names);

% now create the string to use to read / write  from / to this file
if (numel(export_set.ASCII_dec) == 0)
    export_set.ASCII_dec = GetExportPrecision();
end
export_set.ASCII_read = '';
write_format = '';
for i = 1:export_set.dims
    export_set.ASCII_read = sprintf('%s%s%%g', export_set.ASCII_read, repmat(', ', 1, i > 1));
    write_format = sprintf('%s%s%%0.%if', write_format, repmat(', ', 1, i > 1), export_set.ASCII_dec);
end
write_format = sprintf('%s\n', write_format);  % close the write string

% ignore the time column when reading
if (export_set.time_col)
    export_set.ASCII_read = sprintf('%%*[^,], %s', export_set.ASCII_read);
end

