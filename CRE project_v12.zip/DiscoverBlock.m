function [data_set, X]  = DiscoverBlock(data_set, indexs)
% function [data_set, X] = DiscoverBlock(data_set, indexs)
% function to (re)discover the data_set's lookup table to in the ranges
% indexs(1) though to indexs(2)

% if the file pointer isnt open open it
fOpen = (data_set.file_ptr > 0);
if (~fOpen)
    data_set.file_ptr = fopen(data_set.file_name, 'r');
    if (data_set.file_ptr < 0)
        error('DiscoverDataBlock:: Could not open %s', data_set.file_name);
    end
else
    fPos = ftell(data_set.file_ptr);  % at the end we will go back to this position
end

% load the data in blocks where possible
max_load_els = 3 * 1562500;  % load the data in full if it has less than this many elements (~300mb)
block_lines = data_set.lookgap;
chunk_lines = min(data_set.lookgap, floor(max_load_els / data_set.dims));  
load_all = (numel(data_set.data) > 0);  % are we storing it all?

% find the last discovered block
lastKnownBlock = find(~isnan(data_set.lookup), 1, 'last') - 1;
lastKnownPoint = lastKnownBlock * data_set.lookgap;  % the last "good" point

% the block the first index starts in
indexStartBlock = floor((indexs(1)-1) / data_set.lookgap) + 1;
indexEndBlock = floor((indexs(2)-1) / data_set.lookgap) + 1;

% corresponding points
indexStartBlockPoint = (indexStartBlock-1) * data_set.lookgap + 1;
indexEndBlockPoint = indexEndBlock * data_set.lookgap;

if (~load_all)
    X = zeros(indexs(2) - indexs(1)+1, data_set.dims);
    outCount = 0;
end

% preload whatever we can using GetData
if (lastKnownPoint >= indexs(1))
    
    % the max to try and load
    preLoadInds = [indexStartBlockPoint, min(lastKnownPoint, indexEndBlockPoint)];
    
    if (load_all)

        % case with preloaded data
        if numel(data_set.data)
            
            % check its actually there
            [valid, bIdx] = CheckDataSetStore(data_set, preLoadInds);
            
            % missing anything?
            if any(~valid)
            
                % load any missing blocks
                misStart = 0;
                while (misStart < numel(valid))
                    misStart = misStart + 1;
                    if (~valid(counter))
                        misEnd = misStart;
                        while (misEnd < numel(valid)) && (~valid(misEnd))
                            misEnd = misEnd + 1;
                        end
                        misPoints = [bIdx(misStart), bIdx(misEnd) + data_set.lookgap-1];
                        data_set.data(misPoints(1):misPoints(2), :) = GetData(data_set, misPoints);
                    end
                end
            end
           
        else
            % load it - note the entire lookup table may be known in this
            % case, e.g. if data_set.data has been cleared
            [XPreLoad, data_set] = GetData(data_set, preLoadInds);  % load entire blocks
            
            % allocate
            data_set.data = NaN(data_set.num_points, data_set.dims);
            data_set.data(preLoadInds(1):preLoadInds(2), :) = XPreLoad;
            
        end
        
        % special case - the lookup was known but the file isn't fully loaded yet
        if (lastKnownPoint >= indexs(2))
            X = data_set.data(indexs(1):indexs(2), :);
            return;
        end
        
    else
        % load up to the last known good point
        [XPreLoad, data_set] = GetData(data_set, [indexs(1), preLoadInds(2)]);  % load entire blocks
        if (size(XPreLoad,1) == size(X,1))
            X = XPreLoad;
            return;  % done here
        else
            X(1:size(XPreLoad,1), :) = XPreLoad;
            outCount = outCount + size(XPreLoad,1);
        end
    end
    XPreLoad = []; % no longer needed
   
end

% got to the start of the block
fseek(data_set.file_ptr, data_set.lookup(lastKnownBlock+1), 'bof');
lookup_index = lastKnownBlock + 1;

% how many points is this into the file?
num_points = (lookup_index-1) * data_set.lookgap; 

while (~feof(data_set.file_ptr) && (lookup_index <= indexEndBlock))
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % process this block (potentially multiple "chunks")
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    c_line = 0;
    while (c_line < block_lines) && ~feof(data_set.file_ptr)
        
        % end the load operation here (end of the block)
        grab_points = min(chunk_lines, block_lines - c_line);
        
        if (~load_all)
            if (lookup_index == indexStartBlock) && (indexs(1) > num_points + 1)
                grab_points = min(grab_points, indexs(1)-num_points-1); % skip over some berfore the return range
            elseif (lookup_index == indexEndBlock) && (indexs(2) > num_points) && (indexs(2) < num_points + grab_points)
                    grab_points = min(grab_points, indexs(2)-num_points);   % limit the first
            end
        end
            
        
        % do we need to interpret this data?
        if (load_all) || ((num_points+1 <= indexs(2)) && (grab_points + num_points >= indexs(1)))
            
            % grab and parse the data
            values = fscanf(data_set.file_ptr, data_set.ASCII_read, [data_set.dims, grab_points]);
            
            % how many loaded points
            loaded = size(values,2);
            
            if (loaded > 0)  % could be the end of the file
                
                % validate it
                if any(~isfinite(values(:)))
                    [r,c] = find(~isfinite(values(:)), 1, 'first');
                    error('Unable to process and / or interpret data as numeric at data point %i', num_points + c);
                end
                
                % add storage if needed
                if (load_all)
                    if ((num_points + loaded) > size(data_set.data,1))
                        data_set.data(num_points + loaded + max(5*lookgap, 1e4), :) = NaN;  
                    end
                
                    % and store
                    data_set.data(num_points+1:num_points+loaded, :) = values.';
                
                else
                    % trim back if inxes(2) isn't the block end
                    n_trim = num_points + grab_points - indexs(2);
                    if (n_trim > 0)
                        values(:, end-n_trim+1:end) = [];
                    end
                    
                    % assign
                    if (size(values,2) == size(X,1)) && (outCount == 0)
                        X = values.';
                        outCount = size(X,1);
                        
                    else
                        X(outCount+1:outCount+size(values,2), :) = values.';
                        outCount = outCount + size(values,2);
                    end
                end
            end
            
        else
            
            % no need to parse data in this case
            values = textscan(data_set.file_ptr, '%s', grab_points, 'delimiter', {'\n', '\r'}, 'MultipleDelimsAsOne', true);
            loaded = numel(values{1});
            
        end
        
        % add to the number of points
        num_points = num_points + loaded;
        
        % update where we are in the block
        c_line = c_line + loaded;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    % add a lookup table entry
    %%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % add storage if needed
    if (lookup_index >= numel(data_set.lookup))
        data_set.lookup(end + 1000) = 0;  % add 1000 elements at a time
    end
    
    % and store the byte offset
    lookup_index = lookup_index + 1;
    data_set.lookup(lookup_index) = ftell(data_set.file_ptr);
    
end

% did we reach the end of the file?
if feof(data_set.file_ptr)
    
    % update the number of points
    data_set.num_points = num_points;
    
    %%%%%%%%%%%%%%%%%%%%
    % now trim back
    %%%%%%%%%%%%%%%%%%%%
    
    if (numel(data_set.lookup) > lookup_index)
        data_set.lookup(lookup_index+1:end) = [];
    end
    if (load_all) && (size(data_set.data,1) > data_set.num_points)
        data_set.data(data_set.num_points+1:end, :) = [];
    end
    data_set.view_type = 2;  % we now have a full view
    
    if (indexs(2) > data_set.num_points)
        indexs(2) = data_set.num_points;
        if (~load_all)
            X(outCount+1:end, :) = [];
        end
    end
    
else
    
    % new estimate
    data_set.num_points = max(num_points + 5*data_set.lookgap, data_set.num_points); 
    
end

% when returning data with a full load
if (load_all)    
    X = data_set.data(indexs(1):indexs(2), :);
end

% reset the file pointer like nothing happened
if (~fOpen)
    fclose(data_set.file_ptr);
    data_set.file_ptr = -1;
end





