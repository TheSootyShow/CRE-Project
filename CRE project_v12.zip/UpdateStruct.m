function destStruct = UpdateStruct(destStruct, srcStruct, add_fields)
% function destStruct = UpdateStruct(destStruct, srcStruct, add_fields)
% this function updates destStruct with the corresponding fields of
% srcStruct.  If add_fields = true, fields of srcStruct that done exist in
% destStruct are added to destStruct

% get the field names to update
srcFields = fieldnames(srcStruct);

% only update fields that exist in destStruct is add_fields = false
if (~add_fields)
    srcFields = intersect(srcFields, fieldnames(destStruct));
end

% and assign
for i = 1:numel(srcFields)
    destStruct.(srcFields{i}) = srcStruct.(srcFields{i});
end
