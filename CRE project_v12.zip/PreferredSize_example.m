function PreferredSize_example()
% function PreferredSize_example()
% function to demonstrate preferred sizes of text box's

% create a figure
fig_h = figure();

% create a html string for the text box
url = 'http://www.uq.edu.au';
html_text = 'I want to be html';
string = ['<HTML><a href="', url, '">', html_text, '</a></html>'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create a text box (doesn't auto size)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create the text box
txt_h = uicontrol(fig_h, 'style', 'text', 'string', string, 'horizontalalignment', 'left', 'units', 'pixels');
pos_orig = get(txt_h, 'position');

% indicate it's not what I was trying to do
title_pos = [pos_orig(1), pos_orig(2) + 1.5*pos_orig(4), 200, pos_orig(4)];
uicontrol(fig_h, 'style', 'text', 'string', 'Not what I want...', 'position', title_pos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% try to dynamically resize a text box with MATLAB
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create the text box
txt2_pos = [title_pos(1), title_pos(2) + 2*title_pos(4), title_pos(3), title_pos(4)];
txt2_h = uicontrol(fig_h, 'style', 'text', 'string', string, 'horizontalalignment', 'left', 'units', 'pixels', ...
    'position', txt2_pos);

% Matlab help indicates to use the textwrap function
[tmp, pos_new] = textwrap(txt2_h, {string}, numel(string));  
set(txt2_h, 'position', pos_new);

% indicate it's not what I was trying to do
title_pos = [pos_new(1), pos_new(2)+pos_new(4) + pos_orig(4)/2, pos_new(3), pos_orig(4)];
uicontrol(fig_h, 'style', 'text', 'string', 'Still not what I want...', 'position', title_pos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Dynamically resize a text box at the java level
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create the text box
txt3_pos = [pos_orig(1), title_pos(2) + 2*title_pos(4), pos_new(3), pos_orig(4)];
txt3_h = uicontrol(fig_h, 'style', 'text', 'string', string, 'horizontalalignment', 'left', 'units', 'pixels', 'position', txt3_pos);

% get the java handle!
jHandle = findjobj(txt3_h);  % this function is available on FEX

% now get width and height
height = jHandle.getPreferredSize.height;
width = jHandle.getPreferredSize.width;

% update the desired position
txt3_pos(3) = width + 2;
txt3_pos(4) = height + 2;
set(txt3_h, 'position', txt3_pos);

% indicate it's what I was trying to do
title_pos = [txt3_pos(1), txt3_pos(2)+txt3_pos(4)+txt3_pos(4)/2, txt3_pos(3), txt3_pos(4)];
uicontrol(fig_h, 'style', 'text', 'string', 'Using java preferred sizes', 'position', title_pos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Better way - if you can control the text box creation
% (i.e. not using guide).  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get the usual font of a matlab text box
def_font = jHandle.getFont();
bodyRule = ['body { font-family: ', def_font.getFamily().char(), '; font-size: ', num2str(def_font.getSize()), 'pt; }'];

% it's position
txt4_pos = [pos_orig(1), title_pos(2) + 2*title_pos(4), txt3_pos(3), txt3_pos(4)];

% create the "not quite a" text box
[jText, hText] = javacomponent('javax.swing.JTextPane', txt4_pos, gcf());
jText = javaObjectEDT(jText);
jText.setContentType('text/html');
jText.setText(string);
jText.getDocument().getStyleSheet.addRule(bodyRule);
jText.setEditable(false);
jText.setOpaque(false);
jText.setBorder('');
jText.setFont(def_font);
height = jText.getPreferredSize.height;
width = jText.getPreferredSize.width;

% update its position now its been interpretted by HTML
txt4_pos(3) = width+2;
txt4_pos(4) = height+2;
set(hText, 'position', txt4_pos);

% and get it to hyperlink
%jText.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
hCallback = handle(jText, 'CallbackProperties' );
set(hCallback, 'MousePressedCallback', @(varargin)web(url));
set(hCallback, 'MouseEnteredCallback', @(varargin)set(fig_h,'Pointer','hand'));
set(hCallback, 'MouseExitedCallback', @(varargin)set(fig_h,'Pointer','arrow'));

% show what we can do
title_pos = [txt4_pos(1), txt4_pos(2)+txt4_pos(4)+txt4_pos(4)/2, pos_new(3), txt4_pos(4)];
uicontrol(fig_h, 'style', 'text', 'string', 'Other features we can add with java handles', 'position', title_pos);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Trim the figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(fig_h, 'units', 'pixels');
fig_pos = get(fig_h, 'position');
fig_pos(3) = 2*title_pos(1) + txt3_pos(3);
fig_pos(4) = title_pos(2) + 2*title_pos(4);
set(fig_h, 'position', fig_pos);










