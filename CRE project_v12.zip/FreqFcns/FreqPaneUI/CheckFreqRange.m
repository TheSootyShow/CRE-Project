function [freqStruct, featStruct, handles] = CheckFreqRange(hObject, freqStruct, featStruct, update_ind, pane_str, handles)
% function freqStruct, featStruct, handles] = CheckFreqRange(hObject, freqStruct, featStruct, update_ind, pane_str, handles)
% function to do everything when the frequency grab range is changed

% get the new value
str = get(hObject, 'string');
freq = str2double(str);  

% get the tags for max / min
minTag = 'ebMinFreq';
maxTag = 'ebMaxFreq';
if numel(pane_str)  % they are on tabs if multiple frequency slections are allowed
    pane_id = str2double(pane_str);
    minTag = [minTag, pane_str];
    maxTag = [maxTag, pane_str];
else
    pane_id = 1;  % only 1 pane / row in freqStruct
end
minH = handles.(minTag);
maxH = handles.(maxTag);

% and the old values so we can track down associated features
oldRange = [get(minH, 'userdata'), get(maxH, 'userdata')];

% is it interpretable?
if isfinite(freq) && (freq >= 0) && (freq <= handles.data_set.fs / 2)
    
    % round it in case it was a time
    if (update_ind == 1)
        overlap = freq >= freqStruct.fbounds(pane_id, 2);
    else
        overlap = freq <= freqStruct.fbounds(pane_id, 1);
    end
    
    % always allow this to be set (even if overlap)
    freqStruct.fbounds(pane_id, update_ind) = freq;
    
    % set it as the user data
    set(hObject, 'userdata', freq);
    
    % get the new range
    newRange = freqStruct.fbounds(pane_id, :);
    
    % update all of the features with this range
    if numel(featStruct)
        
        % and update the structure
        featStruct = UpdateFeatureStruct(featStruct, oldRange, newRange, pane_str, handles);
    end
    
    % set it
    if (~overlap)  % check max and min aren't on different sides of each other
        
        % set the title (only in the tabbed version)
        if numel(pane_str)
            set(handles.(['tabFrange', pane_str]), 'title', sprintf('%0.2g-%0.2g', newRange(1), newRange(2)));
        end
        
        % and remove from the block list
        handles.block_list = handles.block_list(handles.block_list ~= hObject);
        
        % now if the minimum handle is in the blocked list (i.e. we have
        % unoverlapped them by changing the max) fix it
        if any(handles.block_list == minH) && (str2double(get(minH, 'string')) == oldRange(1))
            handles.block_list = handles.block_list(handles.block_list ~= hMin);  % remove from the block list
        end
    
    else
        
        % make it clear something is wrong in the title (only in the tabbed version)
        if numel(pane_str)
            set(handles.(['tabFrange', pane_str]), 'title', '?-?');
        end
        
        % and add to the block list if needed
        if ~any(handles.block_list == minH)
            
            % always block using the hObject from the minimum
            handles.block_list(end+1) = minH;
        end
    end
    
else
    
    % make it clear something is wrong in the title
    if numel(pane_str)
        set(handles.(['tabFrange', pane_str]), 'title', '?-?');
    end
    
    if ~any(handles.block_list == hObject)
    
        % block the "OK" output
        handles.block_list(end+1) = hObject;
        
    end
end






function featStruct = UpdateFeatureStruct(featStruct, oldRange, newRange, paneStr, handles)
% function featStruct = UpdateFeatureStruct(featStruct, oldRange, newRange, paneStr, handles);
% this function update the frequency range of all frequency based features


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the list of features selected in the current frequency pane
% so we can modify them
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% list box features
hList = findobj(handles.(['tabFrange', paneStr]), 'style', 'listbox');
panelFeats = CREFeatures(0);
for i = 1:numel(hList)
    
    % recreate the features from this box
    tag = get(hList(i), 'tag');

    % convert the tag to a type
    type = Tag2Type(tag);

    % and each selected value
    data = get(hList(i), 'userdata');
    data = data{1};  % this is the numeric version of the options strings
    data = data(get(hList(i), 'Value'));
    
    % and build features
    for j = 1:numel(data)
        inputs = {data(j), newRange(1), newRange(2), handles.data_set.fs};
        panelFeats(end+1,1) = CREFeatures(type, inputs{:});
    end
end

% radio button
hButton = findobj(handles.(['uiTabPane', paneStr]), 'style', 'radiobutton');
for i = 1:numel(hButton)
    % recreate the features from this radio button
    if get(hButton, 'value')
        panelFeats = AddButtonFeature(hButton(i), panelFeats,  {newRange(1), newRange(2), handles.data_set.fs});
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now find each of these in feat struct and modify it
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% test each one
for i = 1:numel(panelFeats)
    
   % find the equivilent feature in feat struct 
   index = FindFeature(panelFeats(i).name, featStruct, [panelFeats(i).input_args(1:end-3), {oldRange(1), oldRange(2), handles.data_set.fs}]);
   
   if (numel(index) == 0)
       error('Could not find selected feature: %s', panelFeats(i).name);
   else
       index = index(end);  % in case multiple panels use the same frequency range
   end
   
   % replace
   featStruct(index) = panelFeats(i);

end