function handles = InitFreqPane(fRange, fs, handles)
% function handles = InitFreqPane(fRange, fs, handles)
% function to initialize the frequency range pane

% always update the frequency slection even if we aren't using it
set(handles.txtFs, 'string', sprintf('Data set sampling frequency: %s', num2str(fs)));

% ensure its in bounds
fRange(1) = max(fRange(1), 0);
fRange(2) = min(fRange(2), fs/2);

% and set values
set(handles.ebMinFreq, 'string', num2str(fRange(1)));
set(handles.ebMinFreq, 'userdata', fRange(1));

set(handles.ebMaxFreq, 'string', num2str(fRange(2)));
set(handles.ebMaxFreq, 'userdata', fRange(2));


