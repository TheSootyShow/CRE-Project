function freq_struct = InitFreqRangeStruct(data_set)
% function freq_struct = InitFreqRangeStruct()
% function freq_struct = InitFreqRangeStruct(data_set)

% function to initialise the frequency range structure
freq_struct = struct('fbounds', zeros(0, 2), ...  % each row is an analysis range of interest
                     'fres',    0);               % maximum fft resolution to use
                 
               
% fill in default frequency bounds                 
if (nargin == 1)
    freq_struct.fbounds = [.1, data_set.fs/2];
end