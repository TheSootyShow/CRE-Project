function is_dev = IsDeveloper()
% function is_dev = IsDeveloper()
% are we in developer mode?

if (~isdeployed())
    is_dev = CheckDevMode();
else
    is_dev = false;
end
    
function is_dev = CheckDevMode()

global dev_mode;
is_dev = (numel(dev_mode) > 0) && dev_mode;