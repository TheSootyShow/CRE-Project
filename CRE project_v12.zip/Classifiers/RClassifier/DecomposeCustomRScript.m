function [sections, msg] = DecomposeCustomRScript(rScriptFile)
% function sections DecomposeCustomRScript(rScriptFile)
% this function loads the rScirpt to use for classification and 
% breaks it into two sections
%
% section{1} - everything to do before transfering the data to R
% section{2} - everything to do after transfering the data to R
%              but before exporting classifcation results back to matlab
%
% the sections are broken into lines
%
% returns empty when the script can't be parsed

key_tokens = {'^\s*#+\s*Start do not edit import'; ...
              '^\s*#+\s*End do not edit import';   ...
              '^\s*Y <-';                     ...
              '^\s*#+\s*Start do not edit export'};
          
% error messages for when tokens are missing
key_msg = [repmat({'Could not locate the data import section'},2,1); ...
                  'Could not locate the prediction result'
                  'Could not locate the export section'];
              

% default for sucess              
msg = '';
             
    

% pre-allocate
sections = cell(1,2);

fid = fopen(rScriptFile, 'r');
if (fid <= 0)
    sections = [];
    return;
end

% read it all
str = fread(fid, inf, 'char=>char');
str = reshape(str, 1, numel(str));
fclose(fid);

% remove tab spacings
str = regexprep(str, '\t', '');

% remove new line preceding {
% str = regexprep(str, '\s*\n+\s*{', ' {');
% do all {} block in one go

% make sure code blocks are all on 1 line
open = cumsum(str == '{') - cumsum(str == '}');
starts = 1 + find((open(2:end) == 1) & (open(1:end-1) == 0));
ends =   1 + find((open(2:end) == 0) & (open(1:end-1) ~= 0));
if (numel(starts) ~= numel(ends))
    sections = [];
    return;
end
for i = numel(starts):-1:1
    
    % take out new lines that might be before the {
    starts(i) = starts(i) - 1;
    while (starts(i) > 1) && numel(regexp(str(starts(i)), '[\n\s]', 'match', 'once'))
        starts(i) = starts(i) - 1;
    end
    
    
    block = str(starts(i)+1:ends(i));
    
    % have to get rid of comments
    block = regexprep(block, '#[^\n]*', '');

    % now get rid of new lines
    block = regexprep(block, '\n+', ' ');
    str = [str(1:starts(i)), block, str(ends(i)+1:end)];
end


% break it into lines
lines = regexp(str, '\n+', 'split');

% find all of the key tokens
token_inds = zeros(size(key_tokens));
for i = 1:numel(token_inds)
    tokens = regexpi(lines, key_tokens{i}, 'match', 'once');
    tokens = find(cellfun(@(x)(numel(x) > 0), tokens));
    if (numel(tokens) ~= 1)
        % given up if we cant find key tokens
        sections = [];
        msg = key_msg{i};
        return;
    end
    token_inds(i) = tokens;
end
    
% remove all comments
lines = regexprep(lines, '\s*#.*', '');

% and blanks at the start of lines
lines = regexprep(lines, '^\s+', '');

% and break into sections
sections{1} = lines(1:token_inds(1)-1);
sections{2} = lines(token_inds(2)+1:token_inds(end)-1);

% remove all blank lines
for i = 1:2
    sections{i} = sections{i}(cellfun(@(x)(numel(x) > 0), sections{i}));
    
    % trim back the lines
    for j = 1:numel(sections{i})
        sections{i}{j} = strtrim(sections{i}{j});
    end
    
end





