function getDims = GetClassDimInfo(classifier, data_set)
% function getDims = GetClassDimInfo(classifier, data_set)
% this function parses a classifier structure(s) (see InitClassifiers.m)
% and creates a single structure with all information required to load and
% classify

% base this off the structure used to calculate secondary dimensions
% (there's large overlap)
getDims = ParseDimInfo();

getDims = struct(  'primary_name',      {{}},         ... % the name of each primary dimension
                   'primary_dims',      [],           ... % the primary dimension to get from the raw data
                   'primary_disp',      false(1,0),   ... % if false, the dimension is only needed for a derived dimension calculation
                   'derived_name',      {{}},         ... % name of the derived dimension
                   'derived_tag',      {{}},          ... % type of the derived dimension
                   'derived_disp',      false(1,0),   ... % if false, the dimension is only needed for another derived dimension calculation
                   'derived_func',      {{}},         ... % the function to calculate the derived dimension
                   'derived_args',      {{}},         ... % extra input aruguments for derived_func
                   'derived_input_col', {{}},         ... % the columns the derived dimenions needs to be calculated
                   'extra_points',      [],           ... % the maximum number of extra points to be used in the calculation of a derived dimension
                   'n_dims',            [],           ... % the total number of dimensions
                   'n_display',         []);          ... % the total number of dimensions to display
               
if (nargin == 0)               
    return;
end
               
               
               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start with the primary dimensions
% export them all (i.e. this appends another column)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

getDims.primary_name = data_set.dims;
getDims.primary_dims = 1:numel(data_set.dims);
getDims.primary_disp = true(size(getDims.primary_dims));
getDims.extra_points = 0;                                % no need for extra points in this ever



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Keep a list of the derived dimensions we aren't displaying
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

undisplayed_dims = repmat(InitDerivedDim(), 0, 1);
undiscovered_dims = cell(0,1);  % name of ones we haven't found yet




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now add simple secondary dimensions
% - the ones that act on only a single primary dimension
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% reset the shown value status on everything
known_types = GetKnownSecondaryDimTypes(dimInfo);

% go through each types
for i = 1:numel(known_types)
    
    % get properties for this supported dimension
    dims = dimInfo.(known_types{i}).dims;
    shown = dimInfo.(known_types{i}).disp;
    args = dimInfo.(known_types{i}).args;
    tag = dimInfo.(known_types{i}).tag;
    func = dimInfo.(known_types{i}).func;
    epfunc = dimInfo.(known_types{i}).epfunc;

    for j = 1:numel(dims)
    
        % create a new dimension
        new_dim = InitDerivedDim();
        new_dim.type = tag;
        new_dim.source{1} = 'primary';
        new_dim.source{2} = dims(j);
        new_dim.source{3} = [];
        new_dim.func = func;
        new_dim.args = args{j};
        new_dim.extra_points = feval(epfunc, args{j}{:});
        new_dim.name = NameDerivedDim(new_dim, dimInfo.primary_names);
        
        % and the sampling rate as the second argument to derivitive
        % functions (needed to scale the deriv)
        if strcmpi(known_types{i}, 'derivitive') && (nargin == 2)
            new_dim.args{2} = 1 / data_set.fs;
        end
            
        % do we display it?
        if (shown(j))
        
            % add it
            getDims = AddDerivedDim(getDims, new_dim, new_dim.source{1,2}, [], true, dimInfo);

        else
        
            % add it it a list of undisplayed dimensions
            undisplayed_dims(end+1) = new_dim;
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now add the more complex secondary dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% and go through them
i = 1;
while (i <= numel(dimInfo.derived_dims))
    
    % and the sampling rate as the second argument to derivitive
    % functions (needed to scale the deriv)
    if strcmpi(dimInfo.derived_dims(i).type, 'deriv') && (nargin == 2)
        dimInfo.derived_dims(i).args{2} = 1 / data_set.fs;
    end
    
    % do we display it?
    if (dimInfo.derived_disp(i))
        
        % have all the derived dimensions it uses already been "discovered"
        if (numel(dimInfo.derived_dims(i).source{1,3}))
                
            % no, are the missing ones in undisplayed_dims?
            [discovered, getDims, deriv_source, undisplayed_dims, undiscovered_dims] = FindPrequisteDims(dimInfo.derived_dims(i), undisplayed_dims, getDims, dimInfo, undiscovered_dims);
            all_discovered = all(discovered);
            
            % have we found them all?
            if ~(all_discovered)
                
                % in this case move this dimension to the back of the
                % queue and hope we find its prerequisites later
                if any(strcmpi(dimInfo.derived_dims(i).name, undiscovered_dims))
                    error('No information is provided in dimInfo to calculate %s (a required (nested) input of %s)', dimInfo.derived_dims(i).source{3}{find(~discovered, 1, 'first')}, dimInfo.derived_dims(i).name);
                else
                    % add it to the undiscovered list
                    undiscovered_dims{end+1} = dimInfo.derived_dims(i).name; %#ok<*AGROW>
                end
            end
        
        else
            all_discovered = true;
            deriv_source = zeros(1,0);
        end
            
        % did we find it?
        if (all_discovered)
            
            % add it!
            getDims = AddDerivedDim(getDims, dimInfo.derived_dims(i), dimInfo.derived_dims(i).source{1,2}, deriv_source, true, dimInfo);
            
            % update the list of dimensions we have found
            % found_dims{end+1} = dimInfo.derived_dims(i).name; 
            undiscovered_dims = cell(0,1);  % maybe this was needed
            i = i + 1;
            
        end
    else
        % add it to the list of undisplayed dimensions
        undisplayed_dims(end+1) = dimInfo.derived_dims(i); 
        undiscovered_dims = cell(0,1);  % maybe this was needed
        i = i + 1;  % move along
    end
end

% finally add the total number of dims and diaplyed dims
getDims.n_dims = numel(getDims.primary_disp) + numel(getDims.derived_disp);
getDims.n_display = sum(getDims.primary_disp) + sum(getDims.derived_disp);

% how many extra points required?
if (numel(getDims.extra_points) == 0)
    getDims.extra_points = 0;
else
    getDims.extra_points = max(getDims.extra_points);
end



function getDims = AddPrimaryDim(getDims, dim, dimInfo)
% function getDims = AddPrimaryDim(getDims, dim, dimInfo)
% function to add a primary dimension to what we're grabbing

% add it
getDims.primary_dims(end+1) = dim;
getDims.primary_disp(end+1) = false;  % dont show it
getDims.primary_name{end+1} = dimInfo.primary_names{dim};

% now sort the list to keep GrabData.m efficient
[getDims.primary_dims, order] = sort(getDims.primary_dims);
getDims.primary_disp = getDims.primary_disp(order);
getDims.primary_name = getDims.primary_name(order);

% adjust any derived dim sources that just got moved
added_at = find(getDims.primary_dims == dim, 1, 'first');
for i = 1:numel(getDims.derived_input_col)
    getDims.derived_input_col{i}(getDims.derived_input_col{i} >= added_at) = getDims.derived_input_col{i}(getDims.derived_input_col{i} >= added_at) + 1;
end



function [discovered, getDims, deriv_source, undisplayed_dims, undiscovered_dims] = FindPrequisteDims(derived_dim, undisplayed_dims, getDims, dimInfo, undiscovered_dims)
% function [discovered, getDims, deriv_source, undisplayed_dims, undiscovered_dims] = FindPrequisteDims(derived_dim, undisplayed_dims, getDims, dimInfo, undiscovered_dims)
% function to find all required derivitive dimensions for this one

% whent his function is called recursively, we will end up with a dimension
% thats a function of only the primary dimensions
if (numel(derived_dim.source{1,3}))

    % check if we have already discovered the dimension
    [discovered, deriv_source] = ismember(derived_dim.source{1,3}, getDims.derived_name);
    
    if ~all(discovered)
        
        unknown_dim = derived_dim.source{1,3}(~discovered);
        unknown_inds = find(~discovered);
        for i = 1:numel(unknown_dim)
            
            % is it a match with any undisplayed dimensions?
            match = strcmpi(unknown_dim{i}, {undisplayed_dims.name});
            
            % did it find something?
            if any(match)
                
                % call this function recursively to add the undisplayed dimension now
                [preq_disc, getDims, tmp, undisplayed_dims, undiscovered_dims] = ...
                    FindPrequisteDims(undisplayed_dims(match), undisplayed_dims, getDims, dimInfo, undiscovered_dims);
                
                % success?
                if (all(preq_disc))
                    
                    % update sources / discovery
                    deriv_source(unknown_inds(i)) = numel(getDims.derived_disp);  % it'll be added as the last entry in getDims
                    discovered(unknown_inds(i)) = true;
                end
            end
        end
    end
else
    % add it below
    discovered = true;
    deriv_source = [];
end

% if we succeeded during a recursive call add the precusor now
if all(discovered) 
    
    % add it!
    if any(strcmpi(derived_dim.name, {undisplayed_dims.name}))
    
        getDims = AddDerivedDim(getDims, derived_dim, derived_dim.source{1,2}, deriv_source, false, dimInfo);
        undisplayed_dims = undisplayed_dims(~strcmpi(derived_dim.name, {undisplayed_dims.name}));
        undiscovered_dims = {}; % reset
    end
end
   
   
function getDims = AddDerivedDim(getDims, derived_dim, primary_source, derived_source, display, dimInfo)   
% function AddDerivedDim(getDims, derived_dim, primary_source, derived_source)   
% function to add a derived dimension to the structure

% check that the primary dimension are already included
for i = 1:numel(primary_source)
    
    % check that we are already grabbing the dimension its based off
    if ~any(getDims.primary_dims == primary_source(i))
        getDims = AddPrimaryDim(getDims, primary_source(i), dimInfo);
    end
    
    % convert from the dimension number to an index into getDims.primary_dims
    primary_source(i) = find(getDims.primary_dims == primary_source(i), 1, 'first');  
    
end

% add it
getDims.derived_name{end+1} = derived_dim.name;
getDims.derived_func{end+1} = derived_dim.func;
getDims.derived_tag{end+1} = derived_dim.type;
getDims.derived_disp(end+1) = display;           % default
getDims.derived_args{end+1} = derived_dim.args;  % default
getDims.derived_input_col{end+1} = [primary_source, derived_source + numel(getDims.primary_dims)];
getDims.extra_points(end+1) = derived_dim.extra_points; 

% if what's its derived from also takes extra points, keep a note of it
if numel(derived_source)
    getDims.extra_points(end) = getDims.extra_points(end) + max(getDims.extra_points(derived_source));
end
                   
