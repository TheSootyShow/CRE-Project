function col_name = ClassifierColumnName(class_name)
% function ClassifierColumnName(class_name)
% function to convert a classifier name into a name for the 
% csv file

% enforce consistency
cellIn = iscell(class_name);
if (~cellIn)
    class_name = {class_name};
end

% make the column name
col_name = cellfun(@(str)([str, ' class']), class_name, 'uniformoutput', false);

% match input format
if (~cellIn)
    col_name = col_name{1};
end