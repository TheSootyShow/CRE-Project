function varargout = WaveletSelectionGui(varargin)
% WAVELETSELECTIONGUI MATLAB code for WaveletSelectionGui.fig
%      WAVELETSELECTIONGUI by itself, creates a new WAVELETSELECTIONGUI or raises the
%      existing singleton*.
%
%      H = WAVELETSELECTIONGUI returns the handle to a new WAVELETSELECTIONGUI or the handle to
%      the existing singleton*.
%
%      WAVELETSELECTIONGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in WAVELETSELECTIONGUI.M with the given input arguments.
%
%      WAVELETSELECTIONGUI('Property','Value',...) creates a new WAVELETSELECTIONGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before WaveletSelectionGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to WaveletSelectionGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help WaveletSelectionGui

% Last Modified by GUIDE v2.5 04-Jul-2014 11:50:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @WaveletSelectionGui_OpeningFcn, ...
                   'gui_OutputFcn',  @WaveletSelectionGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before WaveletSelectionGui is made visible.
function WaveletSelectionGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to WaveletSelectionGui (see VARARGIN)

% Choose default command line output for WaveletSelectionGui
handles.output = {'Cancel', [], {}, []};

% Input dimensions
handles.input_dims = varargin{1};
handles.output_dims = [];
handles.new_names = {};
handles.display = false(1,0);
handles.fs = varargin{2};


% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);

% call the resize function
handles = WaveletSelectionGui_ResizeFcn(hObject, [], handles);
set(hObject, 'resize', 'off');

% call intialization code
handles = InitialiseGUI(handles);

% Update handles structure
guidata(hObject, handles);

% Make the GUI modal
set(handles.WaveletSelectionGui,'WindowStyle','modal')



% % save it while developing
% set(hObject, 'visible', 'on');
% SaveResizedCREFigure(hObject);

% UIWAIT makes WaveletSelectionGui wait for user response (see UIRESUME)
uiwait(hObject);

function handles = InitialiseGUI(handles)
% function handles = InitialiseGUI(handles)
% function to intialise the gui

% the maximum number of wavelet levels to build
max_levels = 10;

% first do the dimension list box
PopulateDimListBox(handles.input_dims, handles.lbDims, handles.lbDims);
set(handles.lbDims, 'value', []);

% now do the details / approx levels boxes
detail_str = cell(max_levels+1, 1);
approx_str = cell(max_levels+1, 1);

for i = 0:max_levels
    
    % low and high range of detail
    fl = handles.fs / (2^(i + 1));
    fh = handles.fs / (2^i);
    detail_str{i+1} = sprintf('%id (%0.2f - %0.2f Hz)', i, fl, fh);
    
    % low and high range of approx
    approx_str{i+1} = sprintf('%ia (%0.2f - %0.2f Hz)', i, 0, fl);
    
end

% and set them
set(handles.lbApprox, 'string', approx_str);
set(handles.lbApprox, 'min', 0, 'max', numel(approx_str));
set(handles.lbApprox, 'value', []);

set(handles.lbDetail, 'string', detail_str);
set(handles.lbDetail, 'min', 0, 'max', numel(detail_str));
set(handles.lbDetail, 'value', []);

% get all available wavlet families
wavFams = cellstr(wavemngr('read'));
wavFams = regexp(wavFams, '[\w\.-]+', 'match');  % these should come in pairs
wavFams = wavFams(cellfun(@(x)(numel(x) > 0), wavFams));
wav_list = cell(numel(wavFams), 1);
wav_code = cell(numel(wavFams), 1);
for i = 1:numel(wavFams)
    wav_list{i} = sprintf('%s ',wavFams{i,1}{1:end-1});
    wav_code{i} = wavFams{i,1}{end};
end
set(handles.pmWavFamily, 'string', wav_list);
set(handles.pmWavFamily, 'userdata', wav_code);

% set the default to 'db'
index = find(strcmpi(wav_code, 'db'), 1, 'first');
set(handles.pmWavFamily, 'value', index);

% get a full list of all wavelets
curr_code = wav_code{index};
wav_str = cellstr(wavemngr('read','full'));  % get the full list
wav_types = regexp(wav_str, [curr_code, '\d+(\.\d)*'], 'match');
wav_types = [wav_types{:}];
set(handles.pmWavType, 'string', wav_types(:));

% default to db10
index = find(strcmpi(wav_types, 'db10'), 1, 'first');
set(handles.pmWavType, 'value', index);

% nothing is selected, so dont enable "OK"
set(handles.pbOK, 'enable', 'off');





% --- Outputs from this function are returned to the command line.
function varargout = WaveletSelectionGui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;

% The figure can be deleted now
delete(handles.WaveletSelectionGui);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.output_dims, handles.new_names, handles.display};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.WaveletSelectionGui);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.output_dims, handles.new_names, handles.display};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.WaveletSelectionGui);


% --- Executes when user attempts to close WaveletSelectionGui.
function WaveletSelectionGui_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to WaveletSelectionGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over WaveletSelectionGui with no controls selected.
function WaveletSelectionGui_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to WaveletSelectionGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
if isequal(get(hObject,'CurrentKey'),'escape')

    % User said no by hitting escape
    handles.output = {'Cancel', handles.output_dims, handles.new_names, handles.display};
    
    % Update handles structure
    guidata(hObject, handles);
    
    uiresume(handles.WaveletSelectionGui);
end    
    
if isequal(get(hObject,'CurrentKey'),'return')
    uiresume(handles.WaveletSelectionGui);
end    


% --- Executes on selection change in lbDims.
function Null_Callback(hObject, eventdata, handles)
% hObject    handle to lbDims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbDims contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbDims

% which dimensions are we applying this to?
% dim_names = get(handles.lbDims, 'string');
dim_names = GetAllDimensionNames(handles.input_dims, true);  % get the names without an alias
dim_names = dim_names(get(handles.lbDims, 'value'));

% which details levels?
detail = get(handles.lbDetail, 'string');
detail = detail(get(handles.lbDetail, 'value'));
detail = regexp(detail, '^\d+', 'match', 'once');
detail = cellfun(@str2double, detail);

% which approx levels?
approx = get(handles.lbApprox, 'string');
approx = approx(get(handles.lbApprox, 'value'));
approx = regexp(approx, '^\d+', 'match', 'once');
approx = cellfun(@str2double, approx);

% how many features are we expecting?
use_sum = get(handles.cbSum, 'value') > 0;
use_rat = get(handles.cbRatio, 'value') > 0;
exp_dims = (numel(detail) + numel(approx));

% build the output features
handles.output_dims = handles.input_dims;  % reset

% what's the wavelet type?
wav_type = get(handles.pmWavType, 'string');
wav_type = wav_type{get(handles.pmWavType, 'value')};

% keep track fo where we're adding them to
indexs = repmat({zeros(exp_dims,2)}, 1, numel(dim_names));
names = repmat({cell(exp_dims,1)}, 1, numel(dim_names));

if ((numel(approx) + numel(detail)) > 0) && (numel(dim_names) > 0)

    % and build
    for i = 1:numel(dim_names) % for each dimension
        
        % is this a primary dimension?
        prim_index = find(strcmpi(handles.input_dims.primary_names, dim_names{i}));
        
        if (numel(prim_index))
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % DWT of a primary dimension
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for j = 1:numel(detail) % construct each detail level
                
                % add it
                indexs{i}(j,1) = 1;  % indicates primary
                args = {wav_type, sprintf('d%i', detail(j))};
                [handles.output_dims, indexs{i}(j,2)] = AddPrimaryDWT(handles.output_dims, prim_index, args);
                handles.output_dims.wavelet.disp(indexs{i}(j,2)) = handles.output_dims.wavelet.disp(indexs{i}(j,2)) || (~(use_sum || use_rat));
                names{i}{j} = CreateDimName('dwt', dim_names{i}, args{:});
                
            end
            
            for j = 1:numel(approx) % and each approx level
                
                % add it
                indexs{i}(j+numel(detail),1) = 1;  % indicates primary
                args = {wav_type, sprintf('a%i', approx(j))};
                [handles.output_dims, indexs{i}(j+numel(detail),2)] = AddPrimaryDWT(handles.output_dims, prim_index, args);
                handles.output_dims.wavelet.disp(indexs{i}(j+numel(detail),2)) = handles.output_dims.wavelet.disp(indexs{i}(j+numel(detail),2)) || (~(use_sum || use_rat));
                names{i}{j+numel(detail)} = CreateDimName('dwt', dim_names{i}, args{:});
                
            end
            
        else
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % DWT of a secondary dimension
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            for j = 1:numel(approx) % and each approx level
                
                % add it
                indexs{i}(j+numel(detail),1) = 0;  % indicates secondary
                args = {wav_type, sprintf('a%i', approx(j))};
                [handles.output_dims, indexs{i}(j+numel(detail),2), existing] = AddSecondaryDWT(handles.output_dims, dim_names{i}, args);
                if (~existing)
                    handles.output_dims.derived_disp(indexs{i}(j+numel(detail),2)) = ~(use_sum || use_rat);
                end
                names{i}{j+numel(detail)} = handles.output_dims.derived_dims(indexs{i}(j+numel(detail),2)).name;
                
            end
            
            for j = 1:numel(detail) % construct each detail level
                
                % add it
                indexs{i}(j,1) = 0;  % indicates secondary
                args = {wav_type, sprintf('d%i', detail(j))};
                [handles.output_dims, indexs{i}(j,2), existing] = AddSecondaryDWT(handles.output_dims, dim_names{i}, args);
                if (~existing)
                    handles.output_dims.derived_disp(indexs{i}(j,2)) = ~(use_sum || use_rat);
                end
                names{i}{j} = handles.output_dims.derived_dims(indexs{i}(j,2)).name;
                
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % build the sum if desired
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        n_added = numel(approx) + numel(detail);
        if ((use_sum) || (use_rat))
            n_added = n_added + 1;
            [handles.output_dims, indexs{i}(n_added,2)] = AddSecondaryDWT(handles.output_dims, names{i}, {}, 'sumsq');
            handles.output_dims.derived_disp(indexs{i}(n_added,2)) = use_sum;
            
            % create a different name for this
            dwt_params = LevelInputStr(approx, detail, wav_type);
            handles.output_dims.derived_dims(indexs{i}(n_added,2)).name = sprintf('SDWT(%s,%s)^2', dim_names{i}, dwt_params);
            
            % and store the name
            names{i}{n_added} = handles.output_dims.derived_dims(indexs{i}(n_added,2)).name;
            
            % show the user the label
            label = ApplyKnownDimAliases(names{i}{n_added}, handles.input_dims.aliases);
            if (i == 1)
                set(handles.txtDWTSumSq, 'string', label);
            else
                cString = get(handles.txtDWTSumSq, 'string');
                set(handles.txtDWTSumSq, 'string', sprintf('%s, %s', cString,  label));
            end
            
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % build the ratio if desired
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if (use_rat)
            
            % we also need the square of this dimension for the ratio
            n_added = n_added + 1;
            [handles.output_dims, indexs{i}(n_added,2)] = AddSecondaryDWT(handles.output_dims, dim_names{i}, {}, 'sq');
            handles.output_dims.derived_disp(indexs{i}(n_added,2)) = false;
            names{i}{n_added} = handles.output_dims.derived_dims(indexs{i}(n_added,2)).name;
            
            % now create the ratio
            n_added = n_added + 1;
            [handles.output_dims, indexs{i}(n_added,2)] = AddSecondaryDWT(handles.output_dims, names{i}(n_added-2:n_added-1), {}, 'rat');
            handles.output_dims.derived_disp(indexs{i}(n_added,2)) = true;
            
            % create a different name for this
            dwt_params = LevelInputStr(approx, detail, wav_type);
            handles.output_dims.derived_dims(indexs{i}(n_added,2)).name = sprintf('RDWT(%s,%s)', dim_names{i}, dwt_params);
            
            % and store the name
            names{i}{n_added} = handles.output_dims.derived_dims(indexs{i}(n_added,2)).name;
            
            % show the user the label
            label = ApplyKnownDimAliases(names{i}{n_added}, handles.input_dims.aliases);
            if (i == 1)
                set(handles.txtDWTRatio, 'string', label);
            else
                cString = get(handles.txtDWTRatio, 'string');
                set(handles.txtDWTRatio, 'string', sprintf('%s, %s', cString, label));
            end
        end
    end
    
    % store all of the new names
    handles.new_names = ApplyKnownDimAliases([names{:}], handles.input_dims.aliases);
    
    % update the handles
    guidata(handles.WaveletSelectionGui, handles);
    
    % enable the output
    set(handles.pbOK, 'enable', 'on');
    
else
    
    % disable OK
    set(handles.pbOK, 'enable', 'off');
    
end

function [output_dims, index] = AddPrimaryDWT(output_dims, dim_ind, args)
% function output_dims = AddPrimaryDWT(output_dims, dim_ind, args)
% function to add a dwt of a primary dimension to the output dimensions
    
% check it doesn't match anything
dim_match = output_dims.wavelet.dims == dim_ind;
arg_match = cellfun(@(x)isequal(x, args), output_dims.wavelet.args);

if ~any(dim_match & arg_match);
    
    output_dims.wavelet.dims(1,end+1) = dim_ind;
    output_dims.wavelet.disp(1,end+1) = true;
    output_dims.wavelet.args{1,end+1} = args;
    index = numel(output_dims.wavelet.args);
    
else
    index = find(dim_match & arg_match);
end


function [output_dims, index, existing] = AddSecondaryDWT(output_dims, dim_str, args, tag)
% function [output_dims, index, existing] = AddSecondaryDWT(output_dims, dim_str, args, tag)
% function to add the dwt of a secondary dimension

if (nargin < 4)
    tag = 'dwt';
end

if ~iscell(dim_str)
    dim_str = {dim_str};
end

% create it
new_dim = DerivedDimFromSources(output_dims, dim_str, tag, args{:});

% check it doesn't match any existing dimensions
existing_names = {output_dims.derived_dims(:).name};
existing = any(strcmpi(new_dim.name, existing_names));
if (~existing)
    output_dims.derived_dims(end+1) = new_dim;
    index = numel(output_dims.derived_dims);
else
    index = find(strcmpi(new_dim.name, existing_names));
end



% --- Executes during object creation, after setting all properties.
function Default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbDims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in cbAutoLabel.
function cbAutoLabel_Callback(hObject, eventdata, handles)
% hObject    handle to cbAutoLabel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cbAutoLabel



% --- Executes when WaveletSelectionGui is resized.
function handles = WaveletSelectionGui_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to WaveletSelectionGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call the feature layout function
if (RunResizeFcn(hObject, handles))

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);
    
    % standardized gaps between objects
    [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Build the selection pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    gridSelect = {handles.txtDims, handles.txtDetail, handles.txtApprox; ...
                  handles.lbDims, handles.lbDetail, handles.lbApprox};
    vertSelect = repmat(smallGap, size(gridSelect,1)-1, size(gridSelect,2));  % vertical gaps between objects
    horzSelect = repmat(largeGap, size(gridSelect,1), size(gridSelect,2)-1);  % horizontal gaps between objects
    
    set(cell2mat(gridSelect), 'parent', handles.uiSelection); % I hate GUIDE
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Build the wavelet properties pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    gridWavelet = {handles.txtWavFamily, handles.pmWavFamily; handles.txtWavType, handles.pmWavType};
    
    vertWavelet = repmat(normGap, size(gridWavelet,1)-1, size(gridWavelet,2));  % vertical gaps between objects
    horzWavelet = repmat(normGap, size(gridWavelet,1), size(gridWavelet,2)-1);  % horizontal gaps between objects
    
    set(cell2mat(gridWavelet), 'parent', handles.uiWavProperties); % I hate GUIDE
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Build the Post Processing properties pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    gridProcess = cell(4,3);
    gridProcess{1,1} = handles.cbSum;
    gridProcess(2,:) = {'h=0.45cm', handles.txtLabelDWTSumSq, handles.txtDWTSumSq};
    gridProcess{3,1} = handles.cbRatio;
    gridProcess(4,:) = {'h=0.45cm', handles.txtLabelDWTRatio, handles.txtDWTRatio};
    
    vertProcess = repmat(normGap, size(gridProcess,1)-1, size(gridProcess,2));  % vertical gaps between objects
    vertProcess(1,3) = smallGap;
    horzProcess = repmat(normGap, size(gridProcess,1), size(gridProcess,2)-1);  % horizontal gaps between objects
    
    % set(cell2mat(gridProcess), 'parent', handles.uiPostProcess); % I hate GUIDE
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Put it all together
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    gridFig = {gridSelect, 'l'; gridWavelet, 'l'; gridProcess, 'l'; handles.pbCancel, handles.pbOK};
    vertFig = {vertSelect, []; vertWavelet, []; vertProcess, []; [], []};
    horzFig = {horzSelect, []; horzWavelet, []; horzProcess, []; [], []};
    
    % and resize
    pane_h = ResizeFigFromPanes(gridFig, horzFig, vertFig, false, true, [], [false,false]);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % modify the widths of the two label boxes(they start empty)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % set([handles.txtDWTRatio, handles.txtDWTSumSq], 'backgroundcolor', [.1,.1,.1]);
    framePos = get(handles.uiPostProcess, 'position');
    [labelHeight, labelWidth] = GetPreferredSize(handles.txtLabelDWTRatio);  % how wide are these labels?
    
    % do the sum of squares box
    posL = get(handles.txtLabelDWTSumSq, 'position');
    posL(3) = labelWidth;
    set(handles.txtLabelDWTSumSq, 'position', posL);  % take it back to its preferred width
    posT = [posL(1) + posL(3) + largeGap, posL(2), framePos(3) - 8, posL(4)];
    posT(3) = posT(3) - posT(1);
    set(handles.txtDWTSumSq, 'position', posT);
    
    % do the ratio box
    posL = get(handles.txtLabelDWTRatio, 'position');
    posL(3) = labelWidth;
    set(handles.txtLabelDWTRatio, 'position', posL);  % take it back to its preferred width
    posT = [posL(1) + posL(3) + largeGap, posL(2), framePos(3) - 8, posL(4)];
    posT(3) = posT(3) - posT(1);
    set(handles.txtDWTRatio, 'position', posT);

    % and save it
    handles = SaveResizedCREFigure(hObject, [], handles);

end



% --- Executes on selection change in pmWavFamily.
function pmWavFamily_Callback(hObject, eventdata, handles)
% hObject    handle to pmWavFamily (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmWavFamily contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmWavFamily

% get the code for the currently selected family
wav_code = get(hObject, 'userdata');
wav_code = wav_code{get(hObject, 'value')};

% get a full list of all wavelets
wav_str = cellstr(wavemngr('read','full'));  % get the full list
wav_types = regexp(wav_str, [wav_code, '\d+(\.\d)*'], 'match');
wav_types = [wav_types{:}];
if numel(wav_types)
    set(handles.pmWavType, 'string', wav_types(:));
else
    set(handles.pmWavType, 'string', {wav_code});  % this means there're no options for this family
end

% default to db10 if debauch...
if strcmpi(wav_code, 'db')
    index = find(strcmpi(wav_types, 'db10'), 1, 'first');
    set(handles.pmWavType, 'value', index);
else
    set(handles.pmWavType, 'value', 1);
end

% and trigger the dimension building callback
Null_Callback(hObject, eventdata, handles);


function str = LevelInputStr(approx_levels, detail_levels, wav_type)
% function str = LevelInputStr(approx_levels, detail, wav_type)
% function to create a string describing the wavelet inputs

% string for the approx levels
astr = GroupLevels(approx_levels, 'a');

% string for the detail levels
dstr = GroupLevels(detail_levels, 'd');

% combine them
if numel(astr) && numel(dstr)
    str = sprintf('%s, %s', astr, dstr);
elseif numel(astr)
    str = astr;
elseif numel(dstr)
    str = dstr;    
else
    str = '';
end

% add wavelet type if its not db10
if ~strcmpi(wav_type, 'db10')
    str = sprintf('%s, %s', wav_type, str);
end



function level_str = GroupLevels(level_vec, type)
% function level_str = GroupLevels(level_vec, type)
% function to create a string giving a compact description of levels
% type is 'a' or 'd'

% special cases
if (numel(level_vec) == 0)
    level_str = '';
elseif (numel(level_vec) == 1)
    level_str = sprintf('%s%i', type, level_vec);
else
    level_vec = sort(level_vec(:));
    breaks = [0; find(diff(level_vec(:)) > 1); numel(level_vec)];
    level_str = '';
    for i = 1:(numel(breaks)-1)
        if (i > 1)
            level_str = sprintf('%s,', level_str);
        end
        if (breaks(i+1) - breaks(i) > 1)
            level_str = sprintf('%s%i-%i', level_str, level_vec(breaks(i)+1), level_vec(breaks(i+1)));
        else
            level_str = sprintf('%s%i', level_str, level_vec(breaks(i)+1));
        end
    end
    
    % wrap it
    level_str = sprintf('%s[%s]', type, level_str);
end
    
