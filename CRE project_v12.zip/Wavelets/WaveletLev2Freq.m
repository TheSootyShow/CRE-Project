function Wavelet = WaveletLev2Freq(Wavelet, Fs)
%function WaveStr = WaveletLev2Freq(Wavelet, Fs)
%function to convert from a wavelet level to frequency
%fills in the FLo and FHi fields of the wavelet

if (nargin < 2)
    Fs = Wavelet.DefFs;
end

%Initialise 
Wavelet.FLo = zeros(1, numel(Wavelet.RecLevels));
Wavelet.FHi = zeros(1, numel(Wavelet.RecLevels));

%And calculate levels
for i = 1:numel(Wavelet.RecLevels)
    
    if (Wavelet.RecType(i) == 'a')
        Wavelet.FLo(i) = 0;
        Wavelet.FHi(i) = Fs / (2 ^ (Wavelet.RecLevels(i) + 1));
    else
        Wavelet.FLo(i) = Fs / (2 ^ (Wavelet.RecLevels(i) + 1));
        Wavelet.FHi(i) = Fs / (2 ^ Wavelet.RecLevels(i));  %Probably 2x FLo but anyway
    end
end