function varargout = ConvertTime(time, date_vec, hhmmss, absolute, max_prec)
% 1) function time_str = ConvertTime(time, date_vec, hhmmss, absolute, max_prec)
% adds a time in seconds to the date vector and returns a string
% representation of the time
%
% 2) function time_str = ConvertTime(time_vec, date_vec, hhmmss, absolute, max_prec)
% returns a string version of the time vector
%
% 3) function time = ConvertTime(time_str, date_vec, absolute, max_prec)
% returns the time difference in seconds between the time described
% by time_str and the date vector in date_vec. Positive time mean
% time_str > date_vec
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% 1) time       - time in seconds after the date vector
%
% 2) time_vec   - a matlab date vector (see datevec.m) 
%               - if the years and months are 0, its treated
%                 as a time ellapsed since the date vec
%               - if year or months are non-zero, its treated as an
%                 absolute time
%
% 3) time_str   - a string with format specified by the arguments
%                 hhmmss.  
%               - If absolute is not selected, the input date
%                 vector date_vec is only subtracted if the time string has year
%                 greater than 0 A.D.
%               - If absolute is selected, the input date
%                 vector date_vec is only added if the time string has year
%                 equal to 0 A.D.
%
% date_vec      - a Matlab date vector [Y, M, D, h, m, s]  (see datevec.m)
%               - input and output times are referenced against this
%                 depending on the value of absolute
%
% hhmmss        = 0  - time strings have the format *S
%               = 1  - time strings have the format HH:MM:SS (seconds will be a decimal)
%               = 2  - time strings have the format HH:MM:SS:MS
%                 when outputting in seconds, the ouput is never absolute
%
% absolute      - if true, the output represents the time since 0 A.D.
%               - if false, the output represents the time since the date vector.
%
% max_prec      - maximum number of decimal places in strings (default 4)
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% time          - if the first input is a string:
%                 - if absolute, the returned time is a date vector
%                   representing the string
%                 - if otherwise, the returned time is the time in seconds
%                   since the date vector
%
% time_str      - if the first input is numeric, the output time_str is the
%                 string representing of time 


if (nargin < 5) || (numel(max_prec) == 0)
    max_prec = 4;
else
    max_prec = min(ceil(abs(max_prec)), 19);
end
    
% define date formats
h_format = 'HH:MM:SS';
h_format_ms = 'HH:MM:SS:MS';
d_format = 'yyyy-mm-dd';

% what input type?
style = isnumeric(time) * (1 + (numel(time) > 1));  % 0 = string input
                                                    % 1 = time in seconds
                                                    % 2 = date vector

% conversion for older style input
if islogical(hhmmss)
    hhmmss = double(hhmmss);
end


% build the formating
if (hhmmss == 1)
    format = h_format;
elseif (hhmmss == 2)
    format = h_format_ms;
else
    format = 's';
end

% and the date format if desired
if (absolute)
    format = sprintf('%s %s', d_format, format);
end

% check the form of date_vec
if (numel(date_vec) == 0)
    date_vec = zeros(1,6);  % a null date vector
elseif (numel(date_vec) == 1) && (date_vec == 0)
    date_vec = zeros(1,6);  % a null date vector
elseif (numel(date_vec) == 1)
    date_vec = datevec(date_vec);  % assume date_vec is a matlab date number
end


if (style > 0)
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % In this case we want to output a string
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % if a time in seconds is inputted turn it into a time vector
    if (style == 1) && (absolute)
        time_vec = AddTimeToDateVec(date_vec, time);
    elseif (style == 1)
        time_vec = AddTimeToDateVec(zeros(1,6), time);
    elseif (absolute) && all(time(1:2) == 0)
        time_vec = AddDateVectors(time, date_vec);  % add the date vctor to the inputted time vector
    elseif (~absolute) && any(time(1:2) ~= 0)
        time_vec = AddDateVectors(time, -date_vec);
    else
        time_vec = time;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%
    % create a string
    %%%%%%%%%%%%%%%%%%%%%%
    
    % come up with a date string?
    if (absolute)
        
        % come up with a string for the data
        date_str = datestr(time_vec, d_format);
        date_str(end+1) = ' ';  % add a space
        time_vec(1:3) = 0;      % the year month and days is now represented
    else
        date_str = '';
    end
    
    % convert the date vector to a time in seconds
    time = etime(time_vec, zeros(1,6));
    
    if (hhmmss > 0)
    
        % hours
        nh = floor(time / 3600);
        time_str = sprintf('%02i', nh);
        time = time - 3600 * nh;
        
        % minutes?
        nm = floor(time / 60);
        time_str = sprintf('%s:%02i',time_str, nm);
        time = time - 60 * nm;
        
        % seconds
        if (hhmmss == 1)
            ns = time;
            s_str = [repmat('0', 1, ns < 10), sprintf(['%0.', num2str(max_prec), 'f'], ns)];
            time_str = sprintf('%s:%s', time_str, s_str);
        else
            
            % this version has ms seperatley
            ns = floor(time);
            time_str = sprintf('%s:%02i', time_str, ns);
            time = time - ns;
            
            if (time > 0)
                ms = time * 1000;
                nz = min(2 - floor(log10(ms)), 2);  % num2str gives a leading zero even for decimals
                ms_str = [repmat('0', 1, nz), sprintf(['%0.', num2str(max_prec), 'f'], ms)];
                time_str = sprintf('%s:%s', time_str, ms_str);
            else
                time_str = sprintf('%s:000', time_str);
            end
        end
        
        % trim trailing zeros from the string
        time_str = TrimDecimals(time_str);
        
    else
        time_str = num2str(time);
    end

    % and assign output
    varargout{1} = [date_str, time_str];
    
else
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % create a time in seconds from the input string
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    time_str = time;
    date_str = '';
    
    % break up the string into date and time
    space_ind = find(time_str == ' ', 1, 'first');
    if (numel(space_ind))
        date_str = time_str(1:space_ind-1);
        time_str = time_str(space_ind+1:end);
    end
    
    % correct order?
    if any(date_str == ':') || any(time_str == '-')
        [date_str, time_str] = deal(time_str, date_str);
    end
    
    % initialise the output to be a time vector (for now)
    if numel(date_str)
        time_vec = datevec(date_str, d_format);
    else
        time_vec = zeros(1,6);
    end
    
    % initialise the current time
    if (numel(time_str))

        % in hours mins and seconds or just seconds
        if (hhmmss > 0)
            
            [tokens, other] = regexp(time_str, ':', 'split');
            if (numel(tokens) ~= (3 + (hhmmss == 2)))
                error('String: %s does not match the specified format');
            end
            
            % convert tokens to numerics
            values = cellfun(@str2double, tokens);
            if any(isnan(values))
                error('Error converting time string %s to time', time_str);
            end
            
            % change to a time in seconds
            time_s = 0;
            for i = 1:3
                time_s = time_s + values(i) * 60^(3-i);
            end
            
            % include ms
            if (numel(values) == 4)
                time_s = time_s + values(4) * 1e-3;
            end
            
        else
            time_s = str2double(time_str);
        end
        
        % check the conversion was valid
        if isnan(time_s)
            error('Error converting time string: %s to time', time_str);
        end
        
        % add to date can't handle fractional seconds, so remove them
        frac_secs = rem(time_s,1);
        time_s = fix(time_s);
        if (frac_secs < 0)
            time_s = time_s - 1;
            frac_secs = 1 + frac_secs;
        end
            
        % now create the time vector
        time_vec = AddTimeToDateVec(time_vec, time_s);
        time_vec(end) = time_vec(end) + frac_secs;
    end
    
    % output absolute or relative time?
    if (~absolute)
        if (time_vec(1) > 0)
            time = etime(time_vec, date_vec);
        else
            time = time_s + frac_secs;
        end
    elseif (time_vec(1) == 0)
        time = AddDateVectors(time_vec, date_vec);  % add the date vector to it
    else
        time = time_vec;
    end
    
    % assign output
    varargout{1} = time;
end

if (nargout == 2)
    varargout{2} = format;
end
    
