function output = AddDateVectors(dv_A, dv_B)
% function dv_A = AddDateVectors(date_vec_A, date_vec_B)
% function to add / subtract date vectors 
% this function assume both date vectors are "sanitized" on input
% (datevec(datenum(date_vec)) will sanitize date_vec)
%
% Notes: 
%
% 1) if the year and month of an input date vector are both 0, the
%    date vector is assumed to contain an ellapsed time rather than an 
%    absolute date
%
% 2) adding absolute dates doesn't make much sense...
%
% 3) if its an absolute date minus another absolute date, the output date
%    vector will not have year or month filled because it will be treated as
%    an ellapsed time (months don't make sense with ellapsed times
%
% 4) if one input is an absolute date and the other is an ellapsed time,
%    the output will be an absolute date
%
% 5) both inputs are ellapsed times, the output is treated as an ellapsed time, 
%    so the date vector will not have year or month filled 
%    (months don't make sense with ellapsed times

% check inputs are date vectors
if (numel(dv_A) ~= 6)
    error('First input is not a date vector')
end
if (numel(dv_B) ~= 6)
    error('Second input is not a date vector')
end

% check inputs have a consistent sign
dvA_sign = sign(dv_A);
dvB_sign = sign(dv_B);
if (any(dvA_sign > 0) && any(dvA_sign < 0)) || (any(dvB_sign > 0) && any(dvB_sign < 0))
    error('Input date vectors must have a consistent sign across all fields');
end

% reduce the sign to a scalar
dvA_sign = 1 - 2*any(dvA_sign < 0);    
dvB_sign = 1 - 2*any(dvB_sign < 0);

% do they represent absolute or ellapsed times?
ellA = all(dv_A(1:2) == 0);
ellB = all(dv_B(1:2) == 0);

if (~ellA) && (~ellB) && (dvA_sign == dvB_sign)
    warning('Adding two absolute times');
end

% is the expected result an ellpased time or an absolute time?
output_ell = (~ellA) && (~ellB) && (dvA_sign ~= dvA_sign);  % note (3) above
output_ell = output_ell ||~xor(ellA, ellB);                 % note (4) above
output_ell = output_ell || (ellA && ellB);                  % note (5) above


    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% see if the operation causes wrapping
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

output = dv_A + dv_B;  % result after addition

% the minimum of the maximum allowable value for each field
element_max = [inf,12,27,24,60,60];

% which fields have "wrapped"
wrapped = any((output < 0) | (output > element_max));
wrapped = wrapped || (any(output(1:2) > 0) && output_ell);  % count it as wrapped if we have months in an ellapsed time
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we do, use time stamps to sort it out
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (wrapped)

    % tstamps don't handle fractional seconds well, so handle seconds ourselves
    seconds = dv_A(end) + dv_B(end);
    dv_A(end) = 0;
    dv_B(end) = 0;
    frac_secs = seconds - floor(seconds);
    seconds = floor(seconds);
    
    % apply sign to make them both +ve for now
    dv_A = dv_A * dvA_sign;
    dv_B = dv_B * dvB_sign;
    
    % if we're subtracting from a -ve value, add the absolutes and negate the result
    dbl_neg = (dvA_sign == -1) && (dvb_sign == 1);
    if (dbl_neg)
        dvA_sign = 1;
        dvB_sign = 1;
    end
    
    % convert them both to time stamps
    tstampA = datenum(dv_A);
    tstampB = datenum(dv_B);
    
    % now add them
    tstamp = dvA_sign * tstampA + dvB_sign * tstampB;
    
    % add seconds
    tstamp = addtodate(tstamp, (1-2*dbl_neg) *  seconds, 'second');
    
    % ensure tstamp is +ve
    if (tstamp < 0)
        dbl_neg = ~dbl_neg;
        tstamp = -tstamp;
    end
    
    % convert back to a date vector
    if (output_ell)  % don't allow months in an ellapsed time
        days = fix(tstamp);
        tstamp = tstamp - days;
    end
    output = datevec(tstamp);
    
    % negate the results
    if (dbl_neg)
        output = -output;
    end
    
    % and put fractinoal seconds back in
    output(end) = output(end) + frac_secs;
    
    % insert days back into the ellapsed time
    if (output_ell)
        if (dbl_neg)
            output(3) = -days;
        else
            output(3) = days;
        end
    end
        

end





