function [relTime, indexs] = TimeRangeToRelative(data_set, timeRange)
% function TimeRangeToRelative(data_set, tstamps)
% convert an absolute time stamp into a time in seconds and index
% within the data set
% timeRange is a cell with two date vectors

% convert time stamps to times in seconds relative to the data set start
relTime(2) = etime(timeRange{2}, data_set.tstamp);  % etime does handles fractional seconds
relTime(1) = etime(timeRange{1}, data_set.tstamp);
indexs = round(data_set.fs * relTime);
indexs(1) = max(indexs(1),1);
if (indexs(2) > data_set.num_points)          % can happen when the number of points was unknown when the export time range was created
    indexs(2) = data_set.num_points;  
    relTime(2) = indexs(2) / data_set.fs;
end

% sanity check
if any(indexs ~= round(indexs))
    error('TimeRangeToRelative: Non integer index supplied');
elseif any((indexs < 1) | (indexs > data_set.num_points))
    error('TimeRangeToRelative: indexs / times requested are beyond the range of the data set');
end