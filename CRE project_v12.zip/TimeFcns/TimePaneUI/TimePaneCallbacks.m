function TimePaneCallbacks(hObject, eventdata, handles)
% function TimePaneCallbacks(hObject, eventdata, handles)
% this function has the callbacks for the ui components of the time pane

try

    % ensure handles are available
    if (nargin < 3)
        handles = guidata(hObject);
    end
    
    % get which ui componenent it is from the tag
    tag = get(hObject, 'tag');
    
    if strcmpi(tag, 'rbAllTime')
        
        % force full time rang for batch mode
        if ~strcmpi(handles.data_set.set_type, 'batch')  
            
            handles.timeInfo.full = get(hObject, 'value');
            
            % and update what's displayed on the panele
            handles = UpdateTimePaneValues(handles);
            
        else
            set(hObject, 'value', 1); % keep this selected
            return;
        end
        
    elseif strcmpi(tag, 'rbPartTime')
        
        handles.timeInfo.full = ~get(hObject, 'value');
        
        % and update what's displayed on the panele
        handles = UpdateTimePaneValues(handles);
        
    % and switch based on the tag
    elseif strcmpi(tag, 'ebStartTime')
        
        % run the callback
        handles = CheckTimeRange(hObject, 1, 1, handles);
        
    elseif strcmpi(tag, 'ebStartDate')
        
        % run the callback
        handles = CheckTimeRange(hObject, 1, 2, handles);
        
    elseif strcmpi(tag, 'pbStartDate')
        
        % generate a calendar  display
        uicalendar('DestinationUI', {handles.ebStartDate, 'string'}, 'InitDate', datenum(floor(handles.timeInfo.tstamp{1})), 'OutputDateFormat', 'yyyy-mm-dd');
        
        % and check
        handles = CheckTimeRange(handles.ebStartDate, 1, 2, handles);
        
    elseif strcmpi(tag, 'ebEndTime')
        
        % run the callback
        handles = CheckTimeRange(hObject, 2, 1, handles);
        
    elseif strcmpi(tag, 'ebEndDate')
        
        % run the callback
        handles = CheckTimeRange(hObject, 2, 2, handles);
        
    elseif strcmpi(tag, 'pbEndDate')
        
        % generate a calendar  display
        uicalendar('DestinationUI', {handles.ebEndDate, 'string'}, 'InitDate', datenum(floor(handles.timeInfo.tstamp{2})), 'OutputDateFormat', 'yyyy-mm-dd');
        
        % and check
        handles = CheckTimeRange(handles.ebEndDate, 2, 2, handles);
        
    elseif strcmpi(tag, 'rbIndexs')
        
        % get the state
        handles.timeInfo.is_time = ~get(hObject, 'value');
        set(handles.rbTimes, 'value', handles.timeInfo.is_time);
        
        % and update what's displayed on the panele
        handles = UpdateTimePaneValues(handles);
        
    elseif strcmpi(tag, 'rbTimes')
        
        % get the state
        handles.timeInfo.is_time = get(hObject, 'value');
        set(handles.rbIndexs, 'value', ~handles.timeInfo.is_time);
        
        % and update what's displayed on the panele
        handles = UpdateTimePaneValues(handles);
        
    elseif strcmpi(tag, 'rbHHMMSS')
        
        % get the state
        handles.timeInfo.is_hhmmss = get(hObject, 'value');
        
        % and update what's displayed on the panele
        handles = UpdateTimePaneValues(handles);
        
        
    elseif strcmpi(tag, 'rbRelTime')
        
        % get the state
        handles.timeInfo.is_relative = get(hObject, 'value');
        
        % and update what's displayed on the panele
        handles = UpdateTimePaneValues(handles);
        
    end
    
    % are selections OK?
    EnableDisableOutput(handles);
    
    % and update the handles
    guidata(hObject, handles);
    
    
catch
    
    % what's the current figure?
    hFig = ancestor(hObject, 'figure');
    if numel(hFig) && strcmpi(get(hFig, 'tag'), 'CREFeatureGui')
        
        % It has a dedicated error handler
        ProcessFeatureGuiError(ME);
    
    else
        
        if (~IsDeveloper)
            errordlg('Unable to process requested feature', 'Error', 'modal');
        else
            rethrow(ME);
        end
    end
    hFig = get(0, 'currentfigure');
    if numel(hFig) && strcmpi(get(hFig, 'tag'), 'CREFeatureGui')
        
        % It has a dedicated error handler
        ProcessFeatureGuiError(ME);
    
    else
        
        if (~IsDeveloper)
            errordlg('Unable to process requested time option', 'Error', 'modal');
        else
            rethrow(ME);
        end
    end
    
    
    
end



function handles = CheckTimeRange(hObject, start, time, handles)
% function CheckTimeRange(hObject, start, time, handles)
% function to do everything when the grab range is changed
% start = 1 is the start date / time
% start = 0 is the end date / time
% time = 1 is a time
% time = 0 is a date

% first try to turn what was inputted into a date vector
string = get(hObject, 'string');

if (handles.timeInfo.is_time && ~handles.timeInfo.is_relative)
    
    % in this case we need to combine date and time
    if (start == 1)
        if (time == 1)
            string = sprintf('%s %s', get(handles.ebStartDate, 'string'), string);
        else
            string = sprintf('%s %s', string, get(handles.ebStartTime, 'string'));
        end
    else
        if (time == 1)
            string = sprintf('%s %s', get(handles.ebEndDate, 'string'), string);
        else
            string = sprintf('%s %s', string, get(handles.ebEndTime, 'string'));
        end
    end
end

try % in case of invalid string
    
    % turn it into an absolute date vector
    tstamp = feval(handles.timeInfo.TimeFcn, string);
    
    % convert to a time in seconds to enforce it being in range
    time_sec = etime(tstamp, handles.timeInfo.ds_stamp{1});
    duration = handles.data_set.num_points / handles.timeInfo.fs;
    
    % is it in range? (give some lee-way because its easy to go over / under with string truncation)
    if (time_sec >= -1) && (time_sec <= (duration + 1))
        
        % enforce max min
        time_sec = min(max(time_sec, 0), duration);
        
        % convert back to a time stamp
        handles.timeInfo.tstamp{start} = AddTimeToDateVec(handles.timeInfo.ds_stamp{1}, time_sec);
        
        % round it in case it was a time
        overlap = etime(handles.timeInfo.tstamp{2}, handles.timeInfo.tstamp{1}) <= 0;
        
        % set it
        if (~overlap)  
            
            % it's fine, remove this control from the block list
            handles.block_list = handles.block_list(handles.block_list ~= hObject);
            
            % check if this undid overlap problems
            if any(handles.block_list == handles.ebStartTime)

                % is it blocked because of overlap?
                di = find(handles.timeInfo.tstamp{1} ~= handles.timeInfo.tstamp{2}, 1, 'first');
                if (numel(di) > 0) && (handles.timeInfo.tstamp{1}(di) < handles.timeInfo.tstamp{2}(di))
                    
                    % call the minimum change callback to fix
                    handles = CheckTimeRange(handles.ebStartTime, 1, 1, handles);
                    
                end
            end
            
        elseif ~any(handles.block_list == handles.ebStartTime)
            
            % always block using the start time's time eb
            handles.block_list(end+1) = handles.ebStartTime;
        end
        
    elseif ~any(handles.block_list == hObject)
        
        % block the "OK" output
        handles.block_list(end+1) = hObject;
    end

catch
    if ~any(handles.block_list == hObject)
        handles.block_list(end+1) = hObject;
    end
end








    
    


