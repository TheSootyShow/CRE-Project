function varargout = CREBatchSet(varargin)
% CREBATCHSET MATLAB code for CREBatchSet.fig
%      CREBATCHSET, by itself, creates a new CREBATCHSET or raises the existing
%      singleton*.
%
%      H = CREBATCHSET returns the handle to a new CREBATCHSET or the handle to
%      the existing singleton*.
%
%      CREBATCHSET('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CREBATCHSET.M with the given input arguments.
%
%      CREBATCHSET('Property','Value',...) creates a new CREBATCHSET or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CREBatchSet_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CREBatchSet_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CREBatchSet

% Last Modified by GUIDE v2.5 18-May-2015 22:58:47

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREBatchSet_OpeningFcn, ...
                   'gui_OutputFcn',  @CREBatchSet_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CREBatchSet is made visible.
function CREBatchSet_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CREBatchSet (see VARARGIN)

% store the data set here
handles.batch_set = InitDataStruct();
handles.batch_set.set_type = 'batch';
handles.batch_set.ds_headers = repmat(InitDataStruct(), 0, 1);

% Choose default command line output for CreateBatchSetOld
handles.output = {'Cancel', handles.batch_set};

% resize it
handles = BatchSetLayout(hObject, eventdata, handles);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CREBatchSet wait for user response (see UIRESUME)
uiwait(handles.CREBatchSet);


% --- Executes during object creation, after setting all properties.
function Default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbFiles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Outputs from this function are returned to the command line.
function varargout = CREBatchSet_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
if numel(handles)
    varargout = handles.output(1:nargout());
    
    % The figure can be deleted now
    delete(handles.CREBatchSet);

else
    % already deleted ???
    output = {'Cancel', []};
    varargout = output(1:nargout());
end




% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {'Cancel', handles.batch_set};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CREBatchSet);



% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {'OK', handles.batch_set};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CREBatchSet);



% --- Executes on selection change in lbFiles.
function lbFiles_Callback(hObject, eventdata, handles)
% hObject    handle to lbFiles (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbFiles contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbFiles


% --- Executes on selection change in lbDims.
function lbDims_Callback(hObject, eventdata, handles)
% hObject    handle to lbDims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbDims contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbDims


% --- Executes on button press in pbAdd.
function pbAdd_Callback(hObject, eventdata, handles)
% hObject    handle to pbAdd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

last_dir = DataLoadDir();

% prompting the user
[file_names, dir_name] = uigetfile('*.csv', 'Add CSV file(s) to the batch set. Use ctrl to select multiple', last_dir, 'Multiselect', 'on');

if iscell(file_names)
    
    % add path
    file_names = cellfun(@(str)fullfile(dir_name, str), file_names, 'uniformoutput', false);
    added = false(size(file_names));
    
    % load each one
    for i = 1:numel(file_names)
        
        % check its not already included
        in_set = false;
        for j = 1:numel(handles.batch_set.ds_headers)
            in_set = strcmpi(file_names{i}, handles.batch_set.ds_headers(j).file_name);
        end
        
        % grab the header data
        if (~in_set)
            try
                
                % load header to get sampling frequency / dimensions
                opts = InitOptions();
                opts.view_type = 1;
                new_data_set = ImportCSV(file_names{i}, opts);
                                
                % indicate success
                added(i) = true;
                
                % lump it in
                handles.batch_set.ds_headers(end+1,1) = new_data_set;
                
            catch ME
                errordlg(sprintf('Unable to add %s to the batch set:\n%s', file_names{i}, ME.message));
            end
        end
    end
    if any(added)
	
		% update the data directory
		DataLoadDir(dir_name);
        
        % update
        handles.batch_set = BatchSetFromDataSets(handles.batch_set.ds_headers, get(handles.ebName, 'string'));
        
        % display
        DisplayBatchSet(handles, handles.batch_set);
    end
    
    % update the handles
    guidata(hObject, handles);
    
end



% --- Executes on button press in pbRemove.
function pbRemove_Callback(hObject, eventdata, handles)
% hObject    handle to pbRemove (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

file_list = get(handles.lbFiles, 'string');
if ~iscell(file_list)
    file_list = {file_list};
end
selection = get(handles.lbFiles, 'value');

if numel(selection)
    
    % remove them
    handles.batch_set = BatchSetRemoveDataSets(handles.batch_set, file_list(selection));
    
    % display
    set(handles.lbFiles, 'value', []);
    DisplayBatchSet(handles, handles.batch_set);
    
    % update the handles
    guidata(hObject, handles);
    
end



function ebName_Callback(hObject, eventdata, handles)
% hObject    handle to ebName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebName as text
%        str2double(get(hObject,'String')) returns contents of ebName as a double

name = get(handles.ebName, 'string');
if numel(name)
    handles.batch_set.name = name;
    guidata(hObject, handles);
end



% --------------------------------------------------------------------
function miLoad_Callback(hObject, eventdata, handles)
% hObject    handle to miLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call save routine
batch_set = LoadBatchSet();
if numel(batch_set)
    handles.batch_set = batch_set;
    DisplayBatchSet(handles, batch_set);
    guidata(hObject, handles);
end


% --------------------------------------------------------------------
function miSave_Callback(hObject, eventdata, handles)
% hObject    handle to miSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call save routine
SaveBatchSet(handles.batch_set);



function DisplayBatchSet(handles, batch_set)
% function DisplayBatchSet(handles, batch_set)
% function to display the batch set

% show mlfile names
csv_names = cell(numel(batch_set.ds_headers), 1);
for i = 1:numel(csv_names)
    csv_names{i} = batch_set.ds_headers(i).file_name;
end
set(handles.lbFiles, 'string', sort(csv_names));
set(handles.lbFiles, 'max', max(numel(csv_names),2));

% show dimensions
set(handles.lbDims, 'string', batch_set.dim_names(:));
set(handles.lbDims, 'min', 0, 'max', 0);

% name and sampling frequency
set(handles.ebName, 'string', batch_set.name);
set(handles.txtMinFs, 'string', sprintf('Minimum Fs: %0.2f Hz', batch_set.fs));
