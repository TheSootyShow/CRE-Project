function batch_set = SetBatchActiveSet(batch_set, dsIdx)
% function batch_set = SetBatchActiveSet(batch_set, dsIdx)
% changes the batch mode active set (which one is displayed)

if (dsIdx < 1) || (dsIdx > (numel(batch_set.ds_headers)))
    error('Invalid option');
end

% change the file name
batch_set.file_name = batch_set.ds_headers(dsIdx).file_name;

% use the time
batch_set.tstamp = batch_set.ds_headers(dsIdx).tstamp;

% load it if needed
if (numel(batch_set.ds_headers(dsIdx).num_points) == 0) || (batch_set.ds_headers(dsIdx).num_points <= 0)
    opts = InitOptions();
    opts.view_type = 1;
    batch_set.ds_headers(dsIdx) = ImportCSV(batch_set.ds_headers(dsIdx).file_name, opts);
end





