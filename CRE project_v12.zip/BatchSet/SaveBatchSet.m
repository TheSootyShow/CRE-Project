function SaveBatchSet(batch_set, file_name)
% function SaveBatchSet(batch_set, file_name)
% function to save the batch mode set

persistent save_dir

if (numel(save_dir) == 0)
    save_dir = DataSaveDir();
end

% check its filled
if (numel(batch_set.ds_headers) == 0)
    errordlg('This batch set has no datasets to save!', 'Save File', 'modal');
    return;
end

% was the filename specified?
if (nargin < 2) || (numel(file_name) == 0)
    [file_name, path] = uiputfile('*.mat', 'Save batch data to:', fullfile(save_dir, SanitizeFileName([regexprep(batch_set.name, '\s+', '_'), '.mat'], false, false)));
    if ~ischar(file_name)
        return;
    else
        file_name = fullfile(path, file_name);
    end
end

% update default save location
save_dir = fileparts(file_name);

% ensure we don't save data or file pointers
for i = 1:numel(batch_set.ds_headers)
    
    batch_set.ds_headers(i).file_ptr = -1;
    batch_set.ds_headers(i).data = [];
    
    % add a hash field to check for changes
    batch_set.ds_headers(i).hash = GetFileHash(batch_set.ds_headers(i).file_name, batch_set.ds_headers(i).hbytes);
    
end

% and save
save(file_name, 'batch_set', '-mat');
    


