function batch_set = LoadBatchSet(file_name)
% function batch_set = SaveBatchSet(batch_set, file_name)
% function to load a batch mode set
% return empty on failure


persistent load_dir

if (numel(load_dir) == 0)
    load_dir = DataLoadDir();
end

% was the filename specified?
if (nargin < 1) || (numel(file_name) == 0)
    [file_name, path] = uigetfile('*.mat', 'Load batch set:', load_dir);
    if ~ischar(file_name)
        batch_set = [];
        return;
    else
        file_name = fullfile(path, file_name);
    end
end

% update default save location
load_dir = fileparts(file_name);

% and load it
tmp  = load(file_name, '-mat');
fnames = fieldnames(tmp);
batch_set = tmp.(fnames{1});

% batch_set should have the same fields as InitDataStruct()
refFields = fieldnames(InitDataStruct());
currFields = fieldnames(batch_set);
if ~all(ismember(currFields, refFields)) || (numel(batch_set.ds_headers) == 0)
    errordlg(sprintf('%s does not appear to be a valid batch set', file_name), 'File Error:', 'modal');
    batch_set = [];
    return;
end

% check the file locations exist
fileExists = false(size(batch_set.ds_headers));
files = cell(size(fileExists));
for i = 1:numel(fileExists)
    files{i} = batch_set.ds_headers(i).file_name;
    fileExists(i) = exist(files{i}, 'file');
end

% check all the individual data sets exist
if any(~fileExists)
    files = files(~fileExists);
    msg = sprintf('The following data sets could not be located:\n');
    for i = 1:numel(files)
        msg = sprintf('%s\t%s\n', msg, files{i});
    end
    msg = sprintf('%s\nPlease recreate the batch set', msg);
    errordlg(msg, 'File Error:', 'modal');
    batch_set = [];
    return;
end

% check the data is ok for each
for i = 1:numel(files)
    
    % check its unchanged
    if ~all(batch_set.ds_headers(i).hash == GetFileHash(files{i}, batch_set.ds_headers(i).hbytes));
        opts = InitOptions();
        opts.view_type = 1;
        batch_set.ds_headers(i) = ImportCSV(files(i), opts);
    end
end

% remove the hash field
batch_set.ds_headers = rmfield(batch_set.ds_headers, 'hash');





