function ui_size = PaneSizesFromGrid(hGrid)
% function ui_size = PaneSizesFromGrid(hGrid)
% this function is designed to get the preferred sizes of each handle in
% the handle grid.  It is designed to be used in conjuction with 
% ResizePaneFromGrid.m.  all uicomponents must be visible!
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% hGrid   - a cell array of handles to gui objects which determines there
%                 place in the pane.  
%               - set a cell empty for a blank "place"
%               - repeat the handle to stretch it across mutliple rows /
%                 columns
%               - use h=%g or v=%g for indents
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% ui_size       - a cell array the same size as handles grid.  Each cell is
%                 the [width, height] of the component in pixels
% 

% get the sizes
[n_rows, n_cols] = size(hGrid);
ui_size = cell(size(hGrid));
is_rb = false(size(hGrid));  % which are radio buttons?

% which have entries
filled = cellfun(@(x)(numel(x)>0), hGrid);

for i = n_rows:-1:1
    
    for j = 1:n_cols
        
        % is this a place holder string?
        if (filled(i,j) && ischar(hGrid{i,j}))
            
            % assume this is a spacing column interpret the string
            [width, height] = SizeFromString(hGrid{i,j});
            ui_size{i,j} = [width, height];
            
        
        % only look at existing ones and 1 copy of each
        elseif filled(i,j) && (~((i < n_rows) && filled(i+1,j) && isequal(hGrid{i,j}, hGrid{i+1,j}))) && (~((j > 1) && filled(i,j-1) && isequal(hGrid{i,j}, hGrid{i,j-1})))
            
            % change to pixels
            old_units = get(hGrid{i,j}, 'units');
            set(hGrid{i,j}, 'units', 'pixels');
            
            % is it a uicontrol?
            if ~strcmpi(get(hGrid{i,j}, 'type'), 'uicontrol');
                
                % if its not a uicontrol, assume it has no java object and
                % just use its current size
                pos = get(hGrid{i,j}, 'position');
                width = pos(3);
                height = pos(4);
        
            % is it anything we just use the raw size for?
            elseif any(strcmpi(get(hGrid{i,j}, 'style'), {'text', 'popupmenu'}))
                    
                % use its preferred size
                [height, width] = GetPreferredSize(hGrid{i,j}, true);
                
            elseif any(strcmpi(get(hGrid{i,j}, 'style'), {'edit'}))
                
                % get its current size
                pos = get(hGrid{i,j}, 'position');
                    
                % use the preferred height but keep the users width
                [height, width] = GetPreferredSize(hGrid{i,j}, true);
                width = max(pos(3), width);

                
            elseif any(strcmpi(get(hGrid{i,j}, 'style'), {'radiobutton','checkbox'}))
                
                % use its preferred size
                [height, width] = GetPreferredSize(hGrid{i,j}, true);
                is_rb(i,j) = true;
                
            elseif any(strcmpi(get(hGrid{i,j}, 'style'), {'listbox'}))

                % grow list boxes horizontally but not vertically
                [height, width] = GetPreferredSize(hGrid{i,j}, true);
                
                % get its current size
                pos = get(hGrid{i,j}, 'position');
                height = pos(4);
                
            else
                
                % if we arent sure use the maximum of its current size and
                % its preferred size
                if ~any(strcmpi(get(hGrid{i,j}, 'style'), {'listbox', 'pushbutton'}))
                    fprintf('PaneSizesFromGrid::Unknown control type: %s\n', get(hGrid{i,j}, 'style'));
                end
                [height, width] = GetPreferredSize(hGrid{i,j}, true);
                pos = get(hGrid{i,j}, 'position');
                width = max(width, pos(3));
                height = max(pos(4), height);
                
            end
            
            % restore old units
            set(hGrid{i,j}, 'units', old_units);
            
            % and assign
            ui_size{i,j} = [width, height];
            
        end
    end
end


function [width, height] = SizeFromString(str)
%function [width, height] = SizeFromString(str)
% interprets a string to get size info
% acceptable units are "pix" (default unit),
% or "cm" for centimeters, or "in" for inches

% default to unspecified
width = 0;
height = 0;

% look for a vertical size
horz_str = regexp(str, '(?<=h\=)(\d*[\.+\d+])+[(cm|pix|in)]*', 'match', 'once');
if numel(horz_str)
    
    % strip the unit
    units = regexp(horz_str, '(cm|pix|in)$', 'match', 'once');
    width = abs(str2double(horz_str(1:end-numel(units))));
    if isnan(width)
        error('Failed to interpret spacing string: %s', str);
    end
    
    % apply the unit
    if (numel(units))
        width = UnitConversion(width, units);
    end
    width = ceil(width);
end

% look for a vertical size
vert_str = regexp(str, '(?<=v\=)(\d*[\.+\d+])+[(cm|pix|in)]*', 'match', 'once');
if numel(vert_str)
    
    units = regexp(vert_str, '(cm|pix)$', 'match', 'once');
    height = abs(str2double(vert_str(1:end-numel(units))));
    if isnan(height)
        error('Failed to interpret spacing string: %s', str);
    end
    
    % apply the unit
    if (numel(units))
        height = UnitConversion(height, units);
    end
    height = ceil(height);
end

function value = UnitConversion(value, unit)
% function value = UnitConversion(value, unit)
% converts the value in a given units to another unit

if strcmpi(unit, 'in')
    
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    value = value * ppi;

elseif strcmpi(unit, 'cm')
    
    % add extra distance from the frame to the text
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    value = value * ppcm;

    
end







