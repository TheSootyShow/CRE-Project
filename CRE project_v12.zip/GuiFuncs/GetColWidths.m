function [col_widths, ext_min, ext_max] = GetColWidths(hGrid, widths, vert_copies, horz_copies, hspace, allow_leak)
% function [col_widths, ext_min, ext_max] = GetColWidths(hGrid, widths, vert_copies, horz_copies, hspace, allow_leak)
% this function determines the minimum columns widths for a grid of objects
% with widths specified in "widths".  
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% hGrid         - a cell array of the handles to the uicomponents.  [] if the
%                 space is empty, repeated if its desired to stretch the
%                 component
%
% widths        - the width of the object
% 
% vert_copies   - the number of rows an object is spread over. 
%
% horz_copies   - the number of columns an object is spread over. 
%
% allow_leak    - if true, objects are allowed to "leak" into unpopulated
%                 parts of the grid


% the size of the inputs
[n_rows, n_cols] = size(hGrid);

% which ones are filled and which are actually handles?
is_filled = cellfun(@(x)(numel(x) > 0), hGrid);
is_handle = cellfun(@(x)((numel(x) > 0) && isnumeric(x) && ishandle(x)), hGrid);


% pad out the widths so each ui object that only uses one column has a width
widths_pad = widths;
horz_copies_pad = horz_copies;
[r, c] = find(vert_copies > 1);
for i = 1:numel(r)
    % adjust these columns
    r_adj = r(i):-1:r(i)-vert_copies(r(i), c(i))+1;
    widths_pad(r_adj, c(i)) = widths(r(i), c(i));
    horz_copies_pad(r_adj, c(i)) = horz_copies(r(i), c(i));
end


% the "pure" width (i.e. only objects with 1 copy per row)
use = (horz_copies_pad == 1);
if (allow_leak)
   use(:, 2:end)   =  use(:, 2:end) & is_filled(:, 1:end-1);
   use(:, 1:end-1) =  use(:, 1:end-1) & is_filled(:, 2:end);
end
width_adj  = widths_pad .* use;

% add the horizontal gap (but ignore it if there're two things the same next
% to each other, i.e. a repeated uiobject)
ignore_mask_w = cellfun(@(x,y)((numel(x) == 0) || ~isnumeric(x) || (numel(y) == 0) || ~isnumeric(y) || isequal(x,y)), hGrid(:, 1:end-1), hGrid(:, 2:end));            % dont care about the gap in this case
width_net = [width_adj(:,1:end-1) + (~ignore_mask_w) .* hspace, width_adj(:, end)];
gap = width_net - width_adj;  % individual gaps

% widths based on only the "pure" ones
col_widths = max(width_net, [], 1);

% remember the column gap for each column
col_gap = min(repmat(col_widths, n_rows, 1) - width_adj, [], 1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create a map of how things spread over the columns
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pre_width = zeros(size(widths));
post_width = zeros(size(widths));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Do the undetermined ones in two stages
% stage 1 are ui components that can't leak
% stage 2 are ui components that do leak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% keep track of how much we have spread into a column
used_leakage = zeros(size(widths));

% this is convenient
hspace = [hspace, zeros(n_rows, 1), hspace];

processed = use | (horz_copies == 0);
for s = 1:(1+allow_leak)
    
    if (s == 1)  % first stage, do ones that stretch but dont leak
        
        if (allow_leak)
            
            % find the ones that are stretch but don't leak
            [r,c] = find(horz_copies > 1);
            stretch = true(1, numel(r));
            for i = 1:numel(r)
                
                % look at these rows
                r_adj = r(i)-vert_copies(r(i), c(i))+1:r(i);
                
                % look at the columns
                c_adj = c(i):c(i)+horz_copies(r(i), c(i))-1;
                
                % width already allocated
                alloc_width = sum(col_widths(c_adj));
                
                % does it already have enough space
                if (alloc_width < widths(r(i), c(i)))
                    
                    % nope - check if it can leak
                    if (c_adj(1) > 1) && all(~is_filled(r_adj(1)-1, c_adj))
                        stretch(i) = false;
                    elseif (c_adj(end) < n_cols) && all(~is_filled(r_adj(end)+1, c_adj))
                        stretch(i) = false;
                    end
                end
            end
            r = r(stretch);
            c = c(stretch);
            
        else
            
            % all of them in this case
            [r,c] = find(~processed);
        end
    else
        
        % stage two -  do the one that leak
        [r,c] = find(~processed);
        req_space = zeros(1, numel(r));
        
        % do the ones that are closest to fitting first
        for i = 1:numel(r)
            
            % look at these rows
            r_adj = r(i)-vert_copies(r(i), c(i))+1:r(i);
            
            % look at the columns
            c_adj = c(i):c(i)+horz_copies(r(i), c(i))-1;
            
            % width already allocated
            alloc_width = sum(col_widths(c_adj));
            
            % height already allocated to the above leak zone
            left = c_adj(1)-1;
            while (left >= 1) && all(~is_filled(r_adj, left))
                alloc_width = alloc_width + col_widths(left);
                left = left - 1;
            end
            right = c_adj(end)+1;
            while (right <= n_cols) && all(~is_filled(r_adj, right))
                alloc_width = alloc_width + col_widths(right);
                right = right + 1;
            end
            
            % how much extra space is required (can be over allocated already)
            req_space(i) = widths(r(i), c(i)) - alloc_width;
            
        end
        
        % order them - do the ones that require the minimum changes first
        [vals, order] = sort(req_space);
        r = r(order);
        c = c(order);
        
%         % mark the ones that already fit as processed
%         fits = (vals <= 0);
%         processed(r(fits) + (c(fits)-1)+n_rows) = true;
%         r = r(~fits);
%         c = c(~fits);
        
    end
    
    for i = 1:numel(r)
        
        % check the usable width
        spread_inds = [c(i), c(i) + horz_copies(r(i),c(i))-1];
        
        % the component is spread across these columns
        spread_cols = spread_inds(1):spread_inds(2);
        useable_width = sum(col_widths(spread_cols)) - col_gap((spread_cols(end)));
        gdiff = max(gap(r(i), spread_inds(2)) - col_gap((spread_cols(end))), 0);
        req_width = widths(r(i),c(i)) + gdiff;
        
        if (req_width > useable_width)
            
            % check - if this is the first things with width in the column
            % assign its entire width to the current column (ordered above so
            % doing this makes sense)
            tmp_widths = col_widths(spread_cols);
            empty_cols = spread_cols((tmp_widths == 0) | (tmp_widths == col_gap(spread_cols)));
            if any(empty_cols)
                
                % add how much height to each?
                add_width = ceil((widths(r(i),c(i)) - useable_width) / numel(empty_cols));
                col_widths(empty_cols) = col_widths(empty_cols) + add_width;
                useable_width = widths(r(i),c(i));
                
                % add the gaps
                if (empty_cols(1) > 1) && (col_widths(empty_cols(1)-1) > 0) && (col_gap(empty_cols(1)) == 0)
                    col_widths(empty_cols(1)) = col_widths(empty_cols(1)) + hspace(r(i), c(i));
                    col_gap(empty_cols(1)) = hspace(r(i), c(i));
                end
                if (empty_cols(end) < n_cols) && (col_widths(empty_cols(end)+1) > 0) && (col_gap(empty_cols(end)+1) == 0)
                    col_widths(empty_cols(end)+1) = col_widths(empty_cols(end)+1) + hspace(r(i), c(i)+1);
                    col_gap(empty_cols(end)+1) = hspace(r(i), c(i)+1);
                end
                
            elseif (allow_leak)
                
                % can we "leak" into other columns?
                allow = [true, true];
                while any(allow) && (widths(r(i),c(i)) > useable_width)
                    
                    % try and go left
                    extra = zeros(1,2);
                    if allow(1) && (spread_inds(1) > 1) && ~is_filled(r(i),spread_inds(1)-1)
                        spread_inds(1) = spread_inds(1) - 1;
                        extra(1) = col_widths(spread_inds(1)) - used_leakage(r(i), spread_inds(1));
                    else
                        allow(1) = false;
                    end
                    
                    if allow(2) && (spread_inds(2) < size(widths,2)) && ~is_filled(r(i),spread_inds(2)+1)
                        spread_inds(2) = spread_inds(2) + 1;
                        extra(2) = col_widths(spread_inds(2)) - used_leakage(r(i), spread_inds(2));
                    else
                        allow(2) = false;
                    end
                    
                    % special case here if it can leak into a row with zero height
                    % just fill that row
                    is_empty = allow & (col_widths(spread_inds) == 0);
                    empty_cols = spread_inds(is_empty);
                    
                    if (numel(empty_cols)) && (widths(r(i),c(i)) - useable_width - sum(extra)) > 0
                        
                        % add how much height to each?                     
                        add_width = ceil((widths(r(i),c(i)) - useable_width - sum(extra)) / numel(empty_cols));
                        col_widths(empty_cols) = col_widths(empty_cols) + add_width;
                        useable_width = widths(r(i),c(i));
                        
                        % add the gaps
                        if (is_empty(1))
                            col_widths(empty_cols(1)) = col_widths(empty_cols(1)) + hspace(r(i), c(i));
                            col_gap(empty_cols(1)) = hspace(r(i), c(i));
                            pre_width(r(i), c(i)) = pre_width(r(i), c(i)) + add_width;    % extra space left
                        end
                        if (is_empty(2))
                            col_widths(empty_cols(end)+1) = col_widths(empty_cols(end)+1) + hspace(r(i)+1, c(i));
                            col_gap(empty_cols(end)+1) = hspace(r(i)+1, c(i));
                            post_width(r(i), c(i)) = post_width(r(i), c(i)) + add_width;  % extra space right
                        end
                    
                    elseif any(extra)
                        
                        % leak proportionally
                        needed = widths(r(i),c(i)) - useable_width;
                        avail = sum(extra);
                        if (avail < needed)
                            % fill them both
                            leak_quant = extra;
                            used_leakage(r(i), spread_inds) = used_leakage(r(i), spread_inds) + leak_quant + hspace(r(i), spread_inds) .* (leak_quant > 0);  % add the gap in case something else "leaks" into it
                            useable_width = useable_width + sum(extra);
                        else
                            % spread proportionally
                            leak_quant = (needed / avail) * extra;
                            used_leakage(r(i), spread_inds) = used_leakage(r(i), spread_inds) + leak_quant + hspace(r(i)+1, spread_inds);                       % add the gap in case something else "leaks" into it
                            useable_width = widths(r(i),c(i));
                        end
                        pre_width(r(i), c(i)) = pre_width(r(i), c(i)) + leak_quant(1);
                        post_width(r(i), c(i)) = post_width(r(i), c(i)) + leak_quant(2);
                    end
                end
            end
        elseif (gdiff > 0)
            % ensure the current column gap is sufficient
            col_widths(spread_inds(end)) = col_widths(spread_inds(end)) + gdiff;
            col_gap(spread_inds(end)) = gap(r(i), spread_inds(2));
            
        end
        
        % can we fit it in now - if not, dont increase the size of the leakage columns
        if (req_width > useable_width)
            
            % insert extra width into the columns the control is spread across equally
            spread_cols = spread_inds(1):spread_inds(2);
            add_width = ceil((widths(r(i), c(i)) - useable_width) / numel(spread_cols));
            col_widths(spread_cols) = col_widths(spread_cols) + add_width;
            dgap = sum(col_widths(spread_cols)) - col_gap(spread_cols(end)) - widths(r(i), c(i));
            if (dgap < 0)
                col_gap(spread_cols(end)) = col_gap(spread_cols(end)) - dgap;
            end
        end
    end
    processed(r + n_rows * (c - 1)) = true;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now build a map of the (maximum) extent of each object
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

column_start = cumsum([0, col_widths], 2);
ext_min = zeros(size(hGrid));
ext_max = zeros(size(hGrid));

for i = n_rows:-1:1
    
    for j = 1:n_cols
        
        % only do the "original"
        if is_handle(i,j) && ((vert_copies(i,j) > 0) && (horz_copies(i,j) > 0))
            
            % if it has a fixed space on its left, take it back to that
            if (j > 1) && is_filled(i, j-1) && ~is_handle(i, j-1)
                ext_min(i,j) = column_start(j-1) + widths(i,j-1);
            else
                % starts here normally
                ext_min(i,j) = column_start(j) - pre_width(i,j);
            end
            
            % stops here
            ecol = j + horz_copies(i,j)-1;
            ext_max(i,j) = column_start(ecol) + col_widths(ecol) + post_width(i,j) - (~allow_leak || ((ecol < n_cols) && is_handle(i,ecol+1))) * col_gap(ecol);
            
        end
    end
end








