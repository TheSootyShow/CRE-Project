function [des_siz, valid] = AdjustDesiredSize(des_siz, req_siz, max_siz)
% function [des_siz, valid] = AdjustDesiredIsze(des_siz, req_siz, max_siz)
% function to make adjustments to desired sizes so that they sum 
% to less than or equal to max_siz.  Used for gui sizing
%

% can it fit
if (sum(req_siz) > max_siz)
    des_siz = req_siz;
    valid = false;
else
    
    % it'll fit
    valid  = true;
    
    % make sure the desired size is at least the required size
    des_siz = max(des_siz, req_siz);
    
    if (sum(des_siz) > max_siz)
        
        % take away in lots of > 1
        over = sum(des_siz) - max_siz;
        dh = des_siz - req_siz;
        nspace = sum(dh > 0);  % the number with space left over
        while (over > 0)
            take = ceil(over / nspace);
            take = min(take, dh);
            des_siz = des_siz - take;
            over = sum(des_siz) - max_siz;
            dh = des_siz - req_siz;
            nspace = sum(dh > 0);  % the number with sapce left over
        end
    end
end