function [fh, txt_h] = CreateMsgBox(title, text_cell)
% function [fh, txt_h] = CreateMsgBox(title, text_cell) 
% this function creates a message box similar to the Matlab 
% message box (I dont link Matlab's message box)


% make tabs this many characters
tab_chars = 4;

% border gap in pixels
b_gap = 3;

% create a raw version where tabs are replace with characters
tchar = sprintf('\t');
text_raw = cell(size(text_cell));
for i = 1:numel(text_raw)
    if ischar(text_cell{i})
        text_raw{i} = strrep(text_cell{i}, tchar, repmat('a', 1, tab_chars));
    end
end
n_chars = cellfun(@(txt)(numel(txt) + 4*sum(txt == tchar)), text_cell);
[max_chars, ind] = max(n_chars);


% use matlabs message box as a basis
fh = msgbox(text_raw, title);

% get handles to its components
otxt_h = findobj(fh, 'type', 'text');
pb_h = findobj(fh, 'style', 'pushbutton');
ax_h = findobj(fh, 'type', 'axes');
set([fh, otxt_h, pb_h, ax_h], 'units', 'pixels');  % work in pixels

% get some positions
ax_pos = get(ax_h, 'position');
b_pos = get(pb_h, 'position');
f_pos = get(fh, 'position');

% cover it in a uipane
ui_panel = uipanel('Parent',fh, 'units', 'pixels', 'position', ax_pos, 'visible', 'off');

% create on box quickly to guess sizes
tmp_h = uicontrol(ui_panel, 'style', 'text', 'string', text_raw{ind}, 'units', 'pixels', 'fontname', 'Segoe UI', 'fontsize', 12);
%[tmp_h, tmp_hg] = javacomponent({'javax.swing.JLabel', text_raw{ind}}, [], ui_panel);

% use text warp to get the recommended size
[tmp, rsize] = textwrap(tmp_h, text_raw);
char_width = round(rsize(3) / max_chars);
tab_width = floor(tab_chars * char_width);
max_width = ceil(char_width * max_chars);  % 4 chars per /t
delete(tmp_h);


% change the size of the figure
dX = max(((max_width + 2*b_gap) - f_pos(3)) / 2, 0);
f_pos(1) = f_pos(1) - dX;
f_pos(3) = f_pos(3) +2*dX;
set(fh, 'position', f_pos);
ui_pos = [-b_gap,-b_gap, f_pos(3:4) + 2*b_gap];
set(ui_panel, 'position', ui_pos);
b_pos(1) = b_pos(1) + dX;
set(pb_h, 'position', b_pos);

% now create the new txt box's
y = ceil(b_pos(2) + b_pos(4) - ui_pos(2) + 1);
char_height = floor((ax_pos(4) - y - b_gap) / numel(text_cell) - 1);


% go from bottom to top
txt_h = cell(numel(text_cell), 2);
for i = numel(text_cell):-1:1
    
    if numel(text_cell{i})
        
        n_tab = 0;
        while (n_tab < numel(text_cell{i})) && (text_cell{i}(n_tab+1) == tchar)
            n_tab = n_tab + 1;
        end
        
        % now create the box
        txt_pos = [n_tab * tab_width - ui_pos(1) + b_gap, y, max_width - n_tab * tab_width, char_height];
        %txt_h(i) = uicontrol(ui_panel, 'style', 'text', 'string', text_cell{i}, 'units', 'pixels', 'position', txt_pos, 'horizontalalignment', 'left');
        [txt_h{i,1}, txt_h{i,2}] = javacomponent({'javax.swing.JLabel', text_cell{i}}, txt_pos, ui_panel);
        
    
    end
    y = y + char_height + 1;
end

% and delete the stuff we dont need
set(ui_panel, 'visible', 'on')
delete(ax_h);










