function corrSize = CheckGuiSize(hFig)
% function corrSize = CheckGuiSize(hFig)
% function to see if the gui needs a resize operation
% 
% Usage:
% 1) corrSize = CheckGuiSize(hFig)
%    checks if the gui has been resized for its current size
%
% 2) CheckGuiSize(hFig)
%    tells the gui it has just been resized to the current size
%    (adds an entry 'Size' in the figure's user data)

% make sure the screen resolution hasn't changed
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch

% which usage?
if (nargout)
    
    % last size info is stored in user data
    sizeData = modUserData(hFig, 'get', 'Size');
    
    % check if it need a resize
    if (numel(sizeData) == 3)
        old_units = get(hFig, 'units');
        set(hFig, 'units', sizeData{2});
        gui_size = get(hFig, 'position');
        
        % allow some leeway if its in pixels
        % I haven't work out where the size changes come from
        if strcmpi(sizeData{2}, 'pixels')
            corrSize = (max(abs(gui_size(3:4) - sizeData{1})) <= 2) && (ppi == sizeData{3});
        else
            corrSize = all(gui_size(3:4) == sizeData{1}) && (ppi == sizeData{3});
        end
        set(hFig, 'units', old_units);
    else
        corrSize = false;
    end
    
else
    
    % tell the gui its just been resized
    gui_size = get(hFig, 'position');
    modUserData(hFig, 'add', 'Size', {gui_size(3:4), get(hFig, 'units'), ppi});
    
end