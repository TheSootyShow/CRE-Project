function [file_name, valid, changed] = SanitizeFileName(file_name, fullpath, warn)
% function [file_name, valid, changed] = SanitizeFileName(file_name, fullpath, warn)
% function to sanitize file name
% if fullpath = true, the file name include the path and extension
% if warn = true, a warning box is created is the file name is changed
%
% NOTES:
%
% Its better to perfrom this on the non-fullpath as file seperators in the
% file name can make cause havoc

persistent rep_str;
persistent modify;

% only sanitize the name
if (fullpath)
    [path, fname, ext] = fileparts(file_name);
else
    fname = file_name;
end

% no way to make it valid in this case
if (numel(file_name) == 0)
    valid = false;
    changed = false;
    if (fullpath)
        file_name = fullfile(path, [fname, ext]);
    end
    return;
end

% intitialise
if (numel(rep_str) == 0)
    
    % add any individual chars for removal
    modify = {'\', '/', '?', '%', '*', ':', '|', '"', '<', '>'};  
    
    % make regexp treat them literally
    modify_literal = LiteralRegExp(cell2mat(modify));
    
    % giving the replacement string
    rep_str = ['[', modify_literal, ']+'];  
    
end

% to check for changes
oname = fname;  % store

% apply
fname = regexprep(fname, rep_str, '_');
valid = true;  % hope so

% check if its was changed
changed = ~strcmpi(fname, oname);
    
% and replace
if (warn) && (changed)
            
    % build a string explaing what's removed for the user ( include all
    % not just the removed )
    warn_str = sprintf('Warning: File name changed from:\n%s\nto:\n%s\nbecause\n', oname, fname);
    warn_str = sprintf('%s ''%s''', warn_str, modify{1});
    for i = 2:numel(modify)
        warn_str = sprintf('%s, ''%s''', warn_str, modify{i});
    end
    warn_str = sprintf('%s\nare not allowed in file names and have been replaced with ''_''', warn_str);
    warndlg(warn_str, 'File name warning');
    
end



if (fullpath)
    file_name = fullfile(path, [fname, ext]);
else
    file_name = fname;
end