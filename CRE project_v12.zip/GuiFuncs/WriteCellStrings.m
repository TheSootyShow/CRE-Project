function WriteCellStrings(cell_array, file_name, delimiter)
% function WriteCellStrings(cell_array, file_name, delimiter)
% function to write a cell array of strings to a file with the
% specified file name
% delimiter is the marker used to indicate string boudaries (default is a
% tab)


if (nargin < 3) || (numel(delimiter) == 0)
    delimiter = sprintf('\t');
end

% open it
fid = fopen(file_name, 'w');
if (fid < 0)
    ThrowError(sprintf('Could not open: %s for writing', file_name));
end

% and write
try
    for i = 1:size(cell_array,1)
        fprintf(fid, '%s', cell_array{i,1});
        for j = 2:size(cell_array,2)
            fprintf(fid, '%s%s', delimiter, cell_array{i,j});
        end
        fprintf(fid, '\r\n');  % for stupid windows text editors
    end
    fclose(fid);
catch ME
    ThrowError(ME.message);
end






function ThrowError(string)
% function ThrowError(string)
% function to generate different types of errors

if isdeployed()
    errordlg(string);
else
    error(string);
end