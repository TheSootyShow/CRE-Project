function PopulateRfunctions(handles)
% function PopulateRfunctions(handles)
% this function is used to add the various R processing functions
% into the gui.  Update this as needed.  A demonstarion functino is
% included below

% this variable is an n x 2 cell array containing the n possible r
% functions to use.  The first column contains the text to display in the
% gui, the second column contains a handle to the functino to execute
r_funcs = {'Halve', @(hObject, eventdata, handles)ExampleHalve(handles), ...% this is a simple example that divides all samples by 2 and is intended to demonstrate how to call r functions.  
           ...                                                              % Inputs are designed to be consistent with a Matlab GUI callback, i.e. function(hObject, eventdata, handles)
           ... % add more as needed
           };
       
       
       
       
       
       
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% No need to edit this
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(handles.pmRFuncs, 'string', r_funcs(:,1));
set(handles.pmRFuncs, 'userdata', r_funcs(:,2));
       
       
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration function
% N.B. this can be in a seperate file
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ExampleHalve(handles)
% function ExampleHalve(handles)
% this is a demonstration function which uses r to divide all samples by 2 .  
% handles are the handles from the gui,
% with handles.data_set of particular interest (see InitDataStruct.m)


global R_lInK_hANdle;  % this keeps the link to R open

% Connect to an R Session if we haven't already
if (numel(R_lInK_hANdle) == 0)
    openR();
end

% Push data the data set data into R
putRdata('X', handles.data_set.data);

% Run a simple R command to sum all of the data
hX = evalR('X / 2');

% this also works
evalR('Y <- X / 2');
hX = getRdata('Y');

% assign the result back to the data set
handles.data_set.data = hX;

% and uppate the gui so it knows about the changes to the data
guidata(handles.CREgui, handles);






