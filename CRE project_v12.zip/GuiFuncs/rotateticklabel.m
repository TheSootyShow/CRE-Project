function tick_handles = rotateticklabel(h_axis,rot)
%ROTATETICKLABEL rotates tick labels
%   TH=ROTATETICKLABEL(H,ROT) is the calling form where H is a handle to
%   the axis that contains the XTickLabels that are to be rotated. ROT is
%   an optional parameter that specifies the angle of rotation. The default
%   angle is 90. TH is a handle to the text objects created. For long
%   strings such as those produced by datetick, you may have to adjust the
%   position of the axes so the labels don't get cut off.
%
%   Of course, GCA can be substituted for H if desired.
%
%   TH=ROTATETICKLABEL([],[],'demo') shows a demo figure.
%
%   Known deficiencies: if tick labels are raised to a power, the power
%   will be lost after rotation.
%
%   See also datetick.

%   Written Oct 14, 2005 by Andy Bliss
%   Copyright 2005 by Andy Bliss
%
%   created labels have tags set to 'XTickLabel%i', where %i is the
%   index into xticks, and user data set to their x value

% tick labels .1 cm off the axis
axis_gap_cm = .1;  


% set the default rotation if user doesn't specify
if (nargin < 2) || (numel(rot) == 0)
    rot=90;
end

if (nargin < 1) || (numel(h_axis) == 0)
    h_axis = gca();
end

% get current tick labels
labels = get(h_axis,'XTickLabel');

% erase current tick labels from figure
set(h_axis,'XTickLabel',[]);

% get tick label positions
x_ticks = get(h_axis,'XTick');
xlims = get(h_axis, 'xlim');

% how far to offset them?
old_units = get(h_axis, 'units');
set(h_axis, 'units', 'centimeters');
a_pos = get(h_axis, 'position');
ylims = get(h_axis, 'ylim');
data_cm = abs(diff(ylims)) / a_pos(4);     % this many data units per centimeters
offset = -axis_gap_cm * data_cm;           % this is in data units
offset = offset + ylims(1);                % make sure it relative to the y value of the x axis
set(h_axis, 'units', old_units);

% make new tick labels (with 0 rotation for now - so we can get "pure" width / height)
tick_handles = text(x_ticks, repmat(offset, size(x_ticks)), labels, 'HorizontalAlignment', 'left', 'VerticalAlignment', 'bottom', ...
    'rotation', 0, 'parent', h_axis, 'tag', 'xticklabel', 'visible', 'off');
set(tick_handles, 'units', 'data');

% rotation matrix
ct = cos(rot * pi / 180);
st = sin(rot * pi / 180);
R = [ct, -st; st, ct];

% and adjust their positions
for i = 1:numel(tick_handles)
    
    % get the unrotated tick extents
    tick_extent = (get(tick_handles(i), 'extent'));
    width = tick_extent(3);
    height = tick_extent(4);
    
    % find out where the points actually are (these are relative to the bottom left)
    X = [[0;0], [0;tick_extent(4)], [tick_extent(3); 0], [tick_extent(3); tick_extent(4)]];
    
    % rotated version of the corners
    Xr = R * X;
    
    % make the points relative to the axis
    Xr(1,:) = Xr(1,:) + tick_extent(1);
    Xr(2,:) = Xr(2,:) + tick_extent(2);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % This is weird, the x adjust seems to make sense,
    % but the y adjustment doesn't
    % so 1) calculate the x adjustment
    %    2) rotate it
    %    3) calculate the y adjustment
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % looking for the top two
    [vals, order] = sort(Xr(2,:), 'descend'); 
    Xt = Xr(:, order(1:2));
    
    % the angle of the line between them
    dx = Xt(1,2) - Xt(1,1);  % distance apart in the x dimension
    theta = acos(abs(dx) ./ norm(Xt(:,2) - Xt(:,1)));    % N.B, 0 if horizontal, pi/2 if vertical
    mp_x = Xt(1,1) + .5 * max((pi/4-theta) / (pi/4), 0) * dx;                     % N.B, the midpoint if the line is horizontal, the highest point if the line is at 45 degs
    
    % what percentage of the way is this across the expected extent?
    x_rat = (mp_x - min(Xr(1,:))) ./ (max(Xr(1,:)) - min(Xr(1,:)));
        
%     % and find out how far they are from where we want them
%     ex = x_ticks(i) - mp_x;
%     
%     % now update X
%     pos = get(tick_handles(i), 'position');
%     pos(1) = pos(1) + ex;
%     set(tick_handles(i), 'position', pos);
    
    % now rotate it
    set(tick_handles(i), 'rotation', rot);
    
    % grab the extent again
    rot_extent = (get(tick_handles(i), 'extent'));
    
    % how far is the top from the desired point?
    top = rot_extent(2) + rot_extent(4);
    ey = offset - top;
    
    % and update the tick location
    pos = get(tick_handles(i), 'position');
    cx = rot_extent(1) + x_rat * rot_extent(3);  % match the % of the way across the extent
    pos(1) = pos(1) + (x_ticks(i) - cx);
    pos(2) = pos(2) + ey;
    set(tick_handles(i), 'position', pos);
    
    % make sure which tick it is is in the user data
    set(tick_handles(i), 'tag', sprintf('XTickLabel%i', i));
    set(tick_handles(i), 'userdata', x_ticks(i));
    
end

% now make them visible
set(tick_handles, 'visible', 'on');




