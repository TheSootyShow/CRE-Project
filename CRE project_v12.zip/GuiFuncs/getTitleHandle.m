function hTitle = getTitleHandle(hPanel)
% function hTitle = getTitleHandle(hPanel)
% functionm to get the title of a uiframe

% get a handle to the title (its actually a seperate ui control)
warning('off', 'MATLAB:Uipanel:HiddenImplementation');
hTitle = get(hPanel,'TitleHandle');
warning('on', 'MATLAB:Uipanel:HiddenImplementation');