function Default_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to the edit box (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)

% persistent wait_list  % keep track of what is waiting


% delay = .5 / (24*60*60);           % wait .5s before executing (in case of another key press)
% 
% if (size(wait_list,2) ~= 2)
%     wait_list = zeros(0,2);
% end

if (~isfield(handles, 'robot'))
    handles = KeyPressInit(hObject, eventdata, handles);
    guidata(hObject, handles);
end

% ignore enter and anything that doesn't have a character
hFig = ancestor(hObject, 'figure');
if (hObject == get(hFig, 'currentobject')) && numel(eventdata) && isstruct(eventdata) && isfield(eventdata, 'Key') && ~strcmpi(eventdata.Key, 'return')
    
    % do callback
    %fprintf('robot: %s\n', eventdata.Key);
    handles.robot.keyPress(handles.press_enter);
        
end
    
%     wait_index = wait_list(:,1) == hObject;
%     if ~any(wait_index)
%         wait_index = size(wait_list,1)+1;
%     end
%     wait_end = now() + delay;
%     wait_list(wait_index,:) = [hObject, wait_end];
%     
%     % start waiting
%     while (now() < wait_end)
%         drawnow();  % this should allow this callback to be interupted by a subsequent one
%     end
%         
%     % just in case cancelling didnt work 
%     wait_index = wait_list(:,1) == hObject;
%     if (wait_list(wait_index,2) == wait_end)
%         
%         % do callback
%         handles.robot.keyPress(handles.press_enter);
%                 
%         wait_index = wait_list(:,1) == hObject;
%         if (wait_list(wait_index,2) == wait_end)
%             wait_list(wait_index,:) = [];
%         end
%     end
% end