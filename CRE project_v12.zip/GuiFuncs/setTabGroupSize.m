function [groupSize, tabSize, tabBorder] = setTabGroupSize(hTabs, tabSizes)
% function [groupSize, tabSize, tabBorder] = setTabGroupSize(hTabs, tabSizes)
% function to set the position of both tabs and the tab container object
% tabSizes should be an n x 2 matrix (width, height)

% height for the selectable regions of tabs
adjHeader = 0;                                           % conver up the gaps bys removing height from th tab header


% tab border
tabBorder = [2,1,5,  adjHeader + GetTabHeight()];        % gap from tab contents edge to the tab groups location


% set the size of the container
hTabGroup = get(hTabs(1), 'parent');
set(hTabGroup, 'units', 'pixels');
groupPos = get(hTabGroup, 'position');
cTop = groupPos(2) + groupPos(4) - 1;  % current top of the tab group (leave it constant)

% the size of the tabs
tabSize = max(tabSizes, [], 1);

% the new size of the tab group
groupSize = tabSize + [sum(tabBorder([1,3])), sum(tabBorder([2,4]))];
groupPos(3:4) = groupSize;

% leave the top of the tab group in the same place
groupPos(2) = cTop - groupPos(4) + 1;

% and set the new position
set(hTabGroup, 'position', groupPos);

% desired location of the left of each tab (under the tab header)
desTop = groupPos(4) - tabBorder(4);
desLeft = repmat(tabBorder(1), 1, numel(hTabs));
desLeft(1) = desLeft(1)-1;  % looks better this way I think

% now set the position of each tab
set(hTabs, 'units', 'pixels');  % just in case

for i = 1:numel(hTabs)
    
    % N.B. object's positions appear to be relative to the tab groups container
    children = get(hTabs(i), 'children');
    
    % get their locations
    if numel(children)
        
        [sizes, extents] = GetObjectSizes(children);
        lb = min(extents(:,1));
        tb = max(extents(:,4));
        
        % now adjust them
        dx = desLeft(i) - lb;
        dy = desTop - tb;
        
        % and update locations
        for j = 1:numel(children)
            set(children(j), 'position', [extents(j,1) + dx, extents(j,2) + dy, sizes(j,:)]);
        end
    end
end

function [sizes, extents] = GetObjectSizes(hObjects)
% function sizes = GetObjectSize(hObject)
% get the size of the object

sizes = zeros(numel(hObjects), 2);
extents = zeros(numel(hObjects), 4);
set(hObjects, 'units', 'pixels');

for i = 1:numel(hObjects)
    pos = get(hObjects(i), 'position');
    sizes(i,:) = pos(3:4);
    extents(i,:) = [pos(1:2), pos(1:2) + pos(3:4) - 1];
end






