function SetAxisVisible(hAxis, state)
% function SetAxisVisible(hAxis, state)
% function to change the visible state of an axis and all its children
% state can be on / off,  or 1 / 0

% standard inputs
if (isnumeric(state)) || islogical(state)
    if (state(1) > 0)
        state = 'on';
    else
        state = 'off';
    end
end

% get all the children first
kids = allchild(hAxis);
set(kids, 'visible', state);

% now look for legend handles
hLegend = findobj(get(hAxis, 'parent'),'Type','axes','Tag','legend');
set(hLegend, 'visible', state);

% now the axis
set(hAxis, 'visible', state);

% setting the axis invisble seems to make the figure lose focus, so restore
% it)
if strcmpi(state, 'off')
    figure(ancestor(hAxis,'figure'));
end
