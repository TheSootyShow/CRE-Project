function hChild = RecurseChildren(hObject)
% function hChild = RecurseChildren(hObject)
% function to recursively find all children


% remove some
hChild = allchild(hObject);
hChild = hChild(:);
i = 0;
while (i < numel(hChild))
    i = i + 1;
    extra = allchild(hChild(i));
    hChild = [hChild; extra(:)];
end