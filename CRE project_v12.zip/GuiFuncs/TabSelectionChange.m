function TabSelectionChange(hObject, event_data, handles)
% function TabSelectionChange(hObject, event_data, handles)
% this function to be exectuted when tabs are changed.  It looks for 
% nested tabs and ensures these are hidden

% ensure its a handle
hObject = double(hObject);

% get all tabs
hTabs = get(hObject, 'children');
hTabs = hTabs(strcmpi(get(hTabs, 'type'), 'uitab'));

% break them into selected and other
hSelected = double(get(hObject, 'SelectedTab'));

% the non-selected ones
hOther = hTabs(hTabs ~= hSelected);

% remove "sub tabs" in unselected panes
for i = 1:numel(hOther)
    [tab_info, handles] = RemoveFigureTabs(hOther(i), handles);
    if numel(tab_info)
        modUserData(hObject, 'add', sprintf('TabInfo_%s', get(hOther(i), 'tag')), tab_info);
    end
end

% restore "sub tabs" for the selected tab
userString = sprintf('TabInfo_%s', get(hSelected, 'tag'));
tab_info = modUserData(hObject, 'get', userString);
if numel(tab_info)
    modUserData(hObject, 'remove', userString);
    handles = RestoreFigureTabs(hObject, handles, tab_info);
end

% there is also an issue when the focus is a uicontrol - Fixed: it was the robot
% hFig = ancestor(hObject, 'figure');
% co = get(hFig, 'currentobject');
% if strcmpi(get(co, 'type'), 'uicontrol') && strcmpi(get(co, 'style'), 'edit')
% 
%     % find any uicontrol on the current tab
%     figure(hFig);
%     %set(hFig, 'currentobject', hSelected);
%     %drawnow();
%     %hControl = findobj(hSelected, 'type', 'uicontrol');
%     %uicontrol(hControl(1));
% end


% update handles
guidata(hObject, handles);


function old_attempt


% make sure all tab group decendants of the non-selected tab pane are
% invisible (matlab doesnt seem to do this for itself weirdly)
nestedGroups = findall(hOther, 'type', 'uitabgroup');
set(nestedGroups, 'visible', 'off');

% now check all of the others
hChildren = findall(hSelected, 'type', 'uitabgroup');
if numel(hChildren)

    % get the closest parent tab ancestor
    tabAnc = getAncestor(hChildren, 'uitab');
    groupAnc = get(tabAnc, 'parent');
    if iscell(groupAnc)
        groupAnc = cell2mat(groupAnc);
    end
    
    % build info on each of theie parents
    hList = [hObject; hChildren(:)];
    processed = false(1, numel(hList));        % the +1 is space for this tab group
    state = cell(1, numel(hList));             % the +1 is space for this tab group
    
    % the input hObject is visible and has been processed
    processed(1) = true;
    state{1} = 'on';
    
    % find the index of the group's parent group in the list
    [tmp, parIndex] = ismember(groupAnc, hList);
    
    % assemble them into a heirarchy
    while ~all(processed)
        
        % go though sequentially
        update = find((~processed) & processed(parIndex)) - 1;
        for i = update
            
            % can only be visible if its parent group is
            state{i+1} = 'off';
            if strcmpi(state{parIndex(i)}, 'on')
                
                % is its tab ancestor the selected one?
                if (tabAnc(i) == double(get(hList(parIndex(i)), 'SelectedTab')))
                    state{i+1} = 'on';
                end
            end
            
            % and set
            set(hChildren(i), 'visible', state{i+1});
            processed(i+1) = true;
        end
    end
end


function hAncestor = getAncestor(hObject, type)
% function hAncestor = getAncestor(hObject, type)
% function to get the ancestor of an object when the ancestors have hidden
% handles

% pre-allocate
hAncestor = zeros(1, numel(hObject));

% loop through each uicontrol
for i = 1:numel(hObject)
    
    % until we find the correct parent
    hAncestor(i) = get(hObject(i), 'parent');
    while (hAncestor(i) ~= 0) && ~strcmpi(get(hAncestor(i), 'type'), type)
        hAncestor(i) = get(hAncestor(i), 'parent');
    end
end






