function [dimInfo, names] = SecondaryDimensionUI(dimInfo, create_type, fs, prompt_types, dim_type)
% function [dimInfo, names] = SecondaryDimensionUI(dimInfo, create_type, fs, prompt_types, dim_type)
% function to create an interactive display for the user create
% new secondary dimensions
% output "names" are the names of all new dimensions
% fs only required for wavelet

% default
names = {};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first get the names of all the dimensions currently known
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

choices = GetAllDimensionNames(dimInfo, true);
choices_alias = ApplyKnownDimAliases(choices, dimInfo.aliases);

% get all known type and tags
[known_types, known_tags] = GetKnownSecondaryDimTypes(dimInfo);

if (nargin < 4) || (numel(prompt_types) == 0)
    prompt_types = known_types;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If no specific type has been inputted, prompt the user
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 2) || (numel(create_type) == 0)
    
    % title for things
    titleStr = 'Create Secondary Dimension';
    listTitle = 'Secondary Dimension Type:';
    
    % in some cases we want to pretend these are features
    if (nargin >= 5) && strcmpi(dim_type, 'feat')
        titleStr = 'Create Post Feature';
        listTitle = 'Post Feature Type:';
    end
    
    % prompt the user
    [resp, selection] = CREListDlg(prompt_types, 'title', titleStr, 'list_title', listTitle, 'list_multi', false);
    
    % did the user repond with OK?
    if strcmpi(resp, 'OK')
        create_type = prompt_types{selection};
    else
        return;
    end
end

% now convert the known_type to a tag
index = find(strcmpi(known_types, create_type), 1, 'first');
if (numel(index) ~= 1)
    % maybe a tag was inputted
    index = find(strcmpi(known_tags, create_type), 1, 'first');
end

% if its unknown spit an error
if (numel(index) ~= 1)
    error('Unknown secondary dimensions type: %s', create_type);
end
create_type = known_types{index};
create_tag = known_tags{index};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now prompt the user for which existsing dimensions the new
% secondary dimensions should be a function of
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% default options for the various queries
arg_cell = {};
multi_select = false;  % only ever operates on 1 dim
arg_process = {};


% prompt the user
if strcmpi(create_type, 'absolute')
    [resp, selection] = CREListDlg(choices_alias, 'title', 'Absolute', 'list_title', 'Absolute values of:');

elseif strcmpi(create_type, 'square')
    [resp, selection] = CREListDlg(choices_alias, 'title', 'Square', 'list_title', 'Square dimension:');

elseif strcmpi(create_type, 'derivitive')
    [resp, selection, arg_cell] = CREListDlg(choices_alias, 'title', 'Select dimension', 'list_title', 'Differentiate:', 'txt_title', 'Order:', 'default_txt', '1');
    arg_process = {@(arg_str)str2double(arg_str)};
    arg_valid = {@(arg)(isfinite(arg) && (arg == round(arg)) && (arg >= 1))};
    arg_message = {@(str)(sprintf('Unable to cast derivitive order string: %s to an integer >= 1', str))};  % error message if args are invalid
    
elseif strcmpi(create_type, 'ratio')
    [resp, num, den] = CRERatioGUI(choices_alias);
    selection = [find(strcmpi(num, choices_alias)), find(strcmpi(den, choices_alias))];
    multi_select = true;  % take multiples inputs    

elseif strcmpi(create_type, 'magnitude')
    [resp, selection] = CREListDlg(choices_alias, 'title', 'Magnitudes', 'list_title', 'Magnitude of:');
    multi_select = true;  % take multiples inputs

elseif strcmpi(create_type, 'sum')
    [resp, selection] = CREListDlg(choices_alias, 'title', 'Summation', 'list_title', 'Sum dimensions:');
    multi_select = true;  % take multiples inputs

elseif strcmpi(create_type, 'sumsquares')
    [resp, selection] = CREListDlg(choices_alias, 'title', 'Sum of Squares', 'list_title', 'Sum the squares of dimensions:');
    multi_select = true;  % take multiples inputs

elseif strcmpi(create_type, 'wavelet')
    
    % use the wavelet selection ui
    [resp, tmp_dimInfo, tmp_names] = WaveletSelectionGui(dimInfo, fs);
    if strcmpi(resp, 'OK')
        dimInfo = tmp_dimInfo;
        names = tmp_names;
    end
    return;  % Wavelet select UI takes care of it
    
elseif strcmpi(create_type, 'constant')    
    
    % special case for constants
    answer = inputdlg({'Name (e.g. weight)', 'Value'}, 'Enter a constant value for the data', 1);
    resp = 'Cancel';
    multi_select = true;
    selection = [];
    if (numel(answer) == 2)
        resp = 'OK';
        arg_cell = {answer{2}, answer{1}};
        arg_process = {@(arg)(str2double(arg)), @(arg)(arg)};
        arg_valid =  {@(arg)(~isnan(arg)), ...
                      @(arg)(numel(arg) > 0)};
        arg_message = {@(str)(sprintf('Can not convert the string "%s" to a numeric value', str)), ...% error message if args are invalid
                      @(str)('Please enter a name for the constant')};                                % error message if args are invalid
    end
    
else
    
    % a generic (ugly) prompt
    [resp, selection] = CREListDlg(choices_alias, 'title', create_type, 'list_title', [create_type, ' of:']);
    
    % determine if its a multi select response
    X = randn(10,4);  % simulate 4 dimensions
    Y = feval(dimInfo.(known_types{index}).func, X, dimInfo.(known_types{index}).args{:});
    multi_select = size(Y,2) == 1;
    
    
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now update dimInfo with user selections
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% did the user repond with OK?
if strcmpi(resp, 'OK')
    
    % parse the argument string
    if (numel(arg_cell))
        
        args = cell(1, numel(arg_cell));
        valid_args = false(1, numel(arg_cell));
        for i = 1:numel(arg_cell)
            
            args{i} = feval(arg_process{i}, arg_cell{i});
            valid_args(i) = feval(arg_valid{i}, args{i});
         
            % show errors
            if (~valid_args(i))
                errordlg(arg_message{i}(arg_cell{i}));
                return;
            end
        end
        
        % do we need to replicate args for all selections?
        if (~multi_select) 
            args = repmat({args}, 1, numel(selection));
        else
            args = {args};
        end
        
    else
        args = {{}};
        if ~(multi_select)
            args = repmat(args, 1, numel(selection));
        end
    end
    
    % cast selection into a cell array
    if (multi_select)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Adding a dimensions that's a function
        % of multiple dimensions
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % in the magnitude case, everything selected is grouped together
        sources = choices(selection);
        
        % build it
        new_dim = DerivedDimFromSources(dimInfo, sources, create_tag, args{1}{:});
        
        % check it doesn't match any existing dimensions
        existing = {dimInfo.derived_dims(:).name};
        if ~any(strcmpi(new_dim.name, existing))
    
            % now build the dimension
            dimInfo.derived_dims(end+1) = new_dim;
            dimInfo.derived_disp(end+1) = true;  % assume the user will want it selected
            names{end+1} = new_dim.name;
            
        end
        
    else
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Adding a dimensions that's a function
        % of only dimensions.  Multiple selctions mean
        % create more than one new dimension
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % go through them one by one - they are all different
        for i = 1:numel(selection)
            
            % what was selected
            dim = choices{selection(i)};
            
            % is it a primary dimensions?
            if any(strcmpi(dim, dimInfo.primary_names))
                
                % simple derived dimension
                dim_ind = find(strcmpi(dim, dimInfo.primary_names), 1, 'first');
                
                % check it doesn't match anything
                dim_match = dimInfo.(create_type).dims == dim_ind;
                arg_match = cellfun(@(x)isequal(x, args{i}), dimInfo.(create_type).args);
                
                if ~any(dim_match & arg_match);
                
                    % is doesn't already exist - add it to dim info
                    dimInfo.(create_type).dims(1,end+1) = dim_ind;
                    dimInfo.(create_type).disp(1,end+1) = true; % assume the user will want it selected
                    dimInfo.(create_type).args{1,end+1} = args{i};
                    dimInfo.(create_type).names{1,end+1} = CreateDimName(create_tag, dim, args{i}{:});
                    
                    % keep track that we've added it
                    names{end+1} = dimInfo.(create_type).names{1,end}; %#ok<*AGROW>
                end
                
            else % no - add it as a derived dimension
                
                % build it
                new_dim = DerivedDimFromSources(dimInfo, {dim}, create_tag, args{1}{:});
                
                % check it doesn't match any existing dimensions
                existing = {dimInfo.derived_dims(:).name};
                if ~any(strcmpi(new_dim.name, existing))
                
                    % now build the dimension
                    dimInfo.derived_dims(end+1) = new_dim;
                    dimInfo.derived_disp(end+1) = true;  % assume the user will want it selected
                    
                    % keep track that we've added it
                    names{end+1} = new_dim.name;
                end
            end
        end
    end
end

% apply aliases to the new names
names = ApplyKnownDimAliases(names, dimInfo.aliases);

