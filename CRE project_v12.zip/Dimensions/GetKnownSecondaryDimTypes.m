function [types, tags] = GetKnownSecondaryDimTypes(dimInfo)
% function [types, tags] = GetKnownSecondaryDimTypes(dimInfo)
% this function retrieves the types of tags of known secondary dimensions
% dimInfo comes from InitDimStruct

% get all fields
fnames = fieldnames(dimInfo);

% which fields relate to the primary dimensions?
is_primary = strncmpi(fnames, 'primary', numel('primary'));

% which fields relate to complicated secondary dimensions?
is_complex = strncmpi(fnames, 'derived', numel('derived'));

% is alias
is_alias = strncmpi(fnames, 'aliases', numel('aliases'));

% the others are the supported types
types = fnames(~is_primary & ~is_complex & ~is_alias);

% return their tags as well
if (nargout == 2)
    tags = cellfun(@(str)(dimInfo.(str).tag), types, 'uniformoutput', false);
end