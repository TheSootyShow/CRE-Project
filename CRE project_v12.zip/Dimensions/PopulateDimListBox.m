function PopulateDimListBox(dimInfo, hPrim, hDerived)
% function PopulateDimListBox(dimInfo, hPrim, hDerived)
% this function populates list boxes for primary and derived dimensions
% for dimInfo, see InitDimStruct.m

% get all of the dimension names
[names, displayed, n_prim] = GetAllDimensionNames(dimInfo);

% are the two handles the same?
if (nargin == 3) && (hPrim == hDerived)
    
    % join the lists
    prim_list = names;
    prim_displayed = displayed;
    
else
    
    % split them
    prim_list = names(1:n_prim);
    prim_displayed = displayed(1:n_prim);
    secondary_list = names(n_prim+1:end);
    secondary_displayed = displayed(n_prim+1:end);
    
end

% add the primary list
if ~isnan(hPrim)
    set(hPrim, 'Min', 0);
    set(hPrim, 'Max', numel(prim_list));
    set(hPrim, 'string', prim_list);
    set(hPrim, 'value', find(prim_displayed));
    set(hPrim, 'ListboxTop', 1); 
end

% and the derived list
if (nargin >= 3) && ~isnan(hDerived) && (hDerived ~= hPrim)
    set(hDerived, 'Min', 0);
    set(hDerived, 'Max', numel(secondary_list));
    set(hDerived , 'string', secondary_list);
    set(hDerived , 'value',  find(secondary_displayed));
    set(hDerived,'ListboxTop', 1); 
end




