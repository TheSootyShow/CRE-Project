function dimInfo = SetDimVisibility(dimInfo, indexs, display, reset)
% function dimInfo = SetDimVisibility(dimInfo, indexs, display, reset)
% this function set the dimensions marked by indexs as to the settings 
% given in display. If reset == true, all other dimensions are set to ~display
% Use PopulateDimListBox.m to see which dimension is at what index

if (nargin < 4) || (numel(reset) == 0)
    reset = false;
end

if (nargin < 3) || (numel(display) == 0)
    display = true;
end
    

% now update dimInfo to reflect the changes
% primary first
if (reset)
    dimInfo.primary_disp(:) = ~display;  % reset them all
end
nPrim = numel(dimInfo.primary_dims);
primIndex = indexs(indexs <= nPrim);
dimInfo.primary_disp(primIndex) = display;

% now secondary dimensions
secIndex = indexs(indexs > nPrim) - nPrim;
if any(secIndex) || (reset)
    
    % find all supported sefcondary dimension types
    types = GetKnownSecondaryDimTypes(dimInfo);
    
    % N.B. ensure this matches the order in which string were placeed in
    % the list box! (see PopulateDimListBox.m)
    offset = 0;
    for i = 1:numel(types)
        
        % the number in this group
        n_exist = numel(dimInfo.(types{i}).disp);
        
        % which selected ones belong to this group?
        indexs = secIndex((secIndex > offset) & (secIndex <= offset + n_exist)) - offset;
        dimInfo.(types{i}).disp(indexs) = display;  % and set the selected ones
        
        % accounted for the selections less than or equal to this
        offset = offset + n_exist;
    
    end

    % remaining ones are the more complex secondary dimensions
    indexs = secIndex(secIndex > offset) - offset;
    if (reset)
        dimInfo.derived_disp(:) = false;     % reset
    end
    dimInfo.derived_disp(indexs) = display; % and set the marked ones
    
end
