function str = WrapInBrackets(str)
% function str = WrapInBrackets(str)
% this function wraps a string in brackets if contains unwrapped
% arithmatic

% are there any arithmatic operators that aren't currently wrapped
b_count = cumsum(str == '(') - cumsum(str == ')');

% find all occurances of arithmatic operators
arith_inds = regexp(str, '[\*\+\-\\\^]');  

% any unwrapped?
if any(b_count(arith_inds) == 0)
    str = sprintf('(%s)', str);
end

