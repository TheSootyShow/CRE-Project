function [mapped_dimInfo, success, warning_list] = MapDimInfoToDataSet(dimInfo, data_set)
% function [mapped_dimInfo, success, warning_list] = MapDimInfoToDataSet(dimInfo, data_set)
% this function maps the input dimInfo structure
%(see InitDimInfo) to a different data set, data_set 

warning_list = '';

% initialise the ouput dimension structure
mapped_dimInfo = InitDimStruct(data_set);

% shortcut
dim_names = data_set.dim_names;

% feature dimensions names
feat_dim_names = dimInfo.primary_names;
n_prim = numel(feat_dim_names);

% create a map between the two
mappings = repmat(-1, 1, numel(feat_dim_names));
missing_dim = false(size(mappings));
missing_deriv = {};
for i = 1:numel(mappings)
    index = find(strcmpi(feat_dim_names{i}, dim_names));
    if numel(index)
        mappings(i) = index;
    end
end

% aliases are a stright copy
mapped_dimInfo.aliases = dimInfo.aliases;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% match primary dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

show_ind = find(dimInfo.primary_disp);
show_dim = dimInfo.primary_dims(show_ind);
mapped_dimInfo.primary_disp(:) = false;
for j = 1:numel(show_ind)
    if (mappings(show_dim(j)) > 0)
        
        % show it and copy arguments
        update = find(mapped_dimInfo.primary_dims == mappings(show_dim(j)), 1, 'first');
        mapped_dimInfo.primary_disp(update) = true;
    else
        % record it as missing
        missing_dim(show_dim(j)) = true;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% match simple secondary dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get all of the known dimensions names
[types, tags] = GetKnownSecondaryDimTypes(dimInfo);

% go through each of them
for i = 1:numel(types)
    
    show_ind = find(dimInfo.(types{i}).disp);
    show_dim = dimInfo.(types{i}).dims(show_ind);
    mapped_dimInfo.(types{i}).disp(:) = false;
    for j = 1:numel(show_ind)
        
        if (mappings(show_dim(j)) > 0)
            
            % show it and copy arguments
            update = find(mapped_dimInfo.(types{i}).dims == mappings(show_dim(j)), 1, 'first');
            if (numel(update) == 0)
                update = numel(mapped_dimInfo.(types{i}).dims) + 1;
                mapped_dimInfo.(types{i}).dims(update) = mappings(show_dim(j));
                mapped_dimInfo.(types{i}).names{update} = dimInfo.(types{i}).names{show_ind(j)};
            end
            mapped_dimInfo.(types{i}).disp(update) = true;
            mapped_dimInfo.(types{i}).args{update} = dimInfo.(types{i}).args{show_ind(j)};
        
        else
            
            % record them as missing
            missing_dim(show_dim(j)) = true;
            missing_deriv{end+1} = CreateDimName(tags{i}, feat_dim_names(show_dim(j)), dimInfo(types{i}).args{show_ind(j)}{:});
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% match more complex secondary dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

parsed_dims = ParseDimInfo(dimInfo);      % parse the input dimenions info (this lets us know what's required to build it)
for i = 1:numel(parsed_dims.derived_name)
    
    % if its a function of a primary dimension, we've already taken care of it
    if (numel(parsed_dims.derived_input_col{i}) > 1) || any(parsed_dims.derived_input_col{i} > numel(feat_dim_names))
        
        % check all prequistites can be traced back to primary dimensions that exist
        all_preqs = true;
        invest_list = i + n_prim;
        while (numel(invest_list) && all_preqs)
            if (invest_list(1) > n_prim)  % investigating a derived dimension?
                
                % break its sources into primary and derived
                derived_ind = invest_list(1) - n_prim;
                inputs = parsed_dims.derived_input_col{derived_ind};
                prims = inputs(inputs <= n_prim);
                derivs = inputs(inputs > n_prim);
                all_preqs = all_preqs && all(mappings(prims) > 0);  % check primary
                invest_list = [invest_list(2:end); derivs(:)];      % and add derived to the investigate list
            else
                % just check it
                all_preqs = all_preqs && (mappings(invest_list(1)) > 0);
                invest_list = invest_list(2:end);
            end
        end
        
        % can we do it?
        if (all_preqs)
            
            % yep - now does it already exist in the new features
            derived_names = {mapped_dimInfo.derived_dims(:).name};
            index = find(strcmpi(derived_names, parsed_dims.derived_name{i}), 1, 'first');
            if numel(index)
               mapped_dimInfo.derived_disp(index) = parsed_dims.derived_disp(i);  % match its display status
            else
                
                % create it
                inputs = parsed_dims.derived_input_col{i};
                prims = inputs(inputs <= n_prim);
                prim_list = feat_dim_names(prims);
                derivs = inputs(inputs > n_prim) - n_prim;
                deriv_list = parsed_dims.derived_name(derivs);
                mapped_dimInfo.derived_dims(end+1) = DerivedDimFromSources(mapped_dimInfo, [prim_list(:); deriv_list(:)], parsed_dims.derived_tag{i}, parsed_dims.derived_args{i}{:});
                mapped_dimInfo.derived_dims(end).name = parsed_dims.derived_name{i};  % keep the same name
                mapped_dimInfo.derived_disp(end+1) = parsed_dims.derived_disp(i);
            end
        else
            
            % report missing dimensions
            missing_dim(prims) = missing_dim(prims) | (mappings(prims) <= 0);
            missing_deriv{end+1} = parsed_dims.derived_name{i};
            
        end
    end
end

% now report on the missing dimensions
for i = 1:numel(missing_dim)
    if (missing_dim(i))
        warning_list = sprintf('%sWarning: Primary dimension %s is used in the input features but is not present in the data set\n', warning_list, feat_dim_names{i});
    end
end
for i = 1:numel(missing_deriv)
    warning_list = sprintf('%sWarning: Could not recreate secondary dimension: %s due to missing primary dimensions\n', warning_list, missing_deriv{i});
end

% check we have at least one thing to calculate the features of
input_show = sum(parsed_dims.primary_disp) + sum(parsed_dims.derived_disp);
output_parsed = ParseDimInfo(mapped_dimInfo);
output_show = sum(output_parsed.primary_disp) + sum(output_parsed.derived_disp);

% call it a success?
success = (output_show > 0) || (input_show == 0);
if (~success)
    warning_list = sprintf('%sError: Could not match any dimensions used in feature calculations\n', warning_list);
end

