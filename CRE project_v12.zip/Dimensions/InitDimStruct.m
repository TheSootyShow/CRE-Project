function dimInfo = InitDimStruct(data_set)
% function dimInfo = InitDimStruct()
% function dimInfo = InitDimStruct(data_set)
% this function initialises the dimension information (including derived
% dimensions) used in the CRE project

default_SI =  {'absolute'};              % create these by default (types that take a single inputs)
default_MI = {'mag', 'enmo'};            % create these by default (types that take multiple inputs)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the list of supported secondary dimenion types (only include those that
% can operate on a single dimension)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

supported_type = {'derivitive', 'absolute', 'constant', 'magnitude', 'enmo', 'wavelet', 'square', 'ratio',    'sum', 'sumsquares'};
supported_tags = {'deriv',      'abs',      'const',    'mag',       'enmo',    'dwt',     'sq',     'rat',   'sum', 'sumsq'};                

% the functions used by each
supported_funcs = {@(X, varargin)CREderiv(X, varargin{:}), ...   % derivitive
                   @(X, varargin)abs(X), ...                     % absolute value
                   @(X, const, varargin)(const),   ...           % constant
                   @(X, varargin)sqrt(sum(X.*X,2)), ...          % magnitude
                   @(X, varargin)max(sqrt(sum(X.*X,2))-1,0), ... % normalized magnitude
                   @(X, varargin)CREdwt(X, varargin{:}), ...     % wavelets
                   @(X, varargin)(X.*X),  ...                    % square
                   @(X, varargin)(X(:,1) ./ X(:, 2)), ...        % ratio
                   @(X, varargin)sum(X,2), ...                   % sum
                   @(X, varargin)sum(X.*X,2)};                   % sum of squares

% input args used by each (can fill later, these are defaults)              
supported_args = repmat({{}}, 1, numel(supported_type));  % input args for the function
supported_args{strcmpi(supported_tags, 'deriv')} = {1, NaN};      % the second argument will be replaced by fs later
supported_args{strcmpi(supported_tags, 'dwt')} = {'db10', 'd4'};  % default for wavelets

% how many extra points the function needs for accurate calculation
epoint_func = repmat({@(varargin)(0)}, 1, numel(supported_type));           % normally none
epoint_func{strcmpi(supported_tags, 'deriv')} = @(order, varargin)(ceil(order/2));            % but derivitives need some
epoint_func{strcmpi(supported_tags, 'dwt')} =  @(type, varargin)(numel(wfilters(type, 'd'))); % as do wavelets


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% create the structure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dimInfo = struct('primary_dims',       [], ...          % primary dimensions to use
                  'primary_disp',      false(1,0), ...  % whether to show each primary dimension
                  'primary_names',     {{}}, ...        % names of the primary dimensions
                  'derived_dims',      [],   ...        % stores arbitrary derived dimensions
                  'derived_disp',      false(1,0), ...  % show arbitrary derived dimensions
                  'aliases',           {cell(0,2)});    % for relabelling dimensions
              
% add the format of more complex derived dimensions to the structure
dimInfo.derived_dims = repmat(InitDerivedDim(), 0, 1);  

% initialise a support structure
support_inf = struct('type',   [],    ... % type of this dimension type
                     'dims',   [],    ... % a vector of which primary dims have been created
                     'names',  {{}},  ... % the names for each of the above dimensions
                     'tag',    [],    ... % tag for this type
                     'func',   [],    ... % function used to calculate it
                     'epfunc', [],    ... % function to calculate how many pre/post points are required to calculate it
                     'disp',   [],    ... % a logical vector indicating which should be displayed
                     'args',   {{}});     % extra input arguments
    
    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add the supported dims
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i = 1:numel(supported_type)
    
    % and the sub strcuture of its contents
    dimInfo.(supported_type{i}) = support_inf;
    
    % the type
    dimInfo.(supported_type{i}).type = supported_type{i};
        
    % a vector of which primary dims are "intialized"
    dimInfo.(supported_type{i}).dims = [];
    
    % a cell array of the names
    dimInfo.(supported_type{i}).names = {};
    
    % the type of derived dimension
    dimInfo.(supported_type{i}).tag = supported_tags{i};
    
    % the function handle
    dimInfo.(supported_type{i}).func = supported_funcs{i};
    
    % extra points function
    dimInfo.(supported_type{i}).epfunc = epoint_func{i};
    
    % a bool vector for which are displayed
    dimInfo.(supported_type{i}).disp = false(1,0);
    
    % keep track of inputs to them
    dimInfo.(supported_type{i}).args = {};
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fill in the defaults to use        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin >= 1)
    
    % add names of primary dimensions
    dimInfo.primary_names = data_set.dim_names;
    
    % default to showing the first 3
    dimInfo.primary_dims = 1:data_set.dims;
    dimInfo.primary_disp = false(1, data_set.dims);
    if strcmpi(data_set.set_type, 'data')
        dimInfo.primary_disp(1:min(data_set.dims, 3)) = true;
    else
        dimInfo.primary_disp(:) = true;
    end
    
    % add the extra single dimenions operators
    for i = 1:numel(default_SI)
        
        % a bool vector for which are "intialized"
        dimInfo.(default_SI{i}).dims = dimInfo.primary_dims;  % initialise it on these dimensions
        
        % a bool vector for which are displayed
        dimInfo.(default_SI{i}).disp = false(1, numel(dimInfo.primary_dims));  % dont show it by default
        
        % keep track of input to them
        index = find(strcmpi(default_SI{i}, supported_type), 1, 'first');  % get the index into supported_args
        dimInfo.(default_SI{i}).args = cell(1, numel(dimInfo.primary_dims));
        [dimInfo.(default_SI{i}).args{:}] = deal(supported_args{index});  
        
        % build the names
        dimInfo.(default_SI{i}).names = cell(1, numel(dimInfo.primary_dims));
        for j = 1 : numel(dimInfo.primary_dims)
            dimInfo.(default_SI{i}).names{j} = CreateDimName(dimInfo.(default_SI{i}).tag, dimInfo.primary_names{j}, dimInfo.(default_SI{i}).args{j}{:});
        end
        
    end
    
    % add default multi dimension operators
    dimInfo.derived_dims = InitDerivedDim(numel(default_MI));
    dimInfo.derived_disp = false(1, numel(default_MI));
    for i = 1:numel(default_MI)
        n_set = min(data_set.dims, 3);
        dimInfo.derived_dims(i).type = default_MI{i};
        dimInfo.derived_dims(i).extra_points = 0;
        dimInfo.derived_dims(i).func = supported_funcs{strcmpi(default_MI{i}, supported_tags)};
        dimInfo.derived_dims(i).args = {};
        dimInfo.derived_dims(i).source{1,1} = 'primary';
        dimInfo.derived_dims(i).source{1,2} = 1:n_set;
        dimInfo.derived_dims(i).name = NameDerivedDim(dimInfo.derived_dims(i), dimInfo.primary_names);
        dimInfo.derived_disp(i) = false;
    end
end

              


    
   
    
    
    

                  
                  
