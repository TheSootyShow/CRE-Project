function derived_dim = DerivedDimFromSources(dimInfo, source_names, type, varargin)
% function derived_dim = DerivedDimFromSources(dimInfo, source_names, type, arg1, arg2, ..., argN)
% this function creates a derivided dimesnions from the inputted name 
% the input source_names should be a cell array of the names of the
% dimensions that this new dimenions is derived from

% initialise the output
derived_dim = InitDerivedDim();
                                             
if (nargin == 0)
    return;
end

% we can fill in the type
derived_dim.type = type;
derived_dim.args = varargin;  % always wrap args


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fill in the sources
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% extract primary dimensions
[derived_dim, source_names] = FindPrimaryDimensions(derived_dim, source_names, dimInfo.primary_names);

% ------ NEW WAY ----- % just lump everything else in as a derived
% dimension.  Must retain how to construct the derived dimension somewhere else
if (numel(source_names) == 0) && (numel(derived_dim.source{1,2}) > 0)
    derived_dim.source{1,1} = 'primary';
else
    if (numel(derived_dim.source{1,2}) == 0)
        derived_dim.source{1,1} = 'derived';
    else
        derived_dim.source{1,1} = 'mixed';
    end
    derived_dim.source{1,3} = reshape(source_names, 1, numel(source_names));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If its a recognised type, add the function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[known_types, known_tags] = GetKnownSecondaryDimTypes(dimInfo);

% this should pick up on whether its a simple dimension
index = find(strcmpi(type, known_tags), 1, 'first');
if numel(index)

    % copy the function over
    derived_dim.func = dimInfo.(known_types{index}).func;
    
    % now generate the name and number of other points
    derived_dim.name = NameDerivedDim(derived_dim, dimInfo.primary_names);

    % and calculate the extra points
    derived_dim.extra_points = feval(dimInfo.(known_types{index}).epfunc, derived_dim.args{:});
    
else
    
    error('Unknown dimension type: %s', type);
    
end






    


% ------ OLD WAY ----- %  allows for the reconstruction of this dimension entirely

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % look for primary dimensions
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% [derived_dim, source_names] = FindPrimaryDimensions(derived_dim, source_names, prim_dim_names);
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % look for derivitive dimensions
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% [derived_dim, source_names] = FindDerivitiveDimensions(derived_dim, source_names, prim_dim_names);
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % look for magnitude dimensions
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% [derived_dim, source_names] = FindMagnitudeDimensions(derived_dim, source_names, prim_dim_names);
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % now update with the unkown dimensions
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% derived_dim = FindUnkownDimensions(derived_dim, source_names, prim_dim_names);




function [derived_dim, source_names] = FindPrimaryDimensions(derived_dim, source_names, prim_dim_names)
% function [derived_dim, source_names] = FindPrimaryDimensions(derived_dim, source_names, prim_dim_names)
% function to find primary dimensions

[is_prim, ind] = ismember(source_names, prim_dim_names);
if any(is_prim)
    %derived_dim.source{end+1,1} = 'primary_dims';
    derived_dim.source{1,2} = ind(ind > 0);
    source_names = source_names(ind == 0);  % leave only unfound dimensions
end


function [derived_dim, source_names] = FindDerivitiveDimensions(derived_dim, source_names, prim_dim_names)
% function [derived_dim, source_names] = FindDerivitiveDimensions(derived_dim, source_names, prim_dim_names)
% function to find derived dimensions

% keep track of which are derivitives
is_deriv = false(1, numel(source_names));

for i = 1:numel(source_names)
    
    % does it follow the pattern?
    [token, other] = regexp(source_names{i}, 'd\d*\([^\(\)]+\)', 'match', 'split');
    
    % was it a perfect match?
    if all(cellfun(@numel, other) == 0)
        
        % its a derivitive
        is_deriv(i) = true;
        
        % get the derivitive order
        [d_ord_str, tmp] = regexp(token{1}, '^d\d+\(', 'match', 'tokens', 'once');
        if numel(d_ord_str)
            d_ord = str2double(d_ord_str(2:end-1));
        else
            d_ord = 1;  % assume first derivitive
        end
        
        % pull out the middle "bit"
        [name, other] = regexp(token{1}, '\(.*\)', 'match', 'tokens', 'once');
        
        % tokenize around commas
        tokens = CommaTokensIgnoreBrackets(name(2:end-1));
        
        % which are primary dimensions and which are derived?
        primary = zeros(1, numel(tokens));
        
        derived = cell(1, numel(tokens));
        for t = 1:numel(tokens)
            ind = find(strcmpi(tokens{t}, prim_dim_names), 1, 'first');
            if (numel(ind) == 1)
                primary(t) = ind;
            else
                % its a derived dimension itself
                derived{t} = tokens;
            end
        end
        
        % and add it to the sources
        derived_dim.source{end+1,1} = 'derivitive';
        derived_dim.source{end,2} = primary(primary > 0);
        derived_dim.source{end,3} = derived(cellfun(@numel, derived) > 0);
        derived_dim.source{end,4} = d_ord;
    end
end


% leave only unfound dimensions
source_names = source_names(~is_deriv);  

function [derived_dim, source_names] = FindMagnitudeDimensions(derived_dim, source_names, prim_dim_names)
% function [derived_dim, source_names] = FindMagnitudeDimensions(derived_dim, source_names, prim_dim_names)
% function to find magnitude dimensions

% keep track of which are magnitudes
is_mag = false(1, numel(source_names));

for i = 1:numel(source_names)
    
    % does it follow the pattern?
    [token, other] = regexp(source_names{i}, 'mag\([^\(\)]+\)', 'match', 'split');
    
    % was it a perfect match?
    if all(cellfun(@numel, other) == 0)
        
        % is a magnitude
        is_mag(i) = true;
        
         % pull out the middle "bit"
        [name, other] = regexp(token{1}, '\(.+\)', 'match', 'tokens', 'once');
        
        % tokenize around commas
        tokens = CommaTokensIgnoreBrackets(name(2:end-1));
        
        % which are primary dimensions and which are derived?
        primary = zeros(1, numel(tokens));
        derived = cell(1, numel(tokens));
        for t = 1:numel(tokens)
            ind = find(strcmpi(tokens{t}, prim_dim_names), 1, 'first');
            if (numel(ind) == 1)
                primary(t) = ind;
            else
                % its a derived dimension itself
                derived{t} = tokens;
            end
        end
        
        % and add it to the sources
        derived_dim.source{end+1,1} = 'magnitude';
        derived_dim.source{end,2} = primary(primary > 0);
        derived_dim.source{end,3} = derived(cellfun(@numel, derived) > 0);
    end
end

% leave only unfound dimensions
source_names = source_names(~is_mag);


function derived_dim = FindUnkownDimensions(derived_dim, source_names, prim_dim_names)
% function derived_dim = FindUnkownDimensions(derived_dim, source_names, prim_dim_names)
% function to find magnitude dimensions



for i = 1:numel(source_names)
    
    % does have the form of a function?
    [token, other] = regexp(source_names{i}, '\w*\(.*\)', 'match', 'split');
    
    if (numel(token) == 1) % yes
        
        b_ind(1) = find(token{1} == '(', 1, 'first');
        b_ind(2) = find(token{1} == ')', 1, 'last');
        
        % grab the function name and the argument
        fname = strtrim(token{1}(1:b_ind(1)-1));
        arg_str = strtrim(token{1}(b_ind(1)+1:b_ind(2)-1));
        
        % tokenize around commas
        tokens = CommaTokensIgnoreBrackets(arg_str);
        
        % which are primary dimensions and which are derived?
        primary = zeros(1, numel(tokens));
        derived = cell(1, numel(tokens));
        for t = 1:numel(tokens)
            ind = find(strcmpi(tokens{t}, prim_dim_names), 1, 'first');
            if (numel(ind) == 1)
                primary(t) = ind;
            else
                % its a derived dimension itself
                derived{t} = tokens;
            end
        end
        
        % and add it to the sources
        derived_dim.source{end+1,1} = fname;
        derived_dim.source{end,2} = primary(primary > 0);
        derived_dim.source{end,3} = derived(cellfun(@numel, derived) > 0);
    else
        
        % no idea what this is
        derived_dim.source{end+1,1} = 'unknown';
        derived_dim.source{end,3} = source_names{i};
        
    end
end


function tokens = CommaTokensIgnoreBrackets(str)
% function tokens = CommaTokensIgnoreBrackets(str)
% function to split str around commas, but not around commas nested in
% brackets

% start with normal tokenization
[tokens, misc] = regexp(str, '\s*,\s*', 'split', 'match');
b_count = 0;   % number of open brackets

% now join some
if any(str == '(')
    i = 1;
    while (i < numel(tokens))  % no need to check the next token
        tokens{i} = strtrim(tokens{i});
        b_count = b_count + (sum(tokens{i} == '(')) - (sum(tokens{i} == ')'));
        if (b_count > 0)
            % join the next token to it
            tokens{i} = [tokens{i}, ', ' tokens{i+1}];
            tokens = [tokens(1:i), tokens(i+2:end)];
        else
            % move along
            i = i + 1;
            b_count = max(b_count, 0);
        end
    end
end
        
        
    
        




    