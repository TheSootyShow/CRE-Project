% function hFig = tabTest()
% function hFig = tabTest()
% function to test tab properties

% to facilitate sizing
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
ppcm = ppi / 2.54;   

% create a figure
hFig = figure('units', 'pixels', 'visible', 'on');
fPos = get(hFig, 'position');

% a panel
hPanel = uipanel(hFig, 'title', 'Main Panel', 'units', 'pixels', 'position', [4,4,fPos(3:4)-8]);

% a tab group
hGroup = uitabgroup('parent', hPanel, 'tag', 'tgMainTab', 'visible', 'on', 'units', 'pixels');

% actual tabs
hTabs(1) = uitab(hGroup, 'tag', 'tmTimeTab', 'title', 'Tab 1');
hTabs(2) = uitab(hGroup, 'tag', 'tmTimeTab', 'title', 'Tab 2');

% desired sizes for the panes
paneSizes = [fPos(3:4)/4; fPos(3:4)/6];

% panels for the tabs
hTabsPanes(1) = uipanel(hTabs(1), 'backgroundcolor', [1,0,0], 'units', 'pixels', 'position', [1,1,paneSizes(1,:)]);
hTabsPanes(2) = uipanel(hTabs(2), 'backgroundcolor', [0,1,0], 'units', 'pixels', 'position', [1,1,paneSizes(2,:)]);

% adjust the base position
pos = get(hGroup, 'pos');
pos(2) = pos(2) + floor(pos(4)/2); 
pos(4) = floor(pos(4)/2);
set(hGroup, 'pos', pos)
%set(hGroup, 'backgroundcolor', [0,0,.5]);



% now test the placement function
[contSize, tabSize, tabBorder] = setTabGroupSize(hTabs, paneSizes);






