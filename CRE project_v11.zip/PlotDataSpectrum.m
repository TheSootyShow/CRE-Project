function [line_h, pxx, data_set] = PlotDataSpectrum(data_set, plotOptions, hAxis, cols, opts, status_func)
% function [line_h, pxx, data_set] = PlotDataSpectrum(data_set, plotOptions, hAxis, cols)
% function [line_h, pxx, data_set] = PlotDataSpectrum(data_set, plotOptions, hAxis, cols)
% this function plots the e power spectral density (using pwelch) of the data.  Each
% dimension is shown on a different axis
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set      - the data set structure to retrieve tha values from
%                 (see ImportCSV.m)
%
% plotOptions   - strcuture containing the plot options (see
%                 CREPlotOptions.m)
%
% hAxis         - handles of the axis to plot onto.  If supplied, this should be 
%                 the same length as dims. Default is to create a new figure
%
% cols          - colour of the plot (default is 'bkmgcr').  One colour is
%                 needed per dimension
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% line_h   - a vector containing the handle to each bar series (1 element
%            per dimension)
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This algorithm currently does not display the DC term
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!


% default colour order
def_cols = 'bkmgcr';



% Defaults for the pwelch calculation
pwelch_opts.n_windows = 8;       % divide into 8 sections (note: this may be increased depending on the max load size)
pwelch_opts.overlap = .5;        % use 50% overlap between sections (valid range is [0, .5])
pwelch_opts.window = @hamming;   % the windowing function
pwelch_opts.use_rat = .9;        % only use the window if it has more than this % of the desired values
pwelch_opts.nfft = NaN;          % use the same number of fft points as the signal length (or the maximum plot elements)
pwelch_opts.hideDC = true;       % hide DC component on the plots


% supply defaults
if (nargin < 6)
    status_func = [];
end

if (nargin < 5) || (numel(opts) == 0)

    % these should match ImportCSV.m
    opts.max_load_els     = 1562500;  % load the data in full if it has less than this many elements (~100mb)
    opts.max_plot_els     = 1e3;  % the maximum number of bars in a bar series
    
elseif ~isfield(opts, 'max_plot_els')

    opts.opts.max_plot_els     = 1e3;  % limit each line to 1000 points per line
    
end

if (nargin < 4) || (numel(cols) == 0)
    cols = def_cols;
end


if (nargin < 6) || (numel(hAxis) == 0)
    
    figure();

    % change to lines not bars, put them all on the same plot
    hAxis = gca;
    set(hAxis, 'xgrid', 'on');
    set(hAxis, 'ygrid', 'on');
    xlabel('Freq (Hz)');
    ylabel('dB / Hz');
        
%   hAxis = zeros(1, outputDims.n_display);    
%     for i = 1:outputDims.n_display
%         hAxis(i) = subplot(outputDims.n_display, 1, i);
%         set(hAxis(i), 'xgrid', 'on');
%         set(hAxis(i), 'ygrid', 'on');
%         xlabel('Freq (Hz)');
%         ylabel('dB / Hz');
%         title(sprintf('Power Spectral Density: dim %i', dims(i)));
%     end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% turn he time range to plot into indices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (plotOptions.timeRange.full)
    [relTime, indexs] = TimeRangeToRelative(data_set, plotOptions.timeRange.ds_stamp);
    runToEnd = data_set.view_type < 2;  % the number of points in the file may be approximate, so run past the final index
else
    [relTime, indexs] = TimeRangeToRelative(data_set, plotOptions.timeRange.tstamp);
end
n_points = indexs(2) - indexs(1) + 1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the dimensions to plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% convert the dimenion info structure into a form where
outputDims = ParseDimInfo(plotOptions.dimInfo, data_set);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% how many points for the fft?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fRange = plotOptions.freqRange.fbounds;  % shortcut
max_plot_els_mod = floor(opts.max_plot_els / (diff(fRange) / (data_set.fs / 2)));  % modified because we may only wish to view a section of it
if isnan(pwelch_opts.nfft)
    %pwelch_opts.nfft = min([n_points, max_plot_els_mod, ceil(2*data_set.fs)]);  % default to the same number of points
    pwelch_opts.nfft = min(n_points, max_plot_els_mod);  % default to the same number of points
end


% do we need to down sample points for the lines?
if (pwelch_opts.nfft > max_plot_els_mod)
    dr = ceil(pwelch_opts.nfft / max_plot_els_mod);
    n_plot = 1 + floor((n_points-1) / dr);
else
    dr = 1;  % no down sampling
    n_plot = pwelch_opts.nfft;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% how many windows to use?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

max_block_points = ceil(opts.max_load_els / outputDims.n_dims);

% NOTE: block size come from the formula: w = (n - bo) / ((1+o)*b) where b
% doesn't include overlap
pwelch_block_points = n_points / (pwelch_opts.n_windows + pwelch_opts.n_windows*pwelch_opts.overlap + pwelch_opts.overlap);  % block size not including overlap
if (max_block_points >= (1 + 2*pwelch_opts.overlap) * pwelch_block_points)
    
    % in this case we can use the desired number of windows
    block_points = floor(pwelch_block_points);
    
else
    % increase the number of windows
    block_points = floor(max_block_points  / (1 + 2*pwelch_opts.overlap));

end

% get a rational approximation of the overlap
[on,od] = rat(pwelch_opts.overlap);
if (od < 10)
    dx = rem(block_points, od);
    block_points = block_points - (dx > 0) * (od - dx);  % convenient to make the overlap size an integer
end

% now finess the number overlap points into integers
n_overlap = ceil(pwelch_opts.overlap * block_points);
sec_points = [n_overlap, block_points, n_overlap];
tot_block_points = sum(sec_points);

% now the number of windows
n_windows = floor((n_points - n_overlap) ./ (tot_block_points - n_overlap));

% the window is then
window = feval(pwelch_opts.window, tot_block_points);
window = repmat(window(:),  1, outputDims.n_display);
wp = sum(window(:,end).*window(:,end));  % the window power

% uncomment this to compare this algorithms to matlabs pwelch
% figure;
% pwelch(GetData(data_set, indexs, false, dims(1)), window, n_overlap, pwelch_opts.nfft, data_set.fs);


%%%%%%%%%%%%%%%%%%%%%%%%
% start grabbing data  %
%%%%%%%%%%%%%%%%%%%%%%%%

sections = cell(3,1);              % first, middle, last
sec_inds = [0, sec_points(1) - 1; ...
            sec_points(1), sec_points(1) + sec_points(2) - 1; ...
            sec_points(1) + sec_points(2), sum(sec_points) - 1];
sec_inds = sec_inds + indexs(1);  % adjust to start in the correct spot        

% load the first section and stick it in the last place
if (pwelch_opts.overlap)
    [sections{3}, data_set] = GetDerivedDims(data_set, sec_inds(1,1), sec_inds(1,2), outputDims);
else
    sections{3} = zeros(0, outputDims.n_display);
end

% allocate space
pxx = zeros(pwelch_opts.nfft, outputDims.n_display);
used_windows = 0;

i = 0;
while (i < n_windows) || runToEnd
    
    % transfer the last block (the first and last block are the same)
    sections{1} = sections{3};
    
    % load the "middle" block
    [sections{2},data_set] = GetDerivedDims(data_set, sec_inds(2,1), sec_inds(2,2), outputDims); 
    
    % check we aren't out of points
    if (size(sections{2},1) == sec_points(2))
        
        % load the last block
        [sections{3},data_set] = GetDerivedDims(data_set, sec_inds(3,1), sec_inds(3,2), outputDims); 
        eof = size(sections{3},1) < n_overlap;
    
    elseif (numel(sections{2}) == 0)
        eof = true;
        break;
        
    else
        
        % include it if we have more points than in the overlap section
        if (size(sections{2},1) > n_overlap)
            eof = true;
            sections{3} = zeros(0, size(sections{2},2));
        else
            eof = true;
            break;
        end
    end
            
    
    % convert to a single "chunk"
    yt = cell2mat(sections);
    
    % apply window
    if (~eof)
        yt = yt .* window;
    else
        yt = yt .* window(1:size(yt,1),:);
    end
    
    % convert to freq domain via the fft
    if (size(yt,1) > pwelch_opts.nfft)
        
        % Handle the case where NFFT is less than the segment length, i.e., "wrap"
        % the data as appropriate.
        xw = zeros(pwelch_opts.nfft, size(yt, 2));
        for j = 1:size(yt, 2)
            xw(:,j) = datawrap(yt(:,j), pwelch_opts.nfft);
        end
        yt = fft(xw, pwelch_opts.nfft, 1);
    else
        yt = fft(yt, pwelch_opts.nfft, 1);
    end
    
    % square it
    yt = yt .* conj(yt) / wp;  % divide here for equivilence to matlab's pwelch
    
    % and add it
    pxx = pxx + yt;
    
    % add increment the grab data indices
    sec_inds = sec_inds + tot_block_points - sec_points(1);
    sec_inds(:, 2) = min(sec_inds(:, 2), indexs(2));
    
    % another used window
    used_windows = used_windows + 1;
    
    % update the status
    if numel(status_func)
        feval(status_func, i, n_windows);
    end
    
    % break if out of data
    if (eof)
        break;
    end
    
end

% scale pxx
pxx = pxx / used_windows;

% select the interesting parts
if rem(pwelch_opts.nfft,2),
    pxx = [pxx(1,:); 2*pxx(2:(pwelch_opts.nfft+1)/2, :)]; % ODD - Only DC is a unique point and doesn't get doubled
else
    pxx = [pxx(1,:); 2*pxx(2:pwelch_opts.nfft/2, :); pxx(pwelch_opts.nfft/2+1, :)]; % EVEN - Don't double unique Nyquist point
end

% fix units
pxx = pxx ./ data_set.fs;

% creating corresponding frequencies
f_all = data_set.fs * ((0:size(pxx,1)-1) / pwelch_opts.nfft);

% down sample if needed
if (dr > 1)
    pxx = pxx(1:dr:end,:);
    f_all = f_all(1:dr:end,:);
end

% select frequency range to view
fview_inds = [find(f_all >= fRange(1), 1, 'first'), find(f_all <= fRange(2), 1, 'last')];

% hide DC?
if (pwelch_opts.hideDC) && (f_all(fview_inds(1)) == 0)
    fview_inds(1) = min(fview_inds(1)+1, fview_inds(2));
end
pxx = pxx(fview_inds(1):fview_inds(2), :);
f_all = f_all(fview_inds(1):fview_inds(2));

% convert to dB
% We want to guarantee that the result is an integer
% if X is a negative power of 10.  To do so, we force
% some rounding of precision by adding 300-300.
pow = (10.*log10(pxx)+300)-300;

% get the display name for each dimenions
[dim_names, selected] = GetAllDimensionNames(plotOptions.dimInfo);
dim_names = dim_names(selected);

% and plot it
line_h = zeros(1, outputDims.n_display);
leg_txt = cell(1, outputDims.n_display);
astate = get(hAxis, 'nextplot');
set(hAxis, 'nextplot', 'add');

for i = 1:outputDims.n_display
    
    line_h(i) = plot(hAxis, f_all, pow(:, i), cols(rem(i-1, numel(cols))+1));
    xlim = get(hAxis, 'xlim');
    xlim(1) = max(xlim(1), 0);
    set(hAxis, 'xlim', xlim);
    leg_txt{i} = dim_names{i};
    
end
set(hAxis, 'xgrid', 'on');
set(hAxis, 'ygrid', 'on');
set(hAxis, 'nextplot', astate);

% add a legend
legend(line_h, leg_txt);

% set x label
xlabel(hAxis, 'Frequency (Hz)')
ylabel(hAxis, 'dB / Hz')


% use this for individual axes
% for i = 1:outputDims.n_display
%     
%     astate = get(hAxis(i), 'nextplot');
%     set(hAxis(i), 'nextplot', 'add');
%     line_h(i) = plot(hAxis(i), f_all, pow(:, dims(i)), 'b');
%     set(hAxis(i), 'nextplot', astate);
%     xlim = get(hAxis(i), 'xlim');
%     xlim(1) = max(xlim(1), -.5);
%     set(hAxis(i), 'xlim', xlim);
%     
% end




function window = rect(n)
% function window = rect(n)
% create a 1d rectangular window

window = ones(n, 1);



