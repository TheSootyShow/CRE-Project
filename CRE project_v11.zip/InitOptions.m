function options = InitOptions()
% function options = InitOptions()
% function to initiliase the options specifying the maximums sizes that can
% be used

options.view_type        = 2;            % 2 = fully load csv's, 1 = partial load csv's (num_points is an estimate).  
options.max_header_lines = 500;          % headers should be larger than this (over allocate to judge dimensions)
options.max_lookup       = 1e5;          % the lookup table has this many entries at most
options.max_load_els     = 3 * 1562500;  % load the data in full if it has less than this many elements (~300mb)
options.max_plot_els     = 1e5;          % limit each line to 10,000 points per line
options.max_bar_els      = 512;          % the maximum number of bars in a bar series