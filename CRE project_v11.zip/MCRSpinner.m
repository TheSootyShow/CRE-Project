function hFig = MCRSpinner(title)
% function hFig = MCRSpinner(title)
% function to give the user something to look at while the MCR loads


% create a figure
hFig = figure('Toolbar', 'none', 'MenuBar', 'none', 'units', 'pixels', 'numbertitle', 'off', 'Color', [1,1,1], 'name', title);
fig_size = get(hFig, 'position');
fig_size(3:4) = 240;
set(hFig, 'position', fig_size);

% where is the gif
path = fileparts(mfilename('fullpath'));
fig_file = fullfile(path, 'circular.gif');

% Create a spinning thing
je = javax.swing.JEditorPane('text/html', ['<html><img src="file:/', fig_file, '"/></html>']);
[hj, hc] =  javacomponent(je,[],hFig);
set(hc, 'pos', [7,-5,fig_size(3),fig_size(4)]);

