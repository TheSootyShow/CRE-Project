function dir = CreateFigureResourceDir()
% function dir = CreateFigureResourceDir()
% this function creates a directory in which to 
% save gui's after resize

persistent CRE_figure_directory;

% first time?
if (numel(CRE_figure_directory) == 0)
    if ~(isdeployed)
        CRE_figure_directory = fullfile(fileparts(mfilename('fullpath')), 'FigureResource');
    else
        % have a look where the executable is (might save some figs)
        [status, exec_dir] = system('path');
        if status == 0
            exec_dir = char(regexpi(exec_dir, 'Path=(.*?);', 'tokens', 'once'));
        end
        CRE_figure_directory = fullfile(exec_dir, 'FigureResource');
    end
    
    % if the figure resource directory doesn't exist, create it
    if ~exist(CRE_figure_directory, 'dir')
        try
            mkdir(CRE_figure_directory);  % may not be able to make it without admin privileges
        catch
            CRE_figure_directory = [];
        end
    end
    
    % check we have write permission
    if ischar(CRE_figure_directory)
        % atrribs = fileattrib(settings_dir);  % not on this version
        test_file = fullfile(CRE_figure_directory, 'tmp_creproject.txt');
        fid = fopen(test_file, 'w');
        if (fid > 0)
            fclose(fid);
            delete(test_file);
        else
            CRE_figure_directory = -1;  % indicates we can't use it
        end
    end
end

% retrieve it
if ischar(CRE_figure_directory) && exist(CRE_figure_directory, 'dir')
    dir = CRE_figure_directory;
else
    dir = [];
end
