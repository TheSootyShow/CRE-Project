function CheckFileOverwrite(dataset_src, dataset_dest, n_blocks)
% function CheckFileOverwrite(dataset_src, dataset_dest, n_blocks)
% this function checks we aren't overwriting the file as we read from it

overwrite = strcmpi(dataset_src.file_name, dataset_dest.file_name);     % fine if different files
overwrite = overwrite && (n_blocks > 1);                                % fine if we read it all in 1 go
overwrite = overwrite && (numel(dataset_src.data) == 0);                % fine if preloaded

if (overwrite)
    error('Source and destination files share the same name: %s\nThis is only allowed when the source file is small enough to be read in one pass', data_set.file_name);
end