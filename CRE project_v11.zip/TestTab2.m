
n_tabs = 5;

% create a figure
hFig = figure('units', 'centimeters');
pos = get(hFig, 'position');
pos(3:4) = n_tabs + 1;

% create the main tab
hTabGroup = uitabgroup('parent', hFig);

% and create the tabs with a pane
hTabs = zeros(1, n_tabs);
hPanels = zeros(1, n_tabs);
for i = 1:n_tabs
    hTabs(i) = uitab(hTabGroup, 'title', sprintf('Tab %i', i));
    hPanels(i) = uipanel(hTabs(i), 'backgroundcolor', circshift([.75,0,0], [0, i-1]));
end
    

