function str = TrimDecimals(str)
% function str = TrimDecimals(str)
% function to trim unused decimal places from a string

str = regexprep(str, '(?<=\.\d*)0+$', '');
if (str(end) == '.')
    str(end) = [];
end
