function [fh, txt_h] = CreateMsgBox(title, text_cell, modal)
% function [fh, txt_h] = CreateMsgBox(title, text_cell, modal) 
% this function creates a message box similar to the Matlab 
% message box (I dont like Matlab's message box)

if (nargin < 3) || (numel(modal) == 0)
    modal = false;
end

% make tabs this many characters
tab_chars = 4;

% border gap in pixels
b_gap = 10;

% create a figure
fh =dialog(                                           ...
        'Name'            , title                   , ...
        'Pointer'         , 'arrow'                 , ...
        'Units'           , 'points'                , ...
        'Visible'         ,'off'                    , ...
        'KeyPressFcn'     ,@doKeyPress              , ...
        'WindowStyle'     ,'normal'                 , ...
        'Toolbar'         ,'none'                   , ...
        'HandleVisibility','on'                     , ...
        'Tag'             ,'MsgboxTag'                ...
        );
    

% create an "OK buttton for it
pb_pos = [0,0, 50, 25];                             % only care about the size no the position
pb_h =uicontrol(fh,                                           ...
    'Style'              ,'pushbutton'                      , ...
    'Units'              ,'points'                          , ...
    'Position'           , pb_pos                           , ...
    'Callback'           ,'delete(gcbf)'                    , ...
    'KeyPressFcn'        ,@(hObject, eventdata)doKeyPress(hObject, eventdata, modal)                       , ...
    'String'             ,'OK'                              , ...
    'HorizontalAlignment','center'                          , ...
    'Tag'                ,'OKButton'                          ...
    );    




% get handles to its components (change units (dont initialise in pixels)
set([fh, pb_h], 'units', 'pixels');  % work in pixels

% get some positions
b_pos = get(pb_h, 'position');
f_pos = get(fh, 'position');


% cover it in a uipane (dont show the frame)
ui_pos = [-b_gap, -b_gap, f_pos(3:4) + 2* b_gap];
ui_panel = uipanel('Parent',fh, 'units', 'pixels', 'position', ui_pos);

% create on box quickly to get line height
[tmp_h, tmp_hg] = javacomponent({'javax.swing.JLabel', 'hello'}, [], ui_panel);
siz = tmp_h.getPreferredSize();
char_height = siz.height;
char_width = siz.width / numel('hello');
tab_width = tab_chars * char_width;
def_font = tmp_h.getFont();
bodyRule = ['body { font-family: ', def_font.getFamily().char(), '; font-size: ', num2str(def_font.getSize()), 'pt; }'];
delete(tmp_h);

% now figure out how hight the figure should be
fig_height = (char_height + 1) * numel(text_cell) + b_pos(4) + 3 * b_gap;
dY = (fig_height - f_pos(4))/2;  % keep it centered
f_pos(2) = f_pos(2) - dY;
f_pos(4) = f_pos(4) +2*dY;


% now start placing the boxes
max_width = 0;
y = -ui_pos(2) + 2*b_gap + 1 + b_pos(4);

% go from bottom to top
tchar = sprintf('\t');
txt_h = cell(numel(text_cell), 2);    
for i = numel(text_cell):-1:1
    
    if numel(text_cell{i})
        
        n_tab = 0;
        while (n_tab < numel(text_cell{i})) && (text_cell{i}(n_tab+1) == tchar)
            n_tab = n_tab + 1;
        end
        
        % now create the box
        txt_pos = [n_tab * tab_width - ui_pos(1) + b_gap + 1, y, 100, char_height];
        [txt_h{i,1}, txt_h{i,2}] = javacomponent('javax.swing.JTextPane', txt_pos, ui_panel);
        txt_h{i,1}.setContentType('text/html'); 
        txt_h{i,1}.setText(text_cell{i});
        txt_h{i,1}.getDocument().getStyleSheet.addRule(bodyRule);
        txt_h{i,1}.setEditable(false); 
        txt_h{i,1}.setOpaque(false); 
        txt_h{i,1}.setBorder(''); 
        txt_h{i,1}.setFont(def_font);
        
        % and change its width to the preferred width
        box_size = txt_h{i,1}.getPreferredSize();
        if (box_size.width + n_tab * tab_width > max_width)
            max_width = box_size.width + n_tab * tab_width;
        end
        
        % update the position
        txt_pos(3) = box_size.width;
        txt_pos(4) = box_size.height;
        set(txt_h{i,2}, 'position', txt_pos);
        
    end
    y = y + char_height + 1;
end


% change the size of the figure
dX = ((max_width + 2*b_gap) - f_pos(3)) / 2;
f_pos(1) = f_pos(1) - dX;
f_pos(3) = f_pos(3) +2*dX;
set(fh, 'position', f_pos);
ui_pos = [-b_gap,-b_gap, f_pos(3:4) + 2*b_gap];
set(ui_panel, 'position', ui_pos);
b_pos(1) = (f_pos(3) - b_pos(3)) / 2;
b_pos(2) = b_gap;
set(pb_h, 'position', b_pos);

% and render it
set(fh, 'visible', 'on');

if (modal)
    uiwait(fh);
end







%%%%% doKeyPress
function doKeyPress(obj, evd, modal)
    switch(evd.Key)
        case {'return','space','escape'}
            hFig = ancestor(obj,'figure');
            if (modal)
                uiresume(hFig);
            end
            delete(hFig);
    end





