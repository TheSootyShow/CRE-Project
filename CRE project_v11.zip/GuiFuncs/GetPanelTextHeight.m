function [text_height, hTitle] = GetPanelTextHeight(h_uiPanel, relative)
% function [text_height, hTitle] = GetPanelTextHeight(h_uiPanel, relative)
% use this function to get text height (pixels) of the title of a uipanel
% if relative = true, the returned height is relative to where the top of the
% panel would be if it didn't have text

rat = .55;  % see PanelTitleHeightModifier for this

% get a handle to the title (its actually a seperate ui control)
warning('off', 'MATLAB:Uipanel:HiddenImplementation');
hTitle = get(h_uiPanel,'TitleHandle');
warning('on', 'MATLAB:Uipanel:HiddenImplementation');

% set units
text_height = 0;  % default output
if (numel(get(h_uiPanel, 'title')) > 0) && (numel(hTitle))
    
    old_units = get(hTitle, 'units');
    set(hTitle, 'units', 'pixels');
    
    % and report the height
    %ext = get(hTitle, 'extent');
    %text_height = ext(4);
    pos = get(hTitle, 'position');
    text_height = pos(4);
    
    % reset units
    set(hTitle, 'units', old_units);
    
    if (relative)
        % the height above the panel line in thise case
        text_height = floor(text_height * rat);
    end
    
    
end