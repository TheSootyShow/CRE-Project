function resize = RunResizeFcn(hObject, handles)
% function resize = RunResizeFcn(hObject, handles)
% function to return yes / no depending on whether the figure need to be
% reized

% check if the gui is the correct size
corrSize = CheckGuiSize(hObject);
resize = IsDeveloper() || (~corrSize);

% old scheme - "no longer using screen_info"
% opt = IsDeveloper() || (~isfield(handles, 'screen_info') || (ppi ~= handles.screen_info.ppi) || ~all(screenSize(3:4) == handles.screen_info.pix_size));

