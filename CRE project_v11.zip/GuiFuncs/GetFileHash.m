function hash = GetFileHash(file_name, hbytes)
% function hash = GetFileHash(file_name, hbytes)
% function the get a MD5 file hash for the first hbytes of the file

% set it up to read through java
mddigest   = java.security.MessageDigest.getInstance('MD5'); 
filestream = java.io.FileInputStream(java.io.File(file_name)); 
digestream = java.security.DigestInputStream(filestream,mddigest);

% check hybtes is in range (file may change)
file_info = dir(file_name);
bytes = file_info.bytes;
hbytes = min(bytes, hbytes);

% and form the hash
for i = 1:hbytes
    digestream.read();
end
hash = reshape(dec2hex(typecast(mddigest.digest(),'uint8'))',1,[]);

% append the file bytes to it (yep, dodgy as)
hash = [hash, dec2hex(bytes)];