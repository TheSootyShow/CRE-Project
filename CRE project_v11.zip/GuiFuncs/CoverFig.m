function hCover = CoverFig(hFig)
% function hCover = CoverFig(hFig)
% function to create a cover for a figure,
% so the user won't see its being manipulated

hCover = figure('units', get(hFig, 'units'), 'position', get(hFig, 'position'), ...
                'toolbar', get(hFig, 'toolbar'), 'menubar',  get(hFig, 'menubar'), ...
                'name', get(hFig, 'name'), 'NumberTitle', get(hFig, 'NumberTitle'), ...
                'color', get(hFig, 'color'));
            
% need to copy the menu's over
hMenus = copyobj(findobj(hFig, 'type', 'uimenu', 'parent', hFig), hCover);
set(hMenus, 'callback', []);
            
% copy appearance            
frame = getframe(hFig);
hObject = uicontrol(hCover,'Style','pushbutton','units','normalized','position',[0,0,1,1],'cdata',frame.cdata);

% make it inaccessable (cant be closed by the user)
jFrame = GetjFrame(hCover);
set(jFrame, 'enabled', false);
jFrame = [];

set(hCover, 'visible', 'on');
drawnow();