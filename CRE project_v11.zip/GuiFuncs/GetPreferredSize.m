function [height, width, control_type, font_info] = GetPreferredSize(hObject, user_prefs)
% function [height, width, control_type, font_info] = GetPreferredSize(hObject, user_prefs)
% this function gets the preffered size of the object hObject
% If the control type, font, font weight and font size have been previously encountered
% it returns the size from a prestored list.  Otherwise it queries the java
% object for the preferred size.  The object must be visible to retrieve
% its preferred size from the java object
%
% height and width are in pixels
%
% If user_prefs is true (default) user modifications are made to the
% preferred sizes based on the control type
%
% edit boxes are always left at their current width!
%
% use:
% use_java = GetPreferredSize() to see if java placement is currently used
%            if java placement is used, the figure must be visible!


persistent font_list height_list width_list

use_java = false;  

% return java state if no inputs
if (nargin == 0)
    height = use_java;
    return;
end

if (size(font_list, 2) < 6)
    font_list = cell(0,6);
    height_list = zeros(0,1);
    width_list = zeros(0,1);
end

% default to user modifications to sizes
if (nargin < 2) || (numel(user_prefs) == 0)
    user_prefs = true;
end

% get the screen resolution in pixels per cm
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
ppcm = ppi / 2.54;                                          % pixels per centimeter


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% User modifications
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% dont let list boxes or popupmenus get less than 2 cm wide
BOX_MIN_WIDTH = ceil(2 * ppcm);  % applies to 'listbox', 'popupmenu'

% For JAVA (if use java = true)
if (use_java)
    JAVA_fake_rb_height = true;              % radio button preferred height seems to be broken, base it off text size instead
    JAVA_rb_height_add = 2*ceil(.05 * ppcm);
    JAVA_rb_width_add = 2*ceil(.1 * ppcm);
    JAVA_eb_height_add = 2*ceil(.1 * ppcm);  % make edit boxes .1cm larged than the java preferred size for their text (top and bottom)
    JAVA_txt_height_add = 2;                 % add two pixels to the height of plain text
    JAVA_txt_width_add = 2;                  % add two pixels to the width of plain text
    JAVA_pm_height_add = 0;
end

% For NOT JAVA (if use java = false)
if (~use_java)
    
    NOJAVA_graphic_width = 20;  % ans this much ato account for the icon / slider widths for {'listbox', 'radiobutton', 'checkbox'}
    NOJAVA_pm_height_add = 5;   % make push menus the same height as edit boxes
    NOJAVA_eb_height_add = 0;   % add height to edit boxes (try to make them the same height as a push menu
   
end






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up optional inputs for findjobj
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

findjobj_args = {};
if ~strcmpi(get(hObject, 'type'), 'uimenu')
    findjobj_args{1} = 'nomenu';
end
findjobj_args{end+1} = 'persist';  % always use this


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now process
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% get the properties of this object
control_type = get(hObject, 'type');
control_tag = get(hObject, 'tag');
if ~ischar(control_tag)
    control_tag = '';
end
if strcmpi(control_type, 'uicontrol')
    control_type = get(hObject, 'style');
end

% and its font
font_name = get(hObject, 'fontname');
font_size = get(hObject, 'fontsize');
font_weight = get(hObject, 'fontweight');
str = get(hObject, 'string');

% since we leave the width of an edix box at what it was,
% we only need to ensure that it has the correct number of lines
if (use_java) && any(strcmpi(control_type, {'edit'}))
    n_lines = numel(str) * iscell(str) + ~iscell(str);
    str = [n_lines, hObject];  % dont mix it up with another text box
end

% similarly for listboxes, however we do change their width so keep track
% of the maximum chars as an approximation
% if any(strcmpi(control_type, {'listbox'}))
%     if ~iscell(str)
%         str = [1, numel(str)];
%     else
%         str = [numel(str), max(cellfun(@numel, str))];
%     end
% end





% does it match anything in the list?
if numel(str)
    match = find(...
                 strcmpi(font_list(:,1), control_type) & ...            % match the control type
                 strcmpi(font_list(:,2), control_tag) &  ...            % match the control name
                 strcmpi(font_list(:,3), font_name) &    ...            % match the font family
                 cellfun(@(x)(x == font_size), font_list(:,4)) & ...    % match the font size
                 strcmpi(font_list(:,5), font_weight) &  ...            % match the font weight
                 cellfun(@(x)(isequal(str, x)), font_list(:,6)), ...    % match the string
              1, 'first');
else
    match = [];
end
         
if (numel(match) == 0)
    
    % deal with it if its a radio / check button
    if (use_java) && (user_prefs) && (JAVA_fake_rb_height) && any(strcmpi({'radiobutton', 'checkbox'}, control_type))
        
        % try to match font family info with a text control
        txt_match = find(...
                         strcmpi(font_list(:,1), 'text') & ...                              % match it to a text box
                         strcmpi(font_list(:,3), font_name) & ...                           % match the font family
                         cellfun(@(x)(x == font_size), font_list(:,4)) & ...                % match the font size 
                         strcmpi(font_list(:,5), font_weight) &  ...                        % match the font weight
                         cellfun(@(x)(~iscell(x) || numel(x) == 1), font_list(:,6)), ...    % ensure its a single line string
             1, 'first');
         
         if (numel(txt_match))
             
             % It matched something, use the text parameters
             height = height_list(txt_match);  
             
             % take its preferred width though
             jObject = CheckJObj([], hObject, findjobj_args);
             width = jObject.getPreferredSize.width(); 
             jObject = []; % explicity clear
             
             
         else
             
             % in this case, create a txt control and get its prefered height
             txt_h = uicontrol('style', 'text', 'fontname', font_name, 'fontsize', font_size, 'fontweight', font_weight, 'String', str, 'tag', 'Virtual');
             jObject = CheckJObj([], txt_h, findjobj_args);
             height = jObject.getPreferredSize.height() + JAVA_txt_height_add;  
             width = jObject.getPreferredSize.width(); 
             
             % we have the sizes so delete the control
             delete(txt_h);
             jObject = []; % explicity clear

         end
         
         % make user chnages to the size
         width = width + JAVA_rb_width_add;
         height = height + JAVA_rb_height_add;
    
    elseif (use_java) 
        
        % query it in this case
        jObject = CheckJObj([], hObject, findjobj_args);
        
        if (numel(jObject) == 0)
            error('Failed to find the java object for %s.  Is the %s visible?', get(hObject, 'tag'), control_type);
        end
        height = jObject.getPreferredSize.height();  
        width = jObject.getPreferredSize.width();
        jObject = []; % explicity clear
        
        % if this is an edit box, multiply by the number of lines
        if (strcmpi(control_type, 'edit'))
            height = height * n_lines;  % str is transformed into the number of lines
            old_units = get(hObject, 'units');
            pos = get(hObject, 'position');
            width = pos(3);
            set(hObject, 'units', old_units);
        end
        
        % insert user prefs
        if (user_prefs)
            if strcmpi(control_type, 'text')
                height = height + JAVA_txt_height_add;
                width = width + JAVA_txt_width_add;
            elseif strcmpi(control_type, 'edit')
                height = height + JAVA_eb_height_add;
            elseif strcmpi(control_type, 'popupmenu')
                height = height + JAVA_pm_height_add;
            end
        end
        
    else
        
        % just dump its string through textwrap :-(
        set(hObject, 'units', 'pixels');
        if iscell(str)
            [max_cols, ind] = max(cellfun(@numel, str));
            max_cols = max_cols + 1;
            if strcmpi(control_type, 'popupmenu')
                [wrapped_str, pos] = textwrap(hObject, str(ind), max_cols);  % assume a popupmenu should only be 1 line high
            else
                [wrapped_str, pos] = textwrap(hObject, str, max_cols);
            end
        else
            max_cols = numel(str) + 1;
            [wrapped_str, pos] = textwrap(hObject, {str}, max_cols);
        end
        width = pos(3);
        height = pos(4);  
        
        % fix the widths of ui object with non-text to render
        if any(strcmpi(get(hObject, 'style'), {'listbox', 'radiobutton', 'checkbox', 'popupmenu'}))
            width = width + NOJAVA_graphic_width;  % sliders and checkboxes always appear this wide
        end
        
        % add height to push menus so they're the same height as edit boxes
        if strcmpi(control_type, 'popupmenu')
            height = height + NOJAVA_pm_height_add;
        elseif strcmpi(control_type, 'edit')
            height = height + NOJAVA_eb_height_add;
        end
    end
    
    % dont shrink list boxes or popupmenus
    if any(strcmpi(control_type, {'listbox', 'popupmenu'}))
        set(hObject, 'units', 'pixels');
        pos = get(hObject, 'position');
        width = max(width, pos(3));
    end
    
    % dont let list boxes or popupmenus get less than 2 cm wide
    if any(strcmpi(control_type, {'listbox', 'popupmenu'}))
        width = max(width, BOX_MIN_WIDTH);
    end
    
    % and add it to the list
    font_info = {control_type, control_tag, font_name, font_size, font_weight, str};
    if numel(str)
        font_list(end+1,:) = font_info;
        height_list(end+1,1) = height;
        width_list(end+1,1) = width;
    end
    
elseif (numel(match) > 1)
    error('Found multiple matches');
else
    
    % return known values
    height = height_list(match);
    width = width_list(match);
    
    % return font info as well
    font_info = font_list(match, :);
    
end




function jObj = CheckJObj(jObj, hObj, params)
% function jObj = CheckJObj(jObj, hObj, params)
% checks that a unique java object was found

max_tries = 5;
n_tries = 0;

% try to find it if not provided on input
if (numel(jObj) == 0)
    jObj = findjobj(hObj, params{:});

    % try again without the persist
    if (numel(jObj) == 0)
        if any(strcmpi(params, 'persist'))
            params_sp = params(~strcmpi(params, 'persist'));
        end
        
        % try a few more times
        while (numel(jObj) == 0) && (n_tries < max_tries)
            drawnow();
            jObj = findjobj(hObj, params_sp{:});
            n_tries = n_tries + 1;
        end    
    end
end

if (numel(jObj) > 1)
    jObj_str = '';
    for i = 1:numel(jObj)
        jObj_str = sprintf('%s\t%s\n', jObj_str, char(jObj(i).getClass()));
    end
    warning('Found %i java objects for Matlab object with tag "%s":\n%s', numel(jObj), get(hObj, 'tag'), jObj_str);
    jObj = jObj(1);
elseif (numel(jObj) == 0)
    error('Found %i java objects for Matlab object with tag: "%s"', numel(jObj), get(hObj, 'tag'));
end


    
    