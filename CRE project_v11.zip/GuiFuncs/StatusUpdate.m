function StatusUpdate(txt_h, wb_h, text, idx, n)
% function StatusUpdate(txt_h, text, idx, n)
% this function support the CRE gui and is used to update the status bar
% when a wait bar update is required
%
% txt_h - a handle to the text box to update
% wb_h  - the wait bar handle
% text  - the text to display in the text box
% idx   - current progress
% n     - total progress

% set the txt
set(txt_h, 'string', text);

% and the wait bar
tooltipwaitbar(wb_h, min(max(idx / n,0), 1));

% and render
drawnow();
