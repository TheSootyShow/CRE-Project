function prev_state = EnableDisableFig(hFig, new_state)
% function prev_state = EnableDisableFig(hFig, new_state)
% this function disable an entire figure
% new_state is either "on" / true or "off" / false
% (e.g. so user can't trigger callbacks during processing')

% when we draw opacity windows, give them this name so we can find them later
opacity_win_name = '$Imanopacitywindow$&$';


% get the figure's java frame
hFig = ancestor(hFig,'figure');  % make sure hFig is a figure
jFig = get(handle(hFig),'javaframe');

try
    jFrame = jFig.fHG1Client.getWindow;  
catch
    jFrame = jFig.fFigureClient.getWindow;  
end

% get the previous state
prev_state = get(jFrame,'Enabled');

% convert previous state to true / false (not sure why it can be returned like that)
if ischar(prev_state)
    prev_state = strcmpi(prev_state, 'on');
end

if (nargin > 1) && numel(new_state)
    if ischar(new_state)
        new_state = strcmpi(new_state, 'on');
    end
else
    new_state = true;  % enabled it with no inputs
end
    

if (~new_state) % disable it
    
    % disable it
    set(handle(jFrame),'Enabled', false);
    
    % make it opaque
    if 1 || (prev_state) 
        
        % Does it already have an opacity window?
        jWindows = get(handle(jFrame), 'OwnedWindows');
        has_window = false;
        for i = 1:numel(jWindows)
            has_window = strcmpi(jWindows(i).getName, opacity_win_name);
            if (has_window)
                
                % Ensure its size and location are current
                SetWindowPos(jFrame, jWindows(i), hFig);
                
                % and show it
                jWindows(i).setVisible(true);
                break;
            end
        end
        
        % If we didnt find an opacity window, create one
        if (~has_window)
            % Create blank panel
            jPanel = javaObjectEDT('javax.swing.JPanel');
            
            % Create jWindow with jFrame as its owner, and add the blank panel
            jWindow = javax.swing.JWindow(jFrame); pause(0.1); % the pause is needed to ensure the object is created before proceeding
            jWindow.setName(opacity_win_name);
            jWindow.pack();
            jWindow.getContentPane().add(jPanel);
            
            % Set size and location to match jFrame
            SetWindowPos(jFrame, jWindow, hFig);
            
            % Make jWindow semi-transparent and visible
            com.sun.awt.AWTUtilities.setWindowOpacity(jWindow,0.5);
            jWindow.setVisible(true);
        end
    end
    
else
    
    % enable it
    set(handle(jFrame),'Enabled', true);
    
    % look for an opacity window and delete it
    jWindows = get(handle(jFrame), 'OwnedWindows');
    is_opacity = false(size(jWindows));
    for i = 1:numel(jWindows)
        is_opacity(i) =  strcmpi(jWindows(i).getName, opacity_win_name);
        if (is_opacity(i))
            jWindows(i).setVisible(false);
        end
    end
end


% if we just enabled it, make it the active window
% dont do this, we want boxes to stay in the correct order
% if (new_state)
%     figure(hFig);
% end


function SetWindowPos(jFrame, jWindow, hFig)
% function SetWindowPos(jFrame, jWindow, hFig)
% function to set the position of the window to ensure it covers the menus

% the size of the figure content pane (exluding the menus)
window_size = jFrame.getContentPane().getSize;

% the height of all menus and tool bars
header_height = 0;

% factor in the menu bar
jMenu =jFrame.getJMenuBar();
if numel(jMenu) && (jMenu(1).isVisible)
    header_height = jMenu.getSize().height;
end

% factor in the tool bar - the above menu seems to encompass it
% hToolbar = findall(hFig,'tag','FigureToolBar');
% if numel(hToolbar)
%     jToolbar = get(get(hToolbar,'JavaContainer'),'ComponentPeer');
%     if numel(jToolbar) && (jToolbar(1).isVisible)
%         header_height = header_height + jToolbar.getSize().height;
%     end
% end

window_size.height = window_size.height + header_height;

% now set the position
window_pos = jFrame.getContentPane().getLocationOnScreen();
window_pos.y = window_pos.y - header_height;


% and set
jWindow.setSize(window_size);
jWindow.setLocation(window_pos);



