function [usablePos, fullSiz, tbarHeight] = GetUsableScreenSize(units, hFig)
% function [usablePos, fullSiz, wbarHeight] = GetUsableScreenSize(units, hFig)
% function to retrieve the usable screen size (for consistency)
%
% INPUTS:
%
% units      -  can be 'pixels' (default) or 'centimeters'
%
% hFig       - if hFig input is used, the toolbar and menu bar are subtracted
%              from the usable height
%
%
% OUTPUS:
%
% usablePos  - 4 element vector of the coordinates of the usable region:
%              [xoffset, yoffset, width, height] from the bottom left
%
% fullSiz    - full size of the screen 
%
% tbarHeight - task bar height (this will return garbage work if its NOT at the bottom)

border_pix = 6;  % I like a little gap (Matlab figure seem to have an extra border not reported below)

% persistent values are in pixels
persistent usablePos_pix;
persistent fullSiz_pix;
persistent tbarHeight_pix;


if (nargin < 1)
    units = 'pixels';
end

% pixels per centimeter (convert border to pixels)
pix_cm = (get(0, 'ScreenPixelsPerInch')) / 2.54;  

% recalculate?
if (numel(usablePos_pix) == 0)
    
    % get the screen size in pixels
    fullSiz_pix = get(0, 'screensize');
    fullSiz_pix = fullSiz_pix(3:4);
    
    % get the effective sceen size
    srect = java.awt.GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();  % N.B. this is top left coordinates
    
    % convert to bottom left coordinates
    usablePos_pix = [srect.x, fullSiz_pix(2) - (srect.y + srect.height), srect.width, srect.height];
    tbarHeight_pix = usablePos_pix(2);
    
    % remove the boarder
    usablePos_pix = usablePos_pix + [border_pix, border_pix, -2*border_pix, -2*border_pix];
    
end

% set output
usablePos = usablePos_pix;
fullSiz = fullSiz_pix;
tbarHeight = tbarHeight_pix;

% if a figure input was specified, remove the toobar and menubar heights
% from the usable figure
if (nargin >= 2) && ishandle(hFig)
    
    % get the menu height
    if ~strcmpi(get(hFig), 'visible')
        set(hFig, 'visible', 'on');
        drawnow();
    end

    % get the current figure size in pixels
    oldunits = get(hFig, 'units');
    set(hFig, 'units', 'pixels');
    fPos = get(hFig, 'position');
    set(hFig, 'units', oldunits);

    % get the java frame
    jFrame = GetjFrame(hFig);
    jBounds = jFrame.getBounds();  % N.B. index from top left, matlab is bottom left
    
    % convert jBounds to bottom left indexing
    jPos = [jBounds.x(), fullSiz_pix(2) - (jBounds.y()+jBounds.height()), jBounds.width(), jBounds.height()];
        
    % matlab figure have a little border to account for as well
    usablePos(1) = usablePos(1) + (fPos(1) - jPos(1));
    usablePos(2) = usablePos(2) + (fPos(2) - jPos(2));  
    usablePos(3) = usablePos(3) - (jPos(3) - fPos(3));
    usablePos(4) = usablePos(4) - (jPos(4) - fPos(4));
   
    % free
    jFrame = [];
    
    
end

% now convert to the correct units
if strcmpi(units, 'centimeters')
    usablePos = usablePos * pix_cm;
    fullSiz = fullSiz * pix_cm;
    tbarHeight = tbarHeight * pix_cm;    
elseif ~strcmpi(units, 'pixels')
    error('Units should be pixels or centimeters');
end
   
% testing - pretend its a 12 inch 800 x 600 ar screen
% diag = 8 * get(0, 'ScreenPixelsPerInch');
% ar = 800 / 600;
% height = sqrt((diag*diag)/(1+ar^2));
% width = height * ar;
% usablePos(3:4) =  [floor(width),floor(height)];
% fullSiz = usablePos(3:4);




    


