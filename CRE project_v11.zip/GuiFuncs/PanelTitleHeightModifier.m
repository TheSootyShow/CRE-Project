function rat = PanelTitleHeightModifier()
% function rat = PanelTitleHeightModifier()
% this function test by what % of the

rat = .55;  % adjust this till it looks good

hFig = figure;
set(hFig, 'units', 'pixels');
fPos = get(hFig, 'position');

lPos = [1,1, floor(fPos(3)/2), fPos(4)];
hLeft = uipanel(hFig, 'backgroundcolor', [1,1,1], 'units', 'pixels', 'position', lPos);

rPos = [lPos(3) + 1, 1, lPos(3), fPos(4)];
hRight = uipanel(hFig, 'backgroundcolor', [1,1,1], 'units', 'pixels', 'position', rPos);

% add text to the left panel
set(hLeft, 'title', 'Match me if you can');

% get the height of the text
tHeight = GetPanelTextHeight(hLeft, false);
hAdj = floor(tHeight * rat);

rPos(4) = rPos(4) - hAdj;
set(hRight, 'position', rPos);