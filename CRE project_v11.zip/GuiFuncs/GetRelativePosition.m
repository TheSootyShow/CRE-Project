function pos = GetRelativePosition(uiObject, uiParent, units)
% function pos = GetRelativePosition(uiObject, uiParent, unit)
% this function get the poisiton of a uicomponent relative to a 
% container higher up the heirarchy

if (nargin < 3)
    units = 'pixels';
end

% get the position relative to its parent
old_units = get(uiObject, 'units');
set(uiObject, 'units', units);
pos = get(uiObject, 'position');
set(uiObject, 'units', old_units);

% and recurse upwards
parent = get(uiObject, 'parent');
while (parent > 0) && (parent ~= uiParent)
    
    uiObject = parent;
    old_units = get(uiObject, 'units');
    set(uiObject, 'units', units);
    new_pos = get(uiObject, 'position');
    pos(1:2) = pos(1:2) + new_pos(1:2);  % update offset
    set(uiObject, 'units', old_units);
    parent = get(uiObject, 'parent');
    
end

if (parent == 0)
    error('The aprent was not found in the object heirachy');
end