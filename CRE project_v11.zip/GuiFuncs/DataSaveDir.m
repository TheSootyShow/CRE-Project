function dir = DataSaveDir(dir)
% function dir = DataSaveDir()
%   get the data directory
%
% function DataSaveDir(dir)
%   set the data directory
%
% this function keeps track of the directory of the data directory

persistent last_dir

if (nargin >= 1)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % setting the data directory
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
    if numel(last_dir) && strcmpi(last_dir, dir)
        return;  % no need to do anything
    else
        % remove trailing file seperators
        idx = find(dir ~= filesep(), 1, 'last');
        if (numel(idx) && idx < numel(dir))
            dir(idx+1:end) = [];
        end
        
        last_dir = dir;   % store
        
        % try to record it
        saveDir = GetSettingsDir();
        if (numel(saveDir))
            file_name = fullfile(saveDir, 'CRE_savedata_dir.txt');
            try
                save(file_name, 'dir', '-ASCII');
            end
        end
    end
else
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % retrieving the data directory
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if numel(last_dir)
        dir = last_dir;
    else
        
        % try to load it from file
%         saveDir = GetSettingsDir();
%         if (numel(saveDir))
%             file_name = fullfile(saveDir, 'CRE_savedata_dir.txt');
%             try
%                 last_dir = char(load(file_name, 'dir', '-ASCII'));
%             catch
%                 last_dir = -1;
%             end
%         end
        
        if ~ischar(last_dir) || (numel(last_dir) == 0) || ~exist(last_dir, 'dir')
            last_dir = DataLoadDir();  % default to the load directory
        end
        dir = last_dir;
    end
end

