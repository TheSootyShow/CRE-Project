function hasTabs = HasTabs(hFig)
% function hasTabs = HasTabs(hFig)
% return true if the figure has tabs, false othewise

hasTabs = (numel(findobj(hFig, '-regexp', 'type', '^uitab$')) > 0);