function ResizeOptionsGui(handles, tr_handles, b_handles)
% function ResizeOptionsGui(handles, tr_handles, b_handles)
% this function is designed to resize GUI's related to picking
% time ranges form the CREproject.  The gui's should have a top left planel
% relating to picking time ranges, a top right panel, and a bottom panel,
% with an OK and Cancel button at the bottom.  For examples of this layout,
% see CREPlotOptions.fig and CREExportOptions.fig.  For a template figure
% for selecting ranges, see RangeTemplate.fig
%
% tr_handles and b_handles are matrix's of the handles to the objects
% inside each pane.  Use NaN to create blank sports
%
% this can only be called after the gui has rendered (use the resize call
% back)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Constants
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p_gap_large = .5;  % use this many cm gap for large gaps
p_gap_norm = .3;  % use this many cm gap between objects        
p_gap_small = .1;  % use this many cm gap for small gaps



uiFig = handles.uiFigPanel;       % the panel that encompasses everything
uiRange = handles.uiRangePane;    % handle to the pane containing ranges

pbOK = handles.pbOK;              % the Ok button
pbCancel = handles.pbCancel;      % the Cancel button


% turn constants into units in pixels
ppi = get(0, 'ScreenPixelsPerInch');                     % pixels per inch
ppcm = ppi / 2.54;                                       % pixels per centimeter
p_gap_large = ceil(p_gap_large  * ppcm);
p_gap_norm = ceil(p_gap_norm  * ppcm);
p_gap_small = ceil(p_gap_small  * ppcm);



% get the figure handle
fig_h = get(uiFig, 'parent');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Start by setting up the range pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rp_grid = [handles.txtStart,        handles.ebMinGrab;   ...
           NaN,                     handles.txtStartLim; ...
           handles.txtEnd,          handles.ebMaxGrab
           NaN,                     handles.txtEndLim;
           handles.txtInterpret,    handles.txtInterpret;
           handles.rbIndexs,        handles.rbIndexs;
           handles.rbTimes,         handles.rbTimes;
           handles.txtDuration,     handles.txtDuration];  % repeated handle to make it cover the whole line
       

% build a vertical spacing grid       
v_space_grid = repmat(p_gap, size(rp_grid,1)-1, 2);
v_space_grid([1,3], :) = 1;  % use a small gap between the text for limits and the edit boxes they are associated with

% for the column gap, use what's already there
set(rp_grid(~isnan(rp_grid)), 'units', 'pixels');
l_pos = get(handles.txtStart, 'position');
r_pos = get(handles.ebMinGrab, 'position');
jStart = findjobj(handles.txtStart);
h_space_grid = repmat(r_pos(1) - (l_pos(1) + jStart.getPreferredSize.width), size(rp_grid,1), 1);

% now build this pane
[range_size] = ResizePaneFromGrid(rp_grid, v_space_grid, h_space_grid);




           
           
           
           







                                  