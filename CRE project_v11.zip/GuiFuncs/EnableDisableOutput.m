function EnableDisableOutput(handles)
% function EnableDisableOutput(handles)
% function to enable or disable a figures output
% handles should conatin a field call "block_list"
% which is a list of handles to uincontrols with invalid selections

java_tooltip = false;

persistent jButtons
persistent hButtons

% easy case here
if (numel(handles.block_list) == 0) && strcmpi(get(handles.pbOK, 'enable'), 'on')
    return;  % nothing to do
end

% do we have the jButton from this control?
if (java_tooltip)
    validHandles = ishandle(hButtons);
    index = find((hButtons == handles.pbOK) & validHandles);
    if (numel(index) == 0)
        
        % clear ones that aren't currently valid
        hButtons = hButtons(validHandles);
        jButtons = jButtons(validHandles);
        
        % now add this one
        index = numel(hButtons)+1;
        try
            jButtons(index,1) = handle(findjobj(handles.pbOK));
            hButtons(index,1) = handles.pbOK;
        catch
            index = -1;
        end
    end
else
    index = -1;
end

% enable or disable "OK"
if (numel(handles.block_list) == 0)
    enable_num = true;
    enable_str = 'on';
    tt_string = '';
else
    enable_num = false;
    enable_str = 'off';
    tags = get(handles.block_list, 'tag');
    if ~iscell(tags)
        tags = {tags};  % a single problem
    end
    tags = cellfun(@(name)(name(3:end)), tags, 'uniformoutput', false);  % remove the uicontrol type from the tag
    tt_string =  char(tags);
end

% and set the tooltip string (via the java object so it renders when the
% control is disabled)
if (index > 0)
    set(jButtons(index), 'Enabled', enable_num);
    set(jButtons(index),'ToolTipText', tt_string);
else
    set(handles.pbOK, 'enable', enable_str);
end


