function [hPane, parSize] = ResizeFigFromPanes(hGrid, hGap, vGap, useCurrSize, resizeFig, paneGap, allowLeak)
% function [hPane, parSize] = ResizeFigFromPanes(hGrid, hGap, vGap, useCurrSize, resizeFig, paneGap, allowLeak)
% this function is designed to automatically layout a figure using its pane
% placement. % The size of text controls is adjusted to the
% preferred size.  The pane must be visible!
%
% only text / edit / radio / uipanels are resized, anything else is simple
% moved
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% hGrid         - A 2D cell array which reflects where the
%                 uipanes should go in the figure.  To leave an empty
%                 space, use an empty cell.  To stretch a pane over two or
%                 more "places", use either 'l' (replicate the pane to the left)
%                 or 'b' (replicate the pane below it).
%               - each cell should contain a either matrix of handles to the panes
%                 childres (see ResizePaneFromGrid.m), or a handle to a ui
%                 component 
%               - e.g. to design a figure that has panes in a [1,2; 3]
%                 format, use hGrid = {p1_handles, p2_handles; p3_handles, 'l'}
%                 where pi_handles is either the handle to the pane itself, or a matrix of the pane's children
%                 compatible with ResizePaneFromGrid.m
%
% hGap          - a cell array with the same layout as hGrid,
%                 containing horizontal spacing info for each pane's children
%                 (see ResizePaneFromGrid.m)
%               - Can be ommitted for default spacings
%
% vGap          - a cell array with the same layout as hGrid,
%                 containing vertical spacing info for each pane's children
%                 (see ResizePaneFromGrid.m)
%               - Can be ommitted for default spacings
%
%
% useCurrSize   - set true if the gui objects have already been resized to
%                 their preferred size.  This is faster as the java object doesn't
%                 need to be found (default false)
%               - optionally, this can be a cell array the same size as hGrid
%                 that contains the component sizes for each pane (see
%                 parSizesFromGrid.m)
% 
%
% resizeFig    - trim the figure to tightly fit the desired layout.  All
%                 of the panes in pane grid can have a single encompassing pane
%                 (default true)
%
% paneGap      - the distance between panes in pixels [horizontal, vertical]
%              - default comes from DefaultGuiBorders.m
%
% allowLeak    - if true, allow objects to "leak" into unoccupied
%                neighouring grid locations (two elements [leak horizontally,
%                leak vertically]; 




%%%%%%%%%%%%%%%%%%%%%%%%
% Define constants
%%%%%%%%%%%%%%%%%%%%%%%%%

[defPaneGap, paneBorder, figBorder] = DefaultGuiBorders();
vcent = true;                          % if true, rows are vertically centered


%%%%%%%%%%%%%%%%%%%%%%%%%
% Parse inputs 
%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 7) || (numel(allowLeak) == 0)
    allowLeak = false(1,2);
end

if (nargin < 6) || (numel(paneGap) == 0)
    paneGap = defPaneGap;
elseif (numel(paneGap) == 1)
    paneGap = repmat(paneGap, 1, 2);
end

if (nargin < 5) || (numel(resizeFig) == 0)
    resizeFig = true;
end

userSizes = false;
uiSizes = cell(size(hGrid));
if (nargin < 4) || (numel(useCurrSize) == 0)
    useCurrSize = false;
elseif iscell(useCurrSize)
    userSizes = true;
    uiSizes = useCurrSize;
    useCurrSize = true;    % if a size is missing, use the current size
end


if (nargin < 3) || (numel(vGap) == 0)
    vGap = cell(size(hGrid));
end

if (nargin < 2) || (numel(hGap) == 0)
    hGap = cell(size(hGrid));
end


%%%%%%%%%%%%%%%%%%%%%%%%%
% now process
%%%%%%%%%%%%%%%%%%%%%%%%%

% these store the heights and widths of each pane
heights = zeros(size(hGrid));
widths = zeros(size(hGrid));
empty = false(size(hGrid));     % is this an empty space?
isObject = false(size(hGrid));  % a uicomponent?     
hPane = cell(size(hGrid));      % handle to the parent pane in each "place"

% these do NOT assign a value to repeated sections
rCopies = zeros(size(hGrid));        % how many copies of the object in the row
cCopies = zeros(size(hGrid));        % how many copies of the object in the column



% general layout of the pane
[n_rows, n_cols] = size(hGrid);


% and go through each
for i = n_rows:-1:1
   
    for j = 1:n_cols
        
        % is it populated?
        if numel(hGrid{i,j}) && ~any(ischar(hGrid{i,j}))
            
            % do we need to recurse this grid location?
            [hPane{i,j}, widths(i,j), heights(i,j)] = RecurseGridLocation(hGrid{i,j}, hGap{i,j}, vGap{i,j}, uiSizes{i,j}, allowLeak, userSizes, useCurrSize);
            
            % check if its repeated over columns
            cCopies(i,j) = 1;  % one column for it
            while (j + cCopies(i,j) <= n_cols) && numel(hGrid{i,j+cCopies(i,j)}) && ischar(hGrid{i,j+cCopies(i,j)}) && (hGrid{i,j+cCopies(i,j)}(1) == 'l')
                cCopies(i,j) = cCopies(i,j) + 1;
            end
            
            % check if its repeated over rows
            rCopies(i,j) = 1;  % one row for it
            while (i - rCopies(i,j) >= 1) && numel(hGrid{i-rCopies(i,j),j}) && ischar(hGrid{i-rCopies(i,j),j}) && (hGrid{i-rCopies(i,j),j}(1) == 'b') 
                rCopies(i,j) = rCopies(i,j) + 1;
            end
            
            % and repeat the handle
            spread_rows = i-rCopies(i,j)+1:i;  % component is spread across these rows
            spread_cols = j:j+cCopies(i,j)-1;  % component is spread across these columns
            hPane(spread_rows, spread_cols) = hPane(i,j);
            isObject(i,j) = true;
            
        elseif any(ischar(hGrid{i,j})) || (numel(hGrid{i,j}) > 1)
            
            % string spacer
            ui_size = PaneSizesFromGrid(hGrid(i,j));
            widths(i,j) = ui_size{1}(1);
            heights(i,j) = ui_size{1}(2);
            rCopies(i,j) = 1;  % one row for it
            cCopies(i,j) = 1;  % one row for it
            
        elseif (numel(hGrid{i,j}) == 0)
            empty(i,j) = true;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get a handle to the parent of them all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

is_handle = cellfun(@(x)((numel(x) > 0) && isnumeric(x) && ishandle(x)), hPane);
hContainer = cell2mat(hPane(is_handle));
hParent = get(hContainer, 'parent');
if iscell(hParent)
    hParent = cell2mat(hParent);
end
hParent = unique(hParent);

% check they all have the same parent
if (numel(hParent) > 1)
    tags = get(hParent, 'tag');
    par_str = '';
    for i = 1:numel(tags)
        par_str = sprintf('%s%s%s', par_str, repmat(', ', 1, i > 1), tags{i});
    end
    error('Elements of the input grid array do not have a common parent.  Parents are: %s ', par_str);
end

% set all containers to pixels
set([hParent; hContainer(:)], 'units', 'pixels');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now figure out how wide each column should be
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this also return the maximum extent for each object
[col_widths, horz_ext_min, horz_ext_max] = GetColWidths(hPane, widths, rCopies, cCopies, repmat(paneGap(1), n_rows, n_cols-1), allowLeak(1));

col_start = cumsum([paneBorder(1), col_widths], 2);
col_start(end) = col_start(end) + paneBorder(3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% and how high each column should be
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this also return the maximum extent for each object
[row_heights, vert_ext_min, vert_ext_max] = GetRowHeights(hPane, heights, rCopies, cCopies, repmat(paneGap(2), n_rows-1, n_cols), allowLeak(2));

row_start = flipud(cumsum(flipud([row_heights; paneBorder(2)]),1));
row_start(1) = row_start(1) + paneBorder(4);      % this is actually the outer boundary (panes start at the bottom)

% add the heights of the panel's title to the required heights of the panel
if strcmpi(get(hParent, 'type'), 'uipanel')
    row_start(1) = row_start(1) + GetPanelTextHeight(hParent, true);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now reposition each pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i = n_rows:-1:1  % start at the bottom
    for j = 1:n_cols
        
        if (rCopies(i,j) && cCopies(i,j) && isObject(i,j))  % only do places with objects
           
            % Notes on indexing:
            % if handles_grid has n rows, then row_start has n+1 elements
            % and v_space_grid has n-1 elements.  Similarly for columns.
            
            % build dimensions
            left = horz_ext_min(i,j) + col_start(1);
            bottom = vert_ext_min(i,j) + row_start(end);
            right = horz_ext_max(i,j) + col_start(1);
            top = vert_ext_max(i,j) + row_start(end);
            
            % now build position from this
            pos = [left, bottom, right - left, top - bottom];
            
            % manipulate its position withing its rectangle
            rightmost = (j > 1) && ((j+cCopies(i,j)-1) == n_cols);  % is this in the right most column?
            pos = AdjustUIPosition(hPane{i,j}, pos, widths(i,j), heights(i,j), j == 1, rightmost, vcent);

            % and set it
            set(hPane{i,j}, 'position', pos);
            
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now resize the parent to fit everything
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

parSize = [col_start(end), row_start(1)];
parPos = get(hParent, 'position');
parPos(3:4) = parSize;


% resize the figure / grandparent
if ~strcmpi(get(hParent, 'type'), 'figure')
    
    % add an offset
    parPos(1:2) = figBorder(1:2);
    
    % offset the parent position
    set(hParent, 'position', parPos);
    
    % get the container of the current parent
    hGrandParent = get(hParent, 'parent');
    if (resizeFig) && (strcmpi(get(hGrandParent, 'type'), 'figure'))
        set(hGrandParent, 'units', 'pixels');
        
        % get new dimensions
        new_width = parSize(1) + figBorder(1) + figBorder(3);
        new_height = parSize(2) + figBorder(2) + figBorder(4);
        
        % and resize
        ResizeFigure(hGrandParent, [new_width, new_height]);
        
        % find all decendants of the figure and change to cm (better to save
        % the resized figure in centimeters)
        % ConvertFigureUnits(hParent, 'centimeters');
        
    end
    
elseif (resizeFig) && strcmpi(get(hParent, 'type'), 'figure')
    
    % resize it
    ResizeFigure(hParent, parPos(3:4));
    
    
end

function [hPane, width, height] = RecurseGridLocation(gridCell, hGap, vGap, uiSizes, allowLeak, userSizes, useCurrSize)
% function [hPane, width, height] = RecurseGridLocation(gridCell, hGap, vGap, uiSizes, allowLeak, userSizes, useCurrSize)
% function to recurse a grid location until we get to the base level

% does it need further recursion?
recurse = iscell(gridCell) && any(cellfun(@iscell, gridCell(:)));
if (~recurse)
    
    % we're at the base level
    [hPane, width, height] = GetGridLocation(gridCell, hGap, vGap, uiSizes, allowLeak, userSizes, useCurrSize);
    
else
    
    % do each cell seperately
    [nRows, nCols] = size(gridCell);
    hGrid = cell(nRows, nCols);
    newUISizes = cell(nRows, nCols);
    for i = nRows:-1:1
        for j = 1:nCols
            if (numel(gridCell{i,j})) 
                if ~ischar(gridCell{i,j})
                
                    % are sizes available?
                    gridSize = {};
                    if (userSizes)
                        gridSize = uiSizes{i,j};
                    end
                    
                    % and calculate this grid spot
                    [hGrid{i,j}, newUISizes{i,j}(1), newUISizes{i,j}(2)] = RecurseGridLocation(gridCell{i,j}, hGap{i,j}, vGap{i,j}, gridSize, allowLeak, userSizes, useCurrSize);
                    
                elseif strcmpi(gridCell{i,j}, 'b')
                    t = 1;
                    while ischar(hGrid{i+t,j})
                        t = t + 1;
                    end
                    hGrid{i,j} = hGrid{i+t,j}; % a repeat instruction
                elseif strcmpi(gridCell{i,j}, 'l')
                    t = 1;
                    while ischar(hGrid{i,j-t})
                        t = t + 1;
                    end
                    hGrid{i,j} = hGrid{i,j-t}; % a repeat instruction
                else
                    hGrid{i,j} = gridCell{i,j};    % a spacing instruction
                    if (numel(uiSizes{i,j}) == 0)
                        newUISizes(i,j) = PaneSizesFromGrid(hGrid(i,j));
                    else
                        newUISizes(i,j) = uiSizes(i,j);
                    end
                end
            end
        end
    end
    
    % and assemble
    [hPane, width, height] = GetGridLocation(hGrid, [], [], newUISizes, allowLeak, userSizes, useCurrSize);
    
end



function [hPane, width, height] = GetGridLocation(gridCell, hGap, vGap, uiSizes, allowLeak, userSizes, useCurrSize)
% function [hPane, width, height] = GetGridLocation(gridCell, hGap, vGap, uiSizes, allowLeak, userSizes, useCurrSize)
% function to retrieve the width and height of a panel / component

% is this a matrix contain ing the pane layout or just an% element to place
hasLayout = (numel(gridCell) > 1);  % always a layout in this case
if (~hasLayout)
    
    % it may still have a layout if its the only child of a uipanel
    if iscell(gridCell)
        hPane = get(gridCell{1}, 'parent');
    else
        hPane = get(gridCell(1), 'parent');
    end
    if (strcmpi(get(hPane, 'type'), 'uipanel'))
        children = get(hPane, 'child');
        children = children(children ~= get(hPane, 'TitleHandle'));  % don't count the pane's title (it may show up if all handles are visible)
        hasLayout =  numel(children) == 1;
    end
end

% case for when its a matrix of the pane's children
if (hasLayout)
    
    % call the pane placement function
    if (userSizes) && numel(uiSizes)
        [hPane, figSize] = ResizePaneFromGrid(gridCell, hGap, vGap, uiSizes, allowLeak, false);
    else
        [hPane, figSize] = ResizePaneFromGrid(gridCell, hGap, vGap, useCurrSize, allowLeak, false);
    end
    width = figSize(1);
    height = figSize(2);
    
else
    
    % a single component
    if (userSizes) && numel(uiSizes)
        hPane = gridCell;
        width = uiSizes(1);
        height = uiSizes(2);
    else
        hPane = gridCell;
        set(hPane, 'units', 'pixels')
        pos = get(hPane, 'position');
        width = pos(3);
        height = pos(4);
    end
    
end


