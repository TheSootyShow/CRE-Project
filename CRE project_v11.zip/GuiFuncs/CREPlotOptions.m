function varargout = CREPlotOptions(varargin)
% GUI is intended to be called as:
% [response, options] = CREPlotOptions(data_set, freq_plot, use_time, use_hhmmss, relative_time, default_opts)
%
% CREPLOTOPTIONS MATLAB code for CREPlotOptions.fig
%      CREPLOTOPTIONS, by itself, creates a new CREPLOTOPTIONS or raises the existing
%      singleton*.
%
%      H = CREPLOTOPTIONS returns the handle to a new CREPLOTOPTIONS or the handle to
%      the existing singleton*.
%
%      CREPLOTOPTIONS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CREPLOTOPTIONS.M with the given input arguments.
%
%      CREPLOTOPTIONS('Property','Value',...) creates a new CREPLOTOPTIONS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CREPlotOptions_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CREPlotOptions_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%

% Edit the above text to modify the response to help CREPlotOptions

% Last Modified by GUIDE v2.5 05-Sep-2014 11:19:20

layout_fcn = GuiLayoutFunction('CREPlotOptions');

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREPlotOptions_OpeningFcn, ...
                   'gui_OutputFcn',  @CREPlotOptions_OutputFcn, ...
                   'gui_LayoutFcn',  layout_fcn, ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

% ensure guis's always load visible
if (nargin == 0)
    varargin = {'visible', 'on'};
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CREPlotOptions is made visible.
function CREPlotOptions_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CREPlotOptions (see VARARGIN)

% get the input data set
handles.data_set = varargin{1};

% create a structure to output
if (numel(varargin) >= 6) && isstruct(varargin{6})
    handles.options = PassFeaturesToDataSet(varargin{6}, handles.data_set);
else
    
    % N.B.  This should match InitFeatSettings.m
    handles.options = struct('timeRange',    [],  ... % has the time to start and stop the analysis (see InitTimeRangeStruct.m)
                             'dimInfo',      [],  ... % which dimensions to build features from (see InitDimStruct)
                             'freqRange',    []); ... % frequency range to analyse for frequency domain features
    
    % initialise each of them
    handles.options.timeRange = InitTimeRangeStruct(handles.data_set); 
    handles.options.dimInfo = InitDimStruct(handles.data_set);
    handles.options.freqRange = InitFreqRangeStruct(handles.data_set);

end

% and whether this is for time or frequency
if (numel(varargin) >= 2) && (numel(varargin{2}) > 0)
    handles.freq_plot = varargin{2};
else
    handles.freq_plot = false;
end

% times or indices?
if (numel(varargin) >= 3) && (numel(varargin{3}) > 0)
    handles.options.timeRange.is_time = varargin{3};
else
    handles.options.timeRange.is_time = true;
end


% how to display times
if (numel(varargin) >= 4) && (numel(varargin{4}) > 0)
    handles.options.timeRange.is_hhmmss = varargin{4};
else
    handles.options.timeRange.is_hhmmss = true;
end

% show times as relative to the recordings start?
if (numel(varargin) >= 5) && (numel(varargin{5}) > 0)
    handles.options.timeRange.is_relative = varargin{5};
else
    handles.options.timeRange.is_relative = true;
end


% set gui name based on whether it is time or freq
if (handles.freq_plot)
    set(hObject, 'name', 'Frequency domain plot options');
    
    % display this pane
    set(get(handles.uiFreq, 'children'), 'enable', 'on')
    set(handles.uiFreq, 'visible', 'on');
    
else
    set(hObject, 'name', 'Time domain plot options');
    
    % don't display this pane
    set(get(handles.uiFreq, 'children'), 'enable', 'off')
    set(handles.uiFreq, 'visible', 'off');
end


% update the time range panel if needed
if (IsDeveloper())

    set(hObject, 'visible', 'on');
    handles = CopyRangeTemplateToFigure(hObject, handles);
    
end
                     
% Initialise the gui                     
handles = InitialiseGui(handles);                     

% Choose default command line output for CREPlotOptions
handles.output = {'Cancel', handles.options};

% call the resize function
CREPlotOptions_ResizeFcn(hObject, eventdata, handles);

% initialise key press robot
handles = KeyPressInit(hObject, eventdata, handles);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CREPlotOptions wait for user response (see UIRESUME)
uiwait(handles.CREPlotOptions);


% --- Outputs from this function are returned to the command line.
function varargout = CREPlotOptions_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;
delete(hObject);


% --- Executes during object creation, after setting all properties.
function default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ebMinGrab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function handles = InitialiseGui(handles)
% function InitialiseGui(handles)
% function to update the gui based on the current selection


% allocate a blocking list for the "OK" button.  This list contains handles
% to objects who's value cant be sensibly interpreted
handles.block_list = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get all the dimension names
[names, selected, n_primary] = GetAllDimensionNames(handles.options.dimInfo);
use = false(size(names));
use(1:n_primary) = true;
use(selected) = true;    % only show primary and selected to begin with

% add the names
set(handles.lbDimensions, 'string', names(use));
indexs = find(use);
set(handles.lbDimensions, 'userdata', indexs);  % keep track of their original indices in case of reordering

% then select them all
set(handles.lbDimensions, 'Max', max(numel(names), 2));
[tmp, subset] = ismember(find(selected), indexs);
set(handles.lbDimensions, 'Value', subset(tmp));

if (numel(selected) == 0)
    handles.block_list(end+1) = handles.lbDimensions;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set data range selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

handles = InitTimePanel(handles, handles.data_set, handles.options.timeRange.is_time, handles.options.timeRange.is_hhmmss, handles.options.timeRange.is_relative);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up freqency selection
% (even if its unused)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

handles = InitFreqPane(handles.options.freqRange.fbounds(1,:), handles.data_set.fs, handles);

% update enabled status
EnableDisableOutput(handles);

% upload the handles
if (nargout == 0)
    guidata(handles.CREPlotOptions, handles);
end





function ebMinFreq_Callback(hObject, eventdata, handles)
% hObject    handle to ebMinFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebMinFreq as text
%        str2double(get(hObject,'String')) returns contents of ebMinFreq as a double

% call the update function
[handles.options.freqRange, tmp, handles] = CheckFreqRange(hObject, handles.options.freqRange, [], 1, [], handles);

% upload the handles
guidata(handles.CREPlotOptions, handles);

% update enabled status
EnableDisableOutput(handles);



function ebMaxFreq_Callback(hObject, eventdata, handles)
% hObject    handle to ebMaxFreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebMaxFreq as text
%        str2double(get(hObject,'String')) returns contents of ebMaxFreq as a double


% call the update function
[handles.options.freqRange, tmp, handles] = CheckFreqRange(hObject, handles.options.freqRange, [], 2, [], handles);

% upload the handles
guidata(handles.CREPlotOptions, handles);

% update enabled status
EnableDisableOutput(handles);



% --- Executes on selection change in lbDimensions.
function lbDimensions_Callback(hObject, eventdata, handles)
% hObject    handle to lbDimensions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbDimensions contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbDimensions

% get the indexes of selected dimensions
indexs = get(hObject, 'userdata');
indexs = indexs(get(hObject, 'value'));

% and set the visiblities in the structure
handles.options.dimInfo = SetDimVisibility(handles.options.dimInfo, indexs, true, true);

if (numel(indexs))
    
    % remove it from blocking if it was
    handles.block_list = handles.block_list(handles.block_list ~= hObject);
    
    
elseif ~any(handles.block_list == hObject)
    
    % add it as a blocking function
    handles.block_list(end+1) = hObject;
    
end

% update enabled status
EnableDisableOutput(handles);

% and update the handles for changes in blocklist
guidata(hObject, handles);



% --- Executes on button press in pbAddDims.
function pbAddDims_Callback(hObject, eventdata, handles)
% hObject    handle to pbAddDims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Fire up the gui
[resp, dimInfo] = SelectDimsGui(handles.options.dimInfo, handles.data_set);

% test the response
if strcmpi(resp, 'OK')
    
    % assign
    handles.options.dimInfo = dimInfo;
    
    % update the pane
    % get all the dimension names
    [names, selected, n_primary] = GetAllDimensionNames(handles.options.dimInfo);
    
    % add the names
    set(handles.lbDimensions, 'string', names);
    set(handles.lbDimensions, 'userdata', 1:numel(names));  % keep track of their original indices in case of reordering
    
    % then select them all
    set(handles.lbDimensions, 'Max', max(numel(names), 2));
    set(handles.lbDimensions, 'Value', find(selected));
    
    if (numel(selected) == 0)
        handles.block_list(end+1) = handles.lbDimensions;
    end
    
    % update enabled status
    EnableDisableOutput(handles);

    % and update the handles for changes in blocklist
    guidata(hObject, handles);
end




% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% indicate OK
handles.options.timeRange = UpdateStruct(handles.options.timeRange, handles.timeInfo, false);
handles.output = {'OK', handles.options};
guidata(hObject, handles);

% and close the gui
CREPlotOptions_CloseRequestFcn(handles.CREPlotOptions, eventdata, handles);



% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% indicate cancel
handles.options.timeRange = UpdateStruct(handles.options.timeRange, handles.timeInfo, false);
handles.output = {'Cancel', handles.options};
guidata(hObject, handles);

% and close the gui
CREPlotOptions_CloseRequestFcn(handles.CREPlotOptions, eventdata, handles);




% --- Executes when user attempts to close CREPlotOptions.
function CREPlotOptions_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CREPlotOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
uiresume(hObject);  % this should trigger the output function



% --- Executes when CREPlotOptions is resized.
function CREPlotOptions_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to CREPlotOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if (RunResizeFcn(hObject, handles))

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);
    
    % to facilitate sizing
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build a grid of ui components for the grab range pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [gRange, hGapRange, vGapRange, sizeRange] = DefaultRangePaneLayout(handles);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the dimensions pane is simple
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    gDims = {handles.lbDimensions, handles.lbDimensions; ...
        handles.pbAddDims, []};
    vGapDims = [];
    hGapDims = [];
    
    % get component sizes
    sizeDims = PaneSizesFromGrid(gDims);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build the pane for the frequency selection
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if ~isfield(handles, 'freq_plot') || (~handles.freq_plot)
        
        % dont include the frequency plot
        hCell = {gRange, gDims; handles.pbCancel, handles.pbOK};
        vGap = {vGapRange, vGapDims; .5*ppcm, .5*ppcm};
        hGap = {hGapRange, hGapDims; [], []};
        uiSizes = {sizeRange, sizeDims; [], []};
        
    else
        
        % build the frequency pane
        gFreq = [{handles.text5, handles.ebMinFreq, handles.text6, handles.ebMaxFreq, handles.text7}; ...
            repmat({handles.txtFs}, 1, 5)];
        vGapFreq = repmat(.2, 1, size(gFreq,2)) * ppcm;  % space to leave between rows
        hGapFreq = repmat(.2, 2, 4) * ppcm;               % space to leave between rows
        
        % get component sizes
        sizeFreq = PaneSizesFromGrid(gFreq);
        
        
        hCell = {gRange, gDims; gFreq, 'l'; handles.pbCancel, handles.pbOK};
        vGap = {vGapRange, vGapDims; vGapFreq, []; .5*ppcm, .5*ppcm};
        hGap = {hGapRange, hGapDims; hGapFreq, []; [], []};
        uiSizes = {sizeRange, sizeDims; sizeFreq, []; [], []};
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % assemble it all
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    % now call the resize function
    ResizeFigFromPanes(hCell, hGap, vGap, uiSizes, true);
    
    % a final tweak
    pos1 = get(handles.uiTimeInterp, 'position');
    pos2 = get(handles.pbAddDims, 'position');
    pos2(2) = pos1(2);
    set(handles.pbAddDims, 'position', pos2);
    
    
    % now turn off the resize option
    set(hObject, 'resize', 'off')
    set(handles.lbDimensions,'ListboxTop', 1);           % make sure these are at the top
    drawnow();
    
    
    % save the resized figure
    if isfield(handles, 'freq_plot') && (handles.freq_plot)
        SaveResizedCREFigure(hObject);
    end
end
