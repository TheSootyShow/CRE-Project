function ResetAxis(hAxis)
% function ResetAxis(hAxis)
% function to clear the axis and return it to a default state

% clear it and lines
cla(hAxis);

% also remove legend entries
delete(findobj(get(hAxis, 'parent'),'Type','axes', 'Tag','legend'));  % make sure the legend gets deleted if it exists

% and rest the labelling mode to auto
set(hAxis, 'xlimmode', 'auto');
set(hAxis, 'ylimmode', 'auto');
set(hAxis, 'xtickmode', 'auto');
set(hAxis, 'ytickmode', 'auto');
set(hAxis, 'xticklabelmode', 'auto');
set(hAxis, 'yticklabelmode', 'auto');

