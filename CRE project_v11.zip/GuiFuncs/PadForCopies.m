function [matrix_pad, vert_copies_pad, horz_copies_pad] = PadForCopies(matrix, vert_copies, horz_copies)
% function [matrix, vert_copies_pad, horz_copies_pad] = PadForCopies(matrix, vert_copies, horz_copies) 
% this function pads an inputs matrix based on how many copies the entry
% should have.  horz_copies are padded to the right, vert_copies are padded
% to the top.  
% e.g. for input matrix [0, 0, a; 
%                        0, b, 0; 
%                        c, d, e]
%
% with vert_copies        [0, 0, 1; 
%                         0, 2 ,0; 
%                         3, 1, 1]
% 
% and col copies         [0, 0, 1; 
%                         0, 2, 0; 
%                         1, 1, 1]
%
% the output would be:
%
% output = [c, b, b;
%           c, b, b;
%           c, d, e]
%
% Note that the value a was overwritten by a copy of b

% preallocate outputs
matrix_pad = matrix;
vert_copies_pad = vert_copies;
horz_copies_pad = horz_copies;

% find values to copy
[r, c] = find((vert_copies | horz_copies) > 1);

for i = 1:numel(r)
    
    % adjust these rows
    r_adj = r(i)-vert_copies(r(i), c(i))+1:r(i);
    
    % adjust these columns
    c_adj = c(i):c(i)+horz_copies(r(i), c(i))-1;
    
    matrix_pad(r_adj, c_adj) = matrix(r(i), c(i));
    vert_copies_pad(r_adj, c_adj) = vert_copies(r(i), c(i));
    horz_copies_pad(r_adj, c_adj) = horz_copies(r(i), c(i));
end
