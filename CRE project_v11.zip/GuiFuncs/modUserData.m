function output = modUserData(hObject, action, tag, value)
% function modUserData(hObject, action, tag, value)
% function to modify tehe user data of a uiobject
%
% Usage:
%
% modUserData('add', hObject, tag, value)  - adds / replaces the given tag
%                                            with the new value
%
% value = modUserData('get', hObject, tag) - gets the value of the user user data with
%                                            the given tag.  [] is returned if the tag
%                                            doesn't exist
%
% modUserData('remove', hObject, tag)      - removes any values associated
%                                            with the tag

% default output
output = [];

% what's in there?
user_data = get(hObject, 'UserData');
if ~iscell(user_data) || (size(user_data,2) ~= 2)
    if any(strcmpi(action, {'get', 'remove'}))
        return;
    end
    user_data = cell(0, 2);
end
row = find(strcmpi(user_data(:,1), tag));

% what action?
if ~ischar(action)
    
    error('Second input must be a string');

elseif strcmpi(action, 'add')
    
    % add it
    if (nargin < 4)
        error('add requires 4 inputs');
    end
    if (numel(row))
        user_data{row,2} = value;
    else
        user_data(end+1, 1:2) = {tag, value};
    end
    set(hObject, 'UserData', user_data);
    
elseif strcmpi(action, 'get')
    
    % retrieve it if it exists
    if numel(row)
        output = user_data{row, 2};
    end
    
elseif strcmpi(action, 'remove')

    % remove it if its there
    if numel(row)
        user_data = [user_data(1:row-1,:); user_data(row+1:end,:)];
        set(hObject, 'UserData', user_data);
    end
    
else
    error('unknown action');
end

