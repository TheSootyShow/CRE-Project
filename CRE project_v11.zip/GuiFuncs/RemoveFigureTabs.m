function [tab_info, handles] = RemoveFigureTabs(hFig, handles)
% function [tab_info, handles] = RemoveFigureTabs(hFig, handles)
% this function removes tabs form a figure and replaces
% them with overlapping frames

if (nargin < 2)
    handles = guidata(hFig);
end

tab_info = struct(  'tag',          [],    ... % its tag
                    'ftag',         [],    ... % tag of a uiframe replacing the tab group
                    'parent',       [],    ... % the tab groups parent
                    'visible',      [],    ... % visible?
                    'props',        {{}},  ... % extra properties to create it with (can be assigned to a ui frame)
                    'tab_tags',     {{}},  ... % the tags of the each child ui tab
                    'frame_tags',   {{}},  ... % the tags of the the created fake frames
                    'tab_props',    {{}}); ... % retain these properties of the tabs

% retain this info about the tab group                
group_props = {'FlowDirection', 'Margin', 'Units', 'Position', ...
               'Visible', 'UIContextMenu', 'SelectionChangeCallback'};
           
% retain this info about tabs group                
tab_props = {'Units', 'Position', 'UIContextMenu', 'Title'};
context_ind = find(strcmpi(tab_props, 'UIContextMenu'));


% find all of the tabs
tab_groups = findall(hFig, 'type', 'uitabgroup');
tab_groups = tab_groups(tab_groups ~= hFig);
tab_info = repmat(tab_info, numel(tab_groups), 1);

% go though them
for i = 1:numel(tab_groups)
    
    % copy tab group meta data
    tab_info(i).tag = get(tab_groups(i), 'tag');
    hParent = get(tab_groups(i), 'parent');
    tab_info(i).parent = get(hParent, 'tag');
    tab_info(i).visible = get(tab_groups(i), 'visible');
    
    % other properties of interest
    tab_info(i).props = cell(2, numel(group_props));
    tab_info(i).props(1,:) = group_props;
    for j = 1:numel(group_props)
        if strcmpi(group_props{j}, 'UIContextMenu')
            tab_info(i).props{2,j} = get(get(tab_groups(i), group_props{j}), 'tag');  % get the context menu by tag
        else
            tab_info(i).props{2,j} = get(tab_groups(i), group_props{j});
        end
        
        % cant store function handles so make it txt
        if strcmpi(group_props{j}, 'SelectionChangeCallback') && numel(tab_info(i).props{2,j})
            tab_info(i).props{2,j} = func2str(tab_info(i).props{2,j});
        end
    end
    
    % create a fake frame to replace this
    tab_info(i).ftag = sprintf('fakeuitabgroupframe_%i_%s', i, tab_info(i).tag);
    set(tab_groups(i), 'units', 'pixels');
    groupPos = get(tab_groups(i), 'position');
    hGroup = uipanel('parent', hParent, 'title', tab_info(i).tag, 'tag', tab_info(i).ftag, 'units', 'pixels', 'position', groupPos);
    handles.(tab_info(i).ftag) = hGroup;
    
    % get the child tabs
    all_tabs = get(tab_groups(i), 'children');
    tab_type = get(all_tabs, 'type');
    tabs = all_tabs(strcmpi(tab_type, 'uitab'));
    tab_info(i).tab_tags = get(tabs, 'tag');
    tab_info(i).frame_tags = cell(size(tab_info(i).tab_tags));
    tab_info(i).tab_props = cell(size(tab_info(i).tab_tags));
        
    % create fake frames for them
    for j = 1:numel(tabs)

        tab_info(i).frame_tags{j} = sprintf('fakeuiframe_%i_%i_%s', i, j, tab_info(i).tab_tags{j});
        hPanel = uipanel('parent', hGroup, 'title',  tab_info(i).frame_tags{j}, 'tag', tab_info(i).frame_tags{j}, 'units', get(tab_groups(i), 'units'), 'position', [4,4,groupPos(3:4)-8]);
        handles.(tab_info(i).frame_tags{j}) = hPanel;
        handles = rmfield(handles, tab_info(i).tab_tags{j});
        
        % collect the other properties
        tab_info(i).tab_props{j} = cell(2, numel(tab_props));
        tab_info(i).tab_props{j}(1,:) = tab_props;
        for k = 1:numel(tab_props)
            tab_info(i).tab_props{j}{2,k} = get(tabs(j), tab_props{k});
        end
        
        % set these properties of the panels
        set(hPanel, tab_info(i).tab_props{j}{:});
        
        % there's no use storing the handle value for a uicontextmenu, so
        % store its tag instead
        if numel(tab_info(i).tab_props{j}{2,context_ind})  
            tab_info(i).tab_props{j}{2,context_ind} = get(tab_info(i).tab_props{j}{2,context_ind}, 'tag');
        end
        
        % make all the children have the new frame as it parent
        set(findall(tabs(j)), 'units', 'pixels');  % uipanel titles seem to fail if not in pixels. No idea why
        set(allchild(tabs(j)), 'parent', hPanel);
        
    end    
end

% now delete all the tab groups
delete(tab_groups);
handles = rmfield(handles, {tab_info(:).tag});

% updated handles
if (nargout < 2)
    guidata(hFig, handles);
end
