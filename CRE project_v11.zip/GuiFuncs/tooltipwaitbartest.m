function varargout = tooltipwaitbartest(varargin)
% TOOLTIPWAITBARTEST M-file for tooltipwaitbartest.fig
%      TOOLTIPWAITBARTEST, by itself, creates a new TOOLTIPWAITBARTEST or raises the existing
%      singleton*.
%
%      H = TOOLTIPWAITBARTEST returns the handle to a new TOOLTIPWAITBARTEST or the handle to
%      the existing singleton*.
%
%      TOOLTIPWAITBARTEST('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TOOLTIPWAITBARTEST.M with the given input arguments.
%
%      TOOLTIPWAITBARTEST('Property','Value',...) creates a new TOOLTIPWAITBARTEST or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tooltipwaitbartest_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tooltipwaitbartest_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tooltipwaitbartest

% Last Modified by GUIDE v2.5 20-Jan-2010 23:39:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tooltipwaitbartest_OpeningFcn, ...
                   'gui_OutputFcn',  @tooltipwaitbartest_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tooltipwaitbartest is made visible.
function tooltipwaitbartest_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tooltipwaitbartest (see VARARGIN)


% --- Outputs from this function are returned to the command line.
function tooltipwaitbartest_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function progress_Callback(hObject, eventdata, handles)
% hObject    handle to progress (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of progress as text
%        str2double(get(hObject,'String')) returns contents of progress as a double


% --- Executes during object creation, after setting all properties.
function progress_CreateFcn(hObject, eventdata, handles)
% hObject    handle to progress (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in update.
function update_Callback(hObject, eventdata, handles)
% hObject    handle to update (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% updates the waitbar with the progress and the message
tooltipwaitbar( getappdata(handles.start, 'toolTipWaitBarHandle'),...
                str2double(get(handles.progress, 'String')),...
                get(handles.message, 'String'));


function message_Callback(hObject, eventdata, handles)
% hObject    handle to message (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of message as text
%        str2double(get(hObject,'String')) returns contents of message as a double


% --- Executes during object creation, after setting all properties.
function message_CreateFcn(hObject, eventdata, handles)
% hObject    handle to message (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% decides what to do about the error
if get(handles.abortOn, 'Value')
    % enable it
    abortAction = true;
    
elseif get(handles.abortError, 'Value')
    % error mode
    abortAction = 'error';
    
else
    % turn it off
    abortAction = false;
end

% starts
toolTipWaitBarHandle = tooltipwaitbar(  hObject,...
                                        str2double(get(handles.progress, 'String')),....
                                        get(handles.message, 'String'),...
                                        get(handles.useContextMenu, 'Value'),...
                                        get(handles.usePercentLabel, 'Value'),...
                                        abortAction);

% HACK - changes the font size (doesn't matter if the label isn't turned
% on)
set(toolTipWaitBarHandle(1), 'FontSize', 10)

% stores them in appdata
setappdata(hObject, 'toolTipWaitBarHandle', toolTipWaitBarHandle)


% --- Executes on button press in clear.
function clear_Callback(hObject, eventdata, handles)
% hObject    handle to clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% clears it out and deletes it from appdata
deletetooltipwaitbar(getappdata(handles.start, 'toolTipWaitBarHandle'))
rmappdata(handles.start, 'toolTipWaitBarHandle')


% --- Executes on button press in usePercentLabel.
function usePercentLabel_Callback(hObject, eventdata, handles)
% hObject    handle to usePercentLabel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of usePercentLabel


% --- Executes on button press in abortAction.
function abortAction_Callback(hObject, eventdata, handles)
% hObject    handle to abortAction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of abortAction




% --- Executes on button press in useContextMenu.
function useContextMenu_Callback(hObject, eventdata, handles)
% hObject    handle to useContextMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of useContextMenu


