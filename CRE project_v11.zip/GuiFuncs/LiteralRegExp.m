function str = LiteralRegExp(str)
% function str = LiteralRegExp(str)
% this function converts str so that regexp treats str
% as a pure literal string
%
% there are 12 characters with special meanings: 
    % the backslash 
    % the caret ^
    % the dollar sign $
    % the period or dot .
    % the vertical bar or pipe symbol |, 
    % the question mark ?, 
    % the asterisk or star *, 
    % the plus sign +, 
    % the opening parenthesis (, the closing parenthesis ), 
    % and the opening square bracket [, 
    % the opening curly brace {
% These special characters are often called "metacharacters".
% Source: http://www.regular-expressions.info/characters.html
    
% add a literal indicator \ to the below

persistent expr

if (numel(expr) == 0)
    
    % the characters to add a literal to
    rep_str = '\^$.|?*+()[{';    
    expr = repmat('\', 1, 2*numel(rep_str));
    expr(2:2:end) = rep_str;
    expr = ['([', expr, '])'];  % to capture a token
end

% and perform
str = regexprep(str, expr, '\\$1');