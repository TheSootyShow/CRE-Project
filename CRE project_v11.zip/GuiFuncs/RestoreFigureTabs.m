function handles = RestoreFigureTabs(hFig, handles, tab_info)
% function handles = RestoreFigureTabs(hFig, handles, tab_info)
% function to restore the figure's tabs
% Input tab_info comes from RemoveFigureTabs

% check if handles are present (if this is called by a create function they
% won't be)
if ~isstruct(handles)
    handles = struct();
end
no_handles = (numel(fieldnames(handles)) == 0);


warning('off', 'MATLAB:uitabgroup:OldVersion');

% go through each tab group
for i = 1:numel(tab_info)
    
    % add the tab panels for different frequencies
    hParent = getHandle(tab_info(i).parent, hFig, handles);
    hTabGroup = uitabgroup('parent', hParent, 'tag', tab_info(i).tag, 'visible', tab_info(i).visible); 
    handles.(tab_info(i).tag) = hTabGroup;
    
    % if the properties include a context menu, find the handle of it
    ind = find(strcmpi(tab_info(i).props(1,:), 'UIContextMenu'));
    if (numel(ind)) && numel(tab_info(i).props{2,ind})
        context_menu = getHandle(tab_info(i).props{2,ind}, hFig, handles);
        tab_info(i).props{2,ind} = context_menu;
    end
    
    % Note: Dont add the callback here (unless it known)
    isCallback = strcmpi(tab_info(i).props(1,:), 'SelectionChangeCallback');
    callback = [];
    if any(isCallback)
        callback = tab_info(i).props{2,isCallback};
    end
    tab_info(i).props = tab_info(i).props(:,~isCallback);
    
    % and set its properties
    filled = cellfun(@(x)(numel(x) > 0), tab_info(i).props(2,:));
    restore_props = tab_info(i).props(:, filled); 
    set(hTabGroup, restore_props{:});
    
    % now add each tab
    for j = 1:numel(tab_info(i).tab_tags)
        
        % if the properties include a context menu's tag (cant store the handle directly), find the handle of it
        ind = find(strcmpi(tab_info(i).tab_props{j}(1,:), 'UIContextMenu'));
        if (numel(ind)) && numel(tab_info(i).tab_props{j}{2,ind})
            context_menu = getHandle(tab_info(i).tab_props{j}{2,ind}, hFig, handles);
            tab_info(i).tab_props{j}{2,ind} = context_menu;
        end
        
        % extract used properties
        filled = cellfun(@(x)(numel(x) > 0), tab_info(i).tab_props{j}(2,:));
        filled = filled & ~strcmpi(tab_info(i).tab_props{j}(1,:), 'visible');  % can't set visible
        create_props = tab_info(i).tab_props{j}(:, filled); 

        % create the tab
        hTab = uitab(hTabGroup, create_props{:});
        set(hTab, 'tag', tab_info(i).tab_tags{j});
        handles.(tab_info(i).tab_tags{j}) = hTab;
        
        % change the parent of object in the "fake" frame
        hFrame = getHandle(tab_info(i).frame_tags{j}, hFig, handles);
        set(findall(hFrame), 'units', 'pixels');      % uipanel titles seem to fail if not in pixels. No idea why
        kids = allchild(hFrame);
        kids = kids(kids ~= get(hFrame, 'titlehandle'));  % N.B. dont transfer the panel title
        set(kids, 'parent', hTab); 
        
        % and delete the fake frame
        delete(hFrame);
        handles = rmHandle(handles, tab_info(i).frame_tags{j});

    end
    
    % in the newer version, a frame is created for the tab group.  Delete it
    if isfield(tab_info, 'ftag')
        delete(getHandle(tab_info(i).ftag, hFig, handles));
        handles = rmHandle(handles, tab_info(i).ftag);
    end
    
    % now all tabs are back, try the callback
    if (numel(callback))
        try
            callback = str2func(callback);
            set(hTabGroup, 'SelectionChangeCallback', callback);
        catch
            callback = [];
        end
    end
    
    % force this one
    if (numel(callback) == 0)
        set(hTabGroup, 'SelectionChangeCallback', @(hObject, eventdata)TabSelectionChange(hObject, eventdata, guidata(hObject)));
    end
end

if (nargout == 0) && (~no_handles)
    guidata(hFig, handles);
end

function h = getHandle(tag, hFig, handles)
% function h = getHandle(tag, hFig, handles)
% get the handle of the ui object with the specified tag

if isfield(handles, tag)
    h = handles.(tag);
else
    h = findobj(hFig, 'tag', tag);
end

if (numel(h) ~= 1) || ~ishandle(h)
    error('Couldnt find the handle for uiobject with tag: %s', tag);
end

function handles = rmHandle(handles, tag)
% function handles = rmHandle(handles, tag)
% remove the field from handles

if isfield(handles, tag)
    handles = rmfield(handles, tag);
end



