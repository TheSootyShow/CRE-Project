function data_set = DisplayData(h_table, h_slider, first_row, data_set, in_hhmmss, rel_time, reset)
% function data_set = DisplayData(h_table, h_slider, first_row, data_set, in_hhmmss, rel_time, reset)
% this function is a helper function for the CRE GUI
% it update the table in h_table with the appropriate data from the data_set
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% h_table           - handle to the Matlab table ui
%
% h_slide           - handle to the Matlab slider ui
%
% first_row         - the first row to display
%
% data_set          - the data set to display (see InitDataStruct.m)
%
% in_hhmmss         - show time format in HH:MM:SS? (or else just seconds)
%
% rel_time          - if true, shows time relative to the start of the
%                     recording
%
% reset             - recalculate the entire table

% get the underlying java object so we have access to properties

% if (numel(f_count) == 0)
%     f_count = 0;
% end
% f_count = f_count + 1;

% display some data if its a batch set
is_batch = strcmpi(data_set.set_type, 'batch');
if (is_batch)
    
    batch_set = data_set;  % store this
    
    % which one is active?
    idx = GetActiveSetIndex(batch_set);
    data_set = data_set.ds_headers(idx);
    
end

% redraw / create the table?
set(h_slider, 'visible', 'on');  % ensure its visible
set(h_table, 'visible', 'on');  % ensure its visible

if (reset)

    % get the java panel underlying the matlab panel
    user_data = get(h_table, 'userdata');
    if (~numel(user_data) || (numel(user_data{1}) == 0))
        jScrollPane = GetScrollPane(h_table);
    else
        jScrollPane = user_data{1};
    end
    
    set(jScrollPane,'VerticalScrollBarPolicy', javax.swing.JScrollPane.VERTICAL_SCROLLBAR_NEVER);  % ensure the vertical scroll never renders (we have h_slide instead)
    jViewPort = jScrollPane.getViewport;  % get the view portion object
    jTable = jViewPort.getView;   % get access to the java table from this
    jTable.setColumnAutoResizable(true);
    
    % get the row height of the table
    row_height = jTable.getRowHeight;
    tot_height = jViewPort.getHeight;
    
    
    % create the table for this many rows
    act_rows = tot_height / row_height; % this many rows are displayed
    n_rows = ceil(act_rows);  
    
    % disable the slider to stop triggering the slider's value adjustment callback
    set(h_slider, 'enable', 'off');
    
    % also disable the listener as it triggers the slider's value adjustment callback
    listener = getappdata(h_slider, 'sliderListener');
    set(listener, 'enabled', 'off')
    
    
    % update max / min of the slider based on the data set size
    if (data_set.num_points > n_rows)
        set(h_slider, 'min', 1);
        set(h_slider, 'max', data_set.num_points);
        sliderStep = [1, n_rows] ./ (data_set.num_points - 1);
        set(h_slider, 'sliderstep', sliderStep);
        set(h_slider, 'value', min(max(data_set.num_points - first_row + 1 - eps(1),1), data_set.num_points));  % N.B, the max is at the top
        
        % and re-enable
        set(h_slider, 'enable', 'on');
        set(listener, 'enabled', 'on');
    else
        set(h_slider, 'visible', 'off');
    end
    
    
    % make the table render
    data = cell(n_rows, data_set.dims + 1);
    set(h_table, 'data', data);
    
    % name the columns
    [null, format] = ConvertTime(0, 0, in_hhmmss, ~rel_time);
    if numel(data_set.dim_names)
        col_names = [sprintf('time (%s)', format); data_set.dim_names(:)];
    else
        col_names = [sprintf('time (%s)', format), num2cell(1:data_set.dims)];
    end
    set(h_table, 'ColumnName', reshape(col_names, 1, numel(col_names)));
    
    % and store the current row / first row
    jTable.setColumnResizable(true);
        
    c_row = 1;
    set(h_table, 'userdata', {jScrollPane, c_row, n_rows});

else
    user_data = get(h_table, 'userdata');
    c_row = user_data{2};
    n_rows = user_data{3};
end


% get the current data
data = get(h_table, 'data');


% can we reuse any data that's already there?
overlap = [0,0];  % first number is the overlap at the "top"
if (~reset)
    overlap(1) = (first_row >= c_row) * max(c_row + n_rows - first_row, 0);            % scrolled forwards
    overlap(2) = (first_row < c_row) * max(first_row + n_rows - c_row, 0);          % scrolled backwards
end
   
% allocate the new data array
new_data = cell(size(data));  

% start filling
if overlap(1)
    new_data(1:overlap(1), :) = data(end-overlap(1)+1:end, :);
end
if overlap(2)
    new_data(end-overlap(2)+1:end, :) = data(1:overlap(2), :);
end

% the indices of the new data to add
inds = first_row + overlap(1):min(first_row + n_rows - 1 - overlap(2), data_set.num_points);
% past_end = max(first_row + n_rows - 1 - data_set.num_points, 0);
if numel(inds)

    % generate time stamps for the points
    t = (inds(:)-1) * 1/data_set.fs;
    
    % add the date to t if desired
    t = num2cell(t);
    
    % convert to string form and assign
    if (rel_time)
        new_data(1+overlap(1):overlap(1)+numel(t), 1) = cellfun(@(t)ConvertTime(t, [], in_hhmmss, false), t(:), 'Uniformoutput', false);
    else
        new_data(1+overlap(1):overlap(1)+numel(t), 1) = cellfun(@(t)ConvertTime(t, data_set.tstamp, in_hhmmss, true), t(:), 'Uniformoutput', false);
    end

    % retrieve the actual data values and include them
    if (numel(data_set.data) == 0)  % i.e. its not in memory
        
        % grab it
        [X, data_set] = GetRawData(data_set, [inds(1), inds(end)], false);
        
        % if we don't have enough points, recall this function with the
        % updated version of the data set
        if (data_set.num_points < inds(end))
            data_set = DisplayData(h_table, h_slider, first_row, data_set, in_hhmmss, rel_time, true);
            return;
        end
    else
        
        % grab it
        X = data_set.data(inds(1):inds(end), :);
        if any(isnan(X(:)))
            
            % we have't loaded it yet
            [X, data_set] = GetRawData(data_set, [inds(1), inds(end)], false);
            
            % if we don't have enough points, recall this function with the
            % updated version of the data set
            if (data_set.num_points < inds(end))
                data_set = DisplayData(h_table, h_slider, first_row, data_set, in_hhmmss, rel_time, true);
                return;
            end
        
        else
            % grab numeric form
            X = num2cell(X);
        
            % and convert to string form
            X = cellfun(@num2str, X, 'Uniformoutput', false);
        end
        
    end
    
    % change class enumeration to the desription
    for i = 1:size(data_set.class_info,1)
        
        % find the column
        colInd = find(strcmpi(ClassifierColumnName(data_set.class_info{i,1}), data_set.dim_names), 1, 'first');
        
        % find the enumerated name
        enum = str2double(X(:, colInd));
        
        % map enumerations to the description columns
        map = data_set.class_info(i,3:3:size(data_set.class_info,2));
        map = cell2mat(map(cellfun(@numel, map) > 0));
        [valid, idx] = ismember(enum, map);
        X(valid, colInd) = data_set.class_info(i, 2 + (idx(valid)-1)*3);
    end
    
    % assign it to the new display
    new_data(1+overlap(1):overlap(1)+size(X,1), 2:end) = X;
    
end
    

% ensure the row names are correct
rows = num2cell(first_row : first_row + n_rows - 1);
row_names = cellfun(@num2str, rows, 'Uniformoutput', false);
set(h_table, 'RowName', row_names(:));

% now update the table
set(h_table, 'data', new_data);


if (abs(first_row - c_row) > 1)  % I hate matlab
    set(h_table, 'visible', 'off');
    drawnow();
    set(h_table, 'visible', 'on');
    drawnow();
else
    drawnow();
end


% and make sure the new first line is recorded
set(h_table, 'userdata', {[], first_row, n_rows});

% restore the batch set
if (is_batch)
    
    batch_set.ds_headers(idx) = data_set;  % update
    data_set = batch_set;
    
end



%fprintf('%i\n', f_count);


function jScrollPane = GetScrollPane(h_table)
% function jScrollPane = GetScrollPane(h_table)
% function to get the java scroll pane underlying the table object

delay = .01;                  % try agin after this many ms
max_tries = ceil(.1 / delay);  % give up if we cant find it in .1 seconds

% try
jScrollPane = findjobj(h_table, 'nomenu', 'persist');
tries = 1;

% we may have to wait for it to render
while (numel(jScrollPane) == 0) && (tries < max_tries)
    jScrollPane = findjobj(h_table, 'nomenu');  % try again without persistency
    drawnow();
    pause(delay);
    tries = tries + 1;
end

    

    
    
    
