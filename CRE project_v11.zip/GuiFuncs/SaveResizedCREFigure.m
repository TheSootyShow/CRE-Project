function handles = SaveResizedCREFigure(hFig, file_name, handles)
% function handles = SaveResizedCREFigure(hFig, file_name, handles)
% function to save a CRE gui after it has been resize
% (so it loads at the correct size next time)
% N.B. Output handles will be different if there are tabs (they cant be
% saved so they are destroyed and recreated after the save)

% this process / save resized and load with the gui layout function
% isn't currently working for deployed applications
% and I don't know why, hence its disabled for now
% if isdeployed()
%     return; 
% end


% so we dont save over and over
persistent in_progress
if ~iscell(in_progress)
    in_progress = {};
end

if (nargin < 3) || (~isstruct(handles))
    handles = guidata(hFig);
end

if (nargin < 2) || (numel(file_name) == 0)
    file_name = '';
end


% recreate the original if we're in developer mode
produce_orig = IsDeveloper();
 
% fill in missing parts of the name
[path, name, ext] = fileparts(file_name);
if (numel(path) == 0)
    path = CreateFigureResourceDir();
end
if (numel(ext) == 0)
    ext = '.fig';
end
if (numel(name) == 0)
    name = get(hFig, 'tag');
end

% if we can't write to the output dir, return now
if (numel(path) == 0) || ~CheckWritePermission(path);
    return;
end

% current version of the project
curr_version_str = CRE_version();

% make sure name has a version
ver_str = regexpi(name, '_\d+_\d+_\d+', 'match', 'once');
if (numel(ver_str))
    name_no_version = regexprep(name, ver_str, '');
    [ver_vec, is_current] = CRE_version(ver_str(2:end));  % is the version string the current one?
    
    % replace it if not
    if (~is_current)
        name = sprintf('%s_%s', name, curr_version_str);
    end
    
else
    
    % name before version is attached
    name_no_version = name;
    
    % attach the version to the name
    name = sprintf('%s_%s', name, curr_version_str);
    
end

if (produce_orig)
    name = name_no_version;
end

% recreate the name
file_name = fullfile(path, [name, ext]);


% look for older version in the path and delete them
if exist(path, 'dir')
    fig_names = cellstr(ls(path));
    matches = regexpi(fig_names, name_no_version, 'match', 'once');
    has_match = cellfun(@(x)(numel(x) > 0), matches);
    for i = 1:numel(has_match)
        if (has_match(i)) && ~strcmpi(file_name, fig_names{i})  % don't delete the current version
            try
                delete(fullfile(path, fig_names{i}));
            end
        end
    end
end

% if it already exists there's no need to do this
if any(strcmpi(in_progress, file_name))
    return;
end

% indicate we're saving this one
in_progress{end+1} = file_name;


% remove all uitab controls (Matlab doesn't like saving / loading them)
tab_info = [];
visState = get(hFig, 'visible');
hCover = [];

% does this figure have tabs?
hasTabs = HasTabs(hFig);
if (hasTabs)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Put Something in front of the figure so the user doesn't see this
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % set hFig visible now in case of lost focus
    set(hFig, 'visible', 'on');
    visState = 'on';
    
    hCover = CoverFig(hFig);
    [tab_info, handles] = RemoveFigureTabs(hFig, handles);
    modUserData(hFig, 'add', 'TabInfo', tab_info);
    
    % create a file to store the tab data in.  The deployed version
    % gui create is weird....
    tabFile = regexprep(file_name, '\.fig$', '_TabData.mat');  % ensure this naming scheme matches GuiLayoutFunction.m
end

% start building the new handles
new_handles = struct;
new_handles.(get(hFig, 'tag')) = hFig;  % this is the figure name

% turn off the warning for accessing titles
warning('off', 'MATLAB:Uipanel:HiddenImplementation');

% copy everything to the new figure
uiObjects = allchild(hFig);

% add all the uicontrols to the new_handles
% (also copying theire children as we go)
i = 0;
while (i < numel(uiObjects))
    
    i = i + 1;
    tag = get(uiObjects(i), 'tag');
    
    if numel(tag)
        new_handles.(tag) = uiObjects(i);
    
    elseif ~strcmpi(get(uiObjects(i), 'type'), 'text')
        
        % delete it unless its the title of a uiframe
        parent = get(uiObjects(i), 'parent');
        delete_obj = ~(strcmpi(get(parent, 'type'), 'uipanel') && (uiObjects(i) == get(parent,'TitleHandle')));
        if (delete_obj)
            delete(uiObjects(i));
            continue;
        end
    end
    if strcmpi(get(uiObjects(i), 'type'), 'uicontrol')
        set(uiObjects(i), 'units', 'centimeters'); % before saving, change all units to cm (pick any absolute measure)
    end
    
    % now recurse
    kids = allchild(uiObjects(i));
    uiObjects = [uiObjects(:); kids];  

end
warning('on', 'MATLAB:Uipanel:HiddenImplementation');

% re-attach context menu's

% assume it'll need these
new_handles.output = {}; 
new_handles.ismodal = strcmpi(get(hFig, 'windowstyle'), 'modal');

% record the system it been setup for
% NEW WAY
if (produce_orig)
    modUserData(hFig, 'remove', 'Size');  % never save originals with size data in them
else
    % but always save non-originals with their size data
    CheckGuiSize(hFig);  
end

% OLD WAY
% screen_size = get(0, 'ScreenSize');
% screen_info.ppi = get(0, 'ScreenPixelsPerInch');
% screen_info.pix_size = screen_size(3:4);
% screen_info.size = screen_info.pix_size / screen_info.ppi;
% screen_info.units = 'inches';
% handles.screen_info = screen_info; % always
% if (~produce_orig)
%     new_handles.screen_info = screen_info;
% end

% before saving, change all units to cm (pick any absolute measure)
set(hFig, 'units', 'centimeters');

% upload the new_handles 
guidata(hFig, new_handles);

% now try to save it (may not be able to if the directory isn't writeable)
% set(hFig, 'visible', 'off')
if (~produce_orig)
    % turn off the resize function while we render it
    resize_fcn = get(hFig, 'ResizeFcn');
    set(hFig, 'ResizeFcn', []);
    modUserData(hFig, 'add', 'ResizeFcn', resize_fcn);
end

% only set visible if it isn't (otherwise it'll pull focus from the cover
% image)
if ~strcmpi(visState, 'on')
    set(hFig, 'visible', 'on');
    drawnow();
end
setappdata(hFig, 'SavedVisible', 'On');            % so it displays after loading


try
    
    % save it
    hgsave(hFig, file_name)
    
    % save auxillary tab info if it exists
    if 0 && (hasTabs)
        save(tabFile, 'tab_info', '-mat');
    end

    if (IsDeveloper())
        fprintf('Saved: %s to %s\n', get(hFig, 'tag'), file_name);
    end
    
catch ME
    if (~isdeployed())
        rethrow(ME);
    end
end

% restore the original new_handles
guidata(hFig, handles);

% and the size data back to the originals now they've been saved
if (produce_orig)
    CheckGuiSize(hFig);  
end

% restore tab info
if numel(tab_info)
    
    handles = RestoreFigureTabs(hFig, handles, tab_info);
    modUserData(hFig, 'remove', 'TabInfo');
    
end

% delete what we covered the figure with
if (numel(hCover) > 0)
    delete(hCover);
end


% unblock it
in_progress = in_progress(~strcmpi(in_progress, file_name));


