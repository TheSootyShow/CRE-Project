function CREGuiLayout(hGui, eventdata, handles)
% function CREGuiLayout(hGui, eventdata, handles)
% this function resized the CRE gui to make it perty

% get the screen resolution
pix_cm = (get(0, 'ScreenPixelsPerInch')) / 2.54;  % pixels per centimeter

% the minimum list box height
minDataHeight = ceil(3 * pix_cm);
minListHeight = ceil(2 * pix_cm);

minViewWidth = ceil(5 * pix_cm);

% pre-define some panel divisions for vertical space
vert_rat = [.45; ...  % 45% for the data set panel
            .45; ...  % 45% for the processing functions panel
            .10];     % 10% for the status bar panel (the value used is actually 1 - sum(vert_rat(1:2))
        
% pre-define some panel divisions for horizontal space   
horz_rat = [.3; ... % 30% for the data set / processing functions panels
            .7];    % 70% for the plot / table panel (the value used is actually 1 - horz_rat(1))
        
% within panel gaps
[smallGap, normGap, largeGap] = DefaultPaneGaps();

% gaps from ui objects to borders, gaps between panels
% and gaps between border and figure boundaries
[paneGap, paneBorder, figBorder] = DefaultGuiBorders();
figBorder(4) = ceil(figBorder(2)/2);  % mess with this

widthSpace = sum(figBorder([1,3])) + (numel(horz_rat)-1) * paneGap(1);  % blank horizontal space to leave for gaps between things
heightSpace = sum(figBorder([2,4])) + (numel(vert_rat)-1) * paneGap(2);

% make sure its the handles to the gui
if ~strcmpi(get(hGui, 'tag'), 'CREgui')
    hGui = ancestor(hGui,'figure');
end

% work in pixels
gui_units = 'pixels';
set(hGui, 'units', gui_units);

% get the gui size
guiPos = get(hGui, 'position'); % [left, bottom, width, height]

% get the maximum allowable gui size
[~, maxSiz] = GetUsableScreenSize(gui_units, hGui);

useSiz = min(guiPos(3:4), maxSiz);

% ensure the size works
%guiPos = GetUsableScreenSize('pixels', hGui);
%set(hGui, 'position', guiPos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Work out minimum height of the status panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% work in pixels
set([handles.uiStatus; get(handles.uiStatus, 'children')], 'units', 'pixels');

% how high is its label for the pane?
sts_title_height = GetPanelTextHeight(handles.uiStatus, true);

% the status text
sts_txt_height = GetPreferredSize(handles.txtStatus);

% it uses a bar configuration under it, add this to the required height
sts_bar_height = ceil(0.75 * sts_txt_height);
sts_req_height = sts_txt_height + sts_bar_height + sum(paneBorder([2,4])) + normGap + sts_title_height;  % leave room for the gap above it


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Work out minimum height of the function panel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% work in pixels
set([handles.uiProcessing; get(handles.uiProcessing, 'children')], 'units', 'pixels');

% assemble the components into a grid
func_grid = cell(4, 3);
func_grid(1, [1,3]) = {handles.txtFeatures, handles.txtDims};
func_grid(2, :) = {handles.lbFeats, 'h=0.5cm', handles.lbDims};
func_grid(3,  1:2) = {handles.txtBinDur};
func_grid(4, [1,3]) = {handles.pbFeatures, handles.pbExtractFeatures};

% get the size of them all
func_sizes = PaneSizesFromGrid(func_grid);

% some size modifications
availList = func_sizes{2,1}(2) - minListHeight;
func_sizes{2,end}(2) = func_sizes{2,1}(2);                      % ensure they match

func_sizes{2,1}(1) = ceil(3.4 * pix_cm);    % fix the width of the listboxes
func_sizes{2,end}(1) = func_sizes{2,1}(1);  % fix the width of the listboxes

% make some space between them
func_vgaps = repmat(smallGap, 3, 3);
func_vgaps(3,:) = normGap;
func_hgaps = repmat(largeGap, 4, 2);

% determine the final size but don't actually resize it
[func_pane, func_size] = ResizePaneFromGrid(func_grid, func_hgaps, func_vgaps, func_sizes, [false, false], -1);
func_req_width = func_size(1);
func_req_height = func_size(2) - availList;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set an arbitrary minimum height for the display pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% work in pixels
set([handles.uiDatasetFrame; get(handles.uiDatasetFrame, 'children')], 'units', 'pixels');
dfPos = get(handles.uiDatasetFrame, 'position');
availDF = dfPos(4) - minDataHeight;
data_req_height = dfPos(4) - availDF;  

% set the load CSV button to the correct position
set(handles.pbLoadCSV, 'units', 'pixels');
pos = get(handles.pbLoadCSV, 'position');
pos(1:2) = paneBorder(1:2);
set(handles.pbLoadCSV, 'position', pos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set an arbitrary minimum width for the view pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% work in pixels
set([handles.uiPlot; get(handles.uiPlot, 'children')], 'units', 'pixels');
view_req_width = min(minViewWidth, maxSiz(1)-func_req_width-widthSpace);  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Is the screen large enough?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% desired size based on the current size
desHeights = floor(vert_rat * (useSiz(2) - heightSpace));  
reqHeights = [data_req_height; func_req_height; sts_req_height];

% ensure it compatible with the maximum size
[adjHeights, valid] = AdjustDesiredSize(desHeights, reqHeights, maxSiz(2) - heightSpace);
    

desWidths = floor(horz_rat * (useSiz(1) - widthSpace));
reqWidths = [func_req_width; view_req_width];

% ensure it compatible with the maximum size
[adjWidths, valid] = AdjustDesiredSize(desWidths, reqWidths, maxSiz(1) - widthSpace);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now figure out the gui size
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

newGuiSiz = [sum(adjWidths) + widthSpace, sum(adjHeights) + heightSpace];
% newGuiSiz = max(newGuiSiz, useSiz);

if any(newGuiSiz ~= guiPos(3:4))

    % disable resize function
%     resize_fcn = get(set(hGui, 'ResizeFcn'));
%     set(hGui, 'ResizeFcn', []);
%     set(hGui, 'Resize', 'off');
            
    % and resize
    try
        ResizeFigure(hGui, newGuiSiz);
    catch ME
        new_error = sprintf('%s\nHeight dimensions: %i (%i, %i)', ME.message, adjHeights(1), reqHeights(1), desHeights(1));
        for i = 2:numel(adjHeights)
            new_error = sprintf('%s, %i (%i, %i)', new_error, adjHeights(i), reqHeights(i), desHeights(i));
        end
        new_error = sprintf('%s\nHeight space: %i (%i, %i, %i)', new_error, heightSpace, figBorder(2), paneGap(2), figBorder(4));
        new_error = sprintf('%s\nPixels per cm: %0.5g', new_error, pix_cm);
        error(new_error);
    end
    drawnow();
    guiPos = get(hGui, 'position');  % update for sanity checks
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now place each pane in its correction position
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% the status pane
sts_pos = [figBorder(1:2), guiPos(3) - sum(figBorder([1,3])), adjHeights(3)];
set(handles.uiStatus, 'position', sts_pos);
sts_top = sts_pos(2) + sts_pos(4) - 1;

% the function pane
func_pos = [figBorder(1), sts_top + paneGap(2), adjWidths(1), adjHeights(2)];
set(handles.uiProcessing, 'position', func_pos);
func_top = func_pos(2) + func_pos(4) - 1;


% the data set pane
data_pos = [figBorder(1), func_top + paneGap(2), adjWidths(1), adjHeights(1)];
set(handles.uiDatasetFrame, 'position', data_pos);
data_top = data_pos(2) + data_pos(4) - 1;

% sanity check
if (data_top) ~= (guiPos(4) - sum(figBorder([2,4])))
%    error('crap top');
end

% the right most point so far
max_right = max(data_pos(1) + data_pos(3), func_pos(1) + func_pos(3)) - 1;

% sanity check
if (max_right) ~= (adjWidths(1) + figBorder(1))
%    error('crap left');
end


% the view pane
view_pos = [max_right + paneGap(1), sts_top + paneGap(2), adjWidths(2), ...
    data_top - GetPanelTextHeight(handles.uiDatasetFrame, true) - (sts_top + paneGap(2)) + 1];  % N.B. the plot ui has no title so take away the height of the data panel
set(handles.uiPlot, 'position', view_pos);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now set the position of each element in the status pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% do this to center the text & waitbar
extra_height = (sts_pos(4) - sts_req_height);
txt_status_pos = [paneBorder(1), paneBorder(2) + ceil(extra_height / 2) + sts_bar_height, sts_pos(3) - sum(paneBorder([1,3])), sts_txt_height];
set(handles.txtStatus, 'position', txt_status_pos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now set the position of each element in the function pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lb_extra_up = func_pos(4) - func_size(2);
lb_extra_left = func_pos(3) - func_req_width;
func_sizes{2,1} = func_sizes{2,1} + floor([lb_extra_left/2, lb_extra_up]);
func_sizes{2,end} = func_sizes{2,1};
if rem(lb_extra_left,2)
    func_hgaps(2,1) = func_hgaps(2,1) + 1;  % the floor above remove a pixel, so add it back as space
end

% now use the grid resize function to resize it all
[tmp, func_pos_check] = ResizePaneFromGrid(func_grid, func_hgaps, func_vgaps, func_sizes, [false, false]);
if ~all(func_pos_check == func_pos(3:4))
%     error('crap');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now set the position of each element in the data set pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% recreate all components of it (line wrapping changes)
if isfield(handles, 'data_set')
    ShowDataSetInfo(handles.uiDatasetFrame, handles.data_set, handles.HHMMSS);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now set the position of each element in the viewing pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% how high is its label?
text_height = GetPanelTextHeight(handles.uiPlot, true);

% update the axis position within it
axis_pos = [paneBorder(1), paneBorder(2), view_pos(3) - sum(paneBorder([1,3])), view_pos(4) - sum(paneBorder([2,4])) - text_height];
set(handles.axPlot, 'position', axis_pos);
if strcmpi(get(handles.axPlot, 'visible'), 'on')
    CRERedrawAxis(handles.axPlot, handles.uiPlot);  % update the graph
end

% how wide should the slider be?
sld_width = ceil(0.45 * pix_cm); % (make the slider .45 cm wide)

% now set the table
table_pos = [paneBorder(1), paneBorder(2), view_pos(3) - sum(paneBorder([1,3])) - sld_width, axis_pos(4)];

% % hack - expand the table to cover the entire contents
% old_pos = get(handles.uiTable, 'position');
% X = get(handles.uiTable, 'data');
% if (table_pos(3) > old_pos(3))
%     X = repmat(X, 1, ceil(table_pos(3) / old_pos(3)));
% end
% if (table_pos(4) > old_pos(4))
%     X = repmat(X, ceil(table_pos(4) / old_pos(4)),1);
% end
% set(handles.uiTable, 'data', X);
set(handles.uiTable, 'position', table_pos);

% now set the slider
slider_pos = [table_pos(1) + table_pos(3), paneBorder(2), sld_width, axis_pos(4)];  % leave a two pixel gap between slider and table
set(handles.sldTable, 'position', slider_pos);

% add a tooltip to miDayMatch while we're here
drawnow();
warning('off','MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
jFrame = get(hGui,'JavaFrame');
try 
    jMenuBar = jFrame.fHG1Client.getMenuBar;
catch
    jMenuBar = jFrame.fFigureClient.getMenuBar;
end

% get the advanced menu
for i = 1 : jMenuBar.getComponentCount()
    jMenu = jMenuBar.getComponent(i-1);
    if strcmpi(jMenu.getText, 'Advanced')
        javaMethodEDT('doClick', jMenu);  % force it to render children (open it)
        drawnow();
        for j = 1:javaMethodEDT('getMenuComponentCount', jMenu)
            jMenuItem = javaMethodEDT('getMenuComponent', jMenu , j-1);
            if numel(strfind(jMenuItem.getClass(), 'MenuItem'))  % dont check seperators
                if strcmpi(jMenuItem.getText(), 'Match times within the day')
                    jMenuItem.setToolTipText('When this is selected, only the time of day is retained when the data set is changed (i.e. date is ignored)');
                elseif strcmpi(jMenuItem.getText(), 'Preload all data')
                    jMenuItem.setToolTipText('Selecting this tells the program to fully process each loaded CSV. This allows exact calculation of the number of points, otherwise the number of points is estimated.');
                end
            end
        end
        javax.swing.MenuSelectionManager.defaultManager().clearSelectedPath();
        break;
    end
end




function widths = WidthFromSizes(sizes)
% function widths = WidthFromSizes(sizes)
% get the width from a cell array of sizes

widths = zeros(size(sizes));
n_els = cellfun(@numel, sizes);
widths(n_els > 0) = cellfun(@(x)x(1), sizes(n_els > 0));



function heights = HeightFromSizes(sizes)
% function heights = HeightFromSizes(sizes)
% get the height from a cell array of sizes

heights = zeros(size(sizes));
n_els = cellfun(@numel, sizes);
heights(n_els > 0) = cellfun(@(x)x(2), sizes(n_els > 0));

















