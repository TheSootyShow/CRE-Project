function cell_array = ReadCellStrings(file_name, delimiter)
% function cell_array = ReadCellStrings(file_name, delimiter)
% function to read an array of strings from a cell array
% delimiter is the marker used to indicate string boudaries (default is a
% tab)


if (nargin < 2) || (numel(delimiter) == 0)
    delimiter = sprintf('\t');
end

% open it
fid = fopen(file_name, 'r');
if (fid < 0)
    ThrowError(sprintf('Could not open: %s for reading', file_name));
end

% and start reading
cell_array = cell(50, 20);
n_lines = 0;
max_cols = 0;
while ~feof(fid)
    
    % get the line
    line = fgetl(fid);
    
    % anything there?
    if ischar(line) && numel(line)
        
        % and tokenize
        line = regexp(line, delimiter, 'split');
        
        % expand the buffer?
        n_lines = n_lines + 1;
        max_cols = max(max_cols, numel(line));
        if (n_lines <= size(cell_array,1)) && (size(cell_array,2) >= max_cols)
            % do nothing
        elseif (n_lines > size(cell_array,1)) || (size(cell_array,2) < max_cols)
            cell_array{n_lines + 50,max_cols + 20} = [];
        elseif (size(cell_array,2) < max_cols)
            cell_array{1, max_cols + 20} = [];
        elseif (n_lines > size(cell_array,1))
            cell_array{n_lines + 50,1} = [];
        end
        
        % expand the buffer?
        cell_array(n_lines, 1:numel(line)) = line;
        
    end
end

% prune back over allocation
cell_array = cell_array(1:n_lines, 1:max_cols);



function ThrowError(string)
% function ThrowError(string)
% function to generate different types of errors

if isdeployed()
    errordlg(string);
else
    error(string);
end