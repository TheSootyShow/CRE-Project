function CRERedrawAxis(hAxis, hPanel)
% function CRERedrawAxis(hAxis, hPanel)
% this function redras h_axes so that it fits within the bounds
% of hPanel


% use the following distance between the axis boundary and the uipanel (in characters)
pix_cm = (get(0, 'ScreenPixelsPerInch')) / 2.54;      % pixels per centimeter
border_space = .2 * pix_cm * ones(1,4);  % [left bottom right top]
text_gap = .1 * pix_cm;                  % gap between titles and things



% enure they are in the same units
old_panel_units = get(hPanel, 'units');
old_axis_units = get(hAxis, 'units');
set([hAxis, hPanel], 'units', 'pixels');

% find relevant labels and remove them while we calculate the inset
x_label = get(hAxis, 'xlabel');
if numel(x_label) && numel(get(x_label, 'string'))
    set(x_label, 'units', 'pixels');
    x_info = get(x_label);
    xlabel(hAxis, []);  % set empty for now
else
    x_label = [];
end

y_label = get(hAxis, 'ylabel');
if numel(y_label) && numel(get(y_label, 'string'))
    set(y_label, 'units', 'pixels');
    y_info = get(y_label);
    ylabel(hAxis, []);  % set empty for now
else
    y_label = [];
end

title_label = get(hAxis, 'title');
if numel(title_label) && numel(get(title_label, 'string'))
    set(title_label, 'units', 'pixels');
    title_info = get(title_label);
    title(hAxis, []);  % set empty for now
else
    title_label = [];
end


% make the axis as trim as possible
tight_inset = get(hAxis, 'tightinset');
set(hAxis, 'looseinset', tight_inset);
a_pos = get(hAxis, 'position');


% how much space is needed for text around the axis?
left_space = tight_inset(1);
bottom_space = tight_inset(2);
right_space = tight_inset(3);
top_space = tight_inset(4);


% look for any x-tick labels
xtl = findobj(hAxis, 'type', 'text', '-regexp', 'tag', 'XTickLabel\d+');
tick_height = 0;
if numel(xtl)
    
    % don't change the tick positions
    set(hAxis, 'xtickmode', 'manual');
    set(hAxis, 'xticklabelmode', 'manual');
    
    % bottom space seems unnaturally large in this case, so adjust it
    bottom_space = text_gap;
   
    % find how big the ticks are
    set(xtl, 'Units', 'pixels');
    tick_extents = cell2mat(get(xtl, 'extent'));
    
    % turn the extents into bounding boxes
    tick_bbox = zeros(size(tick_extents));
    tick_bbox(:,1:2) = tick_extents(:, 1:2);
    tick_bbox(:,3:4) = tick_extents(:, 1:2) + tick_extents(:, 3:4);
   
    %  now add it to the border
    tick_left = min(tick_bbox(:,1));
    tick_height = max(tick_bbox(:,4) - tick_bbox(:,2) + 1);
    tick_right = max(tick_bbox(:,3)) - a_pos(3);
    
    % and update sizes
    left_space = max(left_space, -tick_left);
    right_space = max(right_space, tick_right);
    
    % record what percentage of the way through the extent the tick is
    x_ticks = cell2mat(get(xtl, 'userdata'));  % their corresponding xtick values are stored in userdata
    set(xtl, 'Units', 'data');
    tick_extents = cell2mat(get(xtl, 'extent'));  % now in units of data
    tick_xper = (x_ticks(:) - tick_extents(:,1)) ./ tick_extents(:,3);  % how far across the label the tick is (keep this the same after resize)
    
    % add the space to the tick height
    tick_height = tick_height + text_gap;
    
end

% if there was an x label, add room for it 
if numel(x_label)
    x_ext = x_info.Extent;
    bottom_space = bottom_space + x_ext(4);  % its rotated 90 degs so the height is in the x direction
end

% if there was a y label, add room for it to left_space
if numel(y_label)
    y_ext = y_info.Extent;
    left_space = left_space + text_gap + y_ext(3);  % its rotated 90 degs so the height is in the x direction
end

% if there was a title, add room for it
if numel(title_label)
    title_ext = title_info.Extent;
    top_space = top_space + text_gap + title_ext(4);  % its rotated 90 degs so the height is in the x direction
end

% how big is the panel?
p_size = get(hPanel, 'position'); % [left bottom width height]

% set the outer position of the axis
outer_pos = [1,1, p_size(3:4) - 2];
set(hAxis, 'outerposition', outer_pos);          

% how big should the axis inset be?
axis_inset = [left_space, bottom_space + tick_height, right_space, top_space] + border_space;
set(hAxis, 'looseinset', axis_inset);

% set the axis position
a_pos = outer_pos;
a_pos(1) = a_pos(1) + axis_inset(1);
a_pos(2) = a_pos(2) + axis_inset(2);
a_pos(3) = a_pos(3) - a_pos(1) - axis_inset(3);
a_pos(4) = a_pos(4) - a_pos(2) - axis_inset(4);
set(hAxis, 'position', a_pos);

% build a way to convert between data units and pixels
% (because text position is always set in data units)
ylims = get(hAxis, 'ylim');
y_data_pp = abs(diff(ylims)) / a_pos(4);  % this many data units per pixel
xlims = get(hAxis, 'xlim');
x_data_pp = abs(diff(xlims)) / a_pos(3);  % this many data units per pixel

% update the position of the ticks if they exist
x_bounds = xlims;  % center the x label between these
if numel(xtl)
    
    % change text_gap to data units
    text_gap_data = ylims(1) - (text_gap * y_data_pp);
    set(xtl, 'Units', 'data');

    for i = 1:numel(xtl)
        tick_ext = get(xtl(i), 'extent');
        tick_pos = get(xtl(i), 'position');
        x_bounds(1) = min(x_bounds(1), tick_ext(1));
        x_bounds(2) = max(x_bounds(2), tick_ext(1) + tick_ext(3));
        
        % fix y position
        ey = text_gap_data - (tick_ext(2) + tick_ext(4));
        tick_pos(2) = tick_pos(2) + ey;
        
        % fix x position
        ex = x_ticks(i) - (tick_ext(1) + tick_xper(i)*tick_ext(3));
        tick_pos(1) = tick_pos(1) + ex;
        
        % and update
        set(xtl(i), 'position', tick_pos);
    end
end

% recreate all of the labels
if numel(x_label)
    
    % recreate the label
    x_label = RecreateLabel(hAxis, x_info, @xlabel);
    
    % and update the position
    set(x_label, 'units', 'data');
    
    % this seems to take two goes - but I'm not sure what's changing in between
    for i = 1:2
        x_extent = get(x_label, 'extent');
        
        % error from where it should be in y
        ey = (ylims(1) - y_data_pp * (tick_height + bottom_space + 1)) - x_extent(2);
        
        % error from where it should be in x
        ex = mean(x_bounds) - (x_extent(1) + x_extent(3)/2);
        
        xpos = get(x_label, 'position');
        xpos(1) = xpos(1) + ex;
        xpos(2) = xpos(2) + ey;
        set(x_label, 'position', xpos);
    end
end

% recreate all of the labels
if numel(y_label)
    
    % recreate the label
    y_label = RecreateLabel(hAxis, y_info, @ylabel);
    
    % and update the position
    set(y_label, 'units', 'data');
    ypos = get(y_label, 'position');
    y_extent = get(y_label, 'extent');
    ex = (xlims(1) - x_data_pp * (tight_inset(1) + text_gap)) - (y_extent(1) + y_extent(3));
    ypos(1) = ypos(1) + ex;
    set(y_label, 'position', ypos);
end

% recreate all of the labels
if numel(title_label)
    
    % recreate the label
    title_label = RecreateLabel(hAxis, title_info, @title);
    
    % and update the position
    set(title_label, 'units', 'data');
    title_pos = get(title_label, 'position');
    title_extent = get(title_label, 'extent');
    ey = (ylims(2) + y_data_pp * text_gap) - (title_extent(2));
    title_pos(2) = title_pos(2) + ey;
    set(title_label, 'position', title_pos);
end


% restore old units
set(hAxis, 'units', old_axis_units);
set(hPanel, 'units', old_panel_units);


function h_label = RecreateLabel(hAxis, label_info, label_func)
% function h_label = RecreateLabel(hAxis, label_info, label_func)
% function to recreate a label from its original properties

% make it
h_label = feval(label_func, hAxis, label_info.String);

% no copy fields
no_copy = {'Position', 'Extent', 'Annotation', 'Parent', 'BeingDeleted', 'Type'};

% and set all of the properites
fnames = fieldnames(label_info);
for i = 1:numel(fnames)
    if ~any(strcmpi(fnames{i}, no_copy))
        set(h_label, fnames{i}, label_info.(fnames{i}));
    end
end
    


