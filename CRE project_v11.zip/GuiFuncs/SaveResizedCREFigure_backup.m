function SaveResizedCREFigure(hFig, file_name)
% function SaveResizedCREFigure(hFig, file_name)
% function to save a CRE gui after it has been resize
% (so it loads at the correct size next time)

produce_orig = true;  % set true while developing

if (nargin < 2)
    file_name = '';
end

% fill in missing parts of the name
[path, name, ext] = fileparts(file_name);
if (numel(path) == 0)
    path = CreateFigureResourceDir();
end
if (numel(ext) == 0)
    ext = '.fig';
end
if (numel(name) == 0)
    name = get(hFig, 'tag');
end

% current version of the project
curr_version_str = CRE_version();

% make sure name has a version
ver_str = regexpi(name, '_\d_\d_\d', 'match', 'once');
if (numel(ver_str))
    name_no_version = regexprep(name, ver_str, '');
    [ver_vec, is_current] = CRE_version(ver_str(2:end));  % is the version string the current one?
    
    % replace it if not
    if (~is_current)
        name = sprintf('%s_%s', name, curr_version_str);
    end
    
else
    
    % name before version is attached
    name_no_version = name;
    
    % attach the version to the name
    name = sprintf('%s_%s', name, curr_version_str);
    
end

if (produce_orig)
    name = name_no_version;
end

% recreate the name
file_name = fullfile(path, [name, ext]);


% look for older version in the path and delete them
if exist(path, 'dir')
    fig_names = cellstr(ls(path));
    matches = regexpi(fig_names, name_no_version, 'match', 'once');
    has_match = cellfun(@(x)(numel(x) > 0), matches);
    for i = 1:numel(has_match)
        if (has_match(i)) && ~strcmpi(file_name, fig_names{i})  % don't delete the current version
            try
                delete(fullfile(path, fig_names{i}));
            end
        end
    end
end

% if it already exists there's no need to do this
if exist(file_name, 'file') || (numel(findall(0, 'tag', get(hFig, 'tag'))) > 1)
    return;
end

% we can't save tabs, so remove them
tab_info = RemoveFigureTabs(hFig);


% make a copy of the figure to save
% (because we remove uicomponents not related to the handles)
%hCopy = figure('Toolbar', 'none', 'MenuBar', 'none', 'visible', 'off');
hCopy = figure('Toolbar', 'none', 'MenuBar', 'none');
set(hCopy, 'units', get(hFig, 'units'));
set(hCopy, 'outerposition', get(hFig, 'outerposition'));
set(hCopy, 'Color', get(hFig, 'Color'));
set(hCopy, 'tag', get(hFig, 'tag'));
set(hCopy, 'name', get(hFig, 'name'));
%set(hCopy, 'numbertitle', get(hFig, 'numbertitle'));
set(hCopy, 'numbertitle', 'off');

% now copy all of the figure's callback's
props = get(hFig);
prop_names = fieldnames(props);
is_callback = cellfun(@(str)(numel(regexpi(str, '^\w+fcn$', 'match', 'once')) > 0), prop_names);
callbacks = prop_names(is_callback);
for i = 1:numel(callbacks)
    set(hCopy, callbacks{i}, get(hFig, callbacks{i}));
end

% copy everything to the new figure
uiObjects_in = allchild(hFig);
uiObjects = copyobj(uiObjects_in, hCopy);
uiObjects = uiObjects(:);
[uiObjects, uiObjects_in] = MatchOrder(uiObjects, uiObjects_in);
uiContext = findall(hCopy, 'type', 'uicontextmenu');
uiContextTag = get(uiContext, 'tag');
if ~iscell(uiContextTag)
    uiContextTag = {uiContextTag};
end


% start building the new handles
handles = struct;
handles.(get(hFig, 'tag')) = hCopy;  % this is the figure name

% turn off the warning for accessing titles
warning('off', 'MATLAB:Uipanel:HiddenImplementation');

% add all the uicontrols to the handles
% (also copying theire children as we go)
i = 0;
while (i < numel(uiObjects))
    
    i = i + 1;
    tag = get(uiObjects(i), 'tag');
    if numel(tag)
        handles.(tag) = uiObjects(i);
    elseif ~strcmpi(get(uiObjects(i), 'type'), 'text')
        
        % delete it unless its the title of a uiframe
        parent = get(uiObjects(i), 'parent');
        delete_obj = ~(strcmpi(get(parent, 'type'), 'uipanel') && (uiObjects(i) == get(parent,'TitleHandle')));
        if (delete_obj)
            delete(uiObjects(i));
            continue;
        end
    end
    if strcmpi(get(uiObjects(i), 'type'), 'uicontrol')
        set(uiObjects(i), 'units', 'centimeters'); % before saving, change all units to cm (pick any absolute measure)
    end
    
    % does it have a context menu?
    cmenu = get(uiObjects_in(i), 'UIContextMenu');
    if numel(cmenu)
        idx = find(strcmpi(get(cmenu, 'tag'), uiContextTag));
        if (numel(idx) ~= 1)
            error('Could not attach context menu %s to uicontrol %s', get(cmenu, 'tag'), tag);
        else
            set(uiObjects(i), 'UIContextMenu', uiContext(idx));
        end
    end
    
    % now recurse
    kids = allchild(uiObjects(i));
    if numel(kids)
        kids_in = allchild(uiObjects_in(i));
        [kids, kids_in] = MatchOrder(kids, kids_in);
        uiObjects = [uiObjects(:); kids];  % N.B. they've already been copied
        uiObjects_in = [uiObjects_in(:); kids_in];
    end
end
warning('on', 'MATLAB:Uipanel:HiddenImplementation');

% re-attach context menu's

% assume it'll need these
handles.output = {}; 
handles.ismodal = strcmpi(get(hFig, 'windowstyle'), 'modal');

% record the system it been setup for
if (~produce_orig)
    screen_size = get(0, 'ScreenSize');
    screen_info.ppi = get(0, 'ScreenPixelsPerInch');
    screen_info.pix_size = screen_size(3:4);
    screen_info.size = screen_info.pix_size / screen_info.ppi;
    screen_info.units = 'inches';
    handles.screen_info = screen_info;
end

% upload the handles 
guidata(hCopy, handles);

% copy all of the appdata
input_appdata = getappdata(hFig);
output_appdata = getappdata(hCopy);
input_appfields = fieldnames(input_appdata);
output_appfields = fieldnames(output_appdata);
for i = 1:numel(input_appfields)
    if ~any(strcmpi(input_appfields{i}, output_appfields)) && ~strcmp(input_appfields{i}, 'savedVisible')  % don't overwrite appdata it already has (e.g. the handles)
        setappdata(hCopy, input_appfields{i}, getappdata(hFig, input_appfields{i}));
    end
end


% before saving, change all units to cm (pick any absolute measure)
set(hCopy, 'units', 'centimeters');

% now try to save it (may not be able to if the directory isn't writeable)
% set(hFig, 'visible', 'off')
try
    if (~produce_orig)
        % turn off the resize function while we render it
        resize_fcn = get(hCopy, 'ResizeFcn');
        set(hCopy, 'ResizeFcn', []);
        set(hCopy, 'Userdata', {'ResizeFcn', resize_fcn});  % prevent multiple resizing (restore it in the custom load)
    end
    set(hCopy, 'visible', 'on');
    drawnow();
    setappdata(hCopy, 'SavedVisible', 'On');            % so it displays after loading
    
    if (produce_orig)
        set(hCopy, 'userdata', []);  % dont receord screen info
    end
    
    hgsave(hCopy, file_name) 
end
delete(hCopy);
% set(hFig, 'visible', 'on')


function [handles1, handles2] = MatchOrder(handles1, handles2)
% function handles1 = MatchOrder(handles1, handles2)
% function to use tags to match the order of the handles in handles1 and
% handles2.  The lists should be the same length

% if the handle has no tags, match it by these fields
match_props = {'style', 'string', 'type'};  % always put style first

if (numel(handles1) ~= numel(handles2))
    error('Trying to match an uneven number of handles');
end

% combine
handles = {handles1(:), handles2(:)};

% match by tags in the first instance
tags = get([handles{1}, handles{2}], 'tag');
tags = reshape(tags, numel(handles{1}), 2);
empty_tag = cellfun(@(str)(numel(str) == 0), tags);
ntags = sum(~empty_tag, 1);

if (ntags(1) ~= ntags(2))
    error('Different numbers of handles have tags');
end

% sort them by empty status, put empty ones last
for i = 1:2
    [empty_tag(:,i), order] = sort(empty_tag(:,i), 'ascend');
    tags(:, i) = tags(order, i);
    handles{i} = handles{i}(order);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now sort the named ones
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

idx = zeros(numel(handles{1}, 1));
[valid, idx(1:ntags(1))] = ismember(tags(1:ntags(1),1), tags(1:ntags(1),2));

if ~all(valid)
    error('Unmatched tags');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now sort the unnamed ones
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% build a list of their properties
n_missing = numel(handles{1}) - ntags(1);
all_handles = [handles{1}, handles{2}];
props = cell(n_missing, 2);
for i = 1:n_missing
    for j = 1:2
        if strcmpi(get(all_handles(i+ntags(1),j), 'type'), 'uicontrol')
            props{i,j} = get(all_handles(i+ntags(1),j), match_props);
        elseif strcmpi(get(all_handles(i+ntags(1),j), 'type'), 'uitabgroup')
            props{i,j} = get(all_handles(i+ntags(1),j), match_props(3:end));
        else
            props{i,j} = get(all_handles(i+ntags(1),j), match_props(2:end));
        end
    end
end

% and match
matched = false(n_missing, 1);
for i = 1:n_missing
    for j = 1:n_missing
        if (~matched(j)) && isequal(props{i,1}, props{j,2})
            idx(i+ntags(1)) = ntags(1) + j;
            matched(j) = true;
            break;
        end
    end
end

% check it
if any(idx == 0) || (numel(unique(idx)) ~= numel(idx))
    error('Can''t uniquely match tags');
end

% and create outputs
handles1(idx) = handles{1};
handles2 = handles{2};





