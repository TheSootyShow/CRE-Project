function jObjFixedWidth(jObj, fixed_width, obj_width)
% function jObjFixedWidth(jObj, fixed_width)
% function to force the java object to have a have the specified fixed
% width.  preferredHeight should still be usable
% jObj must have a "getClientProperty" member function
%
% if obj_width is specified, fixed_width is used for its view (i.e. where
% line wrapping should happen) while the object is forced to have width
% obj_width

if (nargin < 3)
    obj_width = fixed_width;
end

% force it to be the desired width
jView = jObj.getClientProperty('html');
if numel(jView)

    ypref = jView.getPreferredSpan(javax.swing.text.View.Y_AXIS);
    jView.setSize(fixed_width, ypref);  % this should cause jObj.preferredSize to update
    
    % just in case, change maximums and minimum sizes for jObj
    siz = jObj.getMaximumSize();
    siz.width = obj_width;
    jObj.setMaximumSize(siz);
    siz.height = jObj.getMinimumSize.height;
    jObj.setMinimumSize(siz);
else
    error('Input object has no html view (jObj.getClientProperty(''html'') is empty)');
end