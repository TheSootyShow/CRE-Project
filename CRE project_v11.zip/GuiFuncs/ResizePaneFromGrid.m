function [hPane, paneSize, paneBorder] = ResizePaneFromGrid(hGrid, hGap, vGap,  useCurrSize, allowLeak, template)
% function [hPane, paneSize, paneBorder] = ResizePaneFromGrid(hGrid, hGap, vGap,  useCurrSize, allowLeak, template)
% this function is designed to automatically layout a pane accorrding to
% the input instructions.  The size of text controls is adjusted to the
% preferred size.  The pane must be visible!
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% hGrid         - a cell array of handles to gui objects which determines there
%                 place in the pane.  
%               - Use [] to leave a blank place.
%               - repeat the handle to stretch it across mutliple rows /
%                 columns
%
% hGap          - horizontal space to leave between columns in hGrid in pixels
%               - should have size [size(hGrid,1), size(hGrid,2)-1]
%               - defaults to .2 cm everywhere
%
% vGap          - vertical space to leave between rows in hGrid in pixels
%               - should have size [size(hGrid,1)-1, size(hGrid,2)]
%               - defaults to .2 cm everywhere
%
% useCurrSize   - set true if the gui objects have already been resized to
%                 their preferred size.  This is much faster as the java object doesn't
%                 need to be found
%               - optionally this can be a cell array the same size as
%                 hGrid, where each cell is [width, height] of the ui
%                 object (see PaneSizesFromGrid.m)
%
% allowLeak     - if true, allow objects to "leak" into unoccupied
%                 neighouring grid locations (two elements [leak horizontally,
%                 leak vertically]; 
% 
%
% template      = 0, don't create a new figure with a copy of this frame in
%                 it
%               = 1, copies the ui pane created to a new figure and prompts the
%                 user to save it
%               = if -1, instructs this program to calculate the pane size
%                 but not resize anything
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% hPane        - handle to the pane that everythings a child of
% 
% paneSize     - the pane size in pixels [width, height]



%%%%%%%%%%%%%%%%%%%%%%%%
% Define constants
%%%%%%%%%%%%%%%%%%%%%%%%%

[tmp, paneBorder, figBorder] = DefaultGuiBorders();
vcent = true;                                          % if true, rows are vertically centered

% use this gap when vGap or hGap is not inputted (cm)
[tmp, defaultGap] = DefaultPaneGaps();


%%%%%%%%%%%%%%%%%%%%%%%%
% Parse Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%

% if no inputs, just return default pane borders
if (nargin == 0)
    hPane = paneBorder;
    return;
end

if (nargin < 2) || (numel(hGap) == 0)
    hGap = repmat(defaultGap, size(hGrid,1), size(hGrid,2) - 1);
end

if (nargin < 3) || (numel(vGap) == 0)
    vGap = repmat(defaultGap, size(hGrid,1)-1, size(hGrid,2));
end

user_sizes = false;
if (nargin < 4) || (numel(useCurrSize) == 0)
    useCurrSize = false;
    ui_sizes = {};
elseif iscell(useCurrSize) 
    ui_sizes = useCurrSize;
    user_sizes = true;
else
    ui_sizes = {};
end

if (nargin < 5) || (numel(allowLeak) == 0)
    allowLeak = false(1,2);
end

if (nargin < 6) || (numel(template) == 0)
    template = 0;
end

% check hGap and vGap are the correct size
[n_rows, n_cols] = size(hGrid);
if (~all(size(hGap) == [n_rows, n_cols-1]))
    error('Handles matrix has size: [%i, %i],  Horizontal gap matrix should have size: [%i, %i] but has size: [%i, %i]', n_rows, n_cols, n_rows, n_cols-1, size(hGap,1), size(hGap,2));
elseif (~all(size(vGap) == [n_rows-1, n_cols]))
    error('Handles matrix has size: [%i, %i],  Vertical gap matrix should have size: [%i, %i] but has size: [%i, %i]', n_rows, n_cols, n_rows-1, n_cols, size(vGap,1), size(vGap,2));    
end


% grab size the sizes of uicomponents if they weren't entered
if (~user_sizes) && (~useCurrSize)
    ui_sizes = PaneSizesFromGrid(hGrid);
end

% which require space and which have handles?
is_filled = cellfun(@(x)(numel(x) > 0), hGrid);
is_handle = cellfun(@(x)((numel(x) > 0) && isnumeric(x) && ishandle(x)), hGrid);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get a handle to the parent of them all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h_container = cell2mat(hGrid(is_handle));
hPane = get(h_container, 'parent');
if iscell(hPane)
    hPane = cell2mat(hPane);
end
hPane = unique(hPane);

% check they all have the same parent
if (numel(hPane) > 1)
    tags = get(hPane, 'tag');
    par_str = '';
    for i = 1:numel(tags)
        par_str = sprintf('%s%s%s', par_str, repmat(', ', 1, i > 1), tags{i});
    end
    error('Elements of hGrid do not have a common parent.  Parents are: %s ', par_str);
end

% set them all to units of pixels
set([hPane; h_container(:)], 'units', 'pixels');

% get the height and width of each element
heights = zeros(size(hGrid));
widths = zeros(size(hGrid));

% get the sizes
r_copies = zeros(size(hGrid));  % how many copies of the object in the row
c_copies = zeros(size(hGrid));  % how many copies of the object in the column

% go through get width and height and looking at what's a copy of what
for i = n_rows:-1:1
    for j = 1:n_cols
        
        % only look at existing ones and 1 copy of each
        match_down = (i < n_rows) && is_filled(i+1,j) && (isequal(hGrid{i,j}, hGrid{i+1,j}));
        match_left = (j > 1) && is_filled(i,j-1) && isequal(hGrid{i,j}, hGrid{i,j-1});
        
        if (is_filled(i,j) && ~match_down && ~match_left)
            
            % get the size
            if numel(ui_sizes)
                
                if (numel(ui_sizes{i,j}) == 0)
                    error('failed to provide a uisize at grid position r = %i, c = %i', i, j);
                else
                    widths(i,j) = ui_sizes{i,j}(1);
                    heights(i,j) = ui_sizes{i,j}(2);
                end
                
                % ensure it is currently the specified size
                if ~ischar(hGrid{i,j})
                    pos = get(hGrid{i,j}, 'position');
                    pos(3:4) = [widths(i,j), heights(i,j)];
                    set(hGrid{i,j}, 'position', pos);
                end
                
            elseif ~ischar(hGrid{i,j})
                % use the current size
                pos = get(hGrid{i,j}, 'position');
                widths(i,j) = pos(3);
                heights(i,j) = pos(4);
            else
                % text spacing, use this function to get them
                ui_size = PaneSizesFromGrid(hGrid(i,j));
                widths(i,j) = ui_size{1}(1);
                heights(i,j) = ui_size{1}(2);
            end
            
            % check if its repeated over columns
            c_copies(i,j) = 1;  % one column for it
            while (j + c_copies(i,j) <= n_cols) && isequal(hGrid{i,j}, hGrid{i,j+c_copies(i,j)})
                heights(i, j+c_copies(i,j)) = heights(i,j);
                c_copies(i,j) = c_copies(i,j) + 1;
            end
            
            % check if its repeated over rows
            r_copies(i,j) = 1;  % one row for it
            while (i - r_copies(i,j) >= 1) && isequal(hGrid{i,j}, hGrid{i-r_copies(i,j),j})
                widths(i - r_copies(i,j), j) = widths(i,j);
                r_copies(i,j) = r_copies(i,j) + 1;
            end
            
            % and repeat the handle (enforces rectangular)
            spread_rows = i-r_copies(i,j)+1:i;  % component is spread across these rows
            spread_cols = j:j+c_copies(i,j)-1;  % component is spread across these columns
            hGrid(spread_rows, spread_cols) = hGrid(i,j);
            
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now figure out how wide each column should be
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this also return the maximum extent for each object
[col_widths, horz_ext_min, horz_ext_max] = GetColWidths(hGrid, widths, r_copies, c_copies, hGap, allowLeak(1));

col_start = cumsum([paneBorder(1), col_widths], 2);
col_start(end) = col_start(end) + paneBorder(3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% and how high each column should be
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this also return the maximum extent for each object
[row_heights, vert_ext_min, vert_ext_max] = GetRowHeights(hGrid, heights, r_copies, c_copies, vGap, allowLeak(2));

row_start = flipud(cumsum(flipud([row_heights; paneBorder(2)]),1));
row_start(1) = row_start(1) + paneBorder(4);      % this is actually the outer boundary (panes start at the bottom)

% add the height of the panel's title to the required height of the panel
if strcmpi(get(hPane, 'type'), 'uipanel')
    row_start(1) = row_start(1) + GetPanelTextHeight(hPane, true);
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now resize the pane to fit everything
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
paneSize = [col_start(end), row_start(1)];

if (template == -1)
    
    % this is an instruction to not resize anything
    return;
    
end

% use figure resize if its a figure
if strcmpi(get(hPane, 'type'), 'figure')
    ResizeFigure(hPane, paneSize);
else
    pos = get(hPane, 'position');
    pos(3:4) = paneSize;
    set(hPane, 'position', pos);
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now redraw the pane's uicontrols
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i = n_rows:-1:1  % start at the bottom
    for j = 1:n_cols
        
        if is_handle(i,j) && (r_copies(i,j) && c_copies(i,j))  % only do places with objects
            
            % Notes on indexing:
            % if handles_grid has n rows, then row_start has n+1 elements
            % and v_space_grid has n-1 elements.  Similarly for columns.
            
            % build dimensions
            left = horz_ext_min(i,j) + col_start(1);
            bottom = vert_ext_min(i,j) + row_start(end);
            right = horz_ext_max(i,j) + col_start(1);
            top = vert_ext_max(i,j) + row_start(end);
            
            % now build position from this
            pos = [left, bottom, right - left, top - bottom];
            
            % manipulate its position withing its rectangle
            rightmost = (j > 1) && ((j+c_copies(i,j)-1) == n_cols);  % is this in the right most column?
            pos = AdjustUIPosition(hGrid{i,j}, pos, widths(i,j), heights(i,j), j == 1, rightmost, vcent);
            
            
            % and set it
            set(hGrid{i,j}, 'position', pos);
            
        end
    end
end

% export the template?
if (template)
    
    % create a new figure
    fig_h = figure;
    set(fig_h, 'units', 'pixels');
    pos = get(fig_h, 'position');
    pos(3:4) = paneSize + [figBorder(1)+figBorder(3), figBorder(2)+figBorder(4)];
    set(fig_h, 'position', pos);
    
    % now copy this pane onto it
    new_pane = copyobj(hPane, fig_h);
    set(new_pane, 'position', [figBorder(1:2), paneSize]);  % move it to the correct location
    
    % remove the menu bar
    set(fig_h, 'MenuBar', 'none')
    set(fig_h, 'Color', [0.9412, 0.9412, 0.9412]);  % re-color it
    
    % create a handles structure for it
    handles = struct();
    add_handles = findobj(new_pane);
    for i = 1:numel(add_handles)
        tag = get(add_handles(i), 'tag');
        handles.(tag) = add_handles(i);
        
        % put it back in cm for portability
        set(add_handles(i), 'units', 'centimeters');
        
        % free it of all callbacks of any kind
        fields = fieldnames(get(add_handles(i)));
        for j = 1:numel(fields)
            if (numel(strfind(lower(fields{j}), 'callback')) || numel(strfind(lower(fields{j}), 'buttondownfcn')) || numel(strfind(lower(fields{j}), 'createfcn')))
                set(add_handles(i), fields{j}, '');
            end
        end
    end
    
%     % indent the rbRelTime and rbHHMMSS a little
%     set(handles.rbRelTime, 'units', 'pixels');
%     ui_pos = get(handles.rbRelTime, 'position');
%     ui_pos([1,3]) = ui_pos([1,3]) + [1,-1] * 20;
%     set(handles.rbRelTime, 'position', ui_pos);
%     set(handles.rbHHMMSS, 'units', 'pixels');
%     ui_pos = get(handles.rbHHMMSS, 'position');
%     ui_pos([1,3]) = ui_pos([1,3]) + [1,-1] * 20;
%     set(handles.rbHHMMSS, 'position', ui_pos);
    
    
    guidata(fig_h, handles);
    
    % and prompt the user to save it
    [file, path] = uiputfile('*.fig', 'Save template as', 'template.fig');
    
    % if OK
    if numel(file) && ischar(file)
        file = fullfile(path, file);
        [tmp, name, ext] = fileparts(file);
        set(fig_h, 'name', name);
        set(fig_h, 'tag', name);
        handles.(name) = fig_h;
        guidata(fig_h, handles);
        saveas(fig_h, file, 'fig'); 
    end
    
end


