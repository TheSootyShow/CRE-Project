function jFrame = GetjFrame(hFig)
% function jFig = GetjFrame(hFig)
% function to return the handle to the figure java frame

% get the figure's java frame
jFig = get(handle(hFig),'javaframe');
try
    jFrame = jFig.fHG1Client.getWindow;  
catch
    jFrame = jFig.fFigureClient.getWindow;  
end
jFrame = handle(jFrame);