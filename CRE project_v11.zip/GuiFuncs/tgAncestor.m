function hAnc = tgAncestor(hObject, type)
% function hAnc = tgAncestor(hObject, type)
% this function replaces "ancestor"
% because ancestor does not appear to work on type 
% 'uitabgroup'

hAnc = get(hObject, 'parent');
while (hAnc ~= 0) && ~strcmpi(get(hAnc, 'type'), type)
    hAnc = get(hAnc, 'parent');
end

% if we went all the way to the root return empty
if (hAnc == 0)
    hAnc = [];
end

