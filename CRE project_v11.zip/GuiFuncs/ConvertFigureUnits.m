function ConvertFigureUnits(fig_h, units)
% function ConvertFigureUnits(fig_h, units)
% this function changes the units of fig_h and
% ALL of its decendents that have a units property

% get all decendents with "units" property
descendants = [findall(h_grandparent, 'type', 'uicontrol'); ...
               findall(h_grandparent, 'type', 'uipanel');   ...
               findall(h_grandparent, 'type', 'figure');    ...
               findall(h_grandparent, 'type', 'axes')];
           
% and change
set(descendants, 'units', units);
