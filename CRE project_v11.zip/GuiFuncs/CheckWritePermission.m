function valid = CheckWritePermission(check_dir)
% function valid = CheckWritePermission(check_dir)
% function to check write permissions in a directory

persistent check_list

if ~iscell(check_list)
    check_list = cell(0,2);
end

index = find(strcmpi(check_dir, check_list(:,1)));
if numel(index)
    valid = check_list{index, 2};
else
    
    % create a file to test with
    check_file = fullfile(check_dir, 'CRE_permission_test.tmp');
    
    % did it work?
    fid = fopen(check_file, 'w');
    valid = fid > 0;
    if (valid)
        fclose(fid);
        delete(check_file);
    end
    
    % add it to the list
    check_list(end+1, :) = {check_dir, valid};
end

