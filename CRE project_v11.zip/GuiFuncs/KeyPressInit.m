function handles = KeyPressInit(hObject, eventdata, handles)
% function handles = KeyPressInit(hObject, eventdata, handles)
% function to initialise the key press functions for all
% edit boxes that are decendent of hObject

% make a robot to process edit boxed on key press
if ~isfield(handles, 'robot')
    handles.robot = java.awt.Robot;
    handles.press_enter = java.awt.event.KeyEvent.VK_ENTER;
end



