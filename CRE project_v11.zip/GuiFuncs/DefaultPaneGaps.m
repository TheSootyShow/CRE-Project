function [smallGap, normGap, largeGap] = DefaultPaneGaps()
% function = [smallGap, normGap, largeGap] = DefaultPaneGaps()
% function to generate default gaps bewteen ui objects

% Options for spacing
largeGap = .35;    % use this many cm gap for large gaps
normGap = .2;     % use this many cm gap between objects
smallGap = .075;  % use this many cm gap for small gaps


% to facilitate sizing
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
ppcm = ppi / 2.54;                                          % pixels per centimeter

% use standardized gaps
largeGap = ceil(largeGap  * ppcm);
normGap = ceil(normGap  * ppcm);
smallGap = ceil(smallGap  * ppcm);
