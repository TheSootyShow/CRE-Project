function ResizeFigure(hFig, new_size, call_resize_fcn)
% function ResizeFigure(hFig, new_size, call_resize_fcn)
% function to reposition the figure so that it has size new_size (in
% pixels)

if (nargin < 3) || numel(call_resize_fcn)
    call_resize_fcn = false;
end

if (~call_resize_fcn)
    resize_fcn = get(hFig, 'ResizeFcn');
    set(hFig, 'Resize', 'off');
end

set(hFig, 'units', 'pixels');
orig_pos = get(hFig, 'position');

% check the validity of the new size
new_width = new_size(1);
new_height = new_size(2);

% get the usable portion of the screen
usablePos = GetUsableScreenSize('pixels', hFig);
if (new_width > usablePos(3))
    error('Figure is too wide to fit on the screen (figure: %i pixels, usable screen: %i pixels)', new_width, usablePos(3));
end
if (new_height > usablePos(4))
    error('Figure is too high to fit on the screen (figure: %i pixels, usable screen: %i pixels)', new_height, usablePos(4));
end

% leave it centered in the same spot
pos(1) = orig_pos(1) + floor((orig_pos(3) - new_width) / 2);
pos(2) = orig_pos(2) + floor((orig_pos(4) - new_height) / 2);
pos(3) = new_width;
pos(4) = new_height;

% enforce constraints
xlims = [usablePos(1), usablePos(1) + usablePos(3) - new_width];
ylims = [usablePos(2), usablePos(2) + usablePos(4) - new_height];

pos(1) = min(max(pos(1), xlims(1)), xlims(2)); 
pos(2) = min(max(pos(2), ylims(1)), ylims(2)); 

% and set
set(hFig, 'position', pos);
setappdata(hFig, 'AWBSOnscreen', true);  % matlab's move gui function loves shifting the gui offscreen.  movegui.m has been changed to do nothing when this is set

% re-enable resize functions
if (~call_resize_fcn) && numel(resize_fcn)
    set(hFig, 'Resize', 'on');
    set(hFig, 'ResizeFcn', resize_fcn);
end
