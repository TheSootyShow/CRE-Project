function options = OptionsQuery(options)
% function options = OptionsQuery(options)
% this function prompts the user for modifications to the 
% size options used by CREgui

if (nargin < 1) || ~isstruct(options)
    options = InitOptions();  % create default
end


% these shouldnt be user selectable
% options.max_header_lines;  % headers should be larger than this (over allocate to judge dimensions)
% options.max_lookup;  % the lookup table has this many entries at most

% this is not currently used
%options.max_bar_els;  % the maximum number of bars in a bar series

% build a question dialog for the rest
prompt{1} = 'Maximum dataset size to place in memory (mb)';
def_answers{1} = sprintf('%0.2f', options.max_load_els * 64 * 1e-6);

prompt{2} = 'Maximum number of points on a plot';
def_answers{2} = sprintf('%i', round(options.max_plot_els));

% now prompt the user
response = inputdlg(prompt, 'Please select options', 1, def_answers);

% and parse responses
if numel(response)
    
    % the maximum data set size
    max_size = str2double(response{1});
    if isfinite(max_size) && (max_size > 0)
        options.max_load_els = round(max_size * 1e6 / 64);
    end
    
    % the maximum plot points size
    max_plot = str2double(response{2});
    if isfinite(max_plot) && (max_plot > 0)
        options.max_plot_els = round(max_plot);
    end
end

