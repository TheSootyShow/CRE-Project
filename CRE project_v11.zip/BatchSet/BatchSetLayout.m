function handles = BatchSetLayout(hObject, eventdata, handles)
% hObject    handle to CreateBatchSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent resizing

% check its not already resizing
if (numel(resizing) == 0) || (~resizing)
    
    % dont try it twice at once
    resizing = true;
    
    % cover it to prevent epillepsy
    if 0 && strcmpi(get(hObject, 'visible'), 'on')
        hCover = CoverFig(hObject);
    else
        hCover = [];
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build the grid
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hGrid = {handles.txtSetName,    handles.ebName,   'l',              [],       [];                    ...
             'v=.5cm'               [],               [],               [],       [];                    ...               
             handles.txtBatchFiles, 'l',              'l',              [],       handles.txtDimsLabels; ...
             handles.lbFiles,       'l',              'l',              'h=2cm',  handles.lbDims;        ...
             handles.pbAdd,         [],               handles.pbRemove, [],       handles.txtMinFs;      ...
             'v=.5cm',              [],               [],               [],       [];                    ...
             handles.pbCancel,      [],               [],               [],       handles.pbOK};
             

    % and resize
    ResizeFigFromPanes(hGrid);
         
    if numel(hCover)
        delete(hCover);
    end
    
    % and save
    handles = SaveResizedCREFigure(hObject, [], handles);
    
    % clear resizing
    resizing = false;
    
end