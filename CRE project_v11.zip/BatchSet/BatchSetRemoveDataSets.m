function batch_set = BatchSetRemoveDataSets(batch_set, csv_names)
% function batch_set = BatchSetRemoveDataSets(batch_set, csv_names)
% function to remove the specified csv's from the data set

% force cell
if ~iscell(csv_names)
    csv_names = {csv_names};
end
    
% get existing names
ds_names = cell(numel(batch_set.ds_headers), 1);
for i = 1:numel(ds_names)
    ds_names{i} = batch_set.ds_headers(i).file_name;
end

% remove sets that are in both
remove = ismember(ds_names, csv_names);

if any(remove)
    
    % remove them
    batch_set.ds_headers(remove) = [];  
    
    % and recreate
    batch_set = BatchSetFromDataSets(batch_set.ds_headers, batch_set.name);
    
end
