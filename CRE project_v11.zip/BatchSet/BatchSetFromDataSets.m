function batch_set = BatchSetFromDataSets(data_sets, name)
% function batch_set = BatchSetFromDataSets(data_sets, name)
% function to create a batch set from a vector of data_sets
% data_sets should have at least had the header fill by GetCSVHeader.m
% or be fully loaded by ImportCSV

% create it
batch_set = InitDataStruct();
batch_set.set_type = 'batch';
batch_set.ds_headers = data_sets;

% add the name
if (nargin >= 2) &&  (numel(name) > 0)
    batch_set.name = name;
else
    batch_set.name = 'Batch set';
end

% fill info
if (numel(batch_set.ds_headers) > 0)
    
    % fill common dimensions names and sampling frequency
    batch_set.fs = batch_set.ds_headers(1).fs;
    batch_set.num_points = batch_set.ds_headers(1).num_points;
    batch_set.dim_names = batch_set.ds_headers(1).dim_names;
    
    % now compare to the rest
    for i = 2:numel(batch_set.ds_headers)
        batch_set.fs = min(batch_set.fs, batch_set.ds_headers(i).fs);
        batch_set.num_points = min(batch_set.num_points, batch_set.ds_headers(i).num_points);
        batch_set.dim_names = intersect(batch_set.dim_names, batch_set.ds_headers(i).dim_names);
    end
    batch_set.dims = numel(batch_set.dim_names);
    
    % now also put any common properties into the batch set
    fnames = fieldnames(batch_set.ds_headers);
    
    % don't update these!
    noUpdate = {'ds_headers', 'set_type', 'file_ptr', 'dim_names', 'fs', 'num_points'};
    
    % and try
    for j = 1:numel(fnames)
        if ~any(strcmpi(fnames{j}, noUpdate))
            values = {batch_set.ds_headers(:).(fnames{j})};
            if all(cellfun(@(val)isequal(val, values{1}), values))
                batch_set.(fnames{j}) = values{1};
            end
        end
    end
    
    % store the "active" data_set (i.e. which one to view)
    batch_set = SetBatchActiveSet(batch_set, 1);
end
