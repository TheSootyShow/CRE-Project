function idx = GetActiveSetIndex(batch_set)
% function idx = GetActiveSetIndex(batch_set)
% gets thye index of the active set within the batch set
% the set that's active has the same filename as batch_set.file_name

if ~strcmpi(batch_set.set_type, 'batch')
    error('Input data set is not a batch set')
end

files = {batch_set.ds_headers(:).file_name};
idx = find(strcmpi(batch_set.file_name, files), 1, 'first');
if (numel(idx) == 0)
    error('GetActiveSetIndex: Unable to find the active set');
end