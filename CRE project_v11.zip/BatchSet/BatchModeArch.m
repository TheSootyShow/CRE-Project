function [batch_set, varargout] = BatchModeArch(fcn_handle, ds_get, ds_set, varargin)
% function [batch_set, output1, ... outputn] = BatchModeArch(fcn_handle, ds_get, ds_set, input1, ... inputn)
% This function is designed to repeatedly call gui functions that process
% individual data sets for each set in batch mode data
%
% Inputs:
%
% fcn_handle - the function to call.  It has the template:
%              [data_set, output1, ... outputn] = feval(fcn_handle, input1, ... inputn)
%              where the number of outputs must match the number of inputs
%              (i.e. inputs are updated with the outputs)
%
% ds_get     - function to get the data set from the inputs:
%              data_set = feval(ds_get, input1, ... inputn)
%            - if left empty, it defaults to data_set = input1.data_set
%
% ds_set     - function to update the inputs with the new data set:
%              [output1, ... outputn] = feval(ds_get, data_set, input1, ... inputn)
%            - if left empty, it defaults to input1.data_set = data_set
%
% Outputs:
%
% batch_set     - The batch set created from each individual data set result
%
% batch_set_in  - The original batch set (possible updated duwe to views)
%
% outputn       - Updated version of inputn


if (numel(ds_get) == 0)
    ds_get = @default_dsget;
end

if (numel(ds_set) == 0)
    ds_set = @default_dsset;
end

% record inputs
outputs = varargin;

% get the initial data set
batch_set_in = feval(ds_get, outputs{:});

% how many data sets?
n_ds = numel(batch_set_in.ds_headers);

% get the individual outputs and assemble them later
data_sets = repmat(InitDataStruct(), 1);

% show overall progress
wb = waitbar(0, sprintf('Processing: file 0/%i in the batch set', n_ds), 'name', 'Processing batch set');
set(findobj(wb,'type','patch'), 'edgecolor','b','facecolor','b')

try

    % and do each one
    for i = 1:n_ds
        
        waitbar((i-1)/n_ds, wb, sprintf('Processing: file %i/%i in the batch set', i, n_ds));
        
        % set the inputs with the data set
        [outputs{:}] = ds_set(batch_set_in.ds_headers(i), outputs{:});
        
        % and call the function
        [data_sets(i), outputs{:}] = fcn_handle(outputs{:});
        data_sets(i).data = [];  % don't store
        
        % update inputs
        batch_set_in.ds_headers(i) = ds_get(outputs{:});
        
    end

    close(wb);
    
catch ME
    close(wb);
    rethrow(ME);
end

% build a name base on the difference of the input and output data set names
name_in = batch_set_in.ds_headers(1).name;
name_out = data_sets(1).name;
diff = NameDiffs(name_in, name_out);

% and build the output set
batch_set = BatchSetFromDataSets(data_sets, [batch_set_in.name, diff]);

% ensure the outputs have the updated version of the input batch set
[outputs{:}] = ds_set(batch_set_in, outputs{:});

% and fill in the output
varargout = outputs;


function diff = NameDiffs(name_in, name_out)
% function diff = NameDiffs(name_in, name_out)
% find the differences in the names

minEls = min(numel(name_out),numel(name_in));

idxs = 0;
while (idxs < minEls) && (name_in(idxs+1) == name_out(idxs+1))
    idxs = idxs+1;
end

idxe = 0;
while (idxe < minEls) && (name_in(end-idxe) == name_out(end-idxe))
    idxe = idxe+1;
end

diff = name_out(idxs+1:end-idxe);




function data_set = default_dsget(varargin)
% function data_set = default_dsget(varargin)
% default way to get the data set

data_set = varargin{1}.data_set;

function varargout = default_dsset(data_set, varargin)
% function data_set = default_dssget(data_set, varargin)
% default way to get the data set

varargin{1}.data_set = data_set;
varargout = varargin;


