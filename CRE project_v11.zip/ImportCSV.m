function data_set = ImportCSV(csv_name, opts, status_func)
% function data_set = ImportCSV(csv_name)
% this function imports a csv file to create
% the data set used in this program

persistent last_dir

% ensure the header function are on the path
if (~isdeployed) && ~exist('GetCSVHeader.m', 'file')
    AddCREDirs();  % add all sub directories
end


% this allows for status bar updates to be included
% status_func should accept two inputs, the current number and the total
if (nargin < 3) || (numel(status_func) == 0)
    status_func = [];
end

if (nargin < 2) || (numel(opts) == 0)

    opts.view_type        = 2;        % fully process the file by default
    opts.max_header_lines = 500;      % headers should be larger than this (over allocate to judge dimensions)
    opts.max_lookup       = 1e5;      % the lookup table has this many entries at most
    opts.max_load_els     = 1562500;  % load the data in full if it has less than this many elements (~100mb)
    
end


% If no file was specified, prompt the user
if (nargin < 1) || (numel(csv_name) == 0)

	if (numel(last_dir) == 0) || (~ischar(last_dir))
		last_dir = getuserdir();
	end
    
    [csv_name, dir_name] = uigetfile('*.csv', 'Select a CSV file to import', last_dir);

    
    % successful
    if ischar(csv_name)
        last_dir = dir_name;
        csv_name = fullfile(dir_name, csv_name);
    else
        error('No file selected');
    end
elseif (numel(fileparts(csv_name)) == 0)  % add directory if its not there
    csv_name = fullfile(pwd, csv_name);
end

% Check the requested file exists
if ~exist(csv_name, 'file')
    error('The csv file: %s does not exist', csv_name);
end


% Initialise the output data set
data_set = InitDataStruct();

% open the file
data_set.file_name = csv_name;
data_set.file_ptr = fopen(csv_name, 'r');
if (data_set.file_ptr <= 0)
    error('Could not open file: %s', csv_name);
end
data_set.type     = 'ASCII';  % CSV's are ascii


try
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % get header data
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    data_set = GetCSVHeader(data_set, [], opts);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Extract a "block" of data for various uses
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % move to the end of the header
    fseek(data_set.file_ptr, data_set.hbytes, 'bof');
    
    test_lines = 500;  % estimate using the first this many data lines
    line_chars = zeros(test_lines, 1);
    
    % get the lines
    data = zeros(data_set.dims, test_lines);
    i = 0;
    while (i < test_lines) && ~feof(data_set.file_ptr)
        
        % next line
        i = i + 1;
        
        % the last file position
        last_pos = ftell(data_set.file_ptr);
        
        % grab data
        try
            data(:,i) = fscanf(data_set.file_ptr, data_set.ASCII_read, [data_set.dims, 1]);
            
            % how many chars was that?
            line_chars(i) = ftell(data_set.file_ptr) - last_pos;
            
        catch ME
            
            % if the error is because of end of file its fine
            if (feof(data_set.file_ptr))
                i = i - 1;  % back to last valid one
            else
                rethrow(ME);
            end
        end
        
        
        
    end
    if (i ~= test_lines)
        line_chars = line_chars(1:i);  % trim if the file ended
        data = data(:, 1:i);
    end
    
    % sanity check (NaNs happen now so removed)
%     if any(~isfinite(data(:)))
%         error('NaN values encountered in the data from file: %s\n', data_set.file_name);
%     end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % now look for the maximum number of decimal points used in the file
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (numel(data_set.ASCII_dec) == 0)
        dp = 0;
        data_sc = data;
        while ~all(data_sc == round(data_sc))
            dp = dp + 1;
            data_sc = (10.^dp) * data;
        end
        data_set.ASCII_dec = dp;
    end

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % How many points is this file expected to have?
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (numel(data_set.num_points) == 0)
        
            
        % average bytes per line is then
        av_line_bytes = mean(line_chars);
        
        % the total number of points is then expected to be
        file_data = dir(data_set.file_name);
        ex_points = ceil((file_data.bytes - data_set.hbytes)/av_line_bytes);
        if (var(line_chars) > 0)  % are they all exactly the same?
            ex_points = ceil(ex_points * 1.1);  % add a safety factor of 10%
        end
    else
        ex_points = data_set.num_points;  % it was in the header
    end
   
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Build a lookup table as we count the number of data points
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % just load all the data?
    load_all = false;
    if (opts.view_type == 2)
        load_all = (ex_points * data_set.dims) <= opts.max_load_els;
    end
    if (load_all) 
        data_set.data = NaN(ex_points, data_set.dims);
    end
    
    % design the lookup table based on the expected number of points
    data_set.lookgap = max(ceil(ex_points / (opts.max_lookup - 1)), 100);     % make the a minimum of 100 points apart
    data_set.lookup = NaN(1 + ceil(ex_points / data_set.lookgap), 1);
    
    % load the data in blocks 
    block_lines = data_set.lookgap;
    chunk_lines = min(data_set.lookgap, floor(opts.max_load_els / data_set.dims));  %ideally the same as blocklines
    
    % now actually count the total number of entries in the file
    % to build the lookup table
    num_points = 0;
    lookup_index = 0;
    fseek(data_set.file_ptr, data_set.hbytes, 'bof');  % rewind to the begining
    
    if (opts.view_type == 1)
        
        % shortcut for partial view
        data_set.num_points = ex_points;
        data_set.lookup(1) = ftell(data_set.file_ptr);
        data_set.view_type = 1;  % we have a partial view
        
    
    else
        while (~feof(data_set.file_ptr)) 
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            % add a lookup table entry
            %%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % add storage if needed
            if (lookup_index >= numel(data_set.lookup))
                data_set.lookup(end + 1000) = 0;  % add 1000 elements at a time
            end
            
            % and store the byte offset
            lookup_index = lookup_index + 1;
            data_set.lookup(lookup_index) = ftell(data_set.file_ptr);
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % process this block (potentially multiple "chunks")
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            c_line = 0;
            while (c_line < block_lines) && ~feof(data_set.file_ptr)
                
                if (load_all)
                    
                    % grab and parse the data
                    values = fscanf(data_set.file_ptr, data_set.ASCII_read, [data_set.dims, min(chunk_lines, block_lines - c_line)]);
                    
                    % how many loaded points
                    loaded = size(values,2);
                    
                    if (loaded > 0)  % could be the end of the file
                        
                        % validate it
                        if any(~isfinite(values(:)))
                            [r,c] = find(~isfinite(values(:)), 1, 'first');
                            error('Unable to process and / or interpret data as numeric at data point %i', num_points + c);
                        end
                        
                        % add storage if needed
                        if (num_points > size(data_set.data,1))
                            data_set.data(num_points + loaded + max(5*lookgap, 1e4), :) = NaN;  
                        end
                        
                        % and store
                        data_set.data(num_points+1:num_points+loaded, :) = values.';
                        
                    end
                    
                else
                    
                    % no need to parse data in this case
                    values = textscan(data_set.file_ptr, '%s', min(chunk_lines, block_lines - c_line), 'delimiter', {'\n', '\r'}, 'MultipleDelimsAsOne', true);
                    loaded = numel(values{1});
                    
                end
                
                % add to the number of points
                num_points = num_points + loaded;
                
                % update where we are in the block
                c_line = c_line + loaded;
                
                % update status bar
                if (numel(status_func))
                    feval(status_func, num_points, ex_points);
                end
            end
        end
        
        % check the size matched the expected
        if (numel(data_set.num_points) == 0)
            data_set.num_points = num_points;
        elseif (data_set.num_points ~= num_points)
            error('Unexpected number of points infile: %s', csv_name);
        end
        
        %%%%%%%%%%%%%%%%%%%%
        % now trim back
        %%%%%%%%%%%%%%%%%%%%
        
        if (numel(data_set.lookup) > lookup_index)
            data_set.lookup(lookup_index+1:end) = [];
        end
        if (load_all) && (size(data_set.data,1) > data_set.num_points)
            data_set.data(data_set.num_points+1:end, :) = [];
        end
        data_set.view_type = 2;  % we have a full view
    end
    
    
    
    % fprintf('actual points = %i\n', data_set.num_points);
        
    % finally close the data pointer
    fclose(data_set.file_ptr);
    data_set.file_ptr = -1;

catch ME
    fclose(data_set.file_ptr);
    if isdeployed()
        error('An error occurred reading %s -> %s', csv_name, ME.message);
    else
        rethrow(ME);
    end
    data_set.file_ptr = -1;
end








    




    
    










