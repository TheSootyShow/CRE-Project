function [str2time, time2str] = BuildTimeFunctions(tstamp, hhmmss, index_time, index_str, relative_time, relative_str, fs)
% function [str2time, time2str] = BuildTimeFunctions(tstamp, hhmmss, index_time, index_str, relative_time, relative_str, fs)
% this function returns function handles for converting times bewteen
% numeric and string representations
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% tstamp        - the time stamp as a date vector for the start of the data
%                 set (see datevec.m)
%
% hhmmss        = 0  - time strings have the format SS (just seconds)
%               = 1  - time strings have the format HH:MM:SS (seconds will be a decimal)
%               = 2  - time strings have the format HH:MM:SS:MS
%                      N.B. when outputting in seconds, the outputs of the returned
%                      function handles are always relative to tstamp
%                      N.B. hhmmss is only used if index_str = false
%
% index_time    - numerics times are indexs into the data set rather than nomral
%                 times.  Indexs's are always relative
%
% index_str     - strings are representations of indexs into the data set rather than
%                 times.  Indexs's are always relative
%
% relative_time - if true, the output of str2time is the time ellapsed since tstamp.  
%               - if false, the output of str2time is the time ellapsed since 0 A.D.
%
% relative_str  - if true, the output of time2str is the time ellapsed since tstamp.  
%               - if false, the output of time2str is the time ellapsed since 0 A.D.
%
% fs            - data set sampling frequency (only used if index_form =
%                 true)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% str2time      - handle to a function that takes a time / index string as an input
%                 and returns a numeric time / index
%               - If relative_time is selected:
%                 1) the input tstamp is subtracted from the input string if the year
%                 is greater than 0 A.D.
%                 2) The output is either an index or a time in seconds 
%               - If relative_time is not selected:
%                 1) the input tstamp is only added if the time string has year
%                 equal to 0 A.D.
%                 2) the output time is a 6 element date vector 
%
% time2str      - handle to a function that takes a numeric time / index as an input
%                 and returns a string representation of the time
%               - if the input time / index is not a date vector, it is
%                 considered to be relative to tstamp
%               - if the input is a date vector, it is considered to be an absolute time
%                 unless the element indicating year is 0
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Output functions handles are not vectorized



if (~index_time) && (~index_str)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % No indexs in either numerics or strings
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % function to convert numeric representations of times to strings
    time2str = @(time)ConvertTime(time, tstamp, hhmmss, ~relative_str);
    
    % function to convert strings to numeric representations
    str2time = @(time_str)ConvertTime(time_str, tstamp, hhmmss, ~relative_time);
    
else
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Case 2: indexs in either the numeric or the string
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if (index_str)
        
        % convert an index str to either a time or an index
        str2time = @(index_str)IndexStrToTime(index_str, tstamp, fs, relative_time, index_time);
        
        % convert a time / index to an index string
        time2str = @(time)TimeToIndexStr(time, tstamp, fs, index_time);
    
    elseif (index_time)
        
        % convert a time string to an index
        str2time = @(time_str)TimeStrToIndex(time_str, tstamp, fs); 
        
        % convert an index to a time string
        time2str = @(index)IndexToTimeString(index, tstamp, fs, relative_str, hhmmss);
    end
end


function time_str = IndexToTimeString(index, tstamp, fs, relative, hhmmss)
% function time_str = IndexToTimeString(index, tstamp, fs, relative, hhmmss)
% function to convert an index to a time string in the desired format

% time of the index in seconds
time_s = (index-1)/fs;

% and convert
time_str = ConvertTime(time_s, tstamp, hhmmss, ~relative);




function index = TimeStrToIndex(time_str, tstamp, fs)
% function index = TimeStrToIndex(time_str, tstamp, fs)
% function convert a time str to an index

% convert the time string to a time in seconds since the tstamp
time_s = ConvertTime(time_str, tstamp, 0, false);

% and convert to an index
index = (time_s * fs + 1);


function index_str = TimeToIndexStr(time, tstamp, fs, index_time)
% function index_str = TimeToIndexStr(time, tstamp, fs, index_time)
% converts a numeric time / index to an index string

if (index_time)
    
    index_str = num2str(time);  % easy case
    return;
    
% what form is the input time?    
elseif (numel(time) == 6)  % its a date vector
    
    % we always want relative times, so it time has the year set subtract
    % tstamp
    if (time(1) > 0)
        time_s = etime(time, tstamp);  % ellapsed time in seconds since the file's start
    else
        time_s = etime(time, zeros(1,6));
    end
    
else
    
    % time is already in seconds (presumably relative to the tstamp)
    time_s = time;
    
end

% convert the time in seconds to an index
index = 1 + round(time_s * fs);

% and the index to a string
index_str = num2str(index);


function time = IndexStrToTime(index_str, tstamp, fs, relative, index_time)
% function time = IndexStrToTime(time, tstamp, fs, relative)
% converts an index string to a numeric time / index

% turn the index string into an index
index = str2double(index_str);

if (index_time)

    time = indexs;

else

    % convert this to a time in seconds realtive to the recording's start
    time = (index-1)/fs;

    % add this to the date vector if we want an abolsute time
    if (~relative)
        time = AddTimeToDateVec(tstamp, time);
    end
    
end

    




