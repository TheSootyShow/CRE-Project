function [mapped_timeRange, success, warning_list] = MapTimeRangeToDataSet(timeRange, data_set)
% function [mapped_timeRange, success, warning_list] = MapTimeRangeToDataSet(timeRange, data_set)
% this function maps the input dimInfo structure
%(see InitTimeRangeStruct) to a different data set, data_set 
% by time of day

% Intialise the output warning list
warning_list = '';
success = true;  % and whether this was sucessful

% get the duration of the new data set
duration = data_set.num_points / data_set.fs;

% Initialise the output structure
mapped_timeRange = InitTimeRangeStruct(data_set);

% copy viewing options
mapped_timeRange.full = timeRange.full || strcmpi(data_set.set_type, 'batch');  % timing options and batch mode are incompatible
mapped_timeRange.is_relative = timeRange.is_relative;
mapped_timeRange.is_hhmmss = timeRange.is_hhmmss;
mapped_timeRange.is_time = timeRange.is_time;
mapped_timeRange.match_daytime = timeRange.match_daytime;

% if we're using the full timing info, we can exit here
if (mapped_timeRange.full)
    return;
end

% now update start and end times
if (timeRange.is_relative)
    
    % create a version in seconds to check durations
    start_time = etime(timeRange.tstamp{1}, timeRange.ds_stamp{1});
    end_time = etime(timeRange.tstamp{2}, timeRange.ds_stamp{2});
    
    % check the start time isn't longer than the duration
    if (start_time > duration)
        warning_list = sprintf('%sError: Analaysis start at %02.f seconds into the data set, but the data set is only %0.2f seconds long (relative timing was selected)\n', warning_list, start_time, duration);
        success = false;
        return;
    end
    
    % if its shorter let the user know
    if (end_time > duration)
        warning_list = sprintf('%sWarning: Analysis time has been reduced from %0.2f to %0.2f\n', warning_list, end_time - start_time, duration - start_time);
        end_time = duration;
    end
    
    % and update the time range
    mapped_timeRange.tstamp{1} = AddTimeToDateVec(mapped_timeRange.tstamp{1}, start_time);
    mapped_timeRange.tstamp{2} = AddTimeToDateVec(mapped_timeRange.tstamp{1}, end_time);

else
    
    % do we match time and date, or just time?
    if (numel(timeRange.match_daytime) == 0) || force_time_prompt
        
        % prompt the user
        response = questdlg('Match date and time, time only, or use use all the data from the new data set?', 'Time matching options', 'Date and Time', 'Time Only', 'Use all data', 'Use all data'); 
        if strcmpi(response, 'Time Only')
            timeRange.match_daytime = 1;
        elseif strcmpi(response, 'Date and Time')
            timeRange.match_daytime = 0;
        else
            mapped_timeRange.full = true;
            return;
        end
    end
    
    % get rid of the dates for now
    data_tstamp = data_set.tstamp;
    if (timeRange.match_daytime > 0)
        
        % dates to subtract from both
        input_subtract_date  = [timeRange.tstamp{1}(1:3), zeros(1,3)];
        output_subtract_date  = [data_tstamp(1:3), zeros(1,3)];
        
        % remove dates from all time stamps
        for i = 1:2
            timeRange.tstamp{i} = AddDateVectors(timeRange.tstamp{i}, -input_subtract_date);  % make it relative to the start of the day
            mapped_timeRange.tstamp{i} = AddDateVectors(mapped_timeRange.tstamp{i}, -output_subtract_date);  % make it relative to the start of the day
        end
        data_tstamp(1:3) = 0;
        n_days = timeRange.tstamp{2}(3);         % how many days in the analysis period?
        ds_days = floor(duration / (24*60*60));   % how many days is the data set?
        
        % use as many days as we have
        if (n_days > ds_days)
            n_days = ds_days;
            timeRange.tstamp{2}(3) = n_days;
        end
    end
    
    % is there overlap bewteen the desired time range and the data set?
    dxs = etime(timeRange.tstamp{1}, data_tstamp);
    dxe = etime(timeRange.tstamp{2}, data_tstamp);
    in_range(1) = (dxs >= 0) && (dxs <= duration);
    in_range(2) = (dxe >= 0) && (dxe <= duration);
    
    % simple case
    if all(in_range)
        
        % easy case - everything is in range
        mapped_timeRange.tstamp = timeRange.tstamp;
        
    elseif any(in_range) || ((dxs < 0) && (dxe > duration))
        
        % update
        if (~in_range(1))
            % report the change
            str1 = ConvertTime(timeRange.tstamp{1}, data_tstamp, 1, ~timeRange.match_daytime);
            str2 = ConvertTime(mapped_timeRange.tstamp{1}, data_tstamp, 1, ~timeRange.match_daytime);
            warning_list = sprintf('%sWarning: Analysis time start has been increased from %s to %s\n', warning_list, str1, str2);
        else
            % use it
            mapped_timeRange.tstamp{1} = timeRange.tstamp{1};
        end
        
        % update
        if (~in_range(2))
            % report the change
            str1 = ConvertTime(timeRange.tstamp{2}, data_tstamp, 1, ~timeRange.match_daytime);
            str2 = ConvertTime(mapped_timeRange.tstamp{2}, data_tstamp, 1, ~timeRange.match_daytime);
            warning_list = sprintf('%sWarning: Analysis time end has been reduced from %s to %s\n', warning_list, str1, str2);
        else
            % use it
            mapped_timeRange.tstamp{2} = timeRange.tstamp{2};
        end
            
        
    else
        % can't match it
        success = false;
        str1 = ConvertTime(timeRange.tstamp{1}, data_tstamp, 1, ~timeRange.match_daytime);
        str2 = ConvertTime(timeRange.tstamp{2}, data_tstamp, 1, ~timeRange.match_daytime);
        if (timeRange.match_daytime)
            warning_list = sprintf('%sError: Time of day %s to %s not present in data set: %s\n', warning_list, str1, str2, data_set.name);
        else
            warning_list = sprintf('%sError: Date & Time range %s to %s not present in data set: %s\n', warning_list, str1, str2, data_set.name);
        end
    end
        
    % restore dates to the time stamps
    if (timeRange.match_daytime > 0)
        mapped_timeRange.tstamp{1} =  AddDateVectors(mapped_timeRange.tstamp{1}, output_subtract_date);
        mapped_timeRange.tstamp{2} =  AddDateVectors(mapped_timeRange.tstamp{2}, output_subtract_date);
    end
end
        
    
    
