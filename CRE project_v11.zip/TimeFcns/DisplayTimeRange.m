function displayStrs = DisplayTimeRange(timeRange, fs)
% function displayStrs = DisplayTimeRange(timeRange, fs)
% function to get the display time range from the time range structure

% convert the start time
if (timeRange.is_time)
    
    % the start time
    displayStrs{1} = ConvertTime(timeRange.tstamp{1}, timeRange.ds_stamp{1},  timeRange.is_hhmmss, ~timeRange.is_relative);
    
    % the end time
    displayStrs{2} = ConvertTime(timeRange.tstamp{2}, timeRange.ds_stamp{1},  timeRange.is_hhmmss, ~timeRange.is_relative);
    
else
    
    % index format, get the time in seconds first
    times(1) = etime(timeRange.tstamp{1}, timeRange.ds_stamp{1});
    times(2) = etime(timeRange.tstamp{2}, timeRange.ds_stamp{1});
    
    % and convert to indexs
    indexs = round(times / fs) + 1;
    
    % and convert to strings
    displayStrs = {num2str(indexs(1)), num2str(indexs(2))};
    
end