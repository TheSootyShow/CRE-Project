function time = AmbigTimeStr(time_str, vector)
% function time = AmbigTimeStr(time_str, vector)
% this function is designed to examine an ambiguous string 
% representing a time and convert it to a MATLAB timestamp (vector = false)
% or a date vector (vector = true)
% see datenum.m and datevec.m

% hope the string is seperated by spaces
[time_cell, other] = regexp(time_str, '\s+', 'split', 'match'); %#ok<*NASGU>

% output form
if (vector)
    time = zeros(1,6);
else
    time = 0;
end

% now process each one
for i = 1:numel(time_cell)
    
    % this part will hopefully contain time of day
    if any(time_cell{i} == ':') 
        
        % how many colons?
        n_colons = sum(time_cell{i} == ':');
        
        if (n_colons == 0)
            
            % the final result goes in here
            add_time = zeros(1,6);
            
            % assume seconds in this case
            add_time(end) = str2double(time_cell{i});
            
        else
            
            % break it up because datevec will ignore fractional seconds
            [tokens, token_char] = regexp(time_cell{i}, ':', 'split', 'match');
            
            % convert each token to numeric
            values = zeros(1, numel(tokens));
            for j = 1:numel(tokens)
                values(j) = str2double(tokens{j});
            end
            
            % assume the final : is for milliseconds
            if (numel(values) == 4)
                values(3) = values(3) + values(4) * 1e-3;
                values = values(1:3);
            end
            
            % the final result goes in here
            add_time = [0,0,0,values];
            
        end
        
        % sanity check
        if any(isnan(add_time)) || (numel(add_time) ~= 6)
            error('Unsure how to interpret time string: %s', time_cell{i});
        end
        
        % what type of output?
        if (~vector)

            % and convert
            add_time = datenum(add_time);
            
        end
        
    % this part will hopefully contain the date
    elseif any(time_cell{i} == '-') || any(time_cell{i} == '/') || any(time_cell{i} == '\')  % assume this is a date
        
        % tokenize the date
        [tokens, token_char] = regexp(time_cell{i}, '[\\\/-]', 'split', 'match');
        
        if (numel(tokens) ~= 3)
            error('Unsure how to pass the time string: %s', time_str);
        end
        
        % try to work out what is what
        [is_day, is_month, is_year] = deal(false(1, numel(tokens)));
        
        % token length
        token_length = cellfun(@numel, tokens);
        
        % and their values
        values = cellfun(@str2double, tokens);
        
        % if this failed for ones it probably because month was a string
        % try to convert it
        failed_inds = find(isnan(values));
        if (numel(failed_inds) == 1) && (token_length(failed_inds) >= 3)
            values(failed_inds) = MonthFromStr(tokens{failed_inds});
            is_month(failed_inds) = true;  % the only thing it could be
        end
        
        % these indicate its the year
        is_year = ((token_length == 4) | (values > 31)) & (~is_month);
        
        % figure out the year
        if (sum(is_year) == 0)
            is_year(3-2*is_month(3)) = true;  % assume the last unless its the month, then assume the first
        elseif (sum(is_year) > 1)
            error('Unsure how to pass the time string: %s', time_str);
        end
        
        % figure out the day
        if (sum(is_year + is_month) == 2)
            is_day(~is_year & ~is_month) = true;
        else
            is_day = (values > 12) & ~is_year;
        end
        if (sum(is_day) == 0)
            % assume its at the other end to the year
            is_day(3-2*is_year(3)) = true;
        elseif (sum(is_day) > 1)
            error('Unsure how to pass the time string: %s', time_str);
        end
        
        % the month is the left overs
        is_month = ~is_year & ~is_day;
        
        % assemble it into a date vector
        date_vec = zeros(1,6);
        date_vec(3) = values(is_day);
        date_vec(2) = values(is_month);
        date_vec(1) = values(is_year);
        
        % and add to the output
        if (~vector)
            add_time = datenum(date_vec);
        else
            add_time = date_vec;
        end
    elseif any(strcmpi(time_cell{i}, {'am', 'pm'}))
        
        % add 12 hours if its the PM string
        add_time = zeros(1,6);
        if strcmpi(time_cell{i}, 'pm')
            add_time(4) = 12;
        end
        
        if (~vector)
            add_time = datenum(add_time);
        end
    else
        error('Unsure how to pass the time string: %s', time_str);
    end
    
    % check we've processed the token
    if any(isnan(add_time)) || any(add_time < 0)
         error('Unsure how to pass the time string: %s', time_str);
    end
    
    % now add the time to what we've already found
    if (~vector)
        time = time + add_time;  % easy case
    else
        time = AddDateVectors(time, add_time);
    end
end


function month = MonthFromStr(str)
% function month = MonthFromStr(str)
% turn a string into a month

months = {'January';
          'Feburary'
          'March'
          'April'
          'May'
          'June'
          'July'
          'August'
          'September'
          'October'
          'Novemeber'
          'December'};

% which match      
match = false(size(months));
for i = 1:numel(months)
    if (numel(str) <= numel(months{i}))
        match(i) = strncmpi(str, months{i}, numel(str));
    end
end

if (sum(match) == 1)
    month = find(match, 1, 'first');
else
    month = NaN;
end







