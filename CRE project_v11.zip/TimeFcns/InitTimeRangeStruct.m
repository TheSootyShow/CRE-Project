function timeRange = InitTimeRangeStruct(data_set)
% function timeRange = InitTimeRangeStruct()
% function timeRange = InitTimeRangeStruct(data_set)
% function to initialise the sructure used in the project to record details
% of the time range to use
%
% timeRange = struct( 'full',          true,                ...   % use the entire range   
%                     'tstamp',        {cell(1,2)},         ...   % time stamp for the start and end (always 2 x absolute date vectors for start and end)
%                     'ds_stamp',      {cell(1,2)},         ...   % keep track of what relative time should be indexed against
%                     'fs',            [],                  ...   % sampling freq of the data set (currently unused)
%                     'relative',      [],                  ...   % how to display the time range - abosule time vs relative time
%                     'is_hhmmss',     [],                  ...   % how to display the range (seconds or hh:mm:ss)
%                     'is_time',       []                   ...   % how to display the range (time or seconds)
%                     'match_daytime'  [])                     



timeRange = struct( 'full',          true,                ...   % use the entire range   
                    'tstamp',        {cell(1,2)},         ...   % time stamp for the start and end (always 2 x absolute date vectors for start and end)
                    'ds_stamp',      {cell(1,2)},         ...   % data set start and end times
                    'fs',            [],                  ...   % sampling freq of the data set (currently unused)
                    'is_relative',   [],                  ...   % how to display the time range - abosule time vs relative time
                    'is_hhmmss',     [],                  ...   % how to display the range (seconds or hh:mm:ss)
                    'is_time',       [],                  ...   % how to display the range (time or seconds)
                    'match_daytime', []);                 ...   % when matching analysis times with other data sets, only match HH:MM:SS and not the date

% Fill with defaults
if (nargin >= 1)
    
    % get the duration of the new data set
    duration = (data_set.num_points) / data_set.fs;
    
    % and fill
    timeRange.full = true;  % default to entire range
    timeRange.tstamp{1} = data_set.tstamp;
    timeRange.tstamp{2} = AddTimeToDateVec(data_set.tstamp, duration);
    timeRange.ds_stamp = data_set.tstamp;
    timeRange.fs = data_set.fs;
    
    % default viewing options
    timeRange.is_relative = false;
    timeRange.is_hhmmss = true;
    timeRange.is_time = true;

end
