function date_vec = AddTimeToDateVec(date_vec, time)
% function date_vec = AddTimeToDateVec(date_vec, time)
% this function adds a time in seconds to a date vector

if (time == 0) && (date_vec(end) + time < 60) && (date_vec(end) + time >= 0)
    % easy way, doesn't wrap into minutes
    date_vec(end) = date_vec(end) + time;
else
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % to maintain accuracy, handle fractional seconds ourselves
    % (dont want fractional seconds added to days since 0 AD directly)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % add any fractional seconds from the data vector to the time to add
    frac_secs = rem(date_vec(end), 1);
    date_vec(end) = fix(date_vec(end));  % remove any decimal
    time = time + frac_secs;
    
    % now get the fractional seconds from the time to add
    frac_secs = rem(time, 1);        % use fractional seconds not fractional milliseconds to maintain accuracy
    time = fix(time);              
    
    % ensure we are always adding the fractional milliseconds (can't wrap
    % if we are adding)
    if (frac_secs < 0)
        frac_secs = 1 - frac_secs;
        time = time - 1;
    end
    
    
    % Use the matlab function to add the time in seconds (can wrap into minutes)
    date_vec = datevec(addtodate(datenum(date_vec), time, 'second'));  
    date_vec(end) = round(date_vec(end));  % we removed all fractional seconds so any non-integers are the results of rounding
    
    % and add the fractional seconds ourselves (can't wrap)
    date_vec(end) = date_vec(end) + frac_secs;
    
end