function samps = SamplesFromTimeRange(timeStruct)
% function samps = SamplesFromtTimeRange(timeStruct)
% function to get the number of samples in a given time range
% time range is the structure defined in InitTimeRangeStruct.m

% ellapsed time
ellTime = etime(timeStruct.tstamp{2}, timeStruct.tstamp{1});
samps = floor(ellTime * timeStruct.fs);