function binInfo = InitBinInfoStruct(data_set)
% function binInfo = InitBinInfoStruct()
% function binInfo = InitBinInfoStruct(data_set)
% function to intialise the data bin information structure

% create a sub structure for the bin info
binInfo = struct('use_bins',     [], ...              % bin the data
                 'bin_duration', [], ...              % default to 1s bins
                 'time_align',   []);                 % timestamp at the center of the bin 'c' by default (alternatives are 's' and 'e' for start and end)


% Fill defaults             
if (nargin == 1)
    binInfo.use_bins = true;                              % bin the data
    binInfo.bin_duration = 1;
    binInfo.time_align = 'c';
end

