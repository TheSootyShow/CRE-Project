function handles = UpdateTimePaneValues(handles)
% function handles = UpdateTimePaneValues(handles)
% function to update the string discriptions of time based on the new way
% of expressing it.  This only looks at what's in handles.timeInfo (doesn't
% check selections)

% Build function to convert from string to numerics and vice versa
[handles.timeInfo.TimeFcn, handles.timeInfo.TimeStrFcn] = BuildTimeFunctions(handles.timeInfo.ds_stamp{1}, handles.timeInfo.is_hhmmss, false, ~handles.timeInfo.is_time, false, ...
                                                                             handles.timeInfo.is_relative, handles.timeInfo.fs);
% fill in the start time
startStr = feval(handles.timeInfo.TimeStrFcn, handles.timeInfo.tstamp{1});
set(handles.ebStartTime, 'string', GetTimeStr(startStr, 'time'));
set(handles.ebStartDate, 'string', GetTimeStr(startStr, 'date'));

% fill in the end time
endStr = feval(handles.timeInfo.TimeStrFcn, handles.timeInfo.tstamp{2});
set(handles.ebEndTime, 'string', GetTimeStr(endStr, 'time'));
set(handles.ebEndDate, 'string', GetTimeStr(endStr, 'date'));

% fill in the data set start
startDs = feval(handles.timeInfo.TimeStrFcn, handles.timeInfo.ds_stamp{1});
set(handles.txtStartTime, 'string', sprintf('(Begins at: %s)', GetTimeStr(startDs, 'time')));
set(handles.txtStartDate, 'string', sprintf('(Begins at: %s)', GetTimeStr(startDs, 'date')));

% fill in the data set end
endDs = feval(handles.timeInfo.TimeStrFcn, handles.timeInfo.ds_stamp{2});
set(handles.txtEndTime, 'string', sprintf('(Ends at: %s)', GetTimeStr(endDs, 'time')));
set(handles.txtEndDate, 'string', sprintf('(Ends at: %s)', GetTimeStr(endDs, 'date')));

if (handles.data_set.view_type == 2)
    approx_str = '';
else
    approx_str = 'approx';
end

% tell the user the total duration
if (handles.timeInfo.is_time)
    duration = handles.data_set.num_points / handles.data_set.fs;
    [dur_str, format] = ConvertTime(duration, [],handles.timeInfo.is_hhmmss, false);
    set(handles.txtDuration, 'string', sprintf('Duration: %s %s (%s) ',  dur_str, approx_str, format));
else
    set(handles.txtDuration, 'string', sprintf('Duration: %i %s (samples)  ', handles.data_set.num_points, approx_str));
end


% disable partial time boxes if they aren't set
isBatch = strcmpi(handles.data_set.set_type, 'batch');
partObjects = findobj(handles.uiRangePane, 'type', 'uicontrol');
partObjects(ismember(partObjects, [handles.rbAllTime, handles.rbPartTime])) = [];  % dont enable / disable these
if (handles.timeInfo.full) || isBatch
    
    % basic setup
    set(handles.rbAllTime, 'value', 1);
    set(handles.rbPartTime, 'value', 0);
    set(partObjects, 'enable', 'off');
    
    % don't allow partial times to be selected
    if (strcmpi(handles.data_set.set_type, 'batch'))
        handles.timeInfo.full = true;  % ensure
        set(handles.rbPartTime, 'enable', 'off');
        set([handles.rbAllTime, handles.rbPartTime], 'tooltipstring', 'Partial times are not allowed in batch data sets');
    else
        set(handles.rbPartTime, 'enable', 'on');
        set([handles.rbAllTime, handles.rbPartTime], 'tooltipstring', '');
    end
    
else
    set(handles.rbAllTime, 'value', 0);
    set(handles.rbPartTime, 'value', 1);
    set([handles.rbAllTime, handles.rbPartTime], 'tooltipstring', '');
    set(partObjects, 'enable', 'on');

    % disable the date boxes if they aren't used
    if (handles.timeInfo.is_relative) || (~handles.timeInfo.is_time)
        set([handles.ebStartDate, handles.ebEndDate, handles.pbStartDate, handles.pbEndDate], 'enable', 'off');
    else
        set([handles.ebStartDate, handles.ebEndDate, handles.pbStartDate, handles.pbEndDate], 'enable', 'on');
    end
    
    % update the time radio button to reflect the format
    if (handles.timeInfo.is_time)
        
        % enable time format options
        set(handles.rbHHMMSS, 'enable', 'on');
        set(handles.rbRelTime, 'enable', 'on');
        
        [tmp, handles.dateFormat] = handles.timeInfo.TimeStrFcn(0);
        set(handles.rbTimes, 'string', sprintf('Times (%s)', handles.dateFormat));
    else
        % disable time format options
        set(handles.rbHHMMSS, 'enable', 'off');
        set(handles.rbRelTime, 'enable', 'off');
    end
end
