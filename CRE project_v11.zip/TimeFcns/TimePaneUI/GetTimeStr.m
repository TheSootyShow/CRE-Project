function type_str = GetTimeStr(time_str, type)
% function type_str = GetTimeStr(time_str, type)
% funciton to retrieve either the date or time from a string
% if the relevant part of the string is not present, N/A
% is returned.
% N.B. 'time' will also work for indexes

if strcmpi(type, 'time')
    % a time?
    type_str = regexp(time_str, '\S+:\S+:\S+', 'match', 'once');
    if (numel(type_str) == 0)
        % an index?
        type_str = regexp(time_str, '(?<=(^|\s))[\d[\.\d]*]+(?=($|\s))', 'match', 'once');
    end
    
elseif strcmpi(type, 'date')
    type_str = regexp(time_str, '\S+-\S+-\S+', 'match', 'once');
end

if (numel(type_str) == 0)
    type_str = 'N/A';
end