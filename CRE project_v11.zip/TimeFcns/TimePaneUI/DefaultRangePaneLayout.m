function [hCell,  hGap, vGap, sizes] = DefaultRangePaneLayout(handles, smallGap, normGap, largeGap)
% function [hCell, h_gap, v_gap, sizes] = DefaultRangePaneLayout(handles, smallGap, normGap, largeGap)
% This function set up the default layout of the time range panels to use
% in guis (see RangeTemplate.fig).  All GUI handles should have the same name
% as in this template
%
% The output is compatible with ResizePaneFromGrid.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Build spacing constants if they aren't supplied
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% turn constants into units in pixels
ppi = get(0, 'ScreenPixelsPerInch');                     % pixels per inch
ppcm = ppi / 2.54;                                       % pixels per centimeter
indent = .5 * ppcm;

if (nargin < 2)

    % build default gaps
   [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start by setting up the start and end time 
% ranges
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hStart = {handles.ebStartTime, handles.ebStartTime;    ...
          handles.txtStartTime, handles.txtStartTime; ...
          handles.ebStartDate, handles.pbStartDate;   ...
          handles.txtStartDate,  handles.txtStartDate};
      
hEnd =  {handles.ebEndTime, handles.ebEndTime;      ...
          handles.txtEndTime,  handles.txtEndTime;  ...
          handles.ebEndDate, handles.pbEndDate; ...
          handles.txtEndDate,  handles.txtEndDate};
      
% build a vertical spacing grid       
vGapTimes = repmat(normGap, size(hStart,1)-1, size(hStart,2));
vGapTimes([1,3], :) = smallGap;                   % use a small gap between the text for limits and the edit boxes they are associated with

% build horizontal spacing 
hGapTimes = repmat(normGap, size(hStart,1), size(hStart,2) - 1);

% get component sizes
timeSizes = PaneSizesFromGrid(hStart);  % use the same sizes for both


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now set up the interpretation grid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hInterp = {    handles.rbIndexs,        handles.rbIndexs;
               handles.rbTimes,         handles.rbTimes;
               sprintf('h=%g', indent), handles.rbHHMMSS;
               sprintf('h=%g', indent), handles.rbRelTime;
               handles.txtDuration,     handles.txtDuration};

% set up gaps
vGapInterp = repmat(normGap, size(hInterp,1)-1, size(hInterp,2));
vGapInterp(2:3, :) = smallGap;  % smaller gaps between the time formatting options                        

hGapInterp = repmat(0, size(hInterp,1), size(hInterp,2) - 1);

% get component sizes
interpSizes = PaneSizesFromGrid(hInterp);  % use the same sizes for both


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assemble it all
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hCell = {handles.rbAllTime, 'l', 'l'; ...
         handles.rbPartTime,'l', 'l'; ...
         sprintf('h=%g', indent), hStart, hEnd; 
         sprintf('h=%g', indent), hInterp, 'l'};

hGap = {[], [], [];
        [], [], [];
        [], hGapTimes, hGapTimes; 
        [], hGapInterp, []};

vGap = {[], [], [];
        [], [], [];
        [], vGapTimes, vGapTimes; 
        [], vGapInterp, []};    

sizes = {[], [], [];
         [], [], [];
         [], timeSizes, timeSizes; 
         [], interpSizes, []};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If there are no outputs, resize it
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargout == 0)
    ResizeFigFromPanes(hCell, hGap, vGap, sizes, false);
end






           
           
           
           







                                  