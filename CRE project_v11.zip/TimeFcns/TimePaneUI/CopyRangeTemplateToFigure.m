function handles = CopyRangeTemplateToFigure(hDest, handles)
% function destHandles = CopyRangeTemplateToFigure(hDest, destHandles)
% function to copy the updated version of the time range panel onto an
% existing gui

% load the range template figure
figDir = fileparts(mfilename('fullpath'));
figName = fullfile(figDir, 'RangeTemplate.fig');
hSrc = hgload(figName);

% ensure callbacks are correct
srcControls = findobj(hSrc, 'type', 'uiControl');
srcMenus = findobj(hSrc, 'type', 'uiMenu');
set([srcControls(:); srcMenus(:)], 'callback', @(hObject, event_data)TimePaneCallbacks(hObject, event_data, guidata(hObject)));
set(srcControls(:), 'CreateFcn', @(hObject, event_data)Default_CreateFcn(hObject, event_data, guidata(hObject)));

srcRangePane = findobj(hSrc, 'tag', 'uiRangePane');

% remove all the pre-existing things from the uiRangePane panel
if ~isfield(handles, 'uiRangePane')
    error('The input figure does not have a range pane panel');
end

% get the parent of the pane to replace
hParent = get(handles.uiRangePane, 'parent');

% find all children of the range pane panel that have tags
hChildren = findall(allchild(handles.uiRangePane));
rmTags = get(hChildren, 'tag');
rmTags = rmTags(cellfun(@(x)(numel(x) > 0), rmTags));

% does it have an export time column member?
if ~any(strcmpi(rmTags, 'cbTimeCol'));
    delete(findobj(srcRangePane, 'tag', 'cbTimeCol'));
end

% remove those tags and delete them
handles = rmfield(handles, rmTags);

% now delete the old pane
delete(handles.uiRangePane);

% now copy on the new range pane
handles.uiRangePane = copyobj(srcRangePane, hParent);

% make sure the edit boxes know their keypress functions
ebEdits = findobj(handles.uiRangePane, 'style', 'edit');
set(ebEdits, 'KeyPressFcn', @(hObject,eventdata)Default_KeyPressFcn(hObject,eventdata,guidata(hObject)));

% and add all tags to the handles
hChildren = findall(handles.uiRangePane);
addTags = get(hChildren, 'tag');
hasTag = cellfun(@(x)(numel(x) > 0), addTags);
addTags = addTags(hasTag);
hChildren = hChildren(hasTag);
for i = 1:numel(addTags)
    handles.(addTags{i}) = hChildren(i);
end
delete(hSrc);







