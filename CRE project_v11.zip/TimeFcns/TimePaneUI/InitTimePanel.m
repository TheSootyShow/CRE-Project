function handles = InitTimePanel(handles, data_set, is_time, is_hhmmss, is_relative)
% function handles = InitTimePanel(handles, data_set, is_time, is_hhmmss, is_relative)
% function handles = InitTimePanel(handles, data_set, timeInfo)
% the function initialises the default range pane with the given input settings
% settings are stored in handles.timeInfo on output.  The structure of this
% is given in InitTimeRangeStruct.m, but this version also has fields for time
% conversion function and export time
% the time stamp in handles.timeInfo is always an absolute time

% add output to handles
handles.timeInfo = InitTimeRangeStruct();

% Was this a structure input?
if isstruct(is_time)

    handles.timeInfo = is_time;  % a structure input

else
    
    % assume this
    handles.timeInfo.full = true;
    
    % fill in start and end
    handles.timeInfo.full = true;
    handles.timeInfo.tstamp{1} = data_set.tstamp;
    handles.timeInfo.tstamp{2} = AddTimeToDateVec(data_set.tstamp, data_set.num_points / data_set.fs);
    handles.timeInfo.ds_stamp{1} = data_set.tstamp;
    handles.timeInfo.ds_stamp{2} = handles.timeInfo.tstamp{2};
    
    % and fill in options
    handles.timeInfo.fs = data_set.fs;
    handles.timeInfo.is_relative = is_relative;
    handles.timeInfo.is_hhmmss = is_hhmmss;
    handles.timeInfo.is_time = is_time;
    
end
    
% set up check boxes
set(handles.rbAllTime, 'value', handles.timeInfo.full);
set(handles.rbPartTime, 'value', ~handles.timeInfo.full);
set(handles.rbIndexs, 'value', ~handles.timeInfo.is_time);
set(handles.rbTimes, 'value', handles.timeInfo.is_time);
set(handles.rbHHMMSS, 'value', handles.timeInfo.is_hhmmss);
set(handles.rbRelTime, 'value', handles.timeInfo.is_relative);

% now fill in the values
handles = UpdateTimePaneValues(handles);

% make sure everything has its callback set
hChildren = findobj(handles.uiRangePane, 'type', 'uicontrol');
for i = 1:numel(hChildren)
    set(hChildren(i), 'Callback', @(hObject, event_data)TimePaneCallbacks(hObject, event_data, guidata(hObject)));
end





    
    

    


