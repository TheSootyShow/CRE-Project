function dirs = RecurseDir(dirs)
% function dirs = RecurseDir(input_dir)
% this function finds all sub-directories of an input dir

% check its a cell array
if ~iscell(dirs)
    dirs = {dirs};
end

% over allocate it
alloc = 50;
dirs = dirs(:);
dirs{alloc,1} = '';

% current progress
curr = 1;
n_dirs = 1;

% and start
while (curr <= n_dirs)
    
    % look at contents
    files = dir(dirs{curr});
    is_dir = [files(:).isdir];
    new = {files(:).name};
    
    % only want the directories
    new = new(is_dir);
    new = new(~cellfun(@(name)(all(name == '.')), new));  % dont want the relative dirs
    
    % add them
    if ((n_dirs+numel(new)) > numel(dirs))
        dirs{n_dirs+numel(new)+alloc,1} = '';
    end
    dirs(n_dirs+1:n_dirs+numel(new)) = fullfile(dirs{curr}, new);
    n_dirs = n_dirs + numel(new);
    
    % and move along
    curr = curr + 1;
    
end


% and trim back
dirs = dirs(1:n_dirs);


    
