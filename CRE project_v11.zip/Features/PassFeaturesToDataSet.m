function [outputSettings, success, warning_list] = PassFeaturesToDataSet(inputSettings, data_set)
% function [outputSettings, success, warning_list] = PassFeaturesToDataSet(inputSettings, data_set)
% function to adjust the input feature settings to match the data set

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialise the output features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

outputSettings = InitFeatSettingsStruct();

% keep track of potential problems with a warning list
warning_list = '';
success = true;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now match the times
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'timeRange')

    [outputSettings.timeRange, time_success, time_warning_list] = MapTimeRangeToDataSet(inputSettings.timeRange, data_set);
    warning_list = sprintf('%s%s', warning_list, time_warning_list);
    success = success & time_success;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Match analysis Frequecies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'freqRange')

    if isfield(inputSettings, 'features')
        [outputSettings.freqRange, freq_success, freq_warning_list] = MapFreqRangeToDataSet(inputSettings.freqRange, data_set, inputSettings.features);
    else
        [outputSettings.freqRange, freq_success, freq_warning_list] = MapFreqRangeToDataSet(inputSettings.freqRange, data_set);
    end
    warning_list = sprintf('%s%s', warning_list, freq_warning_list);
    success = success & freq_success;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Match the dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'dimInfo')

    [outputSettings.dimInfo, dim_success, dim_warning_list] = MapDimInfoToDataSet(inputSettings.dimInfo, data_set);
    warning_list = sprintf('%s%s', warning_list, dim_warning_list);
    success = success & dim_success;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bin durations are a straight copy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'binInfo')

    outputSettings.binInfo = inputSettings.binInfo;

    % but check the bin range is large enough for the features
    [tmp, obs_warn] = ParseFeatures(outputSettings.features, data_set.fs * outputSettings.binInfo.bin_duration);
    if numel(obs_warn)
        obs_warn = regexpi(strtrim(obs_warn), sprintf('\n'), 'split');
        warning_list = sprintf('%sWarning: Not enough data points per bin to reliably calculate:' , warning_list);
        warning_list = sprintf('%s %s' , warning_list, strtrim(obs_warn{2}));
        for i = 3:numel(obs_warn)  % the first line is a generic warning
            warning_list = sprintf('%s, %s' , warning_list, strtrim(obs_warn{i}));
        end
        warning_list = sprintf('%s\n' , warning_list);
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up the export info
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'exportInfo')
    outputSettings.exportInfo = MapExportOptsToDataSet(inputSettings, data_set);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Map features 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'features')
    outputSettings.features = MapFeaturesToDataSet(inputSettings.features, data_set);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Map post processing features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'postFeatures')

    [outputSettings, missing_feats] = MapPostFeaturesToDataSet(outputSettings, inputSettings.postFeatures);
    if numel(missing_feats)
        missing_str = sprintf('Warning: Unable to find inputs for derived features: %s', missing_feats{1});
        for i = 2:numel(missing_feats)
            missing_str = sprintf('%s, %s', missing_str, missing_feats{i});
        end
        warning_list = sprintf('%s%s\n', warning_list, missing_str);
    end
    
end
        


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aliases are a straight copy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(inputSettings, 'aliases')

    outputSettings.aliases = inputSettings.aliases;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assign the new data set name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

outputSettings.dsName = data_set.name;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% dont include fields in output settings that 
% weren't in 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

inputFields = fieldnames(inputSettings);
outputFields = fieldnames(outputSettings);
remove = outputFields(~ismember(outputFields, inputFields));
if numel(remove)
    outputSettings = rmfield(outputSettings, remove);
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% trim the last new line off the warnings
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(warning_list)  && (warning_list(end) == sprintf('\n'))
    warning_list(end) = [];
end




    
    










