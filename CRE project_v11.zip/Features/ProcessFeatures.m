function [featSettings, out_names, display, idx, indiv_names] = ProcessFeatures(featSettings, varargin)
% function [featSettings, out_names, display, idx, indiv_names] = ProcessFeatures(featSettings, inputDims, ignorePreqs)
% function [featSettings, out_names, display, idx, indiv_names] = ProcessFeatures(featSettings, data_set, ignorePreqs)
% build information on what to output based on selected dimensions and feature settings
%
%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%
%
% featSettings - see InitFeatSettingsStruct.m
%
% inputDims    - parsed input dimensions (see ParseDimInfo.m)
% or
% data_set     - the data set structure
%
% ignorePreqs  - if true, this function will ingore prerequisite features
%                it can find (i.e. features have not been parsed).  Default
%                false
%
%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%
%
% featSettings - updated version of the input with all input features mapped
% 
% out_names    - the name of all created output (these are aliased versions)
%
% display      - which out_names should actually be outputted
%
% idx          - an n x 3 cell array with rows equal to col headings describing where 
%                each output comes from (first column is 'feat' (1) or 'post' (2), the second column is 
%                the feature / post feature index, and the third column the
%                the output number for the feature
%                
%
% indiv_names  - a cell array containing the names of all features / post
%                features (same as out_names but without aliases)


if (numel(varargin) < 2) || (numel(varargin{2}) == 0)
    varargin{2} = false;
end
ignorePreqs = varargin{2};

% if the data set input style was used, created the input dimensions structure
if isfield(varargin{1}, 'hbytes')
    inputDims = ParseDimInfo(featSettings.dimInfo, varargin{1});
else
    inputDims = varargin{1};  % taken directly
end

% start by getting the number of displayed dimensions
n_dims = sum(inputDims.primary_disp) + sum(inputDims.derived_disp);  % GetDerivedDims.m returns this many columns
dim_names = [inputDims.primary_name(inputDims.primary_disp), inputDims.derived_name(inputDims.derived_disp)];
dim_vec = 1:n_dims;

% also get the display version of the names
dim_out_names = ApplyKnownDimAliases(dim_names, featSettings.dimInfo.aliases);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% First Process Ordinary Features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% how many featSettings.features
n_feats = numel(featSettings.features);
feat_names = {featSettings.features.name};

% and keep track of which columns it uses
idx = zeros(100,3);
out_names = cell(100,1);
indiv_names = cell(100,1);
display = false(100,1);
n_outputs = 0;

if (n_feats)

    % also get the index of its prerequisite functions
    [featSettings.features.prereq_indexs] = deal([]);
    
    % and go through them
    for i = 1:n_feats
        
        % find the prerequiste function if needed
        if numel(featSettings.features(i).prereq_name) && (~ignorePreqs)
            [found, featSettings.features(i).prereq_indexs] = ismember(featSettings.features(i).prereq_name, feat_names);
            if any(~found) || any(featSettings.features(i).prereq_indexs >= i)
                error('featSettings.features have not been parsed properly');
            end
        end
        
        % fill in the column numbers
        if (~featSettings.features(i).prereq_only)
            
            % how many outputs?
            order = nchoosek(dim_vec, featSettings.features(i).n_interact);
            
            % create space for output info
            if (numel(featSettings.features(i).output_disp) ~= size(order,1))
                featSettings.features(i).output_names = cell(size(order,1),1);
                featSettings.features(i).output_disp = true(size(order,1), 1);
            end
            
            % always set this
            featSettings.features(i).output_cols = (n_outputs+1:n_outputs+size(order,1)).';
            
            % and generate the names
            for j = 1:size(order,1)
                
                % original dimension names
                terms = dim_names(order(j,:));
                terms_alias = dim_out_names(order(j,:));
                
                % parse them into the feature's string
                featSettings.features(i).output_names{j} = sprintf(featSettings.features(i).label_str, terms{:});
                out_names{n_outputs + j} = sprintf(featSettings.features(i).label_str, terms_alias{:});
                
                % store indexes for how this was made
                idx(n_outputs + j, :) = [1, i, j];
                
            end
            
            % keep track of it all
            display(n_outputs+1:n_outputs + size(order,1)) = featSettings.features(i).output_disp(:);
            indiv_names(n_outputs+1:n_outputs + size(order,1)) = featSettings.features(i).output_names(:);
            
            % update the number of outputs
            n_outputs = n_outputs + size(order,1);
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now do post processing features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% add source and destination data to the post features
if numel(featSettings.postFeatures)
    [featSettings.postFeatures.prereq_indexs] = deal([]);
    [featSettings.postFeatures.output_cols] = deal([]);
end

% now go checking all of the inputs for the desired post features
post_feat_names = {featSettings.postFeatures.name};
for i = 1:numel(featSettings.postFeatures)
    
    % how many inputs does it take?
    n_inputs = numel(featSettings.postFeatures(i).input_dims);
    
    % where do its inputs come from?
    featSettings.postFeatures(i).prereq_indexs = zeros(1, n_inputs);
    
    % keep track of where its inputs come from
    src = zeros(n_inputs, 2);
        
    % find out which columns its input feeatures are in
    for j = 1:n_inputs
        
        % a function of a feature or another post process feature?
        if numel(featSettings.postFeatures(i).input_dims{j})
            
            % its a function of a feature
            feat_ind = FindFeature(featSettings.postFeatures(i).input_feats{j}, featSettings.features, featSettings.postFeatures(i).input_args{j});
            dim_ind = find(strcmpi(featSettings.postFeatures(i).input_dims{j}, dim_names));
            
            % check validity
            
            if (numel(feat_ind) ~= 1) || (numel(dim_ind) ~= 1)
                if (~ignorePreqs)
                    error('Unable to find input %i for post feature: %s\n Have the post processed features been parsed?', j, featSettings.postFeatures(i).name);
                end
            else
                % record where the input comes from
                featSettings.postFeatures(i).prereq_indexs(j) = featSettings.features(feat_ind).output_cols(dim_ind);
                src(j,:) = [feat_ind, dim_ind];
            end
           
        else
            
            % a function of a derived feature
            post_feat_ind = find(strcmpi(featSettings.postFeatures(i).input_feats{j}, post_feat_names));
            src(j,:) = [post_feat_ind, -1];
            
            % check validity
            if (numel(post_feat_ind) ~= 1) && (~ignorePreqs)
                error('Unable to find input %s for post feature: %s\n Have the post processed features been parsed?', featSettings.postFeatures(i).input_feats{j}, featSettings.postFeatures(i).name);
            else
                src(j,:) = [post_feat_ind, -1];
            end
        end
    end
    
    % now add it to the output if its displayed
    if (featSettings.postFeatures(i).display)
        
        % an extra output
        n_outputs = n_outputs + 1;
        featSettings.postFeatures(i).output_cols = n_outputs;  % only ever 1
        out_names{n_outputs} = ApplyKnownDimAliases(featSettings.postFeatures(i).name, featSettings.dimInfo.aliases);
        idx(n_outputs,:) = [2, i, 0];
        indiv_names{n_outputs} = featSettings.postFeatures(i).name;
        display(n_outputs) = true;
        
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Assemble remaining outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

out_names = out_names(1:n_outputs);
idx = idx(1:n_outputs,:);
indiv_names = indiv_names(1:n_outputs);
display = display(1:n_outputs);

% apply feature names aliases
out_names = ApplyKnownFeatAliases(out_names, featSettings.aliases);




