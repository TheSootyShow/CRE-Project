function index = FindFeature(feat_name, featStruct, params)
% function index = FindFeature(feat_name, featStruct, params)
% function to find the feature associated with a particluar uicontrol
% in featStruct

% find it it the feature list
if (numel(featStruct) == 0)
    index = [];
    return;
else
    names = {featStruct(:).name};
    lb_names = {featStruct(:).label_str};
end

% removes all spaces (feat_names may come from a handle's tag and cant have spaces)
feat_name = feat_name(feat_name ~= ' ');  % in case its not from a handle
names = cellfun(@(x)(x(x ~= ' ')), names, 'uniformoutput', false);

    
% try to match of the feature name    
index = find(strcmpi(feat_name, names));

if (numel(index) == 0)
    
    % removes all spaces (feat_name comes from a handle's tag and cant have spaces)
    lb_names = cellfun(@(x)(x(x ~= ' ')), lb_names, 'uniformoutput', false);
    
    % try a match based on the label instead
    match = regexpi(lb_names, ['^', feat_name, '(\(.*\))*$'], 'match', 'once');
    index = find(cellfun(@(x)(numel(x) > 0), match));
    
end

% if multiple matches use the input args to make sense of it
if (numel(index) > 1) && (nargin == 3)
    paramMatch = false(size(index));
    for i = 1:numel(index)
        paramMatch(i) = isequal(featStruct(index(i)).input_args, params);
    end
    index = index(paramMatch);
end
