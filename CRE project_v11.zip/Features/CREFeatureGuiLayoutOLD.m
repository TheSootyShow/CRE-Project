function handles = CREFeatureGuiLayout(hObject, eventdata, handles)
% hObject    handle to FeatureGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent resizing

% restore tab system if needed
tab_info = modUserData(hObject, 'get', 'TabInfo');
force_resize = false;
if numel(tab_info)
    resizing = true;
    modUserData(hObject, 'remove', 'TabInfo');
    handles = RestoreFigureTabs(hObject, handles, tab_info);
    guidata(hObject, handles);
    force_resize = true;
end

% is it already saved at the correct size?
screen_size = get(0, 'ScreenSize');
ppi =  get(0, 'ScreenPixelsPerInch');
resizing = false;
if ((~any(resizing)) && (~isfield(handles, 'screen_info') || (ppi ~= handles.screen_info.ppi) || ~all(screen_size(3:4) == handles.screen_info.pix_size)) || force_resize)

    % dont try it twice at once
    resizing = true;

    % Options for vertical spacing
    p_gap_large = .35;    % use this many cm gap for large gaps
    p_gap_norm = .2;     % use this many cm gap between objects
    p_gap_small = .075;  % use this many cm gap for small gaps
    
    
    % to facilitate sizing
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    
    % use standardized gaps
    p_gap_large = ceil(p_gap_large  * ppcm);
    p_gap_norm = ceil(p_gap_norm  * ppcm);
    p_gap_small = ceil(p_gap_small  * ppcm);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build a grid of ui components for the each pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % the range pane (N.B this pane is used by other gui so the below code is
    % external to this file)
    [range_h, range_h_gap, range_v_gap, range_sizes] = DefaultRangePaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the bin duration pane
    [bin_h, bin_h_gap, bin_v_gap, bin_sizes] = DefaultBinPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the dimensions pane
    [dim_h, dim_h_gap, dim_v_gap, dim_sizes] = DefaultDimPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the post processing pane
    [post_h, post_h_gap, post_v_gap, post_sizes] = DefaultProcessingPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the time domain pane
    [time_h, time_h_gap, time_v_gap, time_sizes] = DefaultTimeDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the frequency domain pane
    [freq_h, freq_h_gap, freq_v_gap, freq_sizes] = DefaultFreqDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the ranking pane
    [rank_h, rank_h_gap, rank_v_gap, rank_sizes] = DefaultRankPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the output file pane
    [outfile_h, outfile_h_gap, outfile_v_gap, outfile_sizes, file_name] = DefaultOutputFilePaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    % the all features pane
    [allfeats_h, allfeats_h_gap, allfeats_v_gap, allfeats_sizes] = DefaultAllFeaturesPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Now build sub panes for time, frequency, and rank features
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
%     % time domain pane
%     [time_pane, time_pane_sizes] = ResizePaneFromGrid(time_h, time_h_gap, time_v_gap, time_sizes, [true, false], false);
%     
%     % frequency domain pane
%     [freq_pane, freq_pane_sizes] = ResizePaneFromGrid(freq_h, freq_h_gap, freq_v_gap, freq_sizes, [false, false], false);
%     
%     % rank pane
%     [rank_pane, rank_pane_sizes] = ResizePaneFromGrid(rank_h, rank_h_gap, rank_v_gap, rank_sizes, false(1,2), false);
%     
%     % assemble it into the layout for the "extract features" pane
%     feature_h = {time_pane,   freq_pane; ...
%                  time_pane,   rank_pane};
%     feature_h_gap = [p_gap_norm; p_gap_norm];
%     feature_v_gap = [p_gap_norm, p_gap_norm];
%     feature_sizes = {[],              freq_pane_sizes; ...
%                     time_pane_sizes,  rank_pane_sizes};
                
    feature_h = {'b',      freq_h; ...
                 time_h,   rank_h};
    feature_h_gap = {[],         freq_h_gap; ...
                    time_h_gap,  rank_h_gap};
    feature_v_gap = {[],         freq_v_gap; ...
                    time_v_gap,  rank_v_gap};
    feature_sizes = {[],         freq_sizes; ...
                    time_sizes,  rank_sizes};
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Now assemble it all
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    fig_layout = {range_h,        'b',         'b',         'b';                ...
                 bin_h,           feature_h,   'l',         'b';                ...
                 dim_h,           'l',         post_h,      'b';                ...
                 outfile_h,       'l',         'l',         allfeats_h;         ...
                 handles.pbOK,    [],          [],          handles.pbCancel};
    
    fig_h_gap = {range_h_gap,      [],              [],             [];             ...
                 bin_h_gap,        feature_h_gap,   [],             [];             ...
                 dim_h_gap,        [],              post_h_gap,     [];             ...
                 outfile_h_gap,    [],              [],             allfeats_h_gap; ...
                 [],               [],              [],             []};
    
    fig_v_gap = {range_v_gap,      [],              [],              [];             ...
                 bin_v_gap,        feature_v_gap,   [],              [];             ...
                 dim_v_gap,        [],              post_v_gap,      [];             ...
                 outfile_v_gap,    [],              [],              allfeats_v_gap; ...
                 [],               [],              [],              []};
    
    pane_sizes = {range_sizes,     [],              [],              [];             ...
                  bin_sizes,       feature_sizes,   [],              [];             ...
                  dim_sizes,       [],              post_sizes,      [];
                  outfile_sizes,   [],              [],              allfeats_sizes; ...
                  [],              [],              [],              []};            ...
    
    
    
    % now call the resize function
    [pane_h, pane_gap] = ResizeFigFromPanes(fig_layout, fig_h_gap, fig_v_gap, pane_sizes, true, [], [false, true]);
    
    set(handles.ebFileName, 'string', file_name);  % we changed it earlier to ensure extra lines
    set(handles.lbDims,'ListboxTop', 1);           % make sure these are at the top
    set(handles.lbCompDims,'ListboxTop', 1);
    
    
    % increase the size of the labels box
    
    
%     % increase the size of the list box to compensate for the large right
%     % hand column
%     pos_txt = get(handles.txtDerived, 'position');
%     gap = pos_txt(2) - p_gap_norm;  % make it pgap norm above the bottom
%     if (gap > 0)
%         
%         % make the list boxes taller
%         cgap = -gap;
%         for i = numel(dim_h):-1:1
%             
%             pos = get(dim_h{i}, 'position');
%             pos(2) = pos(2) + cgap;
%             if strcmpi(get(dim_h{i}, 'style'), 'listbox')
%                 cgap = cgap + floor(gap/2);
%                 pos(4) = pos(4) + floor(gap/2);
%             end
%             set(dim_h{i}, 'position', pos);
%         end
%     end

   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % save the resized figure if applicable
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    handles = SaveResizedCREFigure(hObject, [], handles);
    
%     % add a "hack box" to fix ugliness in the tab group
%     hHackBox = findobj(handles.uiFreqDomain, 'tag', 'hackbox');
%     if (numel(hHackBox) == 0)
%         %hHackBox = uicontrol('style', 'text', 'parent', handles.uiFreqDomain, 'BackgroundColor', get(handles.uiTabPane1, 'BackgroundColor'));
%         hHackBox = uicontrol('style', 'text', 'parent', handles.uiFreqDomain, 'BackgroundColor', [.1,.1,.1]);
%     end
%     
%     % get the position of the first tab's frame relatative to the freq domain panel
%     pos = GetRelativePosition(handles.uiTabPane1, handles.uiFreqDomain, 'pixels');
%     pos(2) = pos(2) + pos(4);
%     pos(4) = 20;
%     set(hHackBox, 'units', 'pixels', 'position', pos);
    
    % clear it
    resizing = [];
    
end
    
% make sure any warnings are visible
if isfield(handles, 'warn_fig') && numel(handles.warn_fig)
    if ishandle(handles.warn_fig)
        drawnow();
        figure(handles.warn_fig);
    end
    handles.warn_fig = [];
end

if (nargout == 0)
    guidata(hObject, handles);
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for output file pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, h_gap, v_gap, sizes, old_txt] = DefaultOutputFilePaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes, old_txt] = DefaultOutputFilePaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the layout for the time domain pane


% allocate filename to have 5 lines in case of long file (but draw it at 3 line size)
set(handles.ebFileName, 'Max', 5 + get(handles.ebFileName, 'Min'))
old_txt = get(handles.ebFileName, 'string');

hGrid = {handles.ebFileName, handles.pbGetFile};
h_gap = p_gap_norm;        
v_gap = [];                                         % space to leave between rows

% get component sizes
sizes = PaneSizesFromGrid(hGrid);

% add space for extra lines in the text box
sizes{1}(2) = sizes{1}(2) * 2.5;






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for frequency domain pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, h_gap, v_gap, sizes] = DefaultFreqDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultFreqDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the layout for the frequency domain pane

% notes:
% 'tgFreqTabs'   is the tabgroup
% 'tabFrange%i'  are the tab panes
% 'uiTabPane%i' is a frame for the tab pane

% start by doing the pane of the first uitab
hTabGrid = cell(4,6);
hTabGrid(1,:) = {handles.rbEntropy1};
hTabGrid(2,1:2) = {handles.txtDomFreq1};
hTabGrid(2,4:5) = {handles.txtDomFreqMag1};
hTabGrid(2,6) = {handles.txtDomFreqRat1};
hTabGrid(3,1:2) = {handles.lbDomFreq1};
hTabGrid(3,4:5) = {handles.lbDomFreqMag1};
hTabGrid(3,6) = {handles.lbDomFreqRat1};
hTabGrid(4, 1:5) = {handles.txtFreqStart1, handles.ebMinFreq1, handles.txtFreqMid1, handles.ebMaxFreq1, handles.txtFreqEnd1};

% tab hgap
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
ppcm = ppi / 2.54;                                          % pixels per centimeter

tab_h_gap = repmat(p_gap_norm, size(hTabGrid,1), size(hTabGrid,2) - 1);
tab_h_gap(:, end) = ceil(1 * ppcm);

% gaps between components vertically
tab_v_gap = repmat(p_gap_norm, size(hTabGrid,1)-1, size(hTabGrid,2));
tab_v_gap(1,:) = p_gap_large;
tab_v_gap(2,:) = p_gap_small;

% size this
[uiTabFrame, tab_pane_size] = ResizePaneFromGrid(hTabGrid, tab_h_gap, tab_v_gap, false, [false, false], false);

% set the size of the tab container based on this
pane_border = [4,4];  % pixels of sapce for the pane border

% set this within the tab pane
set(uiTabFrame, 'units', 'pixels');
frame_pos = [1, 1, tab_pane_size];
set(uiTabFrame, 'position', frame_pos);

% set the tab pane to the same size (+ border space)
cont_size = tab_pane_size + [2*pane_border(1), 8];
set(handles.tabFrange1, 'units', 'pixels');
pos = get(handles.tabFrange1, 'position');
pos(3:4) = cont_size+1;
pos(1:2) = pos(1:2) - 1;

set(handles.tabFrange1, 'position', pos);

% set the tab container to this size
set(handles.tgFreqTabs, 'units', 'pixels');
container_pos = get(handles.tgFreqTabs, 'position');
container_pos(3:4) = cont_size;
container_pos(4) = container_pos(4) + 15;  % leave space for the tabs
set(handles.tgFreqTabs, 'position', container_pos);


% now put it in with the parts of the frequnecy pane that dont vary
hGrid = cell(3,3);
hGrid(1,:) = {handles.tgFreqTabs};
hGrid(2, :) = {handles.txtFFTres1, handles.ebFFTres, handles.txtFFTres2};
hGrid(3, :) = {handles.txtFsLabel, handles.txtFs, handles.txtFsUnit};
set(cell2mat(hGrid), 'parent', handles.uiFreqDomain);

% build spacings
h_gap = repmat(p_gap_norm, size(hGrid,1), size(hGrid,2) - 1);
v_gap = repmat(p_gap_norm, size(hGrid,1)-1, size(hGrid,2));


% get component sizes
sizes = PaneSizesFromGrid(hGrid);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for time domain pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, h_gap, v_gap, sizes] = DefaultTimeDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultTimeDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the layout for the time domain pane

% turn constants into units in pixels
ppi = get(0, 'ScreenPixelsPerInch');                     % pixels per inch
ppcm = ppi / 2.54;                                       % pixels per centimeter
indent = .5 * ppcm;

% set up the matrix of handles
hGrid = cell(10,2);
hGrid(1,:) = {handles.rbMin, handles.rbMean};
hGrid(2,:) = {handles.rbMax, handles.rbStd};
hGrid(3,:) = {handles.rbSum, handles.rbCoeffVar};
hGrid(4,:) = {handles.rbPower, handles.rbSkew};
hGrid(5,:) = {handles.rbLogEnergy, handles.rbKurtosis};
hGrid{6,1} = handles.rbp2p;
hGrid{7,1} = handles.rbPeakOccurances;
hGrid{8,1} = handles.rbXCorr;

% to accomodate auto correlation, replicate the first column (ie make it
% three columns wide)
hGrid =[hGrid(:,1), hGrid(:,1), hGrid(:,2)];
hGrid(9,1:2) = {sprintf('h=%g', indent), handles.txtAutoCorr};
hGrid(10,:) = {sprintf('h=%g', indent), handles.lbLag, handles.pmACorrUnits};

% gaps between components horizontally
h_gap = repmat(p_gap_norm, size(hGrid,1), size(hGrid,2)-1);

% gaps between components vertically
v_gap = repmat(p_gap_norm, size(hGrid,1)-1, size(hGrid,2));
v_gap(end,:) = p_gap_small;

% get component sizes
sizes = PaneSizesFromGrid(hGrid);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for rank pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, h_gap, v_gap, sizes] = DefaultRankPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultFreqDomainPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the layout for the time domain pane

hGrid = cell(4,2);
hGrid(1:3,1) = {handles.lbPercentiles}; 
hGrid{4,1} = handles.txtPercentiles;
hGrid{1,2} = handles.rbXMedian;
hGrid{2,2} = handles.rbInterquartile;

% gaps between components horizontally
h_gap = repmat(p_gap_norm, size(hGrid,1), size(hGrid,2) - 1);

% gaps between components vertically
v_gap = repmat(p_gap_norm, size(hGrid,1)-1, size(hGrid,2));
v_gap(end,1) = p_gap_small;  % small gap from the list to it txt description

% get component sizes
sizes = PaneSizesFromGrid(hGrid);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for bin pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, h_gap, v_gap, sizes] = DefaultBinPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultBinPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the layout for the data bin pane

% set up the matrix of handles
hGrid = cell(5,3);
hGrid(1,1:3) = {handles.rbGlobal};
hGrid(2,1:3) = {handles.rbBinData};
hGrid(3,2:3) = {handles.txtBinDuration, handles.ebBinDuration};
hGrid(4,2:3) = {handles.txtBinAlignment, handles.pmBinTime};
hGrid(5,2:3) = {handles.txtBinPointsLabel, handles.txtBinPoints};

% gaps between components horizontally
h_gap = repmat(p_gap_norm, size(hGrid,1), size(hGrid,2) - 1);
h_gap(3:4,1) = 1.5*p_gap_large;  % leave a very large space for the indent
h_gap(3:5,2) = p_gap_small;  % but a small gap between the connected bits

% gaps between components vertically
v_gap = repmat(p_gap_norm, size(hGrid,1)-1, size(hGrid,2));
v_gap(4, 2:end) = p_gap_small; % a small gap between the bin duration and bin centering


% get component sizes
sizes = PaneSizesFromGrid(hGrid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The dimensions pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hGrid, h_gap, v_gap, sizes] = DefaultDimPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultDimPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the dimensions pane


hGrid = {handles.txtPrimDims,  handles.txtCompDims, []; ...
         handles.lbDims,       handles.lbCompDims, 'b'; ...
         handles.txtPrimary,   handles.txtDerived, handles.pbRelabelDims};

% default spacing     
h_gap = repmat(p_gap_large, size(hGrid,1), size(hGrid,2) - 1);
v_gap = repmat(p_gap_small, size(hGrid,1)-1, size(hGrid,2));

% and get sizes
sizes = PaneSizesFromGrid(hGrid);

% keep the list boxes the same height
list_height = max(sizes{2,1}(2), sizes{2,2}(2));
sizes{2,1}(2) = list_height;
sizes{2,2}(2) = list_height;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The post processing pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function [hGrid, h_gap, v_gap, sizes] = DefaultProcessingPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultProcessingPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function to build the layout for the data bin pane

% set up the matrix of handles
hGrid = cell(3,2);
hGrid(1,1) = {handles.txtPostProcess};
hGrid(2,1:2) = {handles.lbPostProcess, 'b'};
hGrid(3,1:2) = {handles.txtNumPostProcess, handles.pbRelabelFeatures};

% gaps between components horizontally
h_gap = repmat(p_gap_norm, size(hGrid,1), size(hGrid,2) - 1);

% gaps between components vertically
v_gap = repmat(p_gap_small, size(hGrid,1)-1, size(hGrid,2));

% get component sizes
sizes = PaneSizesFromGrid(hGrid);



function [hGrid, h_gap, v_gap, sizes] = DefaultAllFeaturesPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large)
% function [hGrid, h_gap, v_gap, sizes] = DefaultAllFeaturesPaneLayout(handles, p_gap_small, p_gap_norm, p_gap_large);
% function to build the layour for the all features pane

hGrid = {handles.lbAllFeats};

% gaps between components horizontally
h_gap = repmat(p_gap_norm, size(hGrid,1), size(hGrid,2) - 1);

% gaps between components vertically
v_gap = repmat(p_gap_norm, size(hGrid,1)-1, size(hGrid,2));

% get component sizes
sizes = PaneSizesFromGrid(hGrid);








