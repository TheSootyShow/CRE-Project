function feat_struct = CREFeatures(feature_str, varargin)
% function feat_struct = CREFeatures(feature_str, varargin)
% function feat_struct = CREFeatures(siz)
% this function provides a switchyard to return a structure with the
% information to run a particular feature extraction method
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% feature_str -  a string (or cell array of strings) containing the names
%                of one (or more) of these features:
%
% Time domain features:
%                'acorr'                           (note: auto correlation)
%                'coeffvar'                        (note: coefficient of variation uses the unbiased variance)
%                'covariance'                      (note: prerequisite only)
%                'difference'                      (note: mean of the derivative)
%                'kurtosis'                        (note: excess kurtosis - assumes its given the population)
%                'logenergy'                       (note: sum(log(X^2)), no normalization) 
%                'magnitude'                       (note: mean magnitude)
%                'max'
%                'mean'
%                'min'
%                'moments'                         (note: the first four central moments, prerequisite only)
%                'peaktopeak'                      (note: max - min)
%                'power'                           (note: just the sum of squares, no normalization) 
%                'skewness'                        (note: assumes its given the population)
%                'std'                             (note: standard deviation uses the unbiased variance)
%                'sum'                             (note: simply the sum)
%                'zerocrossings' or 'xzero'        (note: zero crossings)
%                'xcorr'                           (note: cross correlation)
%
% Time features that take addition inputs:
% 'acorr' - supply the lag in ms followed by the sampling rate, CREFeatures('acorr', lag_ms, fs);
%
% Ranking features:
%                'interquartile'                   (note: top 25% - bottom 25%)
%                'percentile'
%                'mediancrossings' or 'xmedian'    (note: median crossings)
%
% Rank features that take addition inputs:
% 'percentile' - supply with the desired percentile (0-100), where 0 is the same as the minimum value and 100 is the same as the max
%
% Frequency features:
%                'fft'                             (note: prerequisite only)
%                'dominantfreq' or 'domfreq'       (note: the frequency with the most power in Hz) 
%                'dominantfreqmag' or 'domfreqmag' (note: the magnitude of the frequency with the most power)
%                'dominantfreqrat' or 'domfreqrat' (note: the % of the total power contained by the dominant frequency)
%                'entropy'                         (probability mass function is always normalized between 0 and fs/2)
%
% All frequency features (except fft) take fl, fh, and fs as the final inputs, with
%   fl - lowest frequency to use (Hz)
%   fh - highest frequency to use (Hz)
%   fs - data set sampling frequency (Hz)
%
% Frequency features that take addition inputs:
% 'fft'             - supply the sampling frequency followed by the desired fft resolution in Hz (use 0 for the resolution for max resolution)
% 'dominantfreq'    - supply the ith most dominant frequency is of interest (defaults to 1 for the most dominant) 
% 'dominantfreqmag' - supply the ith most dominant frequency is of interest (defaults to 1 for the most dominant) 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% feat_struct - a structure with one element per desired feature and the
%               following fields:
%
%                      'name',                - the name of the feature
%                      'label_str',           - how to create a label for the feature based on the name of the 
%                                               name of the data dimension. Get the new label by
%                                               sprintf(feat_struct.label_str, dimension name)
%                                               e.g. sprintf(feat_struct.label_str, 'y')
%                                               N.B. if n_interact > 1, the label string will want n_interact labels as input.  The order of the interactions comes form nchoosek.m
%                      'n_interact',          - the number of dimensions interacting for this measure (e.g. correlation will be the interaction of two dimensions)
%                                                
%                      'min_obs',             - the minimum number of observations required for the feature to validily estimated
%                                                 
%                      'prereq_name',         - a cell array of the names of the pre-requisite functions
%                                               If a prerequsite function exists, the function in "func" takes the output of the prerequisite function(s) as input(s)
%                      'prereq_only',         - if true, the only reason we are calculating this is because we need it as a prerequisite
%                                                
%                      'func',                - function to calculate the feature
%                                               if there's no prereq function:
%                                               input 1 is the data with each dimension store column wise
%                                               input 3-N are any other inputs the function may need
%                                               if the function has a prerequiste function: 
%                                                 input 1 to this function is the output of the prerequiste function
%                                                 input 2 is the number of points used during evaluation of the precusor function
%                                                 input 3 - N are other inputs the function may need
%                                                
%                      'running_func',        - the function to calculate the function in a "running" way (not applicable for features that use prerequsite functions)
%                                               (i.e. when there's too much data to load in a single block)
%                                               when this function is called with no inputs it should return initialised
%                                               version of the variables it needs to be passed from one function call to the next
%                                               the first output should contain the feature estimate after this "block"
%                                               
%                                               %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                               Example: Calculate the mean of the data, when the data is broken into two blocks, X{1} and X{2}
%                                               %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                                               1) Initialise working variables:
%                                                  n_variables = nargout(CREmean);                      % get the number of working variables for the function CREmean (CREmean is defined in this file)
%                                                  working_vars = cell(1, n_variables-1);               % create space for the working variables (the first ouput is the feature estimate)
%                                                  [feat_est, working_vars{:}] = CREmean();             % call the CRE_mean function to initialise working variables
%
%                                               2) Call the function on the two blocks:
%                                                  [feat_est, working_vars{:}] = CREmean(X{1}, working_vars{:});   % N.B we pass the working variables in
%                                                  [feat_est, working_vars{:}] = CREmean(X{2}, working_vars{:});  
%
%                                               3) Get the final feature estimate:
%                                                  Xm = feat_est;                                     % the feature estimate is always the first output
%
%                     'input_args',             - any additional input arguments required by the function (each argument in its own cell) 
%                                                 1) when func has no prerequisite, additional arguments start at the second input to the function (the first input is the data)                   
%                                                 2) when func has pre-requisites, additional arguments start at the third input to the function (the first input is the output of the prequisite, the second the number of obervations)                   
%                                                 3) when used with a running_func, additional arguments come BEFORE the working variables.  Using the example above, 
%                                                     input_args = {};  % CREmean doesn't use any
%                                                     all_inputs = [{X{1}}, input_args, working_vars]
%                                                     [feat_est, working_vars{:}] = CREmean(all_inputs{:});


% prototype the structure to return
feat_struct = struct('name',                [], ... % the name of the feature
                                                ...
                     'label_str',           [], ... % how to create a label for the feature based on the name of the 
                                                ... % name of the data dimension. Get the new label by
                                                ... % sprintf(feat_struct.label_str, dimension name)
                                                ... % e.g. sprintf(feat_struct.label_str, 'y')
                                                ... % N.B. if n_interact > 1, the label string will want n_interact labels as input.  The order of the interactions comes form nchoosek.m
                     'n_interact',          [], ... % the number of dimensions interacting for this measure (e.g. correlation will be the interaction of two dimensions)
                                                ...
                     'min_obs',             [], ... % the minimum number of observations required for the feature to validily estimated
                                                ... %
                     'prereq_name',       {{}}, ... % a cell array of the names of the pre-requisite function(s)
                                                ... % 
                     'prereq_only',         [], ... % if true, the only reason we are calculating this is because we need it as a prerequisite
                                                ...
                     'prereq_indexs',       [], ... % indexes of the coulmns of the output of prerequisites (not filled by this functions
                                                ... %
                     'func',                [], ... % function to calculate the feature
                                                ... % if there's no prereq function:
                                                ... % input 1 is the data with each dimension store column wise
                                                ... % input 3-N are any other inputs the function may need
                                                ... % if the function has a prerequiste function: 
                                                ... %   input 1 to this function is the output of the prerequiste function
                                                ... %   input 2 is the number of points used during evaluation of the precusor function
                                                ... %   input 3 - N are other inputs the function may need
                                                ... %
                     'running_func',        [], ... % the function to calculate the function in a "running" way (not applicable for features that use prerequsite functions)
                                                ... % (i.e. when there's too much data to load in a single block)
                                                ... % when this function is called with no inputs it should return initialised
                                                ... % version of the variables it needs to be passed from one function call to the next
                                                ... % the first output should contain the feature estimate after this "block"
                                                ... %
                                                ....%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                ... % Example: Calculate the mean of the data, when the data is broken into two blocks, X{1} and X{2}
                                                ... %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                ... %
                                                ... % 1) Initialise working variables:
                                                ... %    n_variables = nargout(CREmean);                      % get the number of working variables for the function CREmean (CREmean defined in this file)
                                                ... %    working_vars = cell(1, n_variables-1);               % create space for the working variables (the first ouput is the feature estimate)
                                                ... %    [feat_est, working_vars{:}] = CREmean();             % call the CRE_mean function to initialise working variables
                                                ... %
                                                ... % 2) Call the function on the two blocks:
                                                ... %    [feat_est, working_vars{:}] = CREmean(X{1}, working_vars{:});   % N.B we pass the working variables in
                                                ... %    [feat_est, working_vars{:}] = CREmean(X{2}, working_vars{:});  
                                                ... %
                                                ... % 3) Get the final feature estimate:
                                                ... %    Xm = feat_est;                                     % the feature estimate is always the first output
                                                ... %
                     'input_args',        {{}}, ... % any additional input arguments required by the function
                                                ... 
                     'output_names',      {{}}, ... % the name of each feature / dim combination (not filled by this function)
                                                ...
                     'output_cols',       [],   ... % where each feature / dim combination gets placed in the output feature set (not filled by this function)
                                                ...
                     'output_disp',  false(1,0) ... % whether to display each feature / dim combination individually
                                                ...
                                          );

% now fill it in
if (nargin == 0) || (numel(feature_str) == 0)
        
    return;  % return the empty structure
    
elseif isnumeric(feature_str) 
    
    % assume the user is speciying the size of the empty structure
    siz = feature_str;
    if (numel(siz) == 1)
        siz(2) = 1;
    end
    feat_struct = repmat(feat_struct, siz);
    return;
    

elseif ~iscell(feature_str)
    
    % force cell array
    feature_str = {feature_str};
    
end

% preallocate
feat_struct = repmat(feat_struct, numel(feature_str), 1);
    
% and populate
for i = 1:numel(feat_struct)
    
    % remove all white spaces
    feature_str{i} = feature_str{i}(~isstrprop(feature_str{i}, 'wspace'));

   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % These functions do not need prerequisite functions
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    % for the maximum
    if any(strcmpi(feature_str{i}, {'max', 'maximum'}))
        
        feat_struct(i).name =      'maximum';
        feat_struct(i).label_str = 'max(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @max;
        feat_struct(i).running_func = @CREmax;
        
    % for the minimum
    elseif any(strcmpi(feature_str{i}, {'min', 'minimum'}))
        
        feat_struct(i).name =      'minimum';
        feat_struct(i).label_str = 'min(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @min;
        feat_struct(i).running_func = @CREmin;
        
    % for the mean magnitude
    elseif any(strcmpi(feature_str{i}, {'magnitude', 'mag'}))
        
        feat_struct(i).name =      'magnitude';
        feat_struct(i).label_str = 'mag';
        feat_struct(i).n_interact = 0;                         % zero indicates one output no matter how many inputs
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @(X)mean(sqrt(sum(X.*X,2)), 1);
        feat_struct(i).running_func = @CREmag;
        
    % for the differential
    elseif any(strcmpi(feature_str{i}, {'difference', 'd'}))
        
        feat_struct(i).name =      'difference';
        feat_struct(i).label_str = 'd(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @(X)mean(diff(X, 1, 1));
        feat_struct(i).running_func = @CREdiff;
        
        
    % for the covaraince
    elseif any(strcmpi(feature_str{i}, {'covariance', 'cov'}))
        
        feat_struct(i).name =      'covariance';
        feat_struct(i).label_str = 'cov(%s,%s)';
        feat_struct(i).n_interact = 2;             % covariance comes from the interaction of two variables
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @CREcov;
        feat_struct(i).running_func = @CREcov;
        
    % for calculating the moments of X
    elseif strcmpi(feature_str{i}, 'moments')
        
        feat_struct(i).name =      'moments';
        feat_struct(i).label_str = 'moments(%s)';
        feat_struct(i).n_interact = 1;             
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @CREmoments;
        feat_struct(i).running_func = @CREmoments;
        
    % for signal power
    elseif strcmpi(feature_str{i}, 'power')
        
        feat_struct(i).name =      'power';
        feat_struct(i).label_str = 'power(%s)';
        feat_struct(i).n_interact = 1;             
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @(X)(sum(X.*X));
        feat_struct(i).running_func = @CREpower;
        
    % for log energy
    elseif any(strcmpi(feature_str{i}, {'logenergy', 'logen'}))
        
        feat_struct(i).name =      'log energy';
        feat_struct(i).label_str = 'logen(%s)';
        feat_struct(i).n_interact = 1;             
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @(X)(sum(log(X.*X)));
        feat_struct(i).running_func = @CRElogenergy;
        
    % for an fft
    elseif strcmpi(feature_str{i}, 'fft')
        
        feat_struct(i).name =      'fft';
        feat_struct(i).label_str = 'fft(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 3;
        feat_struct(i).func = @CREfft;
        
        % assign functions
        if (numel(varargin) == 2)
            feat_struct(i).input_args = varargin(1:numel(varargin));
        else
            error('FFT requires two inputs, the first the sampling rate, and the seconds specifying the desired fft sensitivity in Hz');
        end
        
        
    % for sorting data
    elseif strcmpi(feature_str{i}, 'sort')
        
        feat_struct(i).name =      'sort';
        feat_struct(i).label_str = 'sort(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @CREsort;
        feat_struct(i).running_func = [];  % no running version available
        
    % for median crossings
    elseif any(strcmpi(feature_str{i}, {'mediancrossings', 'xmedian'}))
        
        feat_struct(i).name =      'median crossings';
        feat_struct(i).label_str = 'xmedian(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 3;
        feat_struct(i).func = @(X, varargin)CREcrossings(X, true);
        feat_struct(i).running_func = [];    % there is no way to do median crossing in a running form
        

    % for median crossings
    elseif any(strcmpi(feature_str{i}, {'zerocrossings', 'xzero'}))
        
        feat_struct(i).name =      'zero crossings';
        feat_struct(i).label_str = 'xzero(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 3;
        feat_struct(i).func = @(X, varargin)CREcrossings(X, false);
        feat_struct(i).running_func = [];    % too lazy to implement
        
        %                'zerocrossing' or 'zcross'        (note: zero crossings)
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % functions below here rely on pre-requiste functions
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % for the sum
    elseif strcmpi(feature_str{i}, 'sum')
        
        feat_struct(i).name =      'sum';
        feat_struct(i).label_str = 'sum(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @CREsum;
        
        % function uses the moments as it prerequisite
        feat_struct(i).prereq_name = {'moments'};
    
    % for the mean
    elseif any(strcmpi(feature_str{i}, {'mean', 'E'}))
    
        feat_struct(i).name =      'mean';
        feat_struct(i).label_str = 'E(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 1;
        feat_struct(i).func = @CREmean;
        
        % function uses the moments as it prerequisite
        feat_struct(i).prereq_name = {'moments'};

        
    % for standard deviation
    elseif any(strcmpi(feature_str{i}, {'std', 'standarddeviation'}))
        
        feat_struct(i).name =      'standard deviation';
        feat_struct(i).label_str = 'std(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @CREstd;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        
        % function needs the moments as it prerequisite
        feat_struct(i).prereq_name = {'moments'};

    % for coefficient of variation
    elseif any(strcmpi(feature_str{i}, {'coeffvar', 'coefficientofvariation', 'cv'}))
        
        feat_struct(i).name =      'coefficient of variation';
        feat_struct(i).label_str = 'cv(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @CREcoeffvar;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        
        % function needs the moments as it prerequisite
        feat_struct(i).prereq_name = {'moments'};
        
    % for skewness
    elseif any(strcmpi(feature_str{i}, {'skew', 'skewness'}))
        
        feat_struct(i).name =      'skewness';
        feat_struct(i).label_str = 'skew(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 4;
        feat_struct(i).func = @CREskew;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        
        % function needs the moments as it prerequisite
        feat_struct(i).prereq_name = {'moments'};
        
    % for kurtosis
    elseif any(strcmpi(feature_str{i}, {'kurtosis', 'kurt'}))
        
        feat_struct(i).name =      'kurtosis';
        feat_struct(i).label_str = 'kurt(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 4;
        feat_struct(i).func = @CREkurt;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        
        % function needs the moments as it prerequisite
        feat_struct(i).prereq_name = {'moments'};
        

    % for peak to peak
    elseif any(strcmpi(feature_str{i}, {'peaktopeak', 'p2p'}))
        
        feat_struct(i).name =      'peak to peak';
        feat_struct(i).label_str = 'p2p(%s)';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @CREpeaktopeak;
        
        % function needs the max and min as it prerequisites
        feat_struct(i).prereq_name = {'maximum', 'minimum'};
                
        
    % for cross correlation
    elseif any(strcmpi(feature_str{i}, {'xcorr', 'crosscorrelation'}))
        
        feat_struct(i).name =      'cross correlation';
        feat_struct(i).label_str = 'xcorr(%s,%s)';
        feat_struct(i).n_interact = 2;
        feat_struct(i).min_obs = 2;
        feat_struct(i).func = @CRExcorr;
        feat_struct(i).running_func = [];                       % no running func for features with prerequistes
        
        % function needs covariance as it prerequisite
        feat_struct(i).prereq_name = {'covariance'};
        
    % for auto correlation
    elseif any(strcmpi(feature_str{i}, {'acorr', 'autocorrelation'}))
        
        feat_struct(i).name =      'auto correlation';
        feat_struct(i).n_interact = 1;
        feat_struct(i).min_obs = 2;
        feat_struct(i).running_func = [];                                     % no running func for features with prerequistes
        feat_struct(i).func = @CREacorr;
        
        % assign functions
        if (numel(varargin) == 2)
            feat_struct(i).input_args = varargin(1:numel(varargin));
            feat_struct(i).min_obs = 1 + round(varargin{1}*(1e-3) * varargin{2});                         % requires 1 observations plus the lag in samples
        else
            error('Auto correlation requires two inputs, the lag in ms and the sampling rate');
        end
        
        % create the label
        feat_struct(i).label_str = sprintf('acorr(%%s, %gms)', feat_struct(i).input_args{1});
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'fft'};
        
        
    % for dominant frequency
    elseif any(strcmpi(feature_str{i}, {'dominantfreq', 'domfreq', 'dominantfrequency'}))
        
        feat_struct(i).name =      'dominant frequency';
        feat_struct(i).n_interact = 1;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        feat_struct(i).func = @CREdomFreq;
        
        % are we supplying additional parameters?
        if (numel(varargin) == 3)
            feat_struct(i).input_args = [{1}, varargin(1:numel(varargin))];
        elseif (numel(varargin) == 4)
            feat_struct(i).input_args = varargin(1:numel(varargin));
        elseif (numel(varargin) > 0)
            error('If inputs are supplied to %s, 4 must be supplied: CREFeatures(%s, i, fl, fh, fs)', feature_str{i}, feature_str{i});
        end
        
        % create the label string
        feat_struct(i).min_obs = feat_struct(i).input_args{1};
        feat_struct(i).label_str = sprintf('f%i(%%s,%0.2g,%0.2g)', feat_struct(i).input_args{1}, feat_struct(i).input_args{2}, feat_struct(i).input_args{3});
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'fft'};
        
    % for dominant frequency magnitude
    elseif any(strcmpi(feature_str{i}, {'dominantfreqmag', 'domfreqmag', 'dominantfrequencymagnitude'}))
        
        feat_struct(i).name =      'dominant frequency magnitude';
        feat_struct(i).n_interact = 1;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        feat_struct(i).func = @CREdomFreqMag;
        
        % are we supplying additional parameters?
        if (numel(varargin) == 3)
            feat_struct(i).input_args = [{1}, varargin(1:numel(varargin))];
        elseif (numel(varargin) == 4)
            feat_struct(i).input_args = varargin(1:numel(varargin));
        elseif (numel(varargin) > 0)
            error('If inputs are supplied to %s, 4 must be supplied: CREFeatures(%s, i, fl, fh, fs)', feature_str{i}, feature_str{i});
        end
        
        % create the label string
        feat_struct(i).min_obs = feat_struct(i).input_args{1};
        feat_struct(i).label_str = sprintf('fm%i(%%s,%0.2g,%0.2g)', feat_struct(i).input_args{1}, feat_struct(i).input_args{2}, feat_struct(i).input_args{3});
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'fft'};

     % for dominant frequency power ratio
    elseif any(strcmpi(feature_str{i}, {'dominantfreqrat', 'domfreqrat', 'dominantfrequencypowerratio'}))
        
        feat_struct(i).name =      'dominant frequency power ratio';
        feat_struct(i).n_interact = 1;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        feat_struct(i).func = @CREdomFreqRat;
        
        % are we supplying additional parameters?
        if (numel(varargin) == 3)
            feat_struct(i).input_args = [{1}, varargin(1:numel(varargin))];
        elseif (numel(varargin) == 4)
            feat_struct(i).input_args = varargin(1:numel(varargin));
        elseif (numel(varargin) > 0)
            error('If inputs are supplied to %s, 4 must be supplied: CREFeatures(%s, i, fl, fh, fs)', feature_str{i}, feature_str{i});
        end
        
        % create the label string
        feat_struct(i).min_obs = feat_struct(i).input_args{1};
        feat_struct(i).label_str = sprintf('fp%i(%%s,%0.2g,%0.2g)', feat_struct(i).input_args{1}, feat_struct(i).input_args{2}, feat_struct(i).input_args{3});
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'fft'};
        
    % for entropy
    elseif any(strcmpi(feature_str{i}, {'entropy'}))
        
        feat_struct(i).name =      'entropy';
        feat_struct(i).min_obs = 2;
        feat_struct(i).n_interact = 1;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        feat_struct(i).func = @CREentropy;
        
        % are we supplying additional parameters?
        if (numel(varargin) == 3)
            feat_struct(i).input_args = varargin(1:numel(varargin));
        elseif (numel(varargin) > 0)
            error('If inputs are supplied to %s, 3 must be supplied: CREFeatures(%s, fl, fh, fs)', feature_str{i}, feature_str{i});
        end
        feat_struct(i).label_str = sprintf('entropy(%%s,%0.2g,%0.2g)', feat_struct(i).input_args{1}, feat_struct(i).input_args{2});
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'fft'};        
        
    % for quantile values
    elseif strcmpi(feature_str{i}, 'percentile')
        
        feat_struct(i).name =      'percentile';
        feat_struct(i).min_obs = 10;
        feat_struct(i).n_interact = 1;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        feat_struct(i).func = @CREpercentile;
        
        % are we supplying additional parameters?
        if (numel(varargin) == 1)
            feat_struct(i).input_args = varargin(1:numel(varargin));
        elseif (numel(varargin) > 0)
            error('Percentile features require one input argument');
        end
        
        % include the percentile value in the label
        feat_struct(i).label_str = sprintf('percentile(%%s, %g)', feat_struct(i).input_args{1});
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'sort'};

    % for inter-quartile values
    elseif any(strcmpi(feature_str{i}, {'interquartile', 'iqr', 'interquartilerange'}))
        
        feat_struct(i).name =      'interquartile range';
        feat_struct(i).min_obs = 8;
        feat_struct(i).n_interact = 1;
        feat_struct(i).running_func = [];                % no running func for features with prerequistes
        feat_struct(i).func = @CREinterquartile;
        
        % include the percentile value in the label
        feat_struct(i).label_str = 'iqr(%s)';
        
        % function needs the fft as its prerequisite
        feat_struct(i).prereq_name = {'sort'};
        
    else
        error('Unknown Feature Type: %s', feature_str{i});
    end
    
    % never as the return from this function
    feat_struct(i).prereq_only = false;
    
end
                                      
                                      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Implement simple feature types here
% These functions do not act on the output 
% of a prerequiste function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [x_est, x_max] = CREmax(X, x_max)
% function [x_est, x_max] = CREmax(X, sum_x, n)
% running maximum

if (nargin == 0)
    [x_est, x_max] = deal(0);  % intialise outputs
else
    x_max = max(max(X,  [], 1), x_max);
    x_est = x_max;
end

function [x_est, x_min] = CREmin(X, x_min)
% function [x_est, x_min] = CREmin(X, sum_x, n)
% running maximum

if (nargin == 0)
    [x_est, x_min] = deal(0);  % intialise outputs
else
    x_min = min(min(X,  [], 1), x_min);
    x_est = x_min;
end



function [x_est, sum_x2, n] = CREpower(X, sum_x2, n)
% function [x_est, sum_x2, n] = CREpower(X, sum_x2, n)
% running power calculation (just the sum of squares)

if (nargin == 0)
    [x_est, sum_x2, n] = deal(0);  % intialise outputs
else
    sum_x2 = sum_x2 + sum(X.*X,1);
    n = n + size(X,1);
    x_est = sum_x2;
end


function [x_est, sum_lx2, n] = CRElogenergy(X, sum_lx2, n)
% function [x_est, sum_lx2, n] = CRElogenergy(X, sum_lx2, n)
% running log energy calculation (just the sum of squares)

if (nargin == 0)
    [x_est, sum_lx2, n] = deal(0);  % intialise outputs
else
    sum_lx2 = sum_lx2 + sum(log(X.*X),1);
    n = n + size(X,1);
    x_est = sum_lx2;
end




function [x_est, mag_s, n] = CREmag(X, mag_s, n)
% function [x_est, mag_s, n] = CREmag(X, mag_s, n)
% running magnitude (defined as the mean magnitude in the bin)

if (nargin == 0)
    [x_est, mag_s, n] = deal(0);  % intialise outputs
else
    mag_s = mag_s + sum(sqrt(sum(X.*X,2)));
    n = n + size(X,1);
    x_est = mag_s / n;
end


function [x_est, dXs, lX, n] = CREdiff(X, dXs, lX, n)
% function [x_est, dXs, lX, n] = CREdiff(X, dXs, lX, n)
% running difference

if (nargin == 0)
    [x_est, dXs, n] = deal(0);  % intialise outputs
    lX = NaN;
else
    % is there a previous value to subtract?
    has_prev = ~any(isnan(lX));
    if (size(X,1) + has_prev) >= 2        
        if (has_prev)
            dXs = dXs + sum(X - [lX; X(1:end-1, :)]);
            n = n + size(X,1);
        else
            dXs = dXs + sum(diff(X,1,1));
            n = n + size(X,1)-1;
        end
        lX = X(end,:);
        x_est = dXs / n;
    else
        % no enough data to estimate it yet
        x_est = zeros(1, size(X,2));
        if size(X,1)
            lX = X(end,:);
        end
    end
end


function [x_est, M, n] = CREmoments(X, M, n)
% function [x_est, Y, n] = CREmoments(X, totals, n)
% function returns the sum of different powers of X
% totals{1} is the X^1
% totals{2} is the X^2
% totals{3} is the X^3
% totals{4} is the X^4
max_power = 4;

if (nargin == 0)
    
    % initialise working vars
    [x_est, n] = deal(0);
    M = num2cell(zeros(1,max_power));
    
elseif (nargin == 1)
    
    % non-running form (two pass form)
    M = cell(1,max_power);
    M{1} = mean(X,1);
    X = bsxfun(@minus, X, M{1});
    
    n = size(X,1);
    tmp = X;
    for i = 2:4
        tmp = tmp .* X;
        M{i} = sum(tmp,1) / n;
    end
    x_est = M;

else
    
    % loop through zzz
    for i = 1:size(X,1) 
        
        n = n + 1;
        delta = X(i,:) - M{1};
        delta_n = delta ./ n;
        delta_n2 = delta_n .* delta_n;
        term1 = delta .* delta_n * (n-1);
        M{4} = M{4} + term1 .* delta_n2 * (n*n - 3*n + 3) + 6 * delta_n2 .* M{2} - 4 * delta_n .* M{3};  % 4th moment update
        M{3} = M{3} + term1 .* delta_n * (n - 2) - 3 * delta_n .* M{2};                                  % 3rd moment update
        M{2} = M{2} + term1;                                                                             % 2cd moment update
        M{1} = M{1} + delta_n;  % the new mean estimate
    
    end
    x_est = M;
    
    % divide by the number of samples
    x_est{2} = x_est{2} / n;
    x_est{3} = x_est{3} / n;
    x_est{4} = x_est{4} / n;
end
 
    
    


    

function [x_cov, s, m, n] = CREcov(X, s, m, n)
% function [x_cov, s, m, n] = CREcov(X, s, m, n)
% running covaraince calculation

naive = false;  % the naive way is faster but can be inaccurate

if (nargin == 0)
    [x_cov, s, m, n] = deal(0);  % initialise outputs
elseif (naive)
    
    % all possible combinations
    n_dims = size(X,2);
    combs = nchoose2(n_dims);
    combs = [repmat((1:n_dims).', 1, 2); combs];  % add the "pure" terms
    
    % all possible second order terms
    s = s + sum(X(:,combs(:,1)) .* X(:,combs(:,2)),1);
    
    % first order terms
    m = m + sum(X,1);
    
    % how many points now
    n = n + size(X,1);
    
    % and current estimate
    x_cov = zeros(n_dims);
    if (n >= 2)
        ind_a = combs(:,1) + (combs(:,2)-1) * n_dims;
        ind_b = combs(:,2) + (combs(:,1)-1) * n_dims;
        x_cov(ind_a) = (s - (m(combs(:,1)) .* m(combs(:,2))) / n) / (n-1);
        x_cov(ind_b) = x_cov(ind_a);  % give it symetry
    end
    
else
    
    % all possible combinations
    n_dims = size(X,2);
    combs = nchoose2(n_dims);
    combs = [repmat((1:n_dims).', 1, 2); combs];  % add the "pure" terms
    comb_l = combs(:,1);
    comb_r = combs(:,2);
    
    if (nargin < 2)
        m = zeros(1, n_dims);
        s = zeros(1, numel(comb_l));
        n = 0;
    elseif (numel(m) == 1)  % when we intialize m we dont know the dimensionality
        m = repmat(m, 1, n_dims);
        s = repmat(s, 1, numel(comb_l));
    end
    
    % do it point by point
    for i = 1:size(X,1)
        dX = X(i, comb_r) - m(comb_r);   % i.e. subtract the m-1 esitimate
        m = m + (X(i,:) - m) / (n + i);  % now update m
        s = s + (X(i, comb_l) - m(comb_l)) .* dX;
    end
    
    % how many points now
    n = n + size(X,1);
    n_div = [repmat(n-1, 1, n_dims), repmat(n, 1, numel(comb_l) - n_dims)];

    % and current estimate
    x_cov = zeros(n_dims);
    if (n >= 2)
        x_cov = zeros(n_dims);
        ind_a = comb_l + (comb_r-1) * n_dims;
        ind_b = comb_r + (comb_l-1) * n_dims;
        x_cov(ind_a) = s ./ n_div;
        x_cov(ind_b) = x_cov(ind_a);  % give it symetry
    end
end

function n_cross = CREcrossings(X, use_median)
% function n_cross = CREcrossings(X, use_median)
% function to count the crossings
% of:
% the median (if use_median is true)
% zero (if use_median is false)

% are there enough points?
if (size(X,1) < 3)
    n_cross = 0;
    return;
end

% get median values
if (use_median)
    X = bsxfun(@minus, X, median(X,1));
end

% assign values = 0 to the last non zero value
n_cross = zeros(1, size(X,2));
for i = 1:size(X,2)
    
    % assign -1,0,1 depending on the side of the median
    value = sign(X(:,i));
    
    % zeros are a PITA because they can go either way
    % so, replace all runs of zeros
    is_zero = (value == 0);
    if any(is_zero)  && ~all(is_zero)
    
        % break into runs
        dX = diff(is_zero);
        run_start = find(dX == 1);
        run_end = find(dX == -1);
        
        % was the first entry a zero (i.e. no run start for it)
        if (is_zero(1))
            value(1:run_end(1)) = value(run_end(1)+1);
            run_end = run_end(2:end);
        end
        
        % was the last entry a zero (i.e. no run end for it)
        if (is_zero(end))
            value(run_start(end)+1:end) = value(run_start(end));
            run_start = run_start(1:end-1);
        end
        
        % now the runs should be paired so modify
        for j = 1:numel(run_start)
            value(run_start(j)+1:run_end(j)) = value(run_start(j));
        end
    end
    
    % now count the number of sign changes in values
    n_cross(i) = sum(abs(diff(value))) / 2;  % divide by two becuase it goes -1 -> 1
    
    
end



function y = CREfft(X, fs, fr)
% function y = CREfft(X, fs, fr)
% fft calcualtion (returns full spectrum)

% maximum number of fft bins to use
max_nfft = 512;
    
% the maximum achievable resolution
min_res = fs / size(X,1);
if (min_res > fr) && (fr > 0)
    nfft = size(X,1);  % use the highest resolution possible
elseif (fr == 0)
    nfft = min(size(X,1), max_nfft);
else
    nfft = round(fs / fr);
end

% now do the fft (divide by 1/n in ifft)
y = fft(X, nfft, 1);
y(1) = 0;  % 0 dc


function y = CREsort(X)
% function y = CREsort(X)
% function to sort data (no running function supplied)

y = sort(X,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These functions act on the output of their prerequsite function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function x_est = CREsum(moments, n)
% function x_est = CREsum(moments, n)
% sum calculation, uses the output of CREmoments

x_est = moments{1} * n;  % the mean times the number of samples


function x_est = CREmean(moments, n)
% function x_est = CREmean(moments, n)
% mean calculation, uses the output of CREmoments

x_est = moments{1};  % the mean is the first moment

function std = CREstd(moments, n)
% function std = CREstd(moments, n)
% this function takes the output of the moments function

% go from the 2nd moment to the unbiased varaince estimate
xvar = moments{2} * (n / (n - 1));
std = sqrt(xvar);

function cv = CREcoeffvar(moments, n)
% function cv = CREcoeffvar(moments, n)
% function to calculate the coefficient of variation
% this function takes the output of the moments function

% go from the 2cd moment to the unbiased variance estimate
xvar = moments{2} * (n / (n - 1));
std = sqrt(xvar);

% and turn them into coefficients of variation
cv = std ./ abs(moments{1});


function skew = CREskew(moments, n)
% function skew = CREskew(moments, n)
% function to calculate skewness using the moments

skew = moments{3} ./ (moments{2}.^1.5);

function kurt = CREkurt(moments, n)
% function skew = CREskew(moments, n)
% function to calculate excess kurtosis using the moments

kurt = moments{4} ./ (moments{2}.*moments{2}) - 3;



function x_est = CREpeaktopeak(x_max, x_min, varargin)
% function x_est = CREpeaktopeak(x_max, x_min, varargin)
% the function uses the outputs of the max and min functions

x_est = x_max - x_min;


function rho = CRExcorr(x_cov, n, varargin)
% function rho = CREcorr(x_cov, n, varargin)
% this function takes the output of the covariance function

% how many dimensions?
n_dims = size(x_cov, 1);

% maintain order by using nchoosek
combs = nchoose2(n_dims);

% covariance indexes in x_cov
co_inds = combs(:,1) + (combs(:,2)-1) * n_dims;

% variance indexes in x_cov
var_inds_l = combs(:,1) + (combs(:,1)-1) * n_dims;
var_inds_r = combs(:,2) + (combs(:,2)-1) * n_dims;

% Zeros are better than NaNs for dims with no variance
x_cov(var_inds_l) = max(x_cov(var_inds_l), eps);
x_cov(var_inds_r) = max(x_cov(var_inds_r), eps);

% turn the covaraince into correlations (correct for variances divided by n-1 so rho = 1 is possible)
rho = n * x_cov(co_inds) ./ sqrt((n-1)*(n-1) * x_cov(var_inds_l) .* x_cov(var_inds_r));
rho = reshape(rho, 1, numel(rho));



function f = CREdomFreq(Y, n, index, fl, fh, fs, varargin)
% function F = CREdomFreq(Y, n, index, fl, fh, fs, varargin)
% function to calculate the dominant frequency
% takes the output of CREfft as input Y

% build the frequency vector corresponding to Y
n = size(Y,1);
f_vec = (fs / n) * (0:n-1);

% find the frequencies in range
bounds(1) = find(f_vec >= fl, 1, 'first');
bounds(2) = find(f_vec <= fh, 1, 'last');

% the magnitude of the fft
mag = sqrt(Y.*conj(Y));

% apply bounds
mag(1:bounds(1)-1, :) = -1;
mag(bounds(2)+1:end, :) = -1;

if (index == 1)
    % its max
    [max_mag, ind] = max(mag, [], 1);
else
    % its ith max
    [Msort, order] = sort(mag, 1, 'descend');
    ind = order(index, :);
end

% the maximum frequecy is then
f = f_vec(ind);


function M = CREdomFreqMag(Y, n, index, fl, fh, fs, varargin)
% function F = CREdomFreqMag(Y, n, index, fl, fh, tmp, n, varargin)
% function to calculate the magnitude of the dominant frequency
% takes the output of CREfft as input Y

% build the frequency vector corresponding to Y
n = size(Y,1);
f_vec = (fs / n) * (0:n-1);

% find the frequencies in range
bounds(1) = find(f_vec >= fl, 1, 'first');
bounds(2) = find(f_vec <= fh, 1, 'last');

% the magnitude of the fft
mag = sqrt(Y.*conj(Y));

% apply bounds
mag(1:bounds(1)-1, :) = -1;
mag(bounds(2)+1:end, :) = -1;


if (index == 1)
    % its max
    M = max(mag, [], 1);
else
    % its ith max
    Msort = sort(mag, 1, 'descend');
    M = Msort(index,:);
end

% normalize the magnitude (use the ACTGraph definition of the fft normalization)
M = 2*M / n;


function R = CREdomFreqRat(Y, n, index, fl, fh, fs, varargin)
% function R = CREdomFreqRat(Y, n, index, fl, fh, tmp, n, varargin)
% function to calculate the magnitude of the dominant frequency
% takes the output of CREfft as input Y

% build the frequency vector corresponding to Y
n = size(Y,1);
f_vec = (fs / n) * (0:n-1);

% find the frequencies in range
bounds(1) = find(f_vec >= fl, 1, 'first');
bounds(2) = find(f_vec <= fh, 1, 'last');

% the magnitude of the fft
mag = sqrt(Y.*conj(Y));
P = sum(mag(1:ceil(n/2), :), 1);  % total power

% apply bounds
mag(1:bounds(1)-1, :) = -1;
mag(bounds(2)+1:end, :) = -1;


if (index == 1)
    % its max
    M = max(mag, [], 1);
else
    % its ith max
    Msort = sort(mag, 1, 'descend');
    M = Msort(index,:);
end

% percentage power in this index
R = (M ./ P) * 100;

function E = CREentropy(Y, n, fl, fh, fs, varargin)
% function E = CREentropy(Y, n, fl, fh, fs, varargin)
% function to calculate the entropy
% takes the output of CREfft as input Y

% build the frequency vector corresponding to Y
n = size(Y,1);
f_vec = (fs / n) * (0:n-1);
f_vec = f_vec(:);

% find the frequencies in range
bounds(1) = find(f_vec >= fl, 1, 'first');
bounds(2) = min(find(f_vec <= fh, 1, 'last'), ceil(n/2));

% calculate the square magnitude from the fft
mag_sq = Y.*conj(Y);

% only interested in the half spectrum
mag_sq = mag_sq(1:ceil(n/2), :);
mag_sq = max(mag_sq, 1e-15);  % rounding protection

% normalize the probability mass function by the full half spectrum
pmf = bsxfun(@rdivide, mag_sq, sum(mag_sq,1)); 

% now calculate the entropy in the desired band
pmf = pmf(bounds(1):bounds(2), :);
E = -sum(pmf .* log(pmf));


function acf = CREacorr(Y, n, lag_ms, fs, varargin)
% function acf = CREacorr(Y, n, lag_ms, fs, varargin)
% function to calculate the autocorrelation at lag lag
% input Y is the FFT

lag_samples = ceil(lag_ms * 1e-3 * fs);

Y(1,:) = 0;          % mean correct
Y = Y.*conj(Y);    % get power
acf = ifft(Y);
acf = bsxfun(@rdivide, acf, acf(1,:)); % Normalize

% and get it at the lag of interest
acf = real(acf(min(lag_samples+1, size(acf,1)), :));

% acf values can be none if there was 0 variance.  Set the acf to 0 in this
% case
acf(isnan(acf)) = 0;


function value = CREpercentile(Y, n, percent)
% function y = CREpercentile(Y, n, percent);
% function to calculate the value of a particular quantile range
% input Y is sorted by CREsort

n_obs = size(Y,1);
row = n_obs * (percent / 100) + .5;  % desired row to get

if (row <= 1)
    value = Y(1,:);
elseif (row >= n_obs)
    value = Y(end,:);
elseif (row == round(row))
    value = Y(row,:);
else
    % linear interpolation
    rmin = floor(row);
    rmax = ceil(row);
    factmax = row - rmin;
    factmin = 1 - factmax;
    value = factmin * Y(rmin,:) + factmax * Y(rmax,:);
end


function value = CREinterquartile(Y, n, varargin)
% function value = CREinterquartile(Y, n, varargin)
% function to calculate the interquartile range
% input Y is sorted by CREsort

% get the 25% and 75% 
value_q1 = CREpercentile(Y, n, 25);
value_q3 = CREpercentile(Y, n, 75);

% and the difference
value = value_q3 - value_q1;






