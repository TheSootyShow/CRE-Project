function output = IsFreqDependentFeature(feature)
% function output = IsFreqDependentFeature(feature)
% function to test if the inputted feature is dependent upon a frequency
% range

% all off them that use fft as a prereq
output = any(strcmpi(feature.prereq_name, 'fft')) && ~strcmpi(feature.name, 'auto correlation');  % always an exception