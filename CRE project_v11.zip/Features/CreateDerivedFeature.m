function derived_feat = CreateDerivedFeature(type, input_names, featSettings)
% function derived_feat = CreateDerivedFeature(type)
% function derived_feat = CreateDerivedFeature(type, input_names, featSettings)
% function to create the structure containing a derived feature
% 
%%%%%%%%%%%%%%%%
% Inputs
%%%%%%%%%%%%%%%%
%
% type           - the type of derived feature
%
% input_names    - a list of the names of the inputs to this function
%
% featSettings  - feature setting structure.  All name in input_names
%                  should be identifiable in this structure

% initialise the output feature
derived_feat = InitDerivedFeature();

if strcmpi(type, 'absolute')
    func = @(X, varargin)(abs(X));
    tag = 'abs(%s)';
    wrap = false;  % wrap input feature in brackets

elseif strcmpi(type, 'square')
    func = @(X, varargin)(X.*X);
    tag = '%s^2';
    wrap = true;  % wrap input feature in brackets
    
elseif strcmpi(type, 'ratio')
    func = @(X, Y, varargin)(X ./ Y);
    tag = '%s / %s';
    wrap = true;  % wrap input feature in brackets

elseif strcmpi(type, 'magnitude')
    func = @(varargin)(sqrt(sum(cell2mat(varargin).^2)));
    tag = 'mag(%s)';
    rp_pattern = ', %s';
    wrap = false;  % wrap input feature in brackets

elseif strcmpi(type, 'sum')
    func = @(varargin)(sum(cell2mat(varargin)));
    tag = '%s';
    rp_pattern = '+ %s';
    wrap = true;  % wrap input feature in brackets

elseif strcmpi(type, 'sumsquares')
    func = @(varargin)(sqrt(sum(cell2mat(varargin).^2)));
    tag = '%s^2';
    rp_pattern = '+ %s^2';
    wrap = true;  % wrap input feature in brackets

else
    errordlg(sprintf('Unknown secondary dimensions type: %s', type), 'Unknown type');
    return;
end

derived_feat.type = type;
derived_feat.func = func;

% add sources if available
if (nargin > 2)
    
    % fill in where the inputs come from
    derived_feat.input_features = feat_names;
    derived_feat.input_dims = dim_names;
    
    % create the name
    n_spots = numel(regexp(tag, '%s'));
    new_feat.name = sprintf(tag, sources{1:n_spots});
    for i = n_spots + 1:numel(sources)
        new_feat.name = sprintf(['%s', rp_pattern], new_feat.name, sources{i});
    end
    
    
end