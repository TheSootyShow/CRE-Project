function DemoFeatureFigure()
% function DemoFeatureFigure()
% function to create a demo figure to illustrate dimensions vs 
% features

% a figure for it
hFig = figure('InvertHardCopy', 'on', 'name', 'DemoFeatureFigure', 'toolbar', 'none', 'color', 'white');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create labels
hDataTxt = uicontrol(hFig, 'style', 'text', 'string', 'Data Set', 'backgroundcolor', 'white', 'fontsize', 12, 'FontWeight', 'bold', 'horizontalalignment', 'left');
hPrimDimTxt = uicontrol(hFig, 'style', 'text', 'string', 'Primary Dimensions', 'backgroundcolor', 'white', 'fontsize', 10, 'horizontalalignment', 'left', 'FontWeight', 'bold');
hSecDimTxt = uicontrol(hFig, 'style', 'text', 'string', 'Secondary Dimensions', 'backgroundcolor', 'white', 'fontsize', 10, 'horizontalalignment', 'center', 'FontWeight', 'bold');


% data for tables
pX = 2*abs(randn(20,3));    % random data for primary dimensions
sX = sqrt(sum(pX.*pX,2));   % use magntitude as a secondary dimensions

% and times
pX = [(0:.1:1.9).',  pX];

% combine them with a blank column
dX = [num2cell(pX), repmat({'...'}, size(pX,1) ,1), num2cell(sX), repmat({'...'}, size(pX,1), 1)];
dX(end+1,:) = {'...'};

% table formats
colNames = {'Time (s)', 'X','Y','Z', '...', 'Magnitude', '...'};
colFormat = repmat({'char'}, 1, size(dX,2));


% create the primary dimension table
hDimTable = uitable('Parent', hFig, 'Data', dX, 'ColumnName', colNames, 'ColumnFormat', colFormat, 'units', 'pixels', 'position', [1,1,300,300]);
[tmp, dimX, dimY] = uiTableSize(hDimTable);  % size it

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Add features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create labels
hFeatSetTxt = uicontrol(hFig, 'style', 'text', 'string', 'Feature Set', 'backgroundcolor', 'white', 'fontsize', 12, 'FontWeight', 'bold', 'horizontalalignment', 'left');
hFeatTxt = uicontrol(hFig, 'style', 'text', 'string', 'Features', 'backgroundcolor', 'white', 'fontsize', 10, 'horizontalalignment', 'left', 'FontWeight', 'bold');
hPostFeatTxt = uicontrol(hFig, 'style', 'text', 'string', 'Post Processed Features', 'backgroundcolor', 'white', 'fontsize', 10, 'horizontalalignment', 'right', 'FontWeight', 'bold');

% create the features table
featCols = {'Time (s)', 'E(X)','E(Y)','E(Z)', 'E(mag)', '...', 'E(Z) / E(mag)', '...'};
colFormat = repmat({'char'}, 1, numel(featCols));

ds = 10;  % 10 points per bin
pF = zeros(floor(size(pX,1)/ds), size(pX,2) + size(sX,2)); 
for i = 1:size(pF,1)
    idx = (i-1)*ds+1:i*ds;
    pF(i, :) = [pX(idx(1),1), mean(pX(idx,2:end),1), mean(sX(idx,1),1)];
end
postF = pF(:, 4) ./ pF(:, 5);

fX = [num2cell(pF), repmat({'...'}, size(pF,1) ,1), num2cell(postF), repmat({'...'}, size(pF,1), 1)];
fX(end+1, :) = {'...'};


% create the features table
hFeatTable = uitable('Parent', hFig,'Data', fX, 'ColumnName', featCols, 'ColumnFormat', colFormat, 'units', 'pixels');
[tmp, featX, featY] = uiTableSize(hFeatTable);  % size it

 
% create layout
hGrid = {hDataTxt,    [];             ...
         hPrimDimTxt, hSecDimTxt;     ...
         hDimTable,   [];             ...
         'v=4cm',     [];             ...
         hFeatSetTxt, [];             ...
         hFeatTxt,    hPostFeatTxt;   ...
         hFeatTable,  [];             ...
         'v=1cm',     []};

% and resize     
[tmp, figSize] = ResizePaneFromGrid(hGrid, [], [], false, true(1,2));

% get dodgy here...
tableImg = getframe(hFig);
dimPos = get(hDimTable, 'position');
dimX = dimX + dimPos(1);
dimY = dimY + dimPos(2);

featPos = get(hFeatTable, 'position');
featX = featX + featPos(1);
featY = featY + featPos(2);

hNonPlot = get(hFig, 'children');

% now create an axis and hide it
hAxis = axes('ActivePositionProperty', 'position', 'units', 'pixels', 'position', [1,1,figSize], 'xtick', [], 'ytick', [], 'xlim', [0, figSize(1)], 'ylim', [0, figSize(2)], 'nextplot', 'add', 'visible', 'on', 'ydir', 'reverse');
uistack(hAxis, 'top');
image(tableImg.cdata, 'parent', hAxis);

% we reverse ydir for the image so
dimY = figSize(2) - dimY;
featY = figSize(2) - featY;

% the plot can never be in fron of the uicontrols so do this
delete(hNonPlot);
     
     
% add some rectangles to highlight dimension calculations
lhd = drawboxpair(dimX, dimY, [3,7], [6,8], [2,2], [3,3], 'g', 2, figSize, 0,0,0);
drawboxpair(dimX, dimY, [3,7], [6,8], [3,3], [4,4], 'g', 2, figSize, 0,0,0);

xOff = -2;
yOff = -2;
bend = 2 * (dimX(1,2) - dimX(1,1));

% add some rectangles to highlight feature calculations
drawboxpair({dimX, featX}, {dimY, featY}, [3,3], [4,4], [2,2], [12,3], 'b', 2, figSize, xOff, yOff, -bend);
drawboxpair({dimX, featX}, {dimY, featY}, [3,3], [4,4], [12,3], [22,4], 'b', 2, figSize, xOff, 1, bend);
lhf = drawboxpair({dimX, featX}, {dimY, featY}, [7,6], [8,7], [2,2], [12,3], 'b', 2, figSize, xOff, yOff, 0);

% add some rectangles to highlight post features
phd = drawboxpair(featX, featY, [5,8], [7,9], [2,2], [3,3], 'r', 2, figSize, 0,0, 0);
drawboxpair(featX, featY, [5,8], [7,9], [3,3], [4,4], 'r', 2, figSize, 0,0, 0);

legend([lhd, lhf, phd], {'Secondary Dimension Calculation', 'Feature Calculation', 'Post Processing Calculation'});


function lh = drawboxpair(xGrid, yGrid, li, ri, ti, bi, color, width, axisSize, xOffset, yOffset, bend)
% function lh = drawboxpair(xGrid, yGrid, li, ri, ti, bi, color, width, axisSize, xOffset, yOffset, bend)
% function to draw a pair of boxes with an arrow between them

if ~iscell(xGrid)
    xGrid = {xGrid, xGrid};
    yGrid = {yGrid, yGrid};
end
    

a_gap = 5;

% make vertices
xRect = cell(1,2);
yRect = cell(1,2);
bm = zeros(2,2);
for i = 1:2
    
    % rectangle vertices
    xRect{i} = [xGrid{i}(ti(i), li(i)), xGrid{i}(ti(i), ri(i)); xGrid{i}(bi(i), li(i)), xGrid{i}(bi(i), ri(i))];
    yRect{i} = [yGrid{i}(ti(i), li(i)), yGrid{i}(ti(i), ri(i)); yGrid{i}(bi(i), li(i)), yGrid{i}(bi(i), ri(i))];
    xRect{i} = xRect{i} + xOffset;
    yRect{i} = yRect{i} + yOffset;

    % and plot it
    lh =  PlotRect(xRect{i}, yRect{i}, color, width);
    bm(i, :) = [mean(xRect{i}(:)), mean(yRect{i}(:))];
end

% and draw an arrow in between
if (bend < 0)  % left curve, use left edges
    end_points = [mean(xRect{1}(:,1)), mean(yRect{1}(:,1)); ...
                      mean(xRect{2}(:,1)), max(yRect{2}(:,1))];
elseif (bend > 0)  % right curve, use right edges
    end_points = [mean(xRect{1}(:,2)), mean(yRect{1}(:,2)); ...
                      mean(xRect{2}(:,2)), max(yRect{2}(:,2))];

elseif (bm(1,2) ~= bm(2,2))
    if (bm(1,2) > bm(2,2))
        end_points = [mean(xRect{1}(1,:)), mean(yRect{1}(1,:)); ...
                      mean(xRect{2}(2,:)), mean(yRect{2}(2,:))];
    else
        end_points = [mean(xRect{1}(2,:)), mean(yRect{1}(2,:)); ...
                      mean(xRect{2}(1,:)), mean(yRect{2}(1,:))];
    end
else
    if (bm(1,1) > bm(2,1))
        end_points = [mean(xRect{1}(:,1)), mean(yRect{1}(:,1)); ...
                      mean(xRect{2}(:,2)), mean(yRect{2}(:,2))];
    else
        end_points = [mean(xRect{1}(:,2)), mean(yRect{1}(:,2)); ...
                      mean(xRect{2}(:,1)), mean(yRect{2}(:,1))];
    end
end

% make it so the arrows don't quite touch
if (bend == 0)
    da = end_points(2,:) - end_points(1,:);
    da = da / norm(da);
    end_points(1,:) = end_points(1,:) + da * a_gap;
    end_points(2,:) = end_points(2,:) - da * a_gap;
    
    % now make the arrow
    annotation('arrow',end_points(:,1) / axisSize(1), 1 - (end_points(:,2) / axisSize(2)), 'color', color);
    
else
    mp = mean(end_points,1);
    mp(1) = mp(1) + bend;

    % use a quadric approximation
    sv(:,1) = ones(3,1);
    sv(:,2) = [0;.5;1];
    sv(:,3) = sv(:,2) .*sv(:,2);
    x = [end_points(1,1); mp(1,1); end_points(2,1)];
    y = [end_points(1,2); mp(1,2); end_points(2,2)];
    cx = sv \ x;
    cy = sv \ y;
    
    svec = .05:.01:.99;
    x = cx(3)*svec.*svec + cx(2) * svec + cx(1);
    y = cy(3)*svec.*svec + cy(2) * svec + cy(1);
    
    plot(x(1:end-1), y(1:end-1), 'color', color);
    annotation('arrow', x(end-1:end) / axisSize(1), 1 - (y(end-1:end) / axisSize(2)), 'color', color);
    
    
end


        



     
         
function lh = PlotRect(X, Y, color, width)
% function lh = PlotRect(X, Y, color, width)
% function to plot a rectangle

xv = [X(1,1), X(1,2),X(2,2), X(2,1), X(1,1)] - width;
yv = [Y(1,1), Y(1,2),Y(2,2), Y(2,1), Y(1,1)] + width;
lh = plot(xv, yv, 'color', color, 'linewidth', width);
uistack(lh, 'top');






