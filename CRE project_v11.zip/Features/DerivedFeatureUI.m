function [featSettings, names] = DerivedFeatureUI(featSettings, create_type, prompt_types)
% function [featSettings, names] = DerivedFeatureUI(featSettings, create_type, prompt_types)
% function to create an interactive display for the user create
% new secondary dimensions
% output "names" are the names of all new dimensions
% fs only required for wavelet

% default
names = {};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If no specific type has been inputted, prompt the user
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 2) || (numel(create_type) == 0)
    
    % all the known types
    known_types = GetKnownSecondaryDimTypes(featSettings.dimInfo);
    
    if (nargin < 3)
        prompt_types = known_types;
    end
    
    % prompt the user
    [resp, selection] = CREListDlg(prompt_types, 'title', 'Create Derived Feature', 'list_title', 'Feature Type:', 'list_multi', false);
    
    % did the user repond with OK?
    if strcmpi(resp, 'OK')
        create_type = prompt_types{selection};
    else
        return;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If no features have been added, only allow constant to be
% selected
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~strcmpi(create_type, 'Constant')
    if (numel(featSettings.features) == 0)
        msgbox('Please select a feature before choosing a (non constant) post processing features', 'No features selected', 'modal')
        return;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% first get the names of all the dimensions currently known
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% turn dim info into the final version
grab_dims = ParseDimInfo(featSettings.dimInfo);
prim_selected = grab_dims.primary_name(grab_dims.primary_disp);
deric_selected = grab_dims.derived_name(grab_dims.derived_disp);
dim_names = [prim_selected(:); deric_selected(:)];


% turn these into names for all of the non derived features
[feat_names, featSettings.features, opf] = CompleteFeatureList(featSettings, true);
feat_names_no_alias = CompleteFeatureList(featSettings, false);
outputs_per_feat = [0; cumsum(opf(:))];





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now prompt the user for which existsing dimensions the new
% secondary dimensions should be a function of
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% default options for the various queries
multi_select = false;  % only ever operates on 1 dim


% prompt the user
if strcmpi(create_type, 'absolute')
    [resp, selection] = CREListDlg(feat_names, 'title', 'Absolute', 'list_title', 'Absolute values of:');
    func = @(X, varargin)(abs(X));
    tag = 'abs(%s)';
    wrap = false;  % wrap input feature in brackets

elseif strcmpi(create_type, 'square')
    [resp, selection] = CREListDlg(feat_names, 'title', 'Square', 'list_title', 'Square features:');
    func = @(X, varargin)(X.*X);
    tag = '%s^2';
    wrap = true;  % wrap input feature in brackets
    
elseif strcmpi(create_type, 'ratio')
    [resp, num, den] = CRERatioGUI(feat_names);
    func = @(X, varargin)(X(:,1)./X(:,2));
    selection = [find(strcmpi(num, feat_names)), find(strcmpi(den, feat_names))];
    multi_select = true;  % take multiples inputs    
    tag = '%s / %s';
    wrap = true;  % wrap input feature in brackets

elseif strcmpi(create_type, 'magnitude')
    [resp, selection] = CREListDlg(feat_names, 'title', 'Magnitudes', 'list_title', 'Magnitude of:');
    func = @(X, varargin)(sqrt(sum(X(:).^2)));
    multi_select = true;  % take multiples inputs
    tag = 'mag(%s)';
    rp_pattern = ', %s';
    wrap = false;  % wrap input feature in brackets

elseif strcmpi(create_type, 'sum')
    [resp, selection] = CREListDlg(feat_names, 'title', 'Summation', 'list_title', 'Sum features:');
    func = @(X, varargin)(sum(X(:)));
    multi_select = true;  % take multiples inputs
    tag = '%s';
    rp_pattern = '+ %s';
    wrap = true;  % wrap input feature in brackets

elseif strcmpi(create_type, 'sumsquares')
    [resp, selection] = CREListDlg(feat_names, 'title', 'Sum of Squares', 'list_title', 'Sum the squares of features:');
    func = @(X, varargin)(sum(X(:).*X(:)));
    multi_select = true;  % take multiples inputs
    tag = '%s^2';
    rp_pattern = '+ %s^2';
    wrap = true;  % wrap input feature in brackets
    
elseif strcmpi(create_type, 'constant')
    
    % special case for constants
    answer = inputdlg({'Name (e.g. weight)', 'Value'}, 'Enter a constant value for the data', 1);
    resp = 'Cancel';
    selection = [];
    if (numel(answer) == 2)
        if (numel(answer{1}) == 0)
            errordlg('Please enter a name for the constant');
        else
            value = str2double(answer{2});
            if isnan(value)
                errordlg(sprintf('Can not convert the string "%s" to a numeric value', answer{2}));
            else
            resp = 'OK';
            func = @(X, varargin)(value);
            multi_select = true;  % take no inputs
            tag = answer{1};
            rp_pattern = '';
            wrap = false;
            end
        end
    end
else
    errordlg(sprintf('Unknown feature type: %s', create_type), 'Unknown type');
    return;
end


% get the names of the source dimensions
sources = feat_names_no_alias(selection);
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now update dimInfo with user selections
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% did the user repond with OK?
if strcmpi(resp, 'OK')
    
    % cast selection into a cell array
    if (multi_select)
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Adding a dimensions that's a function
        % of multiple dimensions
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % build it
        new_feat = InitDerivedFeature();
        new_feat.func = func;
        new_feat.type = create_type;
        new_feat.input_feats = cell(1, numel(sources));
        new_feat.input_dims = cell(1, numel(sources));
        new_feat.display = true;
                
        % find where the sources come from, and build a name
        for i = 1:numel(sources)
            feat_ind = find(selection(i) <= outputs_per_feat,1, 'first') - 1;
            if (feat_ind <= numel(featSettings.features))
                dim_ind = selection(i) - outputs_per_feat(feat_ind);
                new_feat.input_feats{i} = featSettings.features(feat_ind).name;
                new_feat.input_dims{i} = dim_names{dim_ind};
                new_feat.input_args{i} = featSettings.features(feat_ind).input_args;
            else
                % its a derived feature so it has no dimension
                new_feat.input_feats = sources(i);
            end
        
            % wrap the sources if desired
            if (wrap)
                sources{i} = WrapInBrackets(sources{i});
            end
        end
        
        % create the name
        n_spots = numel(regexp(tag, '%s'));
        new_feat.name = sprintf(tag, sources{1:n_spots});
        for i = n_spots + 1:numel(sources)
            new_feat.name = sprintf(['%s', rp_pattern], new_feat.name, sources{i});
        end
        
        % check it doesn't match any existing dimensions
        if ~any(strcmpi(new_feat.name, [feat_names_no_alias(:); names(:)]))
    
            % add it
            featSettings.postFeatures(end + 1,1) = new_feat;
            names{end+1} = new_feat.name;
            
        else
            
            % tell the user the specified feature exists
            FeatureExistsMessage(new_feat.name, featSettings.dimInfo.aliases, featSettings.aliases);
            
        end
        
    else
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Adding a dimensions that's a function
        % of only dimensions.  Multiple selctions mean
        % create more than one new dimension
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        % go through them one by one - they are all different
        for i = 1:numel(selection)
            
            % build it
            new_feat = InitDerivedFeature();
            new_feat.type = create_type;
            new_feat.func = func;
            new_feat.input_features = cell(1, numel(sources));
            new_feat.input_dims = cell(1, numel(sources));
            new_feat.display = true;
            
            % find where the sources come from, and build a name
            feat_ind = find(selection(i) <= outputs_per_feat,1, 'first')-1;
            if (feat_ind <= numel(featSettings.features))
                dim_ind = selection(i) - outputs_per_feat(feat_ind);
                new_feat.input_feats = {featSettings.features(feat_ind).name};
                new_feat.input_dims = dim_names(dim_ind);
                new_feat.input_args = {featSettings.features(feat_ind).input_args};
            else
                % its a derived feature so it has no dimension
                new_feat.input_feats = sources(i);
            end
            
            % wrap the sources if desired
            if (wrap)
                sources{i} = WrapInBrackets(sources{i});
            end
            
            % create the name
            new_feat.name = sprintf(tag, sources{i});
            
            % check it doesn't match any existing dimensions
            if ~any(strcmpi(new_feat.name, [feat_names_no_alias(:); names(:)]))
                
                % add it
                featSettings.postFeatures(end + 1,1) = new_feat;
                names{end+1} = new_feat.name;
                
            else

                % tell the user the specified feature exists
                FeatureExistsMessage(new_feat.name, featSettings.dimInfo.aliases, featSettings.aliases);
                
            end
        end
    end
end




function FeatureExistsMessage(feat_name, dim_aliases, feat_aliases)
% function FeatureExistsMessage(feat_name, dim_aliases, feat_aliases)
% function to tell the user that the feature they've attempted to add
% already exists

% give the feature its aliased name
feat_name = ApplyKnownDimAliases(feat_name, dim_aliases);
feat_name = ApplyKnownDimAliases(feat_name, feat_aliases);

% tell the user
msgbox(sprintf('Feature %s already exists', feat_name), 'Existing Feature', 'modal');











