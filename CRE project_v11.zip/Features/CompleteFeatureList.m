function [feat_list, features, idx] = CompleteFeatureList(featSettings, use_alias)
% function [feat_list, features, opf] = CompleteFeatureList(featSettings, use_alias)
% function to return a list of all calculated features from the feature
% settings

if (nargin < 2) || (numel(use_alias) == 0)
    use_alias = true;
end

if (numel(featSettings.features) == 0) && (numel(featSettings.postFeatures) == 0)
    feat_list = {};
    features = featSettings.features;
    idx = [];
    return;
end

% Parse the dimensions
dims_processed = ParseDimInfo(featSettings.dimInfo);

% how many are there?
n_dims = sum(dims_processed.primary_disp) + sum(dims_processed.derived_disp);  
dim_names = [dims_processed.primary_name(dims_processed.primary_disp), dims_processed.derived_name(dims_processed.derived_disp)];
dim_vec = 1:n_dims;

% apply dimension aliases to dim names
if (use_alias)
    dim_names = ApplyKnownDimAliases(dim_names, featSettings.dimInfo.aliases);
end

% Parse the features
features = ParseFeatures(featSettings.features);

% turn these into names for all of the non derived features
% how many features
n_feats = numel(features);

% and keep track of which columns it uses
indiv_list = cell(1, n_feats);

% and go through them
for i = 1:n_feats
    
    % fill in the column numbers
    if (~features(i).prereq_only)
        
        % how many outputs?
        order = nchoosek(dim_vec, features(i).n_interact);
    
        % and generate the names
        indiv_list{i} = cell(1, size(order,1));
        for j = 1:size(order,1)
        
            % original dimension names
            terms = dim_names(order(j,:));
        
            % parse them into the feature's string
            indiv_list{i}{j} = sprintf(features(i).label_str, terms{:});

        end
    end
end

% feature dimension interactions for each feature
idx = cellfun(@numel, indiv_list);

% put dim names into a more convenient shape
feat_list = [indiv_list{:}];

% add the derived features to the list
derived_names = {featSettings.postFeatures(:).name};
derived_disp = [featSettings.postFeatures(:).display];
derived_names = derived_names(derived_disp);


% apply dimension aliases to dim names in the derived features
if (use_alias)
    derived_names = ApplyKnownDimAliases(derived_names, featSettings.dimInfo.aliases);
end

% and append
feat_list = [feat_list(:); derived_names(:)];
idx(end+1:end+numel(derived_names)) = 1;

% apply known aliases to the list
if (use_alias)
    feat_list = ApplyKnownFeatAliases(feat_list, featSettings.aliases);
end





    