function handles = CREFeatureGuiLayout(hObject, eventdata, handles)
% hObject    handle to FeatureGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent resizing

% check its not already resizing
if (numel(resizing) == 0) || (~resizing)
    
    % dont try it twice at once
    resizing = true;
    
    % cover it to prevent epillepsy
    if strcmpi(get(hObject, 'visible'), 'on')
        hCover = CoverFig(hObject);
    else
        hCover = [];
    end

    % Get the default gaps to use
    [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
    % to facilitate sizing
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % resize each of the tabs
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % Build the time tab
    [hTabPanels(1), panelSizes(1,:)] = BuildTimeTab(handles, smallGap, normGap, largeGap);
    
    % the dimensions tab
    [hTabPanels(2), panelSizes(2,:)] = BuildDimTab(handles, smallGap, normGap, largeGap);
    
    % the features pane
    [hTabPanels(3), panelSizes(3,:)] = BuildFeatureTab(handles, smallGap, normGap, largeGap);
    
    % the post processing pane
    [hTabPanels(4), panelSizes(4,:)] = BuildPostProcessTab(handles, smallGap, normGap, largeGap);
        
    % the output file pane
    [hTabPanels(5), panelSizes(5,:)] = BuildOutputTab(handles, smallGap, normGap, largeGap);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % now set the sizes of the tabs / tab groups
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % this function sets up the tabs / tab groups
    hTabs = cell2mat(get(hTabPanels, 'parent'));
    [tgSize, tabSize] = setTabGroupSize(hTabs, panelSizes);
    
    % match the display feature size to it
    [paneGap, paneBorder] = DefaultGuiBorders();
    lbFeatSize = [ceil(6*ppcm), tabSize(2) - sum(paneBorder([2,4])) - GetPanelTextHeight(handles.uiFeatureDisp, true)];
    [tmp, featDispSize] = ResizePaneFromGrid({handles.lbAllFeats}, [], [], {lbFeatSize});
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % now resize the figure
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % the layout
    figLayout = {'b', []; handles.tgMainTab, handles.uiFeatureDisp; handles.pbCancel, handles.pbOK};
    figSizes = {[], []; tgSize, featDispSize; [], []};
    
    % now call the resize function
    hGlobalPane = ResizeFigFromPanes(figLayout, {}, {}, figSizes);
    
    % shift the display feature "up"
    desTop = GetRelativePosition(hTabs(1), handles.uiFeatureGui);
    desTop = desTop(2) + desTop(4) - 1;
    dispPos = get(handles.uiFeatureDisp, 'position');
    dy = (desTop + GetPanelTextHeight(handles.uiFeatureDisp, true)) - (dispPos(2) + dispPos(4)-1);
    dispPos(2) = dispPos(2) + dy;
    set(handles.uiFeatureDisp, 'position', dispPos);
   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % save the resized figure if applicable
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if numel(hCover)
        delete(hCover)
    end
    
    handles = SaveResizedCREFigure(hObject, [], handles);
   
    % clear it
    resizing = false;
    
end
    
% make sure any warnings are visible
if isfield(handles, 'warn_fig') && numel(handles.warn_fig)
%     if ishandle(handles.warn_fig)
%         drawnow();
%         figure(handles.warn_fig);
%     end
%     handles.warn_fig = [];
end

if (nargout == 0)
    guidata(hObject, handles);
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function to build the time tabs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hPanel, panelSize] = BuildTimeTab(handles, smallGap, normGap, largeGap)
% function [hTimeTab, tabSize] = BuildTimeTab(handles, smallGap, normGap, largeGap)
% funciton to contrust the time tab
    
% the range pane (N.B. this pane is used by other gui so the below code is
% external to this file)
[hGrid,  hGap, vGap, timeSizes] = DefaultRangePaneLayout(handles, smallGap, normGap, largeGap);
[hTimePanel, timeSize] = ResizeFigFromPanes(hGrid, hGap, vGap, timeSizes, false);
hTimePanel = get(hTimePanel{1}, 'parent');

% the bin duration pane
[hBinPanel, binSize] = DefaultBinPaneLayout(handles, smallGap, normGap, largeGap);

% not do the tab pane
[hPanel, panelSize] = ResizePaneFromGrid({hTimePanel, hBinPanel}, [], [], {timeSize, binSize});

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The dimensions tab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hPanel, panelSize] = BuildDimTab(handles, smallGap, normGap, largeGap)
% function [hTimeTab, tabSize] = BuildTimeTab(handles, smallGap, normGap, largeGap)
% funciton to contrust the time tab
    
% the range pane (N.B. this pane is used by other gui so the below code is
% external to this file)
[hGrid,  hGap, vGap, timeSizes] = DefaultDimPaneLayout(handles, smallGap, normGap, largeGap);
[hDimPanel, panelSize] = ResizeFigFromPanes(hGrid, hGap, vGap, timeSizes, false);
hPanel = get(hDimPanel{1}, 'parent');





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The feature tab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hPanel, panelSize] = BuildFeatureTab(handles, smallGap, normGap, largeGap)
% function [hPanel, panelSize] = BuildFeatureTab(handles, smallGap, normGap, largeGap)
% funciton to build the feature tab
    
% use the inbuilt sizing
[hGrid,  hGap, vGap, timeSizes] = DefaultFeatPaneLayout(handles, smallGap, normGap, largeGap);
[hFeatPanel, panelSize] = ResizeFigFromPanes(hGrid, hGap, vGap, timeSizes, false);            % apply sizing function
hPanel = get(hFeatPanel{1}, 'parent');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The post processing tab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hPanel, panelSize] = BuildPostProcessTab(handles, smallGap, normGap, largeGap)
% function [hPanel, panelSize]= BuildPostProcessTab(handles, smallGap, normGap, largeGap)
% function to build the layout for the post processing tab

% call the default layout function
[hGrid,  hGap, vGap, sizes] = DefaultPostPaneLayout(handles, smallGap, normGap, largeGap);

% and resize it
[hPanel, panelSize] = ResizePaneFromGrid(hGrid, hGap, vGap, sizes);

    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the output tab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hPanel, panelSize] = BuildOutputTab(handles, smallGap, normGap, largeGap)
% function [hTab, tabSize, old_txt] = BuildOutputTab(handles, smallGap, normGap, largeGap)

[hGrid,  hGap, vGap, sizes] = DefaultExportPaneLayout(handles, smallGap, normGap, largeGap);

% and resize it
[hPanel, panelSize] = ResizePaneFromGrid(hGrid, hGap, vGap, sizes);

















%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build a grid of ui components for bin pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [hTab, tabSize] = DefaultBinPaneLayout(handles, smallGap, normGap, largeGap)
% function [hGrid, h_gap, v_gap, sizes] = DefaultBinPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the layout for the data bin pane

% set up the matrix of handles
hGrid = cell(5,3);
hGrid(1,1:3) = {handles.rbGlobal};
hGrid(2,1:3) = {handles.rbBinData};
hGrid(3,2:3) = {handles.txtBinDuration, handles.ebBinDuration};
hGrid(4,2:3) = {handles.txtBinAlignment, handles.pmBinTime};
hGrid(5,2:3) = {handles.txtBinPointsLabel, handles.txtBinPoints};

% gaps between components horizontally
hGap = repmat(normGap, size(hGrid,1), size(hGrid,2) - 1);
hGap(3:4,1) = 1.5*largeGap;  % leave a very large space for the indent
hGap(3:5,2) = smallGap;  % but a small gap between the connected bits

% gaps between components vertically
vGap = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));
vGap(4, 2:end) = smallGap; % a small gap between the bin duration and bin centering

% and resize
[hTab, tabSize] = ResizePaneFromGrid(hGrid, hGap, vGap);








% function [hGrid, h_gap, v_gap, sizes] = DefaultAllFeaturesPaneLayout(handles, smallGap, normGap, largeGap)
% % function [hGrid, h_gap, v_gap, sizes] = DefaultAllFeaturesPaneLayout(handles, smallGap, normGap, largeGap);
% % function to build the layour for the all features pane
% 
% hGrid = {handles.lbAllFeats};
% 
% % gaps between components horizontally
% h_gap = repmat(normGap, size(hGrid,1), size(hGrid,2) - 1);
% 
% % gaps between components vertically
% v_gap = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));
% 
% % get component sizes
% sizes = PaneSizesFromGrid(hGrid);








