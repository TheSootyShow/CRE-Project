function [feat_labels, display] = FeatureLabelNames(features, aliases)
% function [feat_labels, display] = FeatureLabelNames(features)
% function [feat_labels, display] = FeatureLabelNames(features, aliases)
% this function builds a list of names to display for each features
% input arguments are added to function where they're applicable
    
% the "standard" labels
feat_labels = {features.label_str};

% remove the naming parts from them
feat_labels = strrep(feat_labels, '%s', '');

% remove the brackets from them
for i = 1:numel(feat_labels)
    feat_labels{i} = regexprep(feat_labels{i}, '\(.*\)', '');
end

% display which ones?
display = ~[features.prereq_only];

% apply aliases if desired
if (nargin > 2) && numel(aliases)
    feat_labels = ApplyKnownFeatAliases(feat_labels, aliases);
end

% sort them
[feat_labels, order] = sort(feat_labels(:));
display = display(order);





