function varargout = ApplyKnownFeatAliases(varargin)
% function to relabel dimension names
% input aliases should be sorted using OrderAliases
% Usages:
% 
% 1) function new_names = ApplyKnownFeatAliases(names, aliases)
%
%     names      - cell array of the original names for the dimensions
%     aliases    - an n x 2 cell array with the n used aliases
%                  the first column is the original name, 
%                  the seconds column is its new name
%     new_names  - dimension nameas after alias's have been applied

if (nargin == 2) && iscell(varargin{1}) && iscell(varargin{2})
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the cell array of names style (usage #1)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    names = varargin{1};
    aliases = varargin{2};
    
    % get the expression form of the alias
    alias_expr = cellfun(@AliasToExpression, aliases(:,1), 'uniformoutput', false);

    % N.B. Aliases should be sorted on input
    for i = 1:numel(names)
        for j = 1:size(aliases,1)
            names{i} = regexprep(names{i}, alias_expr{j}, aliases{j,2}, 'matchcase');
        end
    end

    varargout{1} = names;
    
elseif (nargin == 2) && isstruct(varargin{1})
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the dimension structure has been inputted
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    error('not implemented');
    
else
    error('Unknown input style');
end
    
    
    