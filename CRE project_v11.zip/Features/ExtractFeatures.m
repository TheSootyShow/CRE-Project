function [feature_set, data_set] = ExtractFeatures(data_set, featSettings, opts, status_func)
% function [feature_set, data_set] = ExtractFeatures(data_set, featSettings)
% function to extract the desired features from a data set.  
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set       - the data set structure to retrieve the features from
%                  (see ImportCSV.m)
%
% featSettings  - a structure containing information about the features to extract
%                  (see InitFeatSettings.m)
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% feature_set    - a data set containing the feature information
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set default inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 4) 
    status_func = [];
end

if (nargin < 3) || (numel(opts) == 0)

    opts.max_lookup       = 1e3;  % the lookup table has this many entries at most
    opts.max_load_els     = 1e7;  % load the data in full if it has less than this many elements

end

% Initialise output
feature_set = InitDataStruct();

% use the gui to select features
if (nargin < 2) 
    [resp, featSettings] = CREFeatureGui(data_set);
    if (numel(resp) == 0) || ~strcmpi(resp, 'OK')
        return;
    end
end

% convert the dimenion info structure into a form where
% its easier to compute secondary dimensions
inputDims = ParseDimInfo(featSettings.dimInfo, data_set);

% create a default name if it wasn't supplied
if (numel(featSettings.exportInfo.file_name) == 0)
    featSettings.exportInfo.file_name = AutoNameExportFeatures(data_set, featSettings, true);
end

% ensure the features are parsed
featSettings = ParseAllFeatures(featSettings);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up output feature set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[feature_set, runToEnd] = InitExportSet(data_set, featSettings);

% now build column header etc based on feature and dims
[featSettings, feat_names, record] = ProcessFeatures(featSettings, inputDims);

% add it to the feature set structure
[feature_set, write_format] = AddExportColumnInfo(feature_set, feat_names(record));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add the lookup table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

feature_set.lookgap = max(1 + floor(feature_set.num_points / (opts.max_lookup - 1)), 100);
feature_set.lookup = zeros(1 + floor(feature_set.num_points / feature_set.lookgap), 1);

% retain all the data?
retain_all = (feature_set.num_points * feature_set.dims) <= opts.max_load_els;
if (retain_all)
    feature_set.data = zeros(feature_set.num_points, feature_set.dims);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up working space for each of the features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% shortcut
features = featSettings.features;
postFeatures = featSettings.postFeatures;

% working and current estimate for each feature
working_vars = cell(1, numel(features));
feat_est = cell(1, numel(features));
force_load = false;

for i = 1:numel(features)
    
    % doesn't use a pre-requisite so we need working space
    if (numel(features(i).prereq_indexs) == 0)
        
        % create space for the working variables (the first ouput is the feature estimate)
        if (numel(features(i).running_func))
            n_variables = nargout(features(i).running_func);                         % get the number of working variables for the function
            working_vars{i} = cell(1, n_variables-1);
            [feat_est{i}, working_vars{i}{:}] = feval(features(i).running_func);     % call the function to initialise working variables
        else
            working_vars{i} = {}; % none
            force_load = true;    % no running function, need to load all data for the bin
        end
    end
end
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% How many bins can we read in one go?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (featSettings.binInfo.use_bins)
    max_bin_points = ceil(featSettings.binInfo.bin_duration * data_set.fs);
    read_bins = floor(opts.max_load_els / (max_bin_points * inputDims.n_dims));
    if (force_load)
        read_bins = max(read_bins, 1);
    end
else
    % loading all at once
    max_bin_points = data_set.num_points;
    read_bins = floor(opts.max_load_els / (max_bin_points * inputDims.n_dims));
    read_bins = min(read_bins, 1);
end
    

% make sure we get updates every 5% for display purposes
if (read_bins > 1) && (numel(status_func))
    read_bins = max(1, floor(feature_set.num_points / 20));
end

last_chunk_bin = -inf;
chunk_start = -inf;

% begin try loop in case of unexpected error
try
    
    % open the pointer to the data sets file here so we don't do it over and
    % over again
    ds_open = data_set.file_ptr > 0;
    if (~ds_open)
        data_set.file_ptr = fopen(data_set.file_name, 'r');
        if (data_set.file_ptr <= 0)
            error('Could not read %s\nIs the file in use?', data_set.file_name);
        end
    end
    
    % check we're not doing any crazy overwrites
    CheckFileOverwrite(data_set, feature_set, 1 + (read_bins < feature_set.num_points));

    % write the header before this starts
    feature_set = ExportHeader(feature_set, featSettings.exportInfo, true);
    
    % now process
    feature_set.lookup(1) = feature_set.hbytes;
    lookup_ind = 1;                                 % the last filled lookup table entry
    next_lookup = feature_set.lookgap;              % the next point that should have a lookup entry
    
    % turn the time to extract into indices
    if (featSettings.timeRange.full)
        indexs = [1, data_set.num_points];
        relTime = [0, indexs(2) / data_set.fs];
    else
        [relTime, indexs] = TimeRangeToRelative(data_set, featSettings.timeRange.tstamp);
    end
    addTime = etime(feature_set.tstamp, featSettings.timeRange.tstamp{1});   % time between the bin start and the recording point of the bin 
    
    cp = indexs(1)-1;                           % current point into the original
    ct = relTime(1);                            % current time in the original
    
    % allocate space for the output features
    Xf = zeros(1, feature_set.dims);
    n_points = 0;  % keep track of the written points
    
    % now go though each "bin"
    i = 0;
    chunk_eof = false;
    while (i < feature_set.num_points) || (runToEnd && (i + indexs(1) <= data_set.num_points))
        
        % move along
        i = i + 1;
        
        % the last point in this bin
        lp = floor((i*featSettings.binInfo.bin_duration + relTime(1)) * data_set.fs);
        
        % how many points in this bin?
        bin_points = lp - cp;
        
        if (read_bins > 1) % we load multiple bins at a time (call them a chunk)
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % We CAN load MULTIPLE bins
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % do we need to load another chunk?
            if (i > last_chunk_bin)
                
                % the first and last point in the "chunk"
                chunk_start = cp + 1;
                last_chunk_bin = (i + read_bins - 1);
                chunk_end = min(floor((last_chunk_bin * featSettings.binInfo.bin_duration + relTime(1)) * data_set.fs), data_set.num_points);  % the last point in the chunk
                
                % And load the "chunk"
                [chunk, data_set] = GetDerivedDims(data_set, chunk_start, chunk_end, inputDims);
				chunk_eof = size(chunk,1) < (chunk_end - chunk_start + 1);
                
                
            end
            
            % get the data from the chunk
            if (~chunk_eof) || (size(chunk,1) >= cp - chunk_start + bin_points + 1)
                X = chunk(cp - chunk_start + 2 : cp - chunk_start + bin_points + 1, :);
            else
                % out of file
                eof = true;
                break;
            end
                
            
            % Update the current point
            cp = lp;
            
            % and call each process function
            for fn = 1:numel(features)
        
                if (numel(features(fn).prereq_indexs) == 0)
                    
                    % no prerequisite
                    feat_est{fn} = feval(features(fn).func, X, features(fn).input_args{:});
                
                end
            end
            
        
        % one bin at a time
        elseif (read_bins == 1)
            
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % We CAN ONLY load a SINGLE bin
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            [X, data_set] = GetDerivedDims(data_set, cp+1, lp, inputDims);
            
            % have we run out of file?
            if (size(X,1) < (lp-cp))
                eof = true;
                break;
            end
                
            
            % Update the current point
            cp = lp;
            
            % and call each process function
            for fn = 1:numel(features)
        
                if (numel(features(fn).prereq_indexs) == 0)
                    
                    % no prerequisite
                    feat_est{fn} = feval(features(fn).func, X, features(fn).input_args);
                
                end
            end
        else
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % We CAN'T load a SINGLE bin
            % do it incrementally and use the working functions
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            n_blocks = ceil(inputDims.n_dims * bin_points / opts.max_load_els);
            pp_block = bin_points / n_blocks;  % how many points to load in each block
            
            % reset all the working variables for the features
            for fn = 1:numel(features)
                if (numel(features(fn).prereq_indexs) == 0)
                    [feat_est{fn}, working_vars{fn}{:}] = feval(features(fn).running_func);     % call the function to initialise working variables
                end
            end
            
            % process each block
            j = 0;
            while (j < n_blocks) && (cp < data_set.num_points)
                
                j = j + 1; % move along
                
                % the last index to grab in each block
                be = min(cp + ceil(pp_block), lp);
                
                % grab them
                [X, data_set] = GetDerivedDims(data_set, cp+1, be, inputDims);
                
                % out of file?
                if (size(X,1) < be-cp)
                    eof = true;
                    break;
                end
            
                % increment the current point
                cp = be;
                
                % and call each process function
                for fn = 1:numel(features)
                    
                    % only do function without prerequisites
                    if (numel(features(fn).prereq_indexs) == 0)
                        [feat_est{fn}, working_vars{fn}{:}] = feval(features(fn).running_func, X, features(fn).input_args{:}, working_vars{fn}{:});
                    end
                end
                
                % update progress
                if (numel(status_func))
                    feval(status_func, (i-1) * n_blocks + j, feature_set.num_points * n_blocks);
                    drawnow();
                end
            end
            
            % did we run out of data?
            if (j < n_blocks)
                eof = true;
                break;
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Now grab all ouput values 
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for fn = 1:numel(features)
            if ~(features(fn).prereq_only)  % dont display these
                if (numel(features(fn).prereq_indexs) == 0)
                    Xf(features(fn).output_cols) =  feat_est{fn};
                else
                    % call the function on the output of the prerequisite function
                    prereq_outputs = feat_est(features(fn).prereq_indexs);
                    Xf(features(fn).output_cols) = feval(features(fn).func, prereq_outputs{:}, bin_points, features(fn).input_args{:});
                end
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Do post processing features
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for fn = 1:numel(postFeatures)
            Xf(postFeatures(fn).output_cols) = feval(postFeatures(fn).func, Xf(postFeatures(fn).prereq_indexs), postFeatures(fn).input_args{:});
        end
        
        % cur it back to only the recorded ones
        Xfr = Xf(record);
        
        
        % store this in X if desired
        if (retain_all)
            feature_set.data(i, :) = Xfr;
        end
        
        % print the time at the start of the bin?
        if (feature_set.time_col)
            ct_str = ConvertTime(ct + addTime, data_set.tstamp, 2, true);
            fprintf(feature_set.file_ptr, '%s, ',  ct_str);
        end
        
        % update the time we've processed
        ct = (lp - 1)/ data_set.fs;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Now print the data
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % and the values
        fprintf(feature_set.file_ptr, write_format, Xfr);  % write it
        n_points = n_points + 1;
        
        if (n_points == next_lookup)
                
            % record the lookup table entry
            lookup_ind = lookup_ind + 1;
            feature_set.lookup(lookup_ind) = ftell(feature_set.file_ptr);
            next_lookup = next_lookup + feature_set.lookgap;             % the next point that should have a lookup entry
            
            % update progress
            if (numel(status_func))
                feval(status_func, n_points, feature_set.num_points);
                drawnow();
            end
        end
    end
    
    % this should only happen if eof is encountered
    if (n_points ~= feature_set.num_points) || (lookup_ind ~= numel(feature_set.lookup))
        feature_set.lookup = feature_set.lookup(1:lookup_ind);
        feature_set.num_points = n_points;
        if numel(feature_set.data)
            feature_set.data(feature_set.num_points+1:end, :) = [];
        end
    end
    
    if (featSettings.exportInfo.header > 0)
        UpdateDSHeader(feature_set);  % always call this in case we output the lookup table
    end
    
    
    % and close the file if it was open
    open = feature_set.file_ptr > 0;
    if (open)
        fclose(feature_set.file_ptr);
        feature_set.file_ptr = -1;
    end
    
    % close the data sets file pointer if we opened it
    if (~ds_open)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    
catch ME
    
    % catch error
    if (feature_set.file_ptr > 0)
        fclose(feature_set.file_ptr);
        feature_set.file_ptr = -1;
    end
    
    % close the data set's file pointer if we opened it in this function
    if (~ds_open) && (data_set.file_ptr > 0)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    
    if (isdeployed)
        error('An unexpected error occurred during the feature extraction in file %s\n%s', data_set.file_name, ME.message);
    else
        rethrow(ME);
    end
    
    
end







    
        



