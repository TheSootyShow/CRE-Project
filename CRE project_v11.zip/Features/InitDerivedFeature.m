function feat_struct = InitDerivedFeature(siz)
% function feat_struct = InitDerivedFeature(siz)
% function to initialise a derivied feature (i.e. a simple artimatic
% operation on another feature(s)

% prototype the structure to return
feat_struct = struct('name',                [],   ... % the name of the feature
                                                  ...
                     'type',                [],   ... % type of elementary operation
                                                  ...
                     'func',                [],   ... % function handle with its implementation
                                                  ...
                     'input_feats',         {{}}, ... % the names of the features used as input
                                                  ... 
                     'input_dims',          {{}}, ... % the dimension names for the input feature (same length as input features)
                                                  ...
                     'input_args',          {{}}, ... % contains the arguments for each of input_feats to help match them (same length as input features)
                                                  ...
                     'display',             [],   ... % display this derivied feature? (or is it perequisite for another derived feature)
                                                  ...
                     'prereq_indexs',       [],   ... % indexs of prerequisite functions
                                                  ...
                     'output_cols',         []    ...% where to put the output from this feature
                                                  ...
                                            );

% ensure its type cast
feat_struct.display = logical(feat_struct.display);                                        
                                        
% size it
if (nargin > 0) && (numel(siz > 0))
    feat_struct = repmat(feat_struct, siz);
end
    