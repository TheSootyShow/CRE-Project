function varargout = CreateAliasesGUI(varargin)
% function output_aliases = CreateAliasesGUI(input_list, input_aliases, type)
% CREATEALIASESGUI MATLAB code for CreateAliasesGUI.fig
%      CREATEALIASESGUI by itself, creates a new CREATEALIASESGUI or raises the
%      existing singleton*.
%
%      H = CREATEALIASESGUI returns the handle to a new CREATEALIASESGUI or the handle to
%      the existing singleton*.
%
%      CREATEALIASESGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CREATEALIASESGUI.M with the given input arguments.
%
%      CREATEALIASESGUI('Property','Value',...) creates a new CREATEALIASESGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CreateAliasesGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CreateAliasesGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CreateAliasesGUI

% Last Modified by GUIDE v2.5 24-Sep-2014 14:49:17

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CreateAliasesGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @CreateAliasesGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);

if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before CreateAliasesGUI is made visible.
function CreateAliasesGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CreateAliasesGUI (see VARARGIN)

% get type
handles.label_type = varargin{3};  % either 'dim' or 'feat'

% get the aliases
handles.input_aliases = varargin{2};
handles.aliases = varargin{2};

% process inputs
handles.input_labels =  ApplyKnownDimAliases(varargin{1}, [handles.aliases(:,2), handles.aliases(:,1)]);  % reverse all aliases to get the originals
handles.labels = ApplyKnownDimAliases(handles.input_labels, handles.aliases);                             % and reapply

% give it a title
if strncmpi(handles.label_type, 'dim', 3)
    set(hObject, 'name', 'Relabel Dimensions');
else
    set(hObject, 'name', 'Relabel Features');
end

% link the listboxes
%hLink = linkprop([handles.lbOrigLabels, handles.lbCurrentLabels], {'Value', 'ListboxTop'});
hLink = linkprop([handles.lbOrigLabels, handles.lbCurrentLabels], 'Value');
setappdata(hObject, 'LinkProps', hLink);

% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);


% Choose default command line output for CreateAliasesGUI
handles.output = {'Cancel', handles.input_aliases};

% resize it
handles = CreateAliasesGUI_ResizeFcn(hObject, eventdata, handles);

% Initialise the gui
handles = InitGui(handles, min(1, numel(handles.labels)), []);

% and update the handles
guidata(hObject, handles);

% Make the GUI modal
%set(handles.CreateAliasesGUI,'WindowStyle','modal')

% UIWAIT makes CreateAliasesGUI wait for user response (see UIRESUME)
uiwait(handles.CreateAliasesGUI);


function handles = InitGui(handles, label_val, alias_val)
% function handles = InitGui(handles, label_val, alias_val)
% function to re-initialise the gui state

% set the labels boxes
set(handles.lbOrigLabels, 'string', handles.input_labels);
set(handles.lbCurrentLabels, 'string', handles.labels);
if (numel(label_val) && (label_val > 0))
    
    % select the correct bit
    set([handles.lbOrigLabels, handles.lbCurrentLabels], 'value', label_val); 
    
    % and the aliases
    if (~numel(alias_val))
        
        % what to use as the original and new labels?
        olabel = handles.input_labels{label_val};
        nlabel = handles.labels{label_val};
            
        % only use the old label if it exactly matches an alais
        alias_index = find(strcmp(olabel, handles.aliases(:,1)));
        
        if (numel(alias_index) == 0)
            olabel = nlabel;
            set(handles.lbAliases, 'value', []);
        else
            set(handles.lbAliases, 'value', alias_index);
        end

        % and update the boxes
        set(handles.ebOrigLabel, 'string', olabel);
        set(handles.ebNewLabel, 'string', nlabel);
    end
else
    set([handles.lbOrigLabels, handles.lbCurrentLabels], 'value', []); 
end

% set the alias box
alias_str = cellfun(@(x1, x2)(sprintf('%s -> %s', x1, x2)), handles.aliases(:,1),  handles.aliases(:,2), 'uniformoutput', false);
set(handles.lbAliases, 'string', alias_str);
if numel(alias_val)

    % set it up
    set(handles.lbAliases, 'value', alias_val);
    
    % and set the strings
    set(handles.ebOrigLabel, 'string', handles.aliases{alias_val,1});
    set(handles.ebNewLabel, 'string', handles.aliases{alias_val,2});

else
    set(handles.lbAliases, 'value', []);
end



% --- Outputs from this function are returned to the command line.
function varargout = CreateAliasesGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;

% The figure can be deleted now
delete(handles.CreateAliasesGUI);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.aliases};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CreateAliasesGUI);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.input_aliases};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CreateAliasesGUI);


% --- Executes when user attempts to close CreateAliasesGUI.
function CreateAliasesGUI_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CreateAliasesGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over CreateAliasesGUI with no controls selected.
function CreateAliasesGUI_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to CreateAliasesGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
if isequal(get(hObject,'CurrentKey'),'escape')
    % User said no by hitting escape
    handles.output = {'Cancel', handles.input_aliases};
    
    % Update handles structure
    guidata(hObject, handles);
    
    uiresume(handles.CreateAliasesGUI);
end    
    
if isequal(get(hObject,'CurrentKey'),'return')
    uiresume(handles.CreateAliasesGUI);
end    

% --- Executes during object creation, after setting all properties.
function Default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbCurrentLabels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on selection change in lbOrigLabels.
function Listbox_Callback(hObject, eventdata, handles)
% hObject    handle to lbOrigLabels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbOrigLabels contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbOrigLabels

% get handles tow both boxes
hLists = [handles.lbOrigLabels, handles.lbCurrentLabels];
currBox = hObject;
otherBox = hLists(hLists ~= hObject);

% dont let the user select this
set(otherBox, 'value', get(currBox, 'value'));
set(otherBox, 'listboxtop', get(currBox, 'listboxtop'));
drawnow(); % ensure it updates

% get the selection
selected = get(hObject, 'value');
labels = cellstr(get(handles.lbCurrentLabels,'String'));
nlabel = labels(selected);

labels = cellstr(get(handles.lbOrigLabels,'String'));
olabel = labels(selected);

% only use the old label if it exactly matches an alias
has_alias = strcmp(olabel, handles.aliases(:,1));

if ~any(has_alias)
    olabel = nlabel;
    set(handles.lbAliases, 'value', []);
else
    alias_index = find(has_alias & strcmp(nlabel, handles.aliases(:,2)));
    set(handles.lbAliases, 'value', alias_index);
end

% now update all labels
set(handles.ebOrigLabel, 'string', olabel);
set(handles.ebNewLabel, 'string', nlabel);

% --- Executes on selection change in lbAliases.
function lbAliases_Callback(hObject, eventdata, handles)
% hObject    handle to lbAliases (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbAliases contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbAliases

index = get(hObject, 'value');
alias = handles.aliases(index, :);

% was anything selected?
if (numel(index) == 0)
    return;
end


% set the edit boxes
set(handles.ebOrigLabel, 'string', alias{1});
set(handles.ebNewLabel, 'string', alias{2});

% does it match anything in the list boxes for a selection
lb_value = find(strcmp(alias{1}, get(handles.lbOrigLabels, 'string')) & strcmp(alias{2}, get(handles.lbCurrentLabels, 'string')));
if numel(lb_value)
    set([handles.lbOrigLabels, handles.lbCurrentLabels], 'value', lb_value);
end

% OK condition
set(handles.pbCommit, 'enable', 'on');
set(handles.pbCommit, 'tooltipstring', '');


function ebNewLabel_Callback(hObject, eventdata, handles)
% hObject    handle to ebNewLabel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebNewLabel as text
%        str2double(get(hObject,'String')) returns contents of ebNewLabel as a double

CheckAliasValidity(handles);



function ebOrigLabel_Callback(hObject, eventdata, handles)
% hObject    handle to ebOrigLabel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebOrigLabel as text
%        str2double(get(hObject,'String')) returns contents of ebOrigLabel as a double

CheckAliasValidity(handles);


function [valid,  aliases, new_labels, alias_index] = CheckAliasValidity(handles)
% function [valid, aliases, new_labels, alias_index] = CheckAliasValidity(handles)
% function to check the validity of an alias

% get values
old_label = get(handles.ebOrigLabel, 'string');
new_alias = get(handles.ebNewLabel, 'string');

% ensure they arent cells
if iscell(new_alias)
    new_alias = new_alias{1};
end
if iscell(old_label)
    old_label = old_label{1};
end

if strcmpi(new_alias, 'SP46^2')
    crap = 1;
end

% check it has length and doesn't already exist
if (numel(new_alias) == 0)
    set(handles.pbCommit, 'enable', 'off');
    set(handles.pbCommit, 'tooltipstring', 'No label entered');
    valid = false;
    return;
else
    
    % check it all works
    try
        
        % is it already in the list?
        aliases = handles.aliases;
        alias_index = find(strcmpi(aliases(:,1), old_label));
        if numel(alias_index)
            aliases(alias_index, :) = {old_label, new_alias};
        else
            aliases(end+1, :) = {old_label, new_alias};
            alias_index = size(aliases,1);
        end
        
        % test it
        aliases = OrderAliases(aliases);
        [new_labels] = ApplyKnownDimAliases(handles.input_labels, aliases);
        
        % OK condition
        set(handles.pbCommit, 'enable', 'on');
        set(handles.pbCommit, 'tooltipstring', '');
        valid = true;
    
    catch ME
        
        % report what the problem was
        set(handles.pbCommit, 'enable', 'off');
        set(handles.pbCommit, 'tooltipstring', ME.message);
        valid = false;
    end
end



% --- Executes on button press in pbRestore.
function pbRestore_Callback(hObject, eventdata, handles)
% hObject    handle to pbRestore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% the current alias
alias = get(handles.ebOrigLabel, 'string');
if iscell(alias)
    alias = alias{1};
end

% the current label (reset edit boxes to these)
selected = get(handles.lbOrigLabels, 'value');

% is the current alias used?
alias_ind = find(strcmpi(alias, handles.aliases));
if numel(alias_ind)
    handles.aliases(alias_ind, :) = [];
end

% redo the labels
handles.labels = ApplyKnownDimAliases(handles.input_labels, handles.aliases);

% reintialise for it
handles = InitGui(handles, selected, []);

% update the handles
guidata(hObject, handles);

% OK condition
set(handles.pbCommit, 'enable', 'on');
set(handles.pbCommit, 'tooltipstring', '');


% --- Executes on button press in pbRestoreAll.
function pbRestoreAll_Callback(hObject, eventdata, handles)
% hObject    handle to pbRestoreAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% reset the gui state
handles.aliases = cell(0,2);
handles.labels = handles.input_labels;
handles = InitGui(handles, get(handles.lbCurrentLabels, 'value'), []);

% OK condition
set(handles.pbCommit, 'enable', 'on');
set(handles.pbCommit, 'tooltipstring', '');

% update the handles
guidata(hObject, handles);


% --- Executes on button press in pbCommit.
function pbCommit_Callback(hObject, eventdata, handles)
% hObject    handle to pbCommit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

old_name = get(handles.ebOrigLabel, 'string');
if iscell(old_name)
    old_name = old_name{1};
end
new_name = get(handles.ebNewLabel, 'string');
if iscell(new_name)
    new_name = new_name{1};
end

% check the alias will actually do something
if ~strcmpi(old_name, new_name) 
    
    alias_index = find(strcmpi(handles.aliases(:,1), old_name));
    if (numel(alias_index) == 0)
        alias_index = size(handles.aliases, 1) + 1;
    end
    handles.aliases(alias_index, :) = {old_name, new_name};

    % check validity and update the labels
    [valid, handles.aliases, handles.labels, alias_index] = CheckAliasValidity(handles);
    
    if (valid)
        
        % display them
        selected = get(handles.lbCurrentLabels, 'value');
        handles = InitGui(handles, selected, alias_index);
        guidata(hObject, handles);
       
    end
end


% --------------------------------------------------------------------
function mlFile_Callback(hObject, eventdata, handles)
% hObject    handle to mlFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function miLoadLabels_Callback(hObject, eventdata, handles)
% hObject    handle to miLoadLabels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


persistent last_file;

if (numel(last_file) == 0) || (~ischar(last_file))
    last_file = DataLoadDir();
end

% function to load previously saved features
[file, path] = uigetfile('*.txt', 'Load Aliases:', last_file);
if ~ischar(path) || (numel(path) == 0)
    return;
end

% load it
load_file = fullfile(path, file);
new_aliases = ReadCellStrings(load_file, ' -> ');

% check validity
if (size(new_aliases, 1) > 0) && (size(new_aliases, 2) == 2) && all(cellfun(@(x)(numel(x) > 0), new_aliases(:))) ... 
        && all(cellfun(@ischar, new_aliases(:)))

    handles.aliases = new_aliases;
    
    % update the labels for it
    handles.labels = ApplyKnownDimAliases(handles.input_labels, handles.aliases);
    
    % And up date all ui components
    sel_label = get(handles.lbCurrentLabels, 'value');
    if (numel(sel_label) == 0)
        sel_label = 1;
    end
    handles = InitGui(handles, sel_label, []);
    
    % remember the last loaded file
    last_file = load_file;

    % and store the handles
    guidata(hObject, handles);
    
else
    
    errordlg(sprintf('%s does not appear to be a valid alias file', load_file));
    
end


% --------------------------------------------------------------------
function miSaveLabels_Callback(hObject, eventdata, handles)
% hObject    handle to miSaveLabels (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


persistent last_file;

% what are these the aliases for?
if strncmpi(handles.label_type, 'dim', 3)
    type = 'dimension';
else
    type = 'feature';
end

% save this where?
if (numel(last_file) == 0)
    def_name = fullfile(DataSaveDir(), [type, '_aliases.txt']);
else
    def_name = last_file;
end

% warn the user if there are no features
if (size(handles.aliases) == 0)
    resp = questdlg(sprintf('No aliases have been selected\nSave anyway?'), 'Warning!', 'Yes', 'No', 'No');
    if (numel(resp) && strcmpi(resp, 'No'))
        return;  % dont proceed
    end
end

% open a save file dialog
[save_file, save_path] = uiputfile('*.txt', ['Save ', upper(type(1)), type(2:end), ':'], def_name);

% proceed?
if ischar(save_file) && numel(save_file)
    
    % record save location
    last_file = fullfile(save_path, save_file);
    
    % and save
    WriteCellStrings(handles.aliases, last_file, ' -> ');
    
    if ~isdeployed && 0
        fprintf('Saved aliases as: %s\n', last_file);
    else
        msgbox(sprintf('Aliases saved as:\n%s', last_file), 'Saved as'); 
    end
end


% --------------------------------------------------------------------
function miReset_Callback(hObject, eventdata, handles)
% hObject    handle to miReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% use this callback
pbRestoreAll_Callback(handles.pbRestoreAll, eventdata, handles);

% --------------------------------------------------------------------
function miExit_Callback(hObject, eventdata, handles)
% hObject    handle to miExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.input_aliases};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CreateAliasesGUI);


% --- Executes when CreateAliasesGUI is resized.
function handles = CreateAliasesGUI_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to CreateAliasesGUI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call the feature layout function
if (RunResizeFcn(hObject, handles))

    % to facilitate sizing
    [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    p1cm = ceil(ppcm);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the panel for the lists
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hList = cell(2, 3);
    hList(1,:) = {handles.txtOrigLabels, sprintf('h=%i', p1cm), handles.txtCurrentLabels};
    hList(2,:) = {handles.lbOrigLabels, sprintf('h=%i', p1cm), handles.lbCurrentLabels};
    set(cell2mat([hList(:,1), hList(:,3)]), 'parent', handles.uiLists);  % stupid guide
    
    % vertical spacing
    vGapList = repmat(normGap, size(hList,1)-1, size(hList,2));
    vGapList(1,:) = smallGap;   % small gap between title and list boxes
    
    % horizontal spacing
    hGapList = repmat(normGap, size(hList,1), size(hList,2)-1);
    
    % resize this pane
    [hList, listSize, paneBorder] = ResizePaneFromGrid(hList, hGapList, vGapList,  false, [false, false]);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the panel for the aliases
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    set(handles.uiAliases, 'units', 'pixels');
    aliasSize = get(handles.uiAliases, 'position');
    aliasSize = [aliasSize(1:2), listSize(1), ceil(3*ppcm)];
    set(handles.uiAliases, 'position', aliasSize);  % 3 cm high, same width as the label boxes
    aliasSize = aliasSize(3:4);
    
    
    set(handles.lbAliases, 'units', 'pixels');
    set(handles.lbAliases, 'position', [paneBorder(1:2), listSize(1)- sum(paneBorder([1,3])), ceil(3*ppcm) - sum(paneBorder([2,4])) - GetPanelTextHeight(handles.uiAliases, true)]);
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the panel for modifications
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hLabel = cell(4, 3);
    hLabel(1,1:3) = {handles.txtOrigName, [], handles.txtNewName};
    hLabel(2,1:3) = {handles.ebOrigLabel, sprintf('h=%i', p1cm), handles.ebNewLabel};
    hLabel(3,1:3) = {handles.pbRestore, [], handles.pbCommit};
    hLabel{4,1} = handles.pbRestoreAll;
    set([cell2mat(hLabel(:,1)); handles.pbCommit], 'parent', handles.uiNewAlias);  % stupid guide
    
    % get sizes
    labSizes = PaneSizesFromGrid(hLabel);
    
    % now force the label edit box to be the correct size (match the list pane
    % above)
    p1 = get(handles.lbOrigLabels, 'position');
    labSizes{2,1}(1) = p1(3);
    p1 = get(handles.lbCurrentLabels, 'position');
    labSizes{2,3}(1) = p1(3);
    
    % vertical spacing
    vGapLabel = repmat(normGap, size(hLabel,1)-1, size(hLabel,2));
    vGapLabel(1,:) = smallGap;
    
    % horizontal spacing
    hGapLabel = repmat(normGap, size(hLabel,1), size(hLabel,2)-1);
    
    % and redo the pane
    [hLabel, labelSize] = ResizePaneFromGrid(hLabel, hGapLabel, vGapLabel, labSizes, [false, false]);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Assemble it all
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hGrid = cell(4,2);
    hGrid(1,:) = {hList, 'l'};
    hGrid(2,:) = {handles.uiAliases, 'l'};
    hGrid(3,:) = {hLabel, 'l'};
    hGrid(4,:) = {handles.pbCancel, handles.pbOK};
    
    % assemble sizes
    sizes = {listSize, []; aliasSize, []; labelSize, []; [], []};
    
    % and call the resize
    ResizeFigFromPanes(hGrid, [], [], sizes);
    
    % dont allow it to be resized again
    set(hObject, 'Resize', 'off');
    
    
end
