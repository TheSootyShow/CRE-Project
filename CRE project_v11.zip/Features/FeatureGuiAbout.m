function hFig = FeatureGuiAbout()
% function hFig = FeatureGuiAbout()
% function to create descriptions of dimenensions
% in the feature gui

% for formatting
fig_width = 22;     % A4 is 21 cm wide
fig_height = 29.7;  % A4 is this high
margin    =  1;     % use a 2.5 cm margin
fig_margin = 1.5;
para_sep  = .3;     % 0.5cm between paragraphs
sec_sep  =   .75;   % 1 cm between sections

% font info to use by default
font = javax.swing.plaf.FontUIResource('Calibri', 0, 12);
bodyRule = 'body { font-family: Calibri; font-size: 12 pt; }';

% font for section headers (using html)
header_wrap = @(str)sprintf('<html><p style="font-size: 14 pt;" margin-bottom: 0.3 cm;"><b>%s</b></p></html>', str);

% convert all height from cm to pixels
pix_cm = (get(0, 'ScreenPixelsPerInch')) / 2.54;      % pixels per centimeter
fig_width = floor(fig_width * pix_cm);                % now in pixels
fig_height = floor(fig_height * pix_cm);              % now in pixels
para_sep  = ceil(para_sep * pix_cm);                  % now in pixels
sec_sep  = ceil(sec_sep * pix_cm);                    % now in pixels
fig_margin = ceil(fig_margin * pix_cm);               % now in pixels
margin = ceil(margin * pix_cm);                       % now in pixels

% limit the figure height to the size of the screen
screen_pos = get(0, 'ScreenSize');
menu_height = 200;   % matlab menu should be less high than this (also dont go over the command bar)
fig_height = min(fig_height, screen_pos(4) - menu_height);

 
% load the text file with the help
if ~isdeployed()
    fpath = fileparts(mfilename('fullpath'));
else
    fpath = '';
end
file_name = fullfile(fpath, 'AboutFeatureGui.txt');
fid = fopen(file_name, 'r');
if (fid <= 0)
    error('Failed to open: %s', file_name);
end
raw_text = fread(fid, inf, 'char=>char');
raw_text= reshape(raw_text, 1, numel(raw_text));  % for debugging
fclose(fid);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% find all of the sections
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sections = struct('header', [], 'text', {{}}, 'type', {{}}, 'misc', {{}});

% loof for section markers
[headers, sec_start, sec_end] = regexpi(raw_text, '\/Section[^\n]*', 'match');

% in case of no headers
if (numel(headers) == 0)
    sec_end(1) = 0;
    sec_start(1) = 0;
    headers = {''};
end

% now represent all the sections
sections = repmat(sections, 1, numel(headers));
sec_start(end+1) = numel(raw_text) + 1;     % convenient
for i = 1:numel(headers)
    
    % extract the header
    sections(i).header = strtrim(regexprep(headers{i}, '\/Section\s*', ''));
    
    % grab the section text
    sec_text = raw_text(sec_end(i)+1:sec_start(i+1)-1);
    
    % look for tables in the section
    [tmp, table_start, table_end] = regexpi(sec_text, '\/(start|end)table', 'match');
    
    % check all lists were "closed"
    if rem(numel(table_start), 2)
        error('Improper number of table start / ends in section %i', i);
    end
    
    % look for figure's
    [tmp, fig_start, fig_end] = regexpi(sec_text, '\/image\{[\w\.]*\}', 'match');
    % figure dont have start / end.  Corect for that
    fig_start = [fig_start; fig_end+1];
    fig_end = [fig_start-1; fig_end];
    
    % put it together to make all objects
    obj_start = [table_start(:); fig_start(:)];
    obj_end = [table_end(:); fig_end];
    types = [repmat({'table'}, 1, numel(table_start)), repmat({'image'}, 1, numel(fig_start))];
    [obj_start, order] = sort(obj_start);
    obj_end = obj_end(order);
    types = types(order);
    
    % convenient
    obj_start(end+1) = numel(sec_text)+1;
    obj_end(end+1) = numel(sec_text)+1;
    
    % look for where the text and tables ares
    n_parts = 0;             % keep track of how many sections
    last = 0;
    for j = 1:2:numel(obj_start)  % in increments of two because table_start has an entry for the start and end tables marks
        
        % any text preceeding the table
        pre_text = strtrim(sec_text(last+1:obj_start(j)-1));
        if (numel(pre_text))
            n_parts = n_parts + 1;
            sections(i).text{n_parts} = pre_text;
            sections(i).type{n_parts} = 'text';
        end
        
        % now grab the table
        if (j < numel(obj_start))
            
            % grab the table in raw form
            raw_obj = strtrim(sec_text(obj_end(j)+1:obj_start(j+1) - 1));
            n_parts = n_parts + 1;
            sections(i).type{n_parts} = types{j};
            
            % parse it into table form
            % split based on lines
            if strcmpi(types{j}, 'table')
                
                % read it
                table_cell = regexp(raw_obj, '[\n]+', 'split');  % ignore blank lines
                table_cell = table_cell(:);
            
                for k = 1:size(table_cell,1)
                    
                    % columns are tab delimited
                    entries = regexp(table_cell{k,1}, '\t', 'split');
                    table_cell(k, 1:numel(entries)) = entries;
                    
                end
                sections(i).text{n_parts} = table_cell;
                
            elseif strcmpi(types{j}, 'image')
                file_name = regexp(raw_obj, '(?<=\/image\{)[\w\.]*(?=\})', 'match', 'once');
                if (numel(fileparts(file_name)) == 0)
                    file_name = fullfile(fileparts(mfilename('fullpath')), file_name);
                end
                sections(i).misc{n_parts} = file_name;
                sections(i).text{n_parts} = '';
            else 
                error('Unknown Object Type: %s', types{j});
            end
            last = obj_end(j+1);
        end
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now create the figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hFig = figure;
set(hFig, 'units', 'pixels', 'toolbar', 'none', 'numbertitle', 'off', 'name', 'Feature Selection Help', 'menubar', 'none');   
set(hFig, 'visible', 'on'); % leave visible while debugging

% resize it based on A4
ResizeFigure(hFig, [fig_width, fig_height], false);
f_pos = get(hFig, 'position');

warning('off', 'MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
jFrame = get(hFig, 'javaframe');
warning('on', 'MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');

% get the content pane
try
     jFrame = jFrame.fHG1Client();
catch
     jFrame = jFrame.fFigureClient();
end
jContent = jFrame.getContentPane();


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create a container to encompass it all
% (We're going for a "word" look)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cont_width = f_pos(3) - 2*fig_margin;  % size of the inner container
obj_width = cont_width - 2*margin;    % let the text get this wide on the page
extra_space = 20;                                    % leave some "wriggle" room
text_width = obj_width - extra_space;                % wrap text after this many pixels

% this container will look like a white page hopefully
jContainer  = javaObjectEDT('javax.swing.JTextPane');
jContainer.setContentType('text/html');
jContainer.getDocument().getStyleSheet.addRule(bodyRule);
jContainer.setEditable(false);
jContainer.setOpaque(true);
jContainer.setFont(font);
jContainer.setBackground(java.awt.Color.white);
jContainer.setLayout('');                                             % dont use a layout manager - I lay things out myself

% this container will look like gray hopefully
jOuterContainer  = javaObjectEDT('javax.swing.JTextArea');
jOuterContainer.setOpaque(true);
jOuterContainer.setBackground(java.awt.Color.gray);
jOuterContainer.setBorder('');
jOuterContainer.setLayout('');

% add the inner container to it
jOuterContainer.add(jContainer);                                      % dont use a layout manager - I lay things out myself


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now go through all the sections creating appropriate 
% uicomponents
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% keep track of the height of everthing we add to this text pane
net_height = 0;

for i = 1:numel(sections)
    
    % where is the top of this?
    top = net_height + sec_sep;
    left = margin;
    
    % create the section label
    if numel(sections(i).header)
    
        % format it to let it know its a header
        header_text = header_wrap(sections(i).header);
        
        % and create a jLabel for it
        jHeader = CreateTextJLabel(header_text, text_width, obj_width, font);
        
        % add it to the container
        jContainer.add(jHeader);
        jHeader.setLocation(java.awt.Point(left, top));  % change its location
        jHeader.setSize(jHeader.getPreferredSize);
        net_height = top + jHeader.getPreferredSize.height;
        
    end
    
    % now create the rest
    for j = 1:numel(sections(i).text)
        
        % where is the top of this
        if (j == 1) && (numel(sections(i).header) == 0)
            top = net_height;  % we already have the section gap
        elseif (j == 1)
            top = net_height + floor(para_sep / 2);  % a smaller gap after the heading
        else
            top = net_height + para_sep;
        end
        
        % is it text?
        if any(strcmpi(sections(i).type{j}, {'text', 'image'}))
            
            if strcmpi(sections(i).type{j}, 'text')
            
                % wrap the text in html
                html_str = TextToHTML(sections(i).text{j});
            
                % and create the object
                jLabel = CreateTextJLabel(html_str, text_width, obj_width, font);
                
            else strcmpi(sections(i).type{j}, 'image')

                % create the image
                jLabel = CreateImageJLabel(sections(i).misc{j});
                
            end
            
            % add it to the container
            jContainer.add(jLabel);
            jLabel.setLocation(java.awt.Point(left, top));  % change its location
            jLabel.setSize(jLabel.getPreferredSize);
            net_height = top + jLabel.getPreferredSize.height;
            
        elseif strcmpi(sections(i).type{j}, 'table')
            
            % create the table (return is a jScrollPane - tables must be
            % wrapped in scroll panes)
            jTableScroll = CreateTable(sections(i).text{j}, text_width, obj_width, left, top, pix_cm);
            
            % and sort its size
            jTableScroll.setMaximumSize(jTableScroll.getPreferredSize);
            jTableScroll.setMinimumSize(jTableScroll.getPreferredSize);
            
            % add it to the container
            jContainer.add(jTableScroll);
            jTableScroll.setLocation(java.awt.Point(left, top));  % change its location
            jTableScroll.setSize(jTableScroll.getPreferredSize);
            net_height = top + jTableScroll.getPreferredSize.height;
            
        else
            error('Unknown type: %s in section %i', sections(i).type{j}, i);
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now we know the height, resize the containers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

jContainer.setPreferredSize(java.awt.Dimension(cont_width, net_height + para_sep));
jOuterContainer.setPreferredSize(java.awt.Dimension(f_pos(3)-2, jContainer.getPreferredSize.height + fig_margin));
jOuterContainer.setSize(jOuterContainer.getPreferredSize());
jContainer.setSize(jContainer.getPreferredSize());


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create a jScrollPane because we dont expect the container to fit
% on an A4 page
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create the scroll pane
jScrollPane = javaObjectEDT('javax.swing.JScrollPane', jOuterContainer);
jScrollPane.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);  % always show the vertical scroll
jScrollPane.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  % never show the horizontal scroll

% now change where the inner container is centered on the outer container
% (to account for a vertical scrollbar)
left = fig_margin;
jVertScroll = jScrollPane.getVerticalScrollBar();
if jVertScroll.isEnabled  % N.B. not sure what this line should actually be
    left = left - floor(jVertScroll.getPreferredSize.width / 2);
end
jContainer.setLocation(java.awt.Point(left, ceil(fig_margin/2)));       % add room for some "gray space" top and bottom


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now add the scroll pane to the content pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

jContent.revalidate();
[jScrollPane, jScrollPane_hg] = javacomponent(jScrollPane, [], hFig);
set(jScrollPane_hg, 'position', [1,1,f_pos(3), f_pos(4)]);






function jTableScroll = CreateTable(table, text_width, obj_width, left, top, ppcm)
% function jTableScroll = CreateTable(table, text_width, obj_width, left, top, ppcm)
% function to create a jTable for the input table
% headers are the first row of table
%
% columns 1:end-1 are always set to their preferred width.  If possible, the final
% column is constrianed to fit on the page.  If that's not possible, the
% final column is set to its preferred width and a scrollpane is used
    
% wrap the entire list in html tags (for line wrapping)
table_cell = cellfun(@(str)(sprintf('<html>%s</html>', strtrim(str))), table, 'uniformoutput', false);

% create the jTable
jTable = javaObjectEDT('javax.swing.JTable', table_cell(2:end,:), table_cell(1,:));
    
% for some reason the jTable constructor doesn't recognise the html
% make sure the cell renderer does for all columns
%
% "steal" the html client property from a jlabel...
jLabel = javax.swing.JLabel('<html>hello</html>');

% create a renderer for each column (allows line wrapping)
for i = 1:size(table_cell,2)
    
    % create a new renderer
    jRenderer = javax.swing.table.DefaultTableCellRenderer;
    
    % let the renderer know about html
    jRenderer.putClientProperty('html', jLabel.getClientProperty('html'));
    jRenderer.setName(sprintf('Debug%i', i-1)); % for debugging
    
    % set it as the renderer for this column
    jTable.getColumnModel().getColumn(i-1).setCellRenderer(jRenderer);
    
end
    
% try to get the columns to auto size
net_width = 0;
header_heights = zeros(1, size(table_cell,2));
for i = 1:size(table_cell,2)  % go through each column
    
    % get the maximum size of any of its data
    cell_widths = zeros(size(table_cell,1)-1, 1);
    for j = 1:size(table_cell,1)-1 % N.B the first row is the header
        
        jRenderer = jTable.getCellRenderer(j-1, i-1);
        cell_widths(j) = jTable.prepareRenderer(jRenderer, j-1, i-1).getPreferredSize().width() + 5;  % +5 for room to the border
    end
        
    % how wide is the header?
    jUnknown = jRenderer.getTableCellRendererComponent(jTable, jTable.getColumnModel().getColumn(i-1).getHeaderValue, false, false, -1, i-1);
    max_width = max([cell_widths(:); jUnknown.getPreferredSize.width + 10]);
    header_heights(i) = jUnknown.getPreferredSize.height + 5;
        
    % ensure the final column doesn't go over the maximum width
    if (i == size(table_cell,2))
        
        % does it need to be size limited
        if (text_width - net_width < max_width)
            
            % update it
            max_width = text_width - net_width;
            
            % limit its size and use line wrapping if its going to have 3 cm of usable space
            if (max_width < 3 * ppcm)
                max_width = floor(text_width/2);  % only ever allow preferred width up to this much
            end
            use_width = max_width - 5;
                
                
            % get the renderer for the final column
            jRenderer = jTable.getColumnModel().getColumn(i-1).getCellRenderer();
                
            % now adjust the row heights
            for j = 1:size(table_cell,1)-1 % the first row is the header
                
                % let the renderer "see" the string
                jRenderer = jTable.prepareRenderer(jRenderer, j-1, i-1);
                
                % and force the renderer to have a maximum width
                % (height should adjust to compensate)
                jObjFixedWidth(jRenderer, use_width, max_width);
                
                % now set the row to the height
                pref_height = jRenderer.getPreferredSize().height();
                if (pref_height > jTable.getRowHeight(j-1))
                    jTable.setRowHeight(j-1, pref_height);
                    jRenderer.setVerticalAlignment(javax.swing.table.DefaultTableCellRenderer.BOTTOM_ALIGNMENT);  % N.B. center alignment doesnt work for me
                end
            end
        else
            max_width = text_width - net_width;
        end
    end
    
    % and force the column to be this width
    jTable.getColumnModel().getColumn(i-1).setPreferredWidth(max_width);
    jTable.getColumnModel().getColumn(i-1).setWidth(max_width);
    jTable.getColumnModel().getColumn(i-1).setMaxWidth(max_width);
    jTable.getColumnModel().getColumn(i-1).setMinWidth(max_width);
    
    net_width = net_width + max_width;
end

% set teh height of the header
jHeader = jTable.getTableHeader();
hsize = jHeader.getPreferredSize();
hsize.height = max(header_heights(i));
jHeader.setPreferredSize(hsize);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure out its size
%%%%%%%%%%%%%%%%%%%%%%%%%%

height = 0;
for i = 1:size(table_cell,1)-1 % the first row is the header
    height = height + jTable.getRowHeight(i-1);
end
height = height + jTable.getTableHeader().getPreferredSize.height;  % dont forget the header

jTable.setPreferredSize(java.awt.Dimension(net_width, height));
jTable.setSize(jTable.getPreferredSize);

% and set its location
jTable.setLocation(java.awt.Point(left, top));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% It needs to be in a scrolll pane for the header to render
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create a scroll pane
jTableScroll = javaObjectEDT('javax.swing.JScrollPane', jTable);
jTableScroll.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_NEVER);
jTableScroll.setHorizontalScrollBarPolicy(javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
jTableScroll.setPreferredSize(java.awt.Dimension(min(obj_width, jTable.getPreferredSize.width()), jTable.getPreferredSize.height()))



function jText = CreateTextJLabel(html_str, text_width, obj_width, font)
% function jText = CreateTextJLabel(html_str, text_width, obj_width, font)
% function to create a jLabel of width obj_width and text wrapping after
% text_width pixels

% create a jLabel
jText = javaObjectEDT('javax.swing.JLabel', html_str);

% update appearance
jText.setFont(font);
jText.setBackground(java.awt.Color.white);
jText.setOpaque(false);

% give it the fixed width
jObjFixedWidth(jText, text_width, obj_width);       % add left because when me move to the left the right edge dos
jText.setPreferredSize(java.awt.Dimension(obj_width, jText.getPreferredSize.height()));
jText.setMaximumSize(jText.getPreferredSize);
jText.setMinimumSize(jText.getPreferredSize);


function jImage = CreateImageJLabel(image_file)
% function jImage = CreateImageJLabel(file_name)
                
jIcon = javaObjectEDT('javax.swing.ImageIcon', image_file);

% create a jLabel
jImage = javaObjectEDT('javax.swing.JLabel', jIcon);




function html_str = TextToHTML(str)
% function str = TextToHTML(str, text_width)
% function to convert the input string to HTML

% case for empty strings
if (numel(str) == 0)
    html_str = '';
    return;
end
    
% remove formatting I dont use
html_str = regexprep(str, '[\f\r\v]', '','preservecase');

% use html paragraphs
html_str = regexprep(html_str, '\n+', '</p><br><p style="font-size: 12 pt">','preservecase');

% add the paragraph markers at the start and end
html_str = sprintf('<p style="font-size: 12 pt">%s</p>', html_str);

% and add teh html wrapper
html_str = sprintf('<html>%s</html>', html_str, html_str, html_str);





