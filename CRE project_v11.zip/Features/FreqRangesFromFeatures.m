function [freqRanges, feat_indexs] = FreqRangesFromFeatures(features)
% function [freqRanges, feat_indexs] = FreqRangesFromFeatures(features)
% function to get frequency ranges from features that rely on frequency
%
%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%
%
% freqRange  - an n x 2 matrix of the n feature ranges of interest
%
% feat_indexs - an numel(features) element array with the indices of the
%               frequency range the feature belongs to (0 if its not
%               related to a range)


% find out how many different frequency bound are used
freqRanges = zeros(0, 2);  % store them all here
feat_indexs = zeros(size(features));
for i = 1:numel(features)

    if (IsFreqDependentFeature(features(i)))
        
        % the final three arguments of these functions are always: fl, fh, fs
        fl = features(i).input_args{end-2};
        fh = features(i).input_args{end-1};
        
        % where does it fit into the current frequency ranges
        row = find((fl == freqRanges(:,1)) & (fh == freqRanges(:,2)));
        
        if (numel(row) == 0)
            
            % not seen before
            freqRanges(end+1,:) = [fl, fh]; %#ok<*AGROW>
            feat_indexs(i) = size(freqRanges,1);
            
        else
            
            % assign it
            feat_indexs(i) = row;
        end
    end
end

% sort the result if applicable
if (numel(freqRanges) > 0)
    
    fn = 1e3*freqRanges(:,1) + (1e-3) * freqRanges(:,2);  % quite hacky
    [vals, order] = sort(fn);
    freqRanges = freqRanges(order, :);
    feat_indexs(feat_indexs > 0) = order(feat_indexs(feat_indexs > 0));
    feat_indexs = reshape(feat_indexs, size(features));
    
end
