function combs = nchoose2(n)
% function combs = nchoose2(n)
% function designed to replace nchoosek
% this function remembers the last input

persistent last_n
persistent last_combs

if (numel(last_n) == 0) || (last_n ~= n)
    combs = nchoosek(1:n, 2);
    last_combs = combs;
    last_n = n;
else
    combs = last_combs;
end