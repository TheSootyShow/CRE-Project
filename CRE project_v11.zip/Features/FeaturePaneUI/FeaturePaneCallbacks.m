function FeaturePaneCallbacks(hObject, eventdata, handles)
% function FeaturePaneCallbacks(hObject, eventdata, handles)
% this function has the callbacks for the ui components of the time pane

try % wrap in case of errors

    % disable the figure while this executes
    % hFig = ancestor(hObject,'figure');  % make sure hFig is a figure
    % EnableDisableFig(hFig, 'off');
    
    % ensure handles are available
    if (nargin < 3)
        handles = guidata(hObject);
    end
    
    % this style is only OK for CREfeatureGui
    % make sure to reassign it at the end
    featStruct = handles.featSettings.features;
    freqStruct = handles.featSettings.freqRange;
    
    % get which ui componenent it is from the tag
    tag = get(hObject, 'tag');
    parentTag = get(get(hObject, 'parent'), 'tag');
    
    % and its style
    style = get(hObject, 'type');
    if strcmpi(style, 'uicontrol')
        style = get(hObject, 'style');  % if we're in a callback its a uicontrol
    end
    
    % if its a member of a frequency tab, and the max / min freq
    paneID = regexp(parentTag, '(?<=^uiTabPane)\d+', 'match', 'once');
    if numel(paneID)
        
        % the last valid number used is stored in user data
        params = {get(handles.(['ebMinFreq', paneID]), 'userdata'), ...
            get(handles.(['ebMaxFreq', paneID]), 'userdata'), ...
            handles.data_set.fs};
        
    else
        params = {};
    end

    % is this a radio button?
    if strcmpi(style, 'radiobutton')
        
        % are qe adding or removeing
        if (get(hObject, 'value'))
            
            % adding
            featStruct = AddButtonFeature(hObject, featStruct, params);
            
        else
            
            % removing
            featStruct = RemoveButtonFeature(hObject, featStruct, params);
            
        end
        
    elseif strcmpi(style, 'listbox')
        
        % run the list box feature option
        featStruct = ListBoxFeature(hObject, featStruct, params, handles.data_set.fs);
        
    elseif strcmpi(tag, 'miAddPercentile')
        
        % add a percentile to the rank pane
        AddPercentile(hObject, eventdata, handles);
        
    elseif strcmpi(tag, 'miAddLag')
        
        AddLag(hObject, eventdata, handles);
        
    elseif strcmpi(tag, 'miAddDomFreq')
        
        AddDomFreq(hObject, eventdata, handles);
        
    elseif strcmpi(tag, 'pmACorrUnits')
        
        % which units are we working in?
        unit_list = get(hObject,'string');
        unit = unit_list{get(hObject,'value')};
        
        % convert the list box
        values_all = get(handles.lbACorr, 'UserData');  % these are always in ms
        
        % convert it to samples if needed
        if strncmpi(unit, 'samples', 7)
            values = ceil((values_all{1} / 1000) * handles.data_set.fs);  % convert to samples
        else
            values =  values_all{1};
        end
        
        % convert back to strings
        new_str = cellstr(num2str(values(:)));
        set(handles.lbACorr, 'string', new_str);
        
    elseif strcmpi(tag, 'ebFFTres')
        
        % this is specific to CREfeatureGui
        [freqStruct, featStruct, handles] = UpdateFFTres(hObject, freqStruct, featStruct, handles);
        
    elseif numel(regexp(tag, 'ebMinFreq\d+', 'match', 'once'))
       
        % call the frequency update function
        [freqStruct, featStruct, handles] = CheckFreqRange(hObject, freqStruct, featStruct, 1, paneID, handles);
        
    elseif numel(regexp(tag, 'ebMaxFreq\d+', 'match', 'once'))
       
        % call the frequency update function
        [freqStruct, featStruct, handles] = CheckFreqRange(hObject, freqStruct, featStruct, 2, paneID, handles);
        
    else
        error('Unknown object change to: %s', tag);
    end
    
    
    
    % if any require CRE fft, make sure its already in feature's because
    % it requires input args from the gui
    if any(strcmpi([featStruct(:).prereq_name], 'fft')) && ~any(strcmpi({featStruct(:).name}, 'fft'))
        fftFeat = CREFeatures('fft', handles.data_set.fs, freqStruct.fres);
        fftFeat.prereq_only = true;
        featStruct = [fftFeat; featStruct];
    end
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % specific to CREfeatureGui
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % reassign to handles
    handles.featSettings.features = featStruct;
    handles.featSettings.freqRange = freqStruct;
    
    % check the post process features are all available
    if numel(handles.featSettings.postFeatures)
       
        % check
        handles.featSettings = MapPostFeaturesToDataSet(handles.featSettings);
    
        % redraw the post features panel
        InitialisePostPane(handles.featSettings, handles);
        
    end
    
    % process all of the features
    [handles.featSettings, aliasList, display, idx, featList] = ProcessFeatures(handles.featSettings, handles.data_set, true);
    
    % update the control
    handles.featSettings = UpdateFeatListControl(handles.lbAllFeats, handles.featSettings, aliasList, display, idx, featList);
    
    % set gui output availability
    EnableDisableOutput(handles);
    
    % update
    guidata(hObject, handles);
    
    % re-enable for the next callback
    %EnableDisableFig(hFig, 'on');

    
catch ME
    
    % re-enable for the next callback
    % EnableDisableFig(hFig, 'on');
    
    % what's the current figure?
    hFig = get(0, 'currentfigure');
    if numel(hFig) && strcmpi(get(hFig, 'tag'), 'CREFeatureGui')
        
        % It has a dedicated error handler
        ProcessFeatureGuiError(ME);
    
    else
        
        if (~IsDeveloper)
            errordlg('Unable to process requested feature', 'Error', 'modal');
        else
            rethrow(ME);
        end
    end
end





function featStruct = RemoveButtonFeature(hObject, featStruct, params)
% function featStruct = RemoveButtonFeature(hObject, featStruct, params)
% function to add a feature to the structure

% get its tag
tag = get(hObject, 'tag');

% convert the tag to a type
type = Tag2Type(tag);

% any extra parameters?
new_params = get(hObject, 'userdata');
if ~iscell(new_params)
    new_params = {};
end
params = [new_params, params];

% find the index of the feature to remove
index = FindFeature(type, featStruct, params);

% check validity
if (numel(index) ~= 1)
    error('Could not find unique feature for %s', type);
end

% remove any now unneeded
prereq_names = featStruct(index).prereq_name;

% remove the feature
featStruct(index) = [];

% ensure feat struct is always an n x 1
if (numel(featStruct) == 0)
    featStruct = reshape(featStruct, 0, 1);
end

% and remove the prereq function is desired
if numel(prereq_names) && numel(featStruct)
    featStruct = CheckPrecursor(prereq_names, featStruct);
end


function featStruct = ListBoxFeature(hObject, featStruct, params, fs)
% function featStruct = ListBoxFeature(hObject, featStruct, params, fs)
% function to add a feature to the structure

% get its tag
tag = get(hObject, 'tag');

% convert the tag to a type
type = Tag2Type(tag);

% get the selected values rom the list box
uData = get(hObject, 'userdata');
prevSelect = uData{2};     % its previous selections are stored here
options = uData{1}(:);
    
% add sampling
if strcmpi(tag, 'lbAcorr')
    params = [{fs}, params];  % add sampling frequency
end
currSelect = options(get(hObject, 'value'));

% have any been removed?
remFeatIndex = find(~ismember(prevSelect, currSelect));
for i = 1:numel(remFeatIndex)
    index = FindFeature(type, featStruct, [{prevSelect(remFeatIndex(i))}, params]);  % find the feature matching it
    if numel(index)
        featStruct(index(1)) = [];                                                                 % and remove it
    end
end

% have any been added?
addFeatIndex = find(~ismember(currSelect, prevSelect));
for i = 1:numel(addFeatIndex)
    inputs = [{currSelect(addFeatIndex(i))}, params];
    featStruct(numel(featStruct)+1,1) = CREFeatures(type, inputs{:});
end

% and update "prevSelect"
uData{2} = currSelect;
set(hObject, 'userdata', uData);


  


function featStruct = CheckPrecursor(names, featStruct)
% function featStruct = CheckPrecursor(names, featStruct)
% function to remove any existing precursor function

% get a list of all prerequisites
if (numel(featStruct) == 0)
    return;  % nothing to update
else
    allPreqs = [featStruct(:).prereq_name];
end

% now remove any from names that are still a prereq
names = names(~ismember(names, allPreqs));

% and remove them
for i = 1:numel(names)
    
    % find it
    index = FindFeature(names{i}, featStruct, {});
    
    if (numel(index) == 0)
        featStruct(index) = [];
    end
end


% --------------------------------------------------------------------
function AddPercentile(hObject, eventdata, handles)
% hObject    handle to miAddPercentile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% prompt the user
if (numel(eventdata) == 0)
    response = inputdlg('Select a custom percentile, 0 (min) - 100 (max)', 'Custom percentile', 1, {'50'});
else
    response = eventdata;
    if ~iscell(response)
        response = {response};
    end
end

% did the user say OK?
if numel(response)
    
    % check its interpretable
    new_percent = str2double(response{1});
    if ~isfinite(new_percent) || (new_percent < 0) || (new_percent > 100)
        errordlg(sprintf('%s can not be converted to a number between 0 and 100', response{1}), 'Percentile Selection Error');
    else
        
        % make sure it exists on the list
        CheckNewListValue(new_percent, response{1}, handles.lbPercentile);

    end
end

% --------------------------------------------------------------------
function AddLag(hObject, eventdata, handles)
% hObject    handle to miAddLag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% what units are we working in?
unit_list = get(handles.pmACorrUnits,'string');
des_unit = unit_list{get(handles.pmACorrUnits,'value')};

% prompt the user
if (numel(eventdata) == 0)
    unit = des_unit;
    response = inputdlg(sprintf('Select a custom lag in units of: %s', unit), 'Custom auto correlation', 1, {'1'});
else
    response = eventdata;
    if ~iscell(response)
        response = {response};
    end
    
    unit = 'ms';  % always in this case
end

% did the user say OK?
if numel(response)
    
    % check its interpretable
    lag = str2double(response{1});
    
    if ~isfinite(lag) || (lag < 0) 
        errordlg(sprintf('%s can not be converted to a greater than 0', response{1}), 'Auto Correlation Selection Error');
    else
        
        % if we're working in samples, round it
        if strncmpi(unit, 'samples', 7)
            sLag = ceil(lag);
            msLag = (sLag / handles.data_set.fs) * 1e3;
        else
            msLag = lag;
            sLag = ceil((msLag * 1e-3) * handles.data_set.fs);
        end
        
        % make sure unit and des_unit are the same
        if strncmpi(unit, 'samples', 7)
            CheckNewListValue(msLag, num2str(sLag), handles.lbACorr)
        else
            CheckNewListValue(msLag, num2str(msLag), handles.lbACorr)
        end

    end
end

% --------------------------------------------------------------------
function AddDomFreq(hObject, eventdata, handles)
% hObject    handle to miAddPercentile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% prompt the user
if (numel(eventdata) == 0)
    response = inputdlg('Enter the dominant freqency to extract (1 is the largest)', 'Extract the ith dominant frequency', 1, {'1'});
    hList = gco(); % the list box to modify
else
    response = eventdata(1);
    hList = eventdata{2}; % the list box to modify
end

% did the user say OK?
if numel(response)
    
    % check its interpretable
    new_index = str2double(response{1});
    
    if ~isfinite(new_index) || (new_index < 0) || (new_index ~= round(new_index))
        errordlg(sprintf('%s can not be converted to an integer greater than 0', response{1}), 'Dominant Frequency Selection Error');
    else
        
        % new method - update everylist box
        hList = findobj(handles.uiFreqDomain, 'style', 'listbox');
        for i = 1:numel(hList)
            CheckNewListValue(new_index, response{1}, hList(i));
        end
    end
end


function CheckNewListValue(value, value_str, hList)
% function CheckNewListValue(value, value_str, hList)
% function to add a new value to a list box
% it checks if the value already exists

% check its not one we already have
existing = get(hList, 'userdata');
prevSelect = existing{2};  % the previously selected values
existing = existing{1};    % all options
if ~any(value == existing)
    
    % add it
    new_values = [existing(:); value];
    new_string = [get(hList, 'string'); value_str];
    selected = get(hList, 'value');
    
    % order them
    [new_values, order] = sort(new_values);
    new_string = new_string(order);
    
    % add them
    set(hList, 'String', new_string);
    set(hList, 'UserData', {new_values, prevSelect});
    set(hList, 'max', max(numel(new_string), 2));
    [tmp, idx] = ismember(selected, order);
    set(hList, 'value', sort(idx));
    
end


function [freqStruct, featStruct, handles] = UpdateFFTres(hObject, freqStruct, featStruct, handles)
% function [freqStruct, featStruct, handles] = UpdateFFTres(hObject, freqStruct, featStruct, handles)
% function to change the resolution used for the fft

str = get(hObject, 'string');
value = str2double(str);
if isfinite(value) && (value >= 0) && (value < handles.data_set.fs/2)
    
    % store it
    set(hObject, 'userdata', value);
    
    % update the desired frequency range
    freqStruct.fres = value;
    
    % if there is an fft feature, update it
    index = find(strcmpi({featStruct(:).name}, 'fft'));
    if numel(index)
        featStruct(index).input_args{2} = value;
    end
    
    % remove it from any block lists
    handles.block_list = handles.block_list(handles.block_list ~= hObject);
    
elseif ~any(handles.block_list == hObject)
        
    % block the "OK" output
    handles.block_list(end+1) = hObject;
end











