function LogPostPane(hFig)
% function LogPostPane(hFig)
% function to display a message if the object with tag 

if (~isdeployed)
    log_file = 'C:\CREGuiLog.txt';
else
    log_file = 'C:\CREGuiLog_deployed.txt';
end
check_tag = 'uiPostProcessing';

if (nargin == 0)
    % clear the log file
    fid = fopen(log_file, 'w');
else
    fid = fopen(log_file, 'a');
    hObject = findobj(hFig, 'tag', check_tag);
    if (numel(hObject) ~= 1)
        fprintf('%i copies of %s exist\n', numel(hObject), check_tag);
    else
        hParent = get(hObject, 'parent');
        set([hObject, hParent], 'units', 'pixels');
        frameObj = findobj(hFig, 'tag', 'uiFeatureGui');
        objPos = GetRelativePosition(hObject, frameObj, 'pixels');
        parPos = GetRelativePosition(hParent, frameObj, 'pixels');
        
        
        % Now put it in a string
        inputs = {check_tag, objPos, get(hObject, 'visible'), get(hParent, 'tag'), parPos, get(hParent, 'visible')};
        fprintf(fid, '%s: position = [%g,%g,%g,%g], visible = %s; %s: position = [%g,%g,%g,%g], visible = %s\n', inputs{:});
        
    end
end
fclose(fid);