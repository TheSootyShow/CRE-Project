function DeleteFreqTabCallback(hObject, eventdata, handles)
% hObject    handle to miDeleteFreqTab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% which index is this?
tag = get(gco(), 'tag');  % get the object to delete's tag
index = str2double(regexp(tag, '(?<=tabFrange)\d+', 'match', 'once'));

% delete it
handles = DeleteFreqRangeTab(handles, index);

% and update the handles
guidata(hObject, handles);
