function handles = CopyPostTemplateToFigure(hDest, handles)
% function destHandles = CopyFeatTemplateToFigure(hDest, destHandles)
% function to copy the updated version of the dimension panel onto an
% existing gui

% for debugging
set(hDest, 'visible', 'on');

% load the range template figure
figDir = fileparts(mfilename('fullpath'));
figName = fullfile(figDir, 'PostPane.fig');
hSrc = hgload(figName);

% ensure callbacks are correct
srcControls = findobj(hSrc, 'type', 'uiControl');
srcMenus = findobj(hSrc, 'type', 'uiMenu');
set([srcControls(:); srcMenus(:)], 'callback', @(hObject, event_data)PostPaneCallbacks(hObject, event_data, guidata(hObject)));
set(srcControls(:), 'CreateFcn', @(hObject, event_data)Default_CreateFcn(hObject, event_data, guidata(hObject)));

% and get the pane to copy
srcPostPane = findobj(hSrc, 'tag', 'uiPostProcessing');

% remove all the pre-existing things from the uiRangePane panel
if ~isfield(handles, 'uiPostProcessing')
    error('The input figure does not have a post processing panel');
end

% keep a record of the dim pane's parent
hParent = get(handles.uiPostProcessing, 'parent');

% find all children of the dim pane panel that have tags
hChildren = findall(allchild(handles.uiPostProcessing));
rmTags = get(hChildren, 'tag');
rmTags = rmTags(cellfun(@(x)(numel(x) > 0), rmTags));

% remove those tags and delete them
handles = rmfield(handles, rmTags);

% now delete the old pane
delete(handles.uiPostProcessing);

% now copy on the new range pane
handles.uiPostProcessing = copyobj(srcPostPane, hParent);

% and add all tags to the handles
hChildren = findall(handles.uiPostProcessing);
addTags = get(hChildren, 'tag');
hasTag = cellfun(@(x)(numel(x) > 0), addTags);
addTags = addTags(hasTag);
hChildren = hChildren(hasTag);
for i = 1:numel(addTags)
    handles.(addTags{i}) = hChildren(i);
end

% make sure the uicontext menu gets copied
hContext = findobj(hSrc, 'type', 'uicontextmenu');
for i = 1:numel(hContext)
    
    % delete the old one if it exists
    tag = get(hContext(i), 'tag');
    if isfield(handles, tag)
        delete(handles.(tag));
    end
    
    % and copy over the new one
    handles.(tag) = copyobj(hContext(i), hDest);
    
    % make sure all of the ui menus all have entries
    hMenu = findobj(hContext(i), 'type', 'uimenu');
    for j = 1:numel(hMenu)
        mTag = get(hMenu(j), 'tag');
        if isfield(handles, mTag) && ishandle(handles.(mTag))
            delete(handles.(mTag));
        end
        handles.(mTag) = findobj(hDest, 'tag', mTag);
    end
    
    
    % now find all uiobjects that use it
    hUse = findobj(hSrc, 'uicontextmenu', hContext(i));
    for j = 1:numel(hUse)
        set(handles.(get(hUse(j), 'tag')), 'uicontextmenu', handles.(tag));
    end
end


% restore tab system if needed (do it last because 
% tabs cant be copied across figures)
tab_info = modUserData(hSrc, 'get', 'TabInfo');
if numel(tab_info)
    handles = RestoreFigureTabs(hDest, handles, tab_info);
end

delete(hSrc);







