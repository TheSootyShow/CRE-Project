function InitialisePostPane(featSettings, handles)
% function InitialisePostPane(featSettings, handles)
% function to intialise the post processing panel


% get names
orig_names = {featSettings.postFeatures.name};
selected = [featSettings.postFeatures.display];
orig_names = orig_names(:);
selected = selected(:);

% apply aliases
post_names = ApplyKnownDimAliases(orig_names, handles.featSettings.dimInfo.aliases);
post_names = ApplyKnownFeatAliases(post_names, handles.featSettings.aliases);

% and set the list boxes
SetListBox(handles.lbAvailPostProcess, post_names(~selected), find(~selected), orig_names(~selected));
SetListBox(handles.lbSelPostProcess, post_names(selected), find(selected), orig_names(selected));


function SetListBox(hList, string, indexs, user_data)
% function SetListBox(hList, string, indexs, user_data)
% function to set values for a list box

[string, order] = sort(string);

set(hList, 'string', string);
set(hList, 'userdata', [user_data(order), num2cell(indexs(order))]);
set(hList, 'Min', 0);
set(hList, 'Max', max(numel(string),2));  % ensure its not in single selection mode
