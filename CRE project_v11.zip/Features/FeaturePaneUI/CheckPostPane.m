function CheckPostPane(hFig, handles, pref)
% function CheckPostPane(hFig, handles, pref)
% function to display a message if the object with tag 
% "lbAvailPostProcess" exists


check_tag = 'uiPostProcessing';

objExists = numel(findobj(hFig, 'tag', check_tag));
hasHandle = isfield(handles, check_tag) && ishandle(handles.(check_tag));
msgbox(sprintf('(%s) %s object count: %i, has handle: %i', pref, check_tag, objExists, hasHandle));
if (hasHandle)
    
end