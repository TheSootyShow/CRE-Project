function handles = AddFreqRangeTab(handles, nAdd)
% function handles = AddFreqRangeTab(handles, nAdd)
% function to add a new frequency range tab

% the template
template_children = get(handles.tabFrange1, 'children');
template_pos = get(handles.tabFrange1, 'position');
template_units = get(handles.tabFrange1, 'units');

% which number?
allTabs = get(handles.tgFreqTabs, 'children');
types = get(allTabs, 'type');
allTabs = allTabs(strcmpi(types, 'uitab'));
cTabs = numel(allTabs);  % current number of tabs

% we can't ensure the order they appear in, so template them now
allTabs(cTabs + nAdd) = 0;  % allocate space in this buffer
for i = cTabs+1:cTabs + nAdd
    allTabs(i) = uitab(handles.tgFreqTabs);
end

% copy the "New" tab to the final one
copyobj(get(allTabs(cTabs), 'children'), allTabs(end));
set(allTabs(end), 'title', get(allTabs(cTabs), 'title'), 'tag', get(allTabs(cTabs), 'tag'));
handles.(get(allTabs(cTabs), 'tag')) = allTabs(end);
kids = RecurseChildren(allTabs(end));
for i = 1:numel(kids)
    tag = get(kids(i), 'tag');
    if numel(tag)
        handles.(tag) = kids(i);
    end
end

% fill in all the others
freqRange = [0, handles.data_set.fs/2];
for i = cTabs:cTabs+nAdd-1

    % create the tab
    tag = sprintf('tabFrange%i', i);
    set(allTabs(i), 'tag', tag, 'position', template_pos, 'units', template_units);
    handles.(tag) = allTabs(i);  % ensure its in handles
    
    % now copy the children of "tab 1 over"
    copyobj(template_children, allTabs(i));
    new_kids = RecurseChildren(allTabs(i));  % make sure we do all children recursively
    
    % go through them 
    for j = 1:numel(new_kids)
        
        % update their tags
        old_tag = get(new_kids(j), 'tag');
        if numel(old_tag)
            new_tag = regexprep(old_tag, '\d+$', num2str(i));
            set(new_kids(j), 'tag', new_tag);
            handles.(new_tag) = new_kids(j);  % ensure its in handles
        
            % copy uicontext menus as well (they dont copy with copyobj)
            cmenu = get(handles.(old_tag), 'UIContextMenu');
            if numel(cmenu)
                set(new_kids(j), 'UIContextMenu', cmenu);
            end
        end
        
        % and ensure nothing is selected
        type = get(new_kids(j), 'type');
        if strcmpi(type, 'uicontrol')
            style = get(new_kids(j), 'style');
            if strcmpi(style, 'radiobutton')
                set(new_kids(j), 'value', 0);
            elseif strcmpi(style, 'listbox')
                set(new_kids(j), 'value', []);
                uData = get(new_kids(j), 'userdata');
                uData{2} = [];  % previous list box selections get stored here
                set(new_kids(j), 'userdata', uData);
            end
        end
        
    end
    
    % but revert to full range
    set(handles.(tag), 'title', sprintf('%0.2g-%0.2g', freqRange(1), freqRange(2)));
    minFreqTag = sprintf('ebMinFreq%i', i);
    maxFreqTag = sprintf('ebMaxFreq%i', i);
    set(handles.(minFreqTag), 'string', num2str(freqRange(1)), 'userdata', freqRange(1));
    set(handles.(maxFreqTag), 'string', num2str(freqRange(2)), 'userdata', freqRange(2));
    
    
    % make sure we add this to fbounds
    handles.featSettings.freqRange.fbounds(i, :) = freqRange;
end

% update the handles if desired
if (nargout == 0)
    guidata(handles.CREFeatureGui, handles);
end

