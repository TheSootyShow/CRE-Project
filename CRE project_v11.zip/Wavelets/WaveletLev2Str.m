function WaveStr = WaveletLev2Str(Wavelet)
%function WaveStr = WaveletLev2Str(Wavelet)
%function to convert a wavlet structure to a printable level string

FHi = Wavelet.FHi; FLo = Wavelet.FLo;  %Shortcuts
WaveStr = ['WL ', Wavelet.Level, ': '];

if (FHi < 1)
    WaveStr = [WaveStr, num2str(round(FLo*1000)), ' - ', num2str(round(FHi*1000)), ' Hz'];
elseif (FHi > 1) && ((FLo > 1) || (FLo == 0))
    WaveStr = [WaveStr, num2str(FLo, '%.2f'), ' - ', num2str(FHi, '%.2f'), ' kHz'];
else
    WaveStr = [WaveStr, num2str(round(FLo*1000)), ' Hz - ', num2str(FHi, '%.2f'), ' kHz'];
end
