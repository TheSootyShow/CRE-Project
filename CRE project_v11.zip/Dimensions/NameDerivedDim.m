function name = NameDerivedDim(derived_dim, primary_names)
% function name = NameDerivedDim(derived_dim, primary_names)
% function to create a name for a derived dimension
% does not use argument info
%
% derived_dim   - a filled derived dimension strcuture (see InitDerivedDim)
% primary_names - the name of the primary dimensions

% shortcuts
sources = derived_dim.source;

% build the list of all sources
source_names = primary_names(sources{1,2});
source_names = [source_names(:); sources{1,3}(:)];

% now build the name
name = CreateDimName(derived_dim.type, source_names, derived_dim.args{:});
