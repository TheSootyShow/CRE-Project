function expr = AliasToExpression(alias)
% function expr = AliasToExpression(alias)
% converts an alias into a regular expression to search for

persistent specials;
persistent literals;
if (numel(literals) == 0)
    specials = '.^$*+?()[{|-]}';
    literals = cellfun(@(char)(['\', char]), num2cell(specials), 'uniformoutput', false);
end


% do the literal slash first
alias = regexprep(alias, '\', '\\', 'matchcase');

% now do any other special char
if any(ismember(alias, specials))
    for i = 1:numel(specials)
        alias = strrep(alias, specials(i), literals{i});
    end
end

% and wrap
expr = ['(?<=(\W|^))', alias, '(?=(\W|$))'];