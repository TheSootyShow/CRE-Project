function [names, selected, n_prim, n_secondary] = GetAllDimensionNames(dimInfo, no_alias)
% function [names, selected, n_prim, n_secondary] = GetAllDimensionNames(dimInfo);
% function [names, selected, n_prim, n_secondary] = GetAllDimensionNames(dimInfo, no_alias);
% this function returns the names of all used dimensions (primary followed by secondary)
% set no_alis = true to not apply aliases

if (nargin < 2) || (numel(no_alias) == 0)
    no_alias = false;  % default
end

% initialise
names = cell(20,1);  % over allocate
selected = false(20,1);  % over allocate

% the list of primary dimensions to look at
n_prim = numel(dimInfo.primary_names);
names(1:n_prim) = dimInfo.primary_names;  % always add them all
selected(1:n_prim) = dimInfo.primary_disp(:);

% go though finding all the simple secondary dimensions
known_types = GetKnownSecondaryDimTypes(dimInfo);

% they can be identified because they have an args field
n_found = n_prim;
for i = 1:numel(known_types)
    
    % get properties for this supported dimension
    n_exist = numel(dimInfo.(known_types{i}).dims);
    names(n_found + (1:n_exist)) = dimInfo.(known_types{i}).names(:);
    selected(n_found + (1:n_exist)) = dimInfo.(known_types{i}).disp(:);
    n_found = n_found + n_exist;

end
    
% what other dimensions have we created?
dnames = {dimInfo.derived_dims(:).name};
names = [names(1:n_found); dnames(:)];
selected = [selected(1:n_found); dimInfo.derived_disp(:)];

% prepare output
n_secondary = numel(names) - n_prim;

% apply know aliases
if (~no_alias)
    names = ApplyKnownDimAliases(names, dimInfo.aliases);
end