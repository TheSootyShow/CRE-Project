function dimInfo = UpdateDimsFromListBox(dimInfo, hPrim, hDerived)
% function dimInfo = UpdateDimsFromListBox(dimInfo, hPrim, hDerived)
% this function updates the shown dimensions in dimInfo with selected
% entries in the list box (the listbox should have been created with 
% PopulateListBox.m).  If primary and derived dimensions are in teh same
% list box, set(hPrim = hDerived).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Do primary dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfinite(hPrim)
    
    % and which are selected
    prim_selected = get(hPrim, 'value');
    
    % is this only primary dimensions?
    if (nargin >= 3) && (hPrim == hDerived)
        
        % break it up now
        derived_selected = prim_selected(prim_selected > numel(dimInfo.primary_dims));
        derived_names = get(hPrim, 'string');
        derived_names = derived_names(derived_selected);
        
        derived_selected = derived_selected - numel(dimInfo.primary_dims);
        prim_selected = prim_selected(prim_selected <= numel(dimInfo.primary_dims));
        
    end
    
    % set all viewing to false
    dimInfo.primary_disp(:) = false;
    dimInfo.primary_disp(prim_selected) = true;  % and view the selected
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Do derived dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin >= 3) && (isfinite(hDerived))
    
    % if its all in the same list box, we already have deriv_selected
    if (hDerived ~= hPrim)
        derived_selected = get(hDerived, 'value');
        derived_names = get(hDerived, 'string');
        derived_names(derived_selected);
    end
    
    % restrict to only selected ones
    derived_names(derived_selected);
    
    % find all supported types
    types = GetKnownSecondaryDimTypes(dimInfo);
    
    % N.B. ensure this matches the order in which string were placeed in
    % the list box! (see PopulateDimListBox.m)
    offset = 0;
    for i = 1:numel(types)
        
        % the number in this group
        n_shown = numel(dimInfo.(types{i}).disp);
        
        % which selected ones belong to this group?
        indexs = derived_selected((derived_selected > offset) & (derived_selected <= offset + n_shown)) - offset;
        dimInfo.(types{i}).disp(:) = false;      % reset them
        dimInfo.(types{i}).disp(indexs) = true;  % and set the selected ones
        
        % accounted for the selections less than or equal to this
        offset = offset + n_shown;
    
    end

    % the number in this group
    n_shown = numel(dimInfo.derived_disp);
    
    % which selected ones belong to this group?
    indexs = derived_selected((derived_selected > offset) & (derived_selected <= offset + n_shown)) - offset;
    dimInfo.derived_disp(:) = false;     % reset
    dimInfo.derived_disp(indexs) = true; % and set the marked ones
end