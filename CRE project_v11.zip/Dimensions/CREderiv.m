function dX = CREderiv(X, order, dt, varargin)
% function dX = CREderiv(X, order, dt, varargin)
% function to calculate derivites of the data X for the CRE project
% this function uses central finite differences


if (nargin < 3) || (numel(dt) == 0)
    dt = 1;  % time between rows of X
end

% preallocate output
dX = zeros(size(X));  % not much we can do here
    
if (size(X,1) < 2*order - 1)
    
    % nothing we can really do... just return zeros

elseif (order == 1)
    
    % fairly simple
    dX(1,:) = (X(2,:) - X(1,:)) / dt;
    dX(end,:) = (X(end,:) - X(end-1,:)) / dt;
    dX(2:end-1,:) = (X(3:end,:) - X(1:end-2,:)) / (2*dt);
    
elseif (order == 2)
    
    dt2 = dt.*dt;
    
    % use a forward / backwards approximation at the boundary
    dX(1,:) = (X(1,:) + X(3,:) - 2 * X(2,:)) / dt2;
    dX(end,:) = (X(end-2,:) + X(end,:) - 2 * X(end-1,:)) / dt2;
    
    % and the rest
    dX(2:end-1,:) = (X(3:end,:) + X(1:end-2,:) - 2*X(2:end-1)) / (dt2);
    

elseif (order > 2)
    
    % get the number of points
    n_points = size(X,1);
    
    % keep track if its odd
    is_odd = rem(order,2);
    
    if (is_odd)
        
        % assume x(3/2) = (x(1) + x(2)) / 2 - linear interpolation
        Xh = (X(2:end,:) + X(1:end-1,:)) / 2;
        
    end
    
    % recurse
    sign = -1;
    for i = 0:order
        
        % flip the sign
        sign = -sign;   % (-1)^i
        
        % get combinations
        combs = nchoosek(order,i);
        
        % use forwards differencing for the first order points
        dX(1:order-1,:) = dX(1:order-1,:) + sign * combs * X((1:order-1) + order - i, :);
        
        % use backwards differencing for the last order points
        dX(end-order+2:end,:) = dX(end-order+2:end,:) + sign * combs * X((n_points-order+2:n_points) - i, :);
        
        % and central differencing for the rest
        if (~is_odd)
            dX(order:end-order+1,:) = dX(order:end-order+1,:) + sign * combs * X((order:n_points-order+1) + (order / 2 - i), :);
        else
            dX(order:end-order+1,:) = dX(order:end-order+1,:) + sign * combs * Xh((order:n_points-order+1) + floor(order / 2 - i), :);
        end
        
    end
    
    dX = dX / (dt .^ order);

else    
    error('Invalid order inputted');
end