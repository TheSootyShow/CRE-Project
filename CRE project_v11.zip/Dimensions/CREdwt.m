function Y = CREdwt(X, wavelet, level_id)
% function Y = CREdwt(X, wavelet, level_id)
% function to perform a dwt on the input data

% get a numeric representation of the level
level = str2double(regexp(level_id, '\d+', 'match', 'once'));

% get the type (detail or approx)
type = lower(regexp(level_id, '[a-zA-z]+', 'match', 'once'));
type = type(1);

% check it worked
if isnan(level) || (numel(type) == 0) || ~any(type == 'ad')
    error('Unable to interpret wavlet level: %s', level_id);
end

% perform the dwt
[c,l] = wavedec(X, max(level), wavelet);

% preallocate output
Y = zeros(numel(X), numel(level));

for i = 1:numel(level)
    if (type(i) == 'd')
        
        % detail level
        d = detcoef(c,l,level(i));
        d = d(:).';
        d = d(ones(1,2^level(i)),:);
        Y(:,i) = wkeep1(d(:),size(X,1));
    else
        % approx level
        a = appcoef(c,l,level(i));
        a = a(:).';
        a = a(ones(1,2^level(i)),:);
        Y(:,i) = wkeep1(a(:),size(X,1));
    end
end