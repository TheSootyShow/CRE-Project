function name = CreateDimName(tag, inputs, varargin)
% function name = CreateDimName(tag, inputs, varargin)
% function to create a name for a derived dimension
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% tag       - the name of the derived dimension type (see InitDimStruct.m)
%
% inputs    - the names of the variables the derived dimenion is calculated
%             from
%           - this can either ba a single string, 
%             or a cell array of strings
%
% varargin  - any other inputs to the calculation function (e.g. derivitive
%             order)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% name      - the name of the dimension



% if input is a cell array of strings, convert to a single string
input_str = '';
if numel(inputs)
    if iscell(inputs)
        input_str = inputs{1};
        for i = 2:numel(inputs)
            input_str = sprintf('%s, %s', input_str, inputs{i});
        end
    else
        input_str = inputs;
    end
end


% now call the appropriate naming function
switch (lower(tag))
    case 'deriv'
        name = DerivName(input_str, varargin{:});
    case 'abs'
        name = AbsName(input_str, varargin{:});
    case 'const'
        name = ConstName(input_str, varargin{:});
    case 'dwt'
        name = DwtName(input_str, varargin{:});
    case 'sq'
        name = SqName(input_str, varargin{:});
    case 'rat'
        name = RatName(input_str, varargin{:});
    case 'sum'
        name = SumName(input_str, varargin{:});
    case 'sumsq'
        name = SumSqName(input_str, varargin{:});
    otherwise
        name = GenericName(tag, input_str, varargin{:});
end




function name = GenericName(tag, str, varargin)
% function name = GenericName(tag, str, varargin)

name = sprintf('%s(%s)', tag, str);

function name = DerivName(str, order, varargin)
% function name = DerivName(str, order, varargin)
% function to name a derivitive

if (order > 1)
    name = sprintf('d%i(%s)', order, str);
else
    name = sprintf('d(%s)', str);
end

function name = AbsName(str, varargin)
% function name = AbsName(str, varargin)
% function to name a derivitive

name = sprintf('|%s|', str);

function name = ConstName(str, value, name, varargin)
% function name = ConstName(str, order, varargin)
% function to name a constant


function name = SumName(str, varargin)
% function name = SumName(str, order, varargin)
% function to name a derivitive

% break into specific inputs
inputs = TokenizeFuncInputs(str);
name = sprintf('');
for i = 1:numel(inputs)
    inputs{i} = WrapInBrackets(inputs{i});
    name = sprintf('%s%s%s', name, repmat('+', 1, i > 1), inputs{i});
end
name = sprintf('%s', name);

function name = SqName(str, varargin)
% function name = SqName(str, order, varargin)
% function to name a derivitive

name = sprintf('%s^2', str);

function name = SumSqName(str, varargin)
% function name = SumSqName(str, order, varargin)
% function to name a derivitive

% break into specific inputs
inputs = TokenizeFuncInputs(str);
name = sprintf('sum(');
for i = 1:numel(inputs)
    inputs{i} = WrapInBrackets(inputs{i});
    name = sprintf('%s%s%s^2', name, repmat('+', 1, i > 1), inputs{i});
end
name = sprintf('%s)', name);

function name = RatName(str, varargin)
% function name = RatName(str, order, varargin)
% function to name a derivitive

inputs = TokenizeFuncInputs(str);
if (numel(inputs) ~= 2)
    error('Ratio should have two inputs');
end

for i = 1:numel(inputs)
    % does it need to be wrapped in bracket?
    inputs{i} = WrapInBrackets(inputs{i});
end
name = sprintf('%s/%s', inputs{1}, inputs{2});

function name = DwtName(str, type, level, varargin)
% function name = DwtName(str, order, varargin)
% function to name a derivitive

if ~strcmpi(type, 'db10')
    name = sprintf('dwt(%s,%s,%s)', str, type, level);
else
    name = sprintf('dwt(%s,%s)', str, level);
end




% function name = MagName(str, varargin)
% % function name = DerivName(str, order, varargin)
% % function to name a derivitive
% 
% name = sprintf('mag(%s)', str);
% 
% function name = CMagName(str, varargin)
% % function name = DerivName(str, order, varargin)
% % function to name a derivitive
% 
% name = sprintf('corrmag(%s)', str);
% 
% function [tag, inputs, args] = InvertDerivName(str)
% % function [tag, inputs, args] = InvertDerivName(str)
% % function to name a derivitive
% 
% % get the tag
% tag = 'deriv';  % always
% 
% % order string
% tag_str = regexpi(derived_names, '(?<=^\W*d)\d*(?=\()]+', 'match', 'once');
% 
% if numel(tag_str)
%     args = {str2double(tag_str)};
% else
%     args = {1};
% end
% 
% % extract inputs to the function
% input_str = regexp(str, '(?<=^.*\(\W*)\w*(?=\W*\)\W*$)', 'match', 'once');
% 
% % tokenize by inputs not in brackets
% inputs = TokenizeFuncInputs(input_str);


function [tag, inputs, args] = InvertAbsName(str)
% function [tag, inputs, args] = InvertDerivName(str)
% function to name a derivitive

% get the tag
tag = 'abs';  % always
args = {};    % no arguments for abs

% extract inputs to the function
input_str = regexp(str, '(?<=^.*\(\W*)\w*(?=\W*\)\W*$)', 'match', 'once');

% tokenize by inputs not in brackets
inputs = TokenizeFuncInputs(input_str);