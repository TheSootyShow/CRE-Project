function derived_dim = InitDerivedDim(siz)
% function derived_dim = InitDerivedDim(siz)
% function to intialise the form of a derived dimension
%
% derived_dim has fields:
%
%   'name'          -  the name of the derived dimension
%
%   'type'          - the type of derived dimension
%
%   'source'        - the source(s) of this dimension (1 x 4). 
%                   - Source has 1 rows for each of the n different types of sources 
%                     e.g. primary dimensions, derivitives, magnitudes, etc)
%                   - Source has 4 columns:
%                     1: a string containing the type of source (primary, derived, mixed)
%                     2: a vector of the primary dimensions the source is
%                               built from
%                     3: a cell array of the names of the derived dimensions the source is
%                               built from
%                     4: Unused
%
%   'type'          - the type of this dimension
%
%   'args'          - arguments relating to the type (e.g. derivitve order)
%
%   'extra_points'  - the number of "extra" points that should be provided
%                     to the function on each side of the data to calculate
%                     (e.g 1 extra point on each side is useful for
%                     calculating the 1st derivitve)
%
%   'func'          - function handle to the the function to calculate this dimension. 
%                   - the function should be vectorized to take an input X with the
%                     different sources in different columns of X.  Column order
%                     follows the order listed in the source CalculateDerivedDimension.m


derived_dim = struct('name',         '',          ...  
                     'type',         '',          ...
                     'source',       {cell(1,4)}, ...    
                     'args',         [],          ...
                     'extra_points', 0,           ...
                     'func',         []);

% create it to size?                 
if (nargin)
    if (numel(siz) == 1)
        siz = [siz, 1];
    end
    derived_dim = repmat(derived_dim, siz);
end
                 
                                                    
                                                    
