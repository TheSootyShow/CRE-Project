function varargout = ApplyKnownDimAliases(varargin)
% function to relabel dimension names
% input aliases should be sorted using OrderAliases
% Usages:
% 
% 1) function new_labels = ApplyKnownDimAliases(labels, aliases)
%
%     labels     - cell array of the original names for the dimensions
%     aliases    - an n x 2 cell array with the n used aliases
%                  the first column is the original name, 
%                  the seconds column is its new name
%     new_labels - dimension nameas after alias's have been applied

strip_cell = false;
if (nargin >= 1) && ischar(varargin{1})
    varargin{1} = {varargin{1}};
    strip_cell = true;
end
    


if (nargin == 2) && iscell(varargin{1}) && iscell(varargin{2})
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the cell array of names style (usage #1)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    labels = varargin{1};
    aliases = varargin{2};
    
    % get the expression form of the alias
    alias_expr = cellfun(@AliasToExpression, aliases(:,1), 'uniformoutput', false);

    % N.B. Aliases should be sorted on input
    for i = 1:numel(labels)
        for j = 1:size(aliases,1)
            labels{i} = regexprep(labels{i}, alias_expr{j}, aliases{j,2}, 'matchcase');
        end
    end

    % and return in the same style
    if (strip_cell)
        varargout{1} = labels{1};
    else
        varargout{1} = labels;
    end
    
elseif (nargin == 2) && isstruct(varargin{1})
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the dimension structure has been inputted
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    dimInfo = varargin{1};
       
    % are there aliases?
    if numel(dimInfo.aliases)
        
        % get the expression form of the alias
        alias_expr = cellfun(@AliasToExpression, dimInfo.aliases(:,1), 'uniformoutput', false);
    
        % which primary dimensions have aliases?
        for i = 1:numel(dimInfo.primary_names)
            for j = 1:size(dimInfo.aliases,2)
                dimInfo.primary_names{i} = regexprep(dimInfo.primary_names{i}, alias_expr{j}, dimInfo.aliases{j,2}, 'matchcase');
            end
        end
        
        % which simple secondary dimensions have aliases?
        known_types = GetKnownSecondaryDimTypes(dimInfo);
        for t = 1:numel(known_types)
            
            % which have aliases?
            for i = 1:numel(dimInfo.(known_types{t}).names)
                for j = 1:size(dimInfo.aliases,2)
                    dimInfo.(known_types{t}).names{i} = regexprep(dimInfo.(known_types{t}).names{i}, alias_expr{j}, dimInfo.aliases{j,2}, 'matchcase');
                end
            end
        end
        
        % and the more complex secondary dimensions
        dnames = {dimInfo.derived_dims(:).name};
        for i = 1:numel(dnames)
            for j = 1:size(dimInfo.aliases,2)
                dimInfo.derived_dims(i).name = regexprep(dimInfo.derived_dims(i).name, alias_expr{j}, dimInfo.aliases{j,2}, 'matchcase');
            end
        end
    end
    varargout{1} = dimInfo;
    
else
    error('Unknown input style');
end
    
    
    