function varargout = SelectDimsGui(varargin)
% function dimInfo = SelectDimsGui(dimInfo, data_set)
% SELECTDIMSGUI MATLAB code for SelectDimsGui.fig
%      SELECTDIMSGUI by itself, creates a new SELECTDIMSGUI or raises the
%      existing singleton*.
%
%      H = SELECTDIMSGUI returns the handle to a new SELECTDIMSGUI or the handle to
%      the existing singleton*.
%
%      SELECTDIMSGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECTDIMSGUI.M with the given input arguments.
%
%      SELECTDIMSGUI('Property','Value',...) creates a new SELECTDIMSGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SelectDimsGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SelectDimsGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SelectDimsGui

% Last Modified by GUIDE v2.5 05-Sep-2014 17:05:50

% use this to try and load a version that's already been resized
layout_fcn = GuiLayoutFunction('SelectDimsGui');

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SelectDimsGui_OpeningFcn, ...
                   'gui_OutputFcn',  @SelectDimsGui_OutputFcn, ...
                   'gui_LayoutFcn',  layout_fcn, ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before SelectDimsGui is made visible.
function SelectDimsGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SelectDimsGui (see VARARGIN)

% Choose default command line output for SelectDimsGui
handles.featSettings.dimInfo = varargin{1};
handles.featSettings.features = [];
handles.data_set = varargin{2};
handles.output = {'Cancel', handles.featSettings.dimInfo};

% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);

% make sure the pane is up to date
if (IsDeveloper())

    set(hObject, 'visible', 'on');
    handles = CopyDimTemplateToFigure(hObject, handles);
    
end

% call the resize function
SelectDimsGui_ResizeFcn(hObject, eventdata, handles);

% initialise it
handles.block_list = [];
InitialiseDimPane(handles.featSettings.dimInfo, handles);

% if the input is a feature set, pretend we're playing around with features
if strcmpi(handles.data_set.set_type, 'features')
    
    % find anything with dimensions in the string
    hUpdate = findobj(hObject, 'type', 'uicontrol');
    for i = 1:numel(hUpdate)
        str = get(hUpdate(i), 'string');
        if ischar(str)
            str = regexprep(str, 'secondary', 'post');
            str = regexprep(str, '[dD]imension', 'feature', 'preservecase');
        end
        set(hUpdate(i), 'string', str);
    end
    
    % find anything with dimensions in the title
    hUpdate = findobj(hObject, 'type', 'uipanel');
    for i = 1:numel(hUpdate)
        str = get(hUpdate(i), 'title');
        if ischar(str)
            str = regexprep(str, 'secondary', 'post');
            str = regexprep(str, '[dD]imension', 'feature', 'preservecase');
        end
        set(hUpdate(i), 'title', str);
    end
    set(hObject, 'name', 'Select Features');
    
end

% Update handles structure
guidata(hObject, handles);

% Set enabled status
EnableDisableOutput(handles);

% Make the GUI modal
set(handles.SelectDimsGui,'WindowStyle','modal')

% UIWAIT makes SelectDimsGui wait for user response (see UIRESUME)
uiwait(handles.SelectDimsGui);

% --- Outputs from this function are returned to the command line.
function varargout = SelectDimsGui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;

% The figure can be deleted now
delete(handles.SelectDimsGui);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.featSettings.dimInfo};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.SelectDimsGui);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.featSettings.dimInfo};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.SelectDimsGui);


% --- Executes when user attempts to close SelectDimsGui.
function SelectDimsGui_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to SelectDimsGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over SelectDimsGui with no controls selected.
function SelectDimsGui_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to SelectDimsGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
if isequal(get(hObject,'CurrentKey'),'escape')
    % User said no by hitting escape
    handles.output = {'Cancel',handles.featSettings.dimInfo};
    
    % Update handles structure
    guidata(hObject, handles);
    
    uiresume(handles.SelectDimsGui);
end    
    
if isequal(get(hObject,'CurrentKey'),'return')
    uiresume(handles.SelectDimsGui);
end    


% --- Executes when SelectDimsGui is resized.
function SelectDimsGui_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to SelectDimsGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (RunResizeFcn(hObject, handles))

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);

    % Default layout of the dimension pane
    [hCell,  hGap, vGap, uiSizes] = DefaultDimPaneLayout(handles);
    
    % Add the OK / Cancel button
    hCell = {hCell, 'l'; handles.pbOK, handles.pbCancel};
    hGap = {hGap, []; [], []};
    vGap = {vGap, []; [], []};
    uiSizes = {uiSizes, []; [], []};
    
    % now call the resize function
    ResizeFigFromPanes(hCell, hGap, vGap, uiSizes, true);
    
    % save the resized figure
    SaveResizedCREFigure(hObject);
    
end
