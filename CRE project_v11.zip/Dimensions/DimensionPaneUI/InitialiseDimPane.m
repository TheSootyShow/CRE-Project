function InitialiseDimPane(dimInfo, handles)
% function InitialiseDimPane(dimInfo, handles)
% function to initialise the dimensions pane


% get all of the dimension names
[names, displayed, n_prim] = GetAllDimensionNames(dimInfo);
    
% get the primary dims
prim_list = names(1:n_prim);
prim_displayed = displayed(1:n_prim);
prim_index = 1:n_prim;

% and set the list boxes
SetListBox(handles.lbAvailPrimDims, prim_list(~prim_displayed), prim_index(~prim_displayed));
SetListBox(handles.lbSelPrimDims, prim_list(prim_displayed), prim_index(prim_displayed));

% get the secondary dims
secondary_list = names(n_prim+1:end);
secondary_displayed = displayed(n_prim+1:end);
secondary_index = n_prim+1:numel(names);

% remove and secondary dimensions that match a primary (can happen on exported set)
match = ismember(secondary_list, prim_list);
secondary_list(match) = [];
secondary_displayed(match) = [];
secondary_index(match) = [];

% and set the list boxes
SetListBox(handles.lbAvailSecDims, secondary_list(~secondary_displayed), secondary_index(~secondary_displayed));
SetListBox(handles.lbSelSecDims, secondary_list(secondary_displayed), secondary_index(secondary_displayed));

% and the text describing the number of entries
set(handles.txtNumPrimDims, 'string', regexprep(get(handles.txtNumPrimDims, 'String'), '\d+', num2str(sum(prim_displayed))));
set(handles.txtNumSecDims, 'string', regexprep(get(handles.txtNumSecDims, 'String'), '\d+', num2str(sum(secondary_displayed))));



function SetListBox(hList, string, indexs)
% function SetListBox(hList, string, indexs)
% function to set values for a list box

indexs = indexs(:);
[tmp, order] = sort(indexs);

set(hList, 'ListboxTop', 1); 
set(hList, 'string', string);
set(hList, 'userdata', indexs(order));
set(hList, 'Min', 0);
set(hList, 'Max', max(numel(string),2));  % ensure its not in single selection mode
set(hList, 'value', []); 





