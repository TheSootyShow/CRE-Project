function DimPaneCallbacks(hObject, eventdata, handles)
% function DimPaneCallbacks(hObject, eventdata, handles)
% this function has the callbacks for the ui components of the time pane

% disable the figure while this executes
% hFig = ancestor(hObject,'figure');  % make sure hFig is a figure
% EnableDisableFig(hFig, 'off');

try
    
    % ensure handles are available
    if (nargin < 3)
        handles = guidata(hObject);
    end


    % this style is only OK for CREfeatureGui
    dimInfo = handles.featSettings.dimInfo;  % make sure to reassign it at the end
    
    
    % get which ui componenent it is from the tag
    tag = get(hObject, 'tag');
    type = get(hObject, 'type');
    if strcmpi(type, 'uicontrol')
        type = get(hObject, 'style');  % if we're in a callback its a uicontrol
    end
    
    if strcmpi(type, 'uiMenu')
        
        % add the specified feature
        type_str = regexp(tag, '(?<=miDimAdd)\w+', 'match', 'once');
        dimInfo = AddDimension(dimInfo, type_str, handles);
        
    elseif strcmpi(tag, 'pbSelPrimDim')
        
        % make primary dimensions visible
        dimInfo = SetDimVisible(dimInfo, handles.lbAvailPrimDims, handles.lbSelPrimDims, handles.txtNumPrimDims, true);
        
    elseif strcmpi(tag, 'pbUnSelPrimDim')
        
        % make primary dimensions invisible
        dimInfo = SetDimVisible(dimInfo, handles.lbSelPrimDims, handles.lbAvailPrimDims, handles.txtNumPrimDims, false);
        
    elseif strcmpi(tag, 'pbSelSecDim')
        
        % make secondary dimensions visible
        dimInfo = SetDimVisible(dimInfo, handles.lbAvailSecDims, handles.lbSelSecDims, handles.txtNumSecDims, true);
        
    elseif strcmpi(tag, 'pbUnSelSecDim')
        
        % make secondary dimensions invisible
        dimInfo = SetDimVisible(dimInfo, handles.lbSelSecDims, handles.lbAvailSecDims, handles.txtNumSecDims, false);
        
    elseif strcmpi(tag, 'pbAddDims')
        
        % add extra dimensions, prompt the user for what type
        dimInfo = AddDimension(dimInfo, [], handles);
        
    elseif strcmpi(tag, 'pbRelabelDims')
        
        % add aliases for existing dimensions
        dimInfo = RelabelDims(dimInfo, handles);
        
    else
        
        % Probably list box selection
        return;
        
    end
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % specific to CREfeatureGui
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % reassign to handles )
    handles.featSettings.dimInfo = dimInfo;
    
    % update the full feature list
    if isfield(handles.featSettings, 'features') && (numel(handles.featSettings.features))
        
        % check the post process features are all available
        if numel(handles.featSettings.postFeatures)
       
            % check
            handles.featSettings = MapPostFeaturesToDataSet(handles.featSettings);
            
            % redraw the post features panel
            InitialisePostPane(handles.featSettings, handles);
            
        end
        
        % process all of the features
        [handles.featSettings, aliasList, display, idx, featList] = ProcessFeatures(handles.featSettings, handles.data_set, true);
        
        % update the control
        handles.featSettings = UpdateFeatListControl(handles.lbAllFeats, handles.featSettings, aliasList, display, idx, featList);
    end
    
    % set gui output availability
    EnableDisableOutput(handles);
    
    % update
    guidata(hObject, handles);
    
    % re-enable for the next callback
%    EnableDisableFig(hFig, 'on');
    
catch ME
    
    % re-enable for the next callback
    % EnableDisableFig(hFig, 'on');
    
    % what's the current figure?
    hFig = ancestor(hObject, 'figure');
    if numel(hFig) && strcmpi(get(hFig, 'tag'), 'CREFeatureGui')
        
        % It has a dedicated error handler
        ProcessFeatureGuiError(ME);
    
    else
        
        if (~IsDeveloper)
            errordlg('Unable to process requested dimension option', 'Error', 'modal');
        else
            rethrow(ME);
        end
    end
    
end


function dimInfo = AddDimension(dimInfo, type, handles)
% function dimInfo = AddDimension(dimInfo, type, handles)
% function to add an extra dimension

% get a long version of the dimension names
uiMenus = get(handles.uiAddDim, 'children');
types = get(uiMenus, 'tag');

% drop the add from the front of them
types = strrep(types, 'miDimAdd', '');
types = flipud(types);  % match display order

% in some case we want to pretend these are features
dimType = {'dim', 'feat'};
dimType = dimType{1 + (numel(regexpi(get(handles.pbAddDims, 'string'), 'feat', 'match', 'once')) > 0)};

% call the selection ui
[dimInfo, new_names] = SecondaryDimensionUI(dimInfo, type, handles.data_set.fs, types, dimType);
    
% now update the list boxes if the user said yes
if (numel(new_names))
    
    % Update the dimensions
    InitialiseDimPane(dimInfo, handles);
    
    % set the top of the list box to the first one we just added
    all_derived = get(handles.lbSelSecDims, 'string');
    was_added = ismember(all_derived, new_names);
    first_new = find(was_added, 1, 'first');
    set(handles.lbSelSecDims,'ListboxTop', first_new);
    
end


function dimInfo = RelabelDims(dimInfo, handles)
% function dimInfo = RelabelDims(dimInfo, handles)
% function to add an extra dimension

% get all dimensions names
dim_names = GetAllDimensionNames(dimInfo, true);

% in some case we want to pretend these are features
type = {'dim', 'feat'};
type = type{1 + (numel(regexpi(get(handles.pbRelabelDims, 'string'), 'feat', 'match', 'once')) > 0)};

% and call the gui
[resp, new_aliases] = CreateAliasesGUI(dim_names, dimInfo.aliases, type);

% how did the user respond?
if strcmpi(resp, 'OK')
    
    % update the aliases
    dimInfo.aliases = new_aliases;
    
    % Update the dimensions
    InitialiseDimPane(dimInfo, handles);
        
end



function dimInfo = SetDimVisible(dimInfo, hBefore, hAfter, hNumber, display)
% function dimInfo = SetDimVisible(dimInfo, hBefore, hAfter, hNumber, display) 
% function to transfer diemnions from the display box to the other box

% the move from list box
bStrings = get(hBefore, 'string');
bIndexs = get(hBefore, 'userdata');

% the move to list box
aStrings = get(hAfter, 'string');
aIndexs = get(hAfter, 'userdata');

% what to transfer?
tValues = get(hBefore, 'value');
if (numel(tValues) == 0)
    return;  % nothing to do
end

tStrings = bStrings(tValues);
tIndexs = bIndexs(tValues);

% the new before list box
bStrings(tValues) = [];
bIndexs(tValues) = [];

% the new after box (gets sorted by the set function)
aStrings = [aStrings(:); tStrings];
aValues = numel(aIndexs)+(1:numel(tIndexs));
aIndexs = [aIndexs(:); tIndexs];

% set both list boxes
SetListBox(hBefore, bStrings, bIndexs, []);
SetListBox(hAfter, aStrings, aIndexs, aValues);

% and update the dim count
if (display)
    set(hNumber, 'string', regexprep(get(hNumber, 'String'), '\d+', num2str(numel(get(hAfter, 'string')))));
else
    set(hNumber, 'string', regexprep(get(hNumber, 'String'), '\d+', num2str(numel(get(hBefore, 'string')))));
end

% and set the visiblities in the structure
dimInfo = SetDimVisibility(dimInfo, tIndexs, display, false);


function SetListBox(hList, string, indexs, values)
% function SetListBox(hList, string, indexs, values)
% function to set values for a list box

[tmp, order] = sort(indexs);

set(hList, 'string', string(order));
set(hList, 'userdata', indexs(order));
set(hList, 'Min', 0);
set(hList, 'Max', max(numel(string),2));  % ensure its not in single selection mode
set(hList, 'ListboxTop', 1); 

% have to match the values to the sorted order
[tmp, idx] = ismember(values, order);
set(hList, 'value', idx); 






