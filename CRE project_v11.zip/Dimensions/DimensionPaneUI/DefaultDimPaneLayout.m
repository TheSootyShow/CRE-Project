function [hCell,  hGap, vGap, sizes] = DefaultDimPaneLayout(handles, smallGap, normGap, largeGap)
% function  [hPanel, panelSize] = DefaultDimPaneLayout(handles, smallGap, normGap, largeGap)
% function to build the default dimension pane layout


if (nargin < 2)

    % build default gaps
   [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% First build the primary dimensions UI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hPrimary = {handles.txtAvailPrimDims, [],                     handles.txtSelPrimDims; ...
            handles.lbAvailPrimDims,  [],                     handles.lbSelPrimDims;  ...
            handles.lbAvailPrimDims,  handles.pbSelPrimDim,   handles.lbSelPrimDims;  ...
            handles.lbAvailPrimDims,  handles.pbUnSelPrimDim, handles.lbSelPrimDims;  ...
            handles.lbAvailPrimDims,  [],                     handles.lbSelPrimDims;  ...
            [],                       [],                     handles.txtNumPrimDims};

% spacing     
hPrimGap = repmat(normGap, size(hPrimary,1), size(hPrimary,2) - 1);
vPrimGap = repmat(normGap, size(hPrimary,1)-1, size(hPrimary,2));        
vPrimGap([1, 5],:) = smallGap;

% and size info
primSizes = PaneSizesFromGrid(hPrimary);        
primSizes{5,3} = primSizes{5,1};  % ensure the list boxes are the same size

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now build the secondary dimensions UI
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hSecondary={handles.txtAvailSecDims, [],                     handles.txtSelSecDims; ...
            handles.lbAvailSecDims,  [],                     handles.lbSelSecDims;  ...
            handles.lbAvailSecDims,  handles.pbSelSecDim,   handles.lbSelSecDims;  ...
            handles.lbAvailSecDims,  handles.pbUnSelSecDim, handles.lbSelSecDims;  ...
            handles.lbAvailSecDims,  [],                     handles.lbSelSecDims;  ...
            [],                      [],                     handles.txtNumSecDims; ...
            handles.pbAddDims,       [],                     handles.pbRelabelDims};

% spacing     
hSecGap = repmat(normGap, size(hSecondary,1), size(hSecondary,2) - 1);
vSecGap = repmat(normGap, size(hSecondary,1)-1, size(hSecondary,2));        
vSecGap([1, 5],:) = smallGap;

% and size info
secSizes = PaneSizesFromGrid(hSecondary);        


% put it all together
hCell = {hPrimary; hSecondary};
hGap = {hPrimGap; hSecGap};
vGap = {vPrimGap; vSecGap};
sizes = {primSizes; secSizes};

