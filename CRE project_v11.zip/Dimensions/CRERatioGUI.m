function varargout = CRERatioGUI(varargin)
% CRERatioGUI(dim_names)
% creratiogui MATLAB code for creratiogui.fig
%      creratiogui by itself, creates a new creratiogui or raises the
%      existing singleton*.
%
%      H = creratiogui returns the handle to a new creratiogui or the handle to
%      the existing singleton*.
%
%      creratiogui('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in creratiogui.M with the given input arguments.
%
%      creratiogui('Property','Value',...) creates a new creratiogui or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CRERatioGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CRERatioGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help creratiogui

% Last Modified by GUIDE v2.5 03-Jul-2014 18:15:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CRERatioGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @CRERatioGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before creratiogui is made visible.
function CRERatioGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to creratiogui (see VARARGIN)

if (numel(varargin) < 1) || ~iscell(varargin{1}) || (numel(varargin{1}) < 1)
    error('At least least two dimensions must exist for a ratio')
end

% set up the list boxes
set([handles.lbNumerator, handles.lbDenominator], 'string', varargin{1});
set(handles.lbNumerator, 'value', 1);
dind = min(2, numel(varargin{1}));
set(handles.lbDenominator, 'value', dind);
if (dind > 1)
    set(handles.pbOK, 'enable', 'on');
else
    set(handles.pbOK, 'enable', 'off');
end

% Choose default command line output for creratiogui
handles.output = {'Cancel', varargin{1}{1}, varargin{1}{dind}};


% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);


% resize this gui
handles = CRERatioGUI_ResizeFcn(hObject, eventdata, handles);

% commit
guidata(hObject, handles);

% Make the GUI modal
set(handles.CRERatioGUI,'WindowStyle','modal')

% UIWAIT makes creratiogui wait for user response (see UIRESUME)
uiwait(handles.CRERatioGUI);

% --- Outputs from this function are returned to the command line.
function varargout = CRERatioGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;

% The figure can be deleted now
delete(handles.CRERatioGUI);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% set up the output
handles.output{1} = get(hObject,'String');

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CRERatioGUI);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), [], []};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CRERatioGUI);


% --- Executes when user attempts to close creratiogui.
function CRERatioGUI_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to creratiogui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over creratiogui with no controls selected.
function CRERatioGUI_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to creratiogui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
if isequal(get(hObject,'CurrentKey'),'escape')

    % User said no by hitting escape
    handles.output = {'Cancel', '', ''};
    
    % Update handles structure
    guidata(hObject, handles);
    
    uiresume(handles.CRERatioGUI);
end    
    
if isequal(get(hObject,'CurrentKey'),'return')
    uiresume(handles.CRERatioGUI);
end    


% --- Executes when creratiogui is resized.
function handles = CRERatioGUI_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to creratiogui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call the feature layout function
if (RunResizeFcn(hObject, handles))

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);
    
    % standardized gaps between objects
    [smallGap, normGap, largeGap] = DefaultPaneGaps();

    % build grid layout
    hGrid = cell(3,3);
    hGrid(1,:) = {handles.txtNumerator, [], handles.txtDenominator};
    hGrid(2,:) = {handles.lbNumerator, handles.txtOperator, handles.lbDenominator};
    hGrid(3,:) = {handles.pbCancel, [], handles.pbOK};
    
    % verical spacing
    v_space = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));
    v_space(1,:) = smallGap;   % small gap between title and list boxes
    v_space(end,:) = largeGap; % LARGE gap between list boxes and OK / CANCEL
    
    % horizontal spacing
    h_space = repmat(largeGap, size(hGrid,1), size(hGrid,2)-1);
    
    % and call the resize
    ResizePaneFromGrid(hGrid, h_space, v_space);
    
    % and save it
    handles = SaveResizedCREFigure(hObject, [], handles);

end
    
    
    




% --- Executes on selection change in lbNumerator.
function List_Callback(hObject, eventdata, handles)
% hObject    handle to lbNumerator (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbNumerator contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbNumerator

dims = get(handles.lbNumerator, 'String');
numerator = dims{get(handles.lbNumerator, 'Value')};
denominator = dims{get(handles.lbDenominator, 'Value')};

if (numel(numerator) == 0) || (numel(denominator) == 0) || strcmpi(numerator, denominator)
    handles.output = {'Cancel', '', ''};
    set(handles.pbOK, 'enable', 'off');
else
    handles.output = {'OK', numerator, denominator};
    set(handles.pbOK, 'enable', 'on');
end
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function Default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbNumerator (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
