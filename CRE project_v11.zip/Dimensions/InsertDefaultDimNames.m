function data_set = InsertDefaultDimNames(data_set)
% function data_set = InsertDefaultDimNames(data_set)
% function to insert default dimension names into the data set

% create names
if (data_set.dims <= 3)
    names = {'X', 'Y' 'Z'};
    data_set.dim_names = names(1:data_set.dims);
else
    data_set.dim_names = num2cell(1:data_set.dims);
    data_set.dim_names = cellfun(@(x)(['X', num2str(x)]), data_set.dim_names, 'Uniformoutput', false);
end