function aliases = OrderAliases(aliases)
% function aliases = OrderAliases(aliases)
% function to order a list of aliases

% the expression form of the alias's
alias_expr = cellfun(@AliasToExpression, aliases, 'uniformoutput', false);

% how many feed into a particulart alias
depend_ids = cell(size(aliases,1),1);
filled = false(size(aliases,1),1);

for i = 1:size(aliases)
    
    % find all inherited dependencies
    [depend_ids, filled] = FillDependencies(i, depend_ids, aliases, alias_expr, filled, 0);
    
end

% now go through creating a full list
order = zeros(size(aliases,1), 1);
n_ordered = 0;
while any(order == 0)

    % try all unordered ones
    inds = find(order == 0);
    for i = 1:numel(inds)
        if (numel(depend_ids{inds(i)}) == 0) || all(order(depend_ids{inds(i)}) > 0)
            n_ordered = n_ordered + 1;
            order(inds(i)) = n_ordered;
        end
    end
end


function [depend_ids, filled] = FillDependencies(index, depend_ids, aliases, alias_expr, filled, lmax)
% function [depend_ids, filled] = FillDependencies(index, depend_ids, aliases, alias_expr, filled, lmax)
% function to fill all dependencies

if (~filled(index))
    
    % does it match anything?
    depend_ids{index} = find(cellfun(@(x)(numel(x) > 0), regexp(aliases(index,1), alias_expr(:,2))));
        
    % recursively work out their dependencies
    for i = 1:numel(depend_ids{index})
        cd = depend_ids{index}(i);  % current dependency
        if (~filled(cd))
            if (numel(depend_ids{cd}))
                circ_str = TraceCircular(cd, aliases);
                error('Circular referencing: %s', circ_str);
            end
            [depend_ids{cd}, filled] = FillDependencies(cd, depend_ids, aliases, alias_expr, filled, lmax+1);
        end
        depend_ids{index} = unique([depend_ids{index},  depend_ids{cd}]);
    end
    
    % and its filled
    filled(index) = true;
end

function str = TraceCircular(start, aliases)
% function str = TraceCircular(start, aliases)
% function to display a circular path

paths = {start};
plen = 1;
completed = false;
cr = 0;

while (~any(completed)) && (cr < size(paths,1))
    cr = cr + 1;
    while (~completed(cr))
        alias_expr = AliasToExpression(aliases{paths{cr, plen(cr)}, 2});
        matches = find(cellfun(@(x)(numel(x) > 0), regexp(aliases(:,1), alias_expr)));
        if (numel(matches) == 0)
            completed(cr) = true;
        else
            
            % create new paths if needed
            arows = [cr, size(paths,1)+(1:numel(matches)-1)];
            paths(arows, :) = repmat(paths(cr, :), numel(arows), 1);  % copy the path to here
            plen(arows,1) =  plen(cr,1) + 1;
            paths(arows, plen(cr)) = num2cell(matches(:));
            completed(arows,1) = matches(:) == start;
        end
    end
end

if (~completed(cr))
    error('Did not find circular path');
else
    % rebuild the path
    str = sprintf('%s', aliases{start,1});
    for i = 1:plen(cr)-1
        if (i > 1) && ~strcmp(aliases{paths{cr, i-1}, 2}, aliases{paths{cr, i}, 1})
            str = sprintf('%s -> %s', str, aliases{paths{cr, i}, 1});
        end
        str = sprintf('%s -> %s', str, aliases{paths{cr, i}, 2});
    end
end




