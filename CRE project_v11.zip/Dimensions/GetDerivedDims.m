function [X, data_set] = GetDerivedDims(data_set, fp, lp, grab_dims)
% function [X, data_set] = GetDerivedDims(data_set, fp, lp, grab_dims)
% function [X, data_set] = GetDerivedDims(Xp, grab_dims)
% function to get the data and calculate any derived dimensions
%
%
% Notes:
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!


persistent lastExtraPoints;  % keep this to store extra points values
                             % we do this so the file ptr never has to go
                             % backwards

% initialise the persistent structure
if (numel(lastExtraPoints) == 0)
          lastExtraPoints = struct('file_name',  '',       ...
                                   'indexs',     [-1, -1], ...  % where we are in samples
                                   'data',       []);      ...  % the data from indexs
    
end

% the style with primary dimensions already loaded
if (nargin == 2)
    grab_dims = fp;
    X = data_set;
end

% are there any derived dimensions?
has_derived_dims = numel(grab_dims.derived_name) > 0; 

if (~has_derived_dims)
    
    % no derived units, easy case
    if (nargin > 2)
        % the case where we load the data
        [X, data_set] = GetData(data_set, [fp, lp], false, grab_dims.primary_dims(grab_dims.primary_disp));
    else
        % in this case we're just returning the input
    end
    
else
    
    % how many points are we grabbing?
    n_prim = numel(grab_dims.primary_dims);
    n_derived = numel(grab_dims.derived_name);
    total_dims = n_prim + n_derived;
    
    % the loading the data case
    if (nargin > 2)
    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % How many extra points do we try and grab for
        % the derived functions?
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        add_s = min(fp - 1, grab_dims.extra_points);
        add_e = min(data_set.num_points - lp, grab_dims.extra_points);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Start by grabbing primary dimension
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        n_points = lp - fp + 1 + add_s + add_e;
        
        % create space
        X = zeros(n_points, total_dims);
        
        % can we use a previous read for add_s?
        if strcmpi(data_set.file_name, lastExtraPoints.file_name) && all([fp - add_s, fp-1] == lastExtraPoints.indexs)
            X(1:add_s, 1:numel(grab_dims.primary_dims)) = lastExtraPoints.data;  % grab from here
            [Xl, data_set] = GetData(data_set, [fp, lp+add_e], false, grab_dims.primary_dims);
            X(add_s+1:add_s+size(Xl,1), 1:numel(grab_dims.primary_dims)) = Xl;
            bsiz = add_s+size(Xl,1);
        else
            [Xl, data_set] = GetData(data_set, [fp - add_s, lp+add_e], false, grab_dims.primary_dims);
            X(1:size(Xl,1), 1:numel(grab_dims.primary_dims)) = Xl;
            bsiz = size(Xl,1);
        end
        
        % any missing points? (from end of file)
        mp = size(X,1) - bsiz;
        if (mp > 0)
            add_e = max(add_e - mp,0);
            X(bsiz+1:end, :) = [];
        end
        
        % store the last extra points
        if (add_e > 0)
            lastExtraPoints.file_name = data_set.file_name;
            lastExtraPoints.indexs = [lp+1, lp+add_e];
            lastExtraPoints.data = X(end-add_e+1:end, 1:numel(grab_dims.primary_dims));
        end
        
    else
        % primary dims already loaded case
        % expand the buffer
        add_s = 0;
        add_e = 0;
        X(end, total_dims) = 0;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Now process derived dimension
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for i = 1:n_derived
        
        % sanity check
        if (any(grab_dims.derived_input_col{i}) >= n_prim + i)
            error('Failed to correctly parse derived dimensions (order)');
        end
        
        % and calculate
        X(:, n_prim + i) = feval(grab_dims.derived_func{i}, X(:, grab_dims.derived_input_col{i}),  grab_dims.derived_args{i}{:});
    
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Now trim X back to the correct number of points
    % and only the dimensions to display
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    show_dims = [grab_dims.primary_disp, grab_dims.derived_disp];
    if ~all(show_dims) || (add_s > 0) || (add_e > 0)
        X = X(add_s+1:end-add_e, show_dims);
    end
    
end
    
 
