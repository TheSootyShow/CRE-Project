function fs_str = FsString(fs)
% function fs_str = FsString(fs)
% function to convert the sampling frequency into a full precision
% decimal string

if (numel(fs) == 0)
    error('No sampling frequency provided');
end


sc = 0;  % scaling factor
if (fs > 0)
    p10 = ceil(log10(fs));  % what power of 10?
    if (p10 < 0)
        sc = -p10;          % scale the number by 10^sc during initial conversion
    end
end

% note: this prints more at max precision
fs_str = sprintf('%0.18f', 10^sc * fs);

% now shift the decimal if we scaled it
if (sc > 0)
    dec_ind = find(fs_str == '.', 1, 'first');
    new_dec_ind = dec_ind - sc;
    if (new_dec_ind <= 0)
        add_zeros = -new_dec_ind + 1;
        fs_str = sprintf('0.%s%s', repmat('0', 1, add_zeros), fs_str(fs_str ~= '.'));
    else
        fs_str = sprintf('%s.%s%s', fs_str(1:new_dec_ind-1), fs_str(new_dec_ind:dec_ind-1), fs_str(dec_ind+1:end));
    end
    
end

% now prune of trailing 0's in the decimal
fs_str = TrimDecimals(fs_str);

% if any(fs_str == '.')
%     dec_ind = find(fs_str == '.', 1, 'first');
%     n_prune = 0;
%     while ((numel(fs_str) - n_prune) > dec_ind) && (fs_str(numel(fs_str) - n_prune) == '0')
%         n_prune = n_prune + 1;  
%     end
%     
%     % get rid of the decimal point if its not needed
%     n_prune = n_prune + ((numel(fs_str) - n_prune) == dec_ind);
%     
%     % and prune
%     if (n_prune)
%         fs_str = fs_str(1:numel(fs_str) - n_prune);
%     end
% end
