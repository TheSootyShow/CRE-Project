function data_set = GetCREHeader(data_set, hlines)
% function data_set = GetCREHeader(data_set, hlines)
% function to fill header data from a csv exported by the CRE gui
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set - the data set structure to fill with meta data (see InitDataStruct.m)
%
% h_lines  - a cell array containing the first n lines of the csv file
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set     - the data set structure with filled meta data
%
% header_lines - the number of lines in the header (data starts at
%                line header_line + 1)


if ~(numel(strfind(lower(hlines{1}), lower('CRE Custom'))))
    error('File does not appear to be a CRE csv file');
end


% special import fields (they require modification)
spec_fields = {'tstamp', @(time_str)AmbigTimeStr(time_str, true); ...                                   % convert to a time stamp
               'fs',     @(fs_str)ParseFsStr(fs_str)};  % strip the Hz thats in the header
           
% use this to ensure we dont add fields to the structure           
field_names = fieldnames(data_set);           
           
% now go through each line
header_lines = 2;  % the first line has no useful data
while (header_lines <= numel(hlines)) && ~all(hlines{header_lines} == '-')  % the dash denotes the end of the header
    
    % each line is generally wrapped in quotes
    if (numel(hlines{header_lines}) && (hlines{header_lines}(1) == '"') && (hlines{header_lines}(end) == '"'))
        hlines{header_lines} = hlines{header_lines}(2:end-1);
    end
    
    % parse this line
    [tokens, other] = regexp(hlines{header_lines}, '=', 'split', 'match');
    
    if (numel(tokens) == 2)
        
        % get the field
        field = strtrim(tokens{1});
        
        % does it match something in the structure?
        if any(strcmpi(field, field_names))
            
            % parse the data value
            raw_data = strtrim(tokens{2});
            
            % does it require pre-processing?
            spec_ind = find(strcmpi(spec_fields(:, 1), field));
            if numel(spec_ind)
                raw_data = feval(spec_fields{spec_ind, 2}, raw_data);
            end
            
            % is it a matrix or cell?
            if any(raw_data == '[') || any(raw_data == '{')
                value = ParseArray(raw_data);
            else
                
                % its scalar
                if ischar(raw_data)                % special functions may have changed this
                    value = str2double(raw_data);  % numeric or otherwise?
                    if ~(numel(value) && isfinite(value))
                        value = raw_data;  % its a string
                    end
                else
                    value = raw_data;  % its numeric
                end
            end
            
            % and assign it
            data_set.(field) = value;
            
        end
    end
    header_lines = header_lines + 1;
end
data_set.hlines = header_lines + 1;  % plue one here because we put column headings after the dashed lined







