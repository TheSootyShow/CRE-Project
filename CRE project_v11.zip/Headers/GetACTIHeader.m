function data_set = GetACTIHeader(data_set, hlines)
% function data_set = GetACTIHeader(data_set, hlines)
% function to fill header data from an actiset CSV
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set - the data set structure to fill with meta data (see InitDataStruct.m)
%
% h_lines  - a cell array containing the first n lines of the csv file
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set     - the data set structure with filled meta data
%
% header_lines - the number of lines in the header (data starts at
%                line header_line + 1)


% which ACTI (graph / life)?
data_set.device_type = regexpi(hlines{1}, 'acti(life|graph)', 'match', 'once');

if (numel(data_set.device_type) == 0)
    error('File does not appear to be an actigraph / actilife csv');
end

% get date format from the first line
dformat = GetHeaderValue(lower(hlines{1}), 'date format', '\s', true);
if ~numel(dformat)
    error('Could not recovering the date format in file: %s', data_set.file_name);
end

% get a list of interpretable prefixes to Hz
prefixes = ParseFsStr();  

% the first column is what its called in the header, the second the field
% of dataset, the 3rd is a processing function to convert
conversions = {'(\W|^)serial number:*(\W|$)',                      'device_serial', @(str, data_set)(str); ...
               '(\W|^)start time:*(\W|$)',                         'tstamp',        @(str, data_set)(AddDateVectors(data_set.tstamp, AmbigTimeStr(str, true))); ...   
               '(\W|^)start date:*(\W|$)',                         'tstamp',        @(str, data_set)(AddDateVectors(data_set.tstamp, ACTIDateFormat(str, dformat))); ...
               ['(\W|^)[\d\.]+\s+[',prefixes,']*[hH][zZ](\W|$)'],  'fs',            @(str, data_set)(ParseFsStr(str))
               };
               
% reset the data set time stamp
data_set.tstamp = zeros(1,6);

% now retrieve whatever else we can
cline = 1;
while (cline < numel(hlines)) && (~all(hlines{cline} == '-'))
    
    % try each possibility
    for i = 1:size(conversions, 1)
        
        % what line is this?
        if numel(regexpi(hlines{cline}, conversions{i,1}, 'match', 'once'))
            
            % what value?
            if (i ~= size(conversions,1))
                % normal case is for the value to be after the keyword
                value_str = GetHeaderValue(hlines{cline}, conversions{i,1}, '\s', true);
            else
                % but in the hz case the value comes before the keyword
                % (use the original search token)
                value_str = regexp(hlines{cline} ,conversions{i,1}, 'match', 'once');
                
            end
            
            % and assign
            try
                data_set.(conversions{i,2}) = feval(conversions{i,3}, value_str, data_set);
            catch ME
                error('Could not extract value for %s from line:\n%s', conversions{i,1}(regexp(conversions{i,1}, '(?<!\\)[\w \[\]]')), hlines{cline});
            end
            
            break;  % no need to check the other conversions
            
        end
    end
    
    % move one forward
    cline = cline+1;
end

if (~all(hlines{cline} == '-'))
    error('Failed to find the end of the ACTI header in CSV: %s', data_set.file_name);
else
    data_set.hlines = cline;
end