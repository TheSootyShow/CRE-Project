function data_set = HeaderInfFromLines(data_set, header_str)
% function data_set = HeaderInfFromLines(data_set, header_str)
% this function examines the lines in header str to determine where the
% data starts, its delimiter, its dimesnionality, and whether the first
% column is a time

% add potential delimiters to this string
delim_opts = sprintf(',\t; ');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Start by finding the delimiter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% dont treat delimiters inside any of these
pre_ignore = '([{"';
post_ignore = ')]}"';
ignore_count = zeros(1, numel(pre_ignore));

% this matrix keeps track of the number of delimiters found of each type
delim_mat = zeros(numel(header_str), numel(delim_opts));

% count them
for i = 1:numel(header_str)
            
    % ignore delimiters in quotes, or inside brackets or preceded by a \
    header_str{i} = regexprep(header_str{i}, '\s{2,}', ' ');  % replace consecutive spaces with just the one
    line = header_str{i};
    
    for j = 1:numel(line)
        
        % is this the beginning of an ignore section?
        ignore_count((line(j) == pre_ignore)) = ignore_count((line(j) == pre_ignore)) + 1;
        
        % is this the end of an ignore section?
        ignore_count((line(j) == post_ignore)) = max(ignore_count((line(j) == post_ignore)) - 1, 0);
        
        % otherwise, is this a delimiter?
        if any(line(j) == delim_opts) && all(ignore_count == 0) && ((j == 1) || (line(j-1) ~= '\'))
            delim_mat(i, line(j) == delim_opts) = delim_mat(i, line(j) == delim_opts) + 1;
        end
    end
end

% find the section with the longest most consistent run
dn = diff(delim_mat, [], 1);
run_inds = zeros(2, numel(delim_opts));
n_delim = zeros(1, numel(delim_opts));
run_length = zeros(1, numel(delim_opts));
for i = 1:numel(delim_opts)
    
    % get the start and end points of the runs
    runs = [0; find(dn(:,i)); size(delim_mat,1)];
    
    % get the maximum length
    rlen = diff(runs);
    [max_len, ind] = max(rlen .* (delim_mat(runs(1:end-1)+1 ,i) > 0));  % runs with zero delimters aren't helpful
    run_length(i) = runs(ind+1) - runs(ind);
    run_inds(:,i) = [runs(ind)+1; runs(ind+1)];
    n_delim(i) = delim_mat(run_inds(1,i), i);
    
end

% generate a score reflecting how likely it is to be the delimter
scores = n_delim .* sqrt(run_length);
scores = scores + (sqrt(max(run_length)) * ((run_inds(2,:) == numel(header_str)) & n_delim > 0));  % add a bonus if it has delimiters and finsihes on the last line

% space is a terrible choice for a delimiter, punish it
scores(delim_opts == ' ') = scores(delim_opts == ' ') / 2;

% Ideally this is a csv, so try commas first if they look likely
comma_ind = find(delim_opts == ',');
if (n_delim(comma_ind) > 1) && ((run_length(comma_ind) > numel(header_str)/2) || (run_inds(comma_ind, 2) == numel(header_str)))
    scores(comma_ind) = inf();
end

% and generate a trial order
[scores, delim_order] = sort(scores, 'descend');

% and try them
delim = [];
for i = delim_order
    
    % trim the header back to the found part of the run
    header_trim = header_str(run_inds(1,i):run_inds(2,i));
    
    % create cell arrays to store the strings and numerics
    str_cell = cell(numel(header_trim), n_delim(i)+1);
    force_invalid = false(numel(header_trim), 1);
    
    % now go through and parse according to the delimiter
    for j = 1:numel(header_trim)
        
        % interpret the line using the delimtier approach
        [tokens, other] = regexp(header_trim{j}, delim_opts(i), 'split', 'match');
        
        % if it doesn't match the search pattern this cant be a valid line later
        force_invalid(j) = (numel(tokens) ~= (n_delim(i)+1));
        
        % strip tokens if there's unexpectedly too many
        tokens = tokens(1:min(numel(tokens), n_delim(i)+1));
        
        % place it in the string array
        str_cell(j, 1:numel(tokens)) = tokens;
    
    end
    
    % convert to numerics where possible
    num_cell = cellfun(@str2double, str_cell);
    valid_nan = cellfun(@(x)(numel(x) > 0), regexpi(str_cell, '^\s*(NaN|N[\\/]*a)\s*$', 'match', 'once'));
    is_numeric = ~isnan(num_cell) | valid_nan;
    
    % which lines look like valid data?
    valid_line = all(is_numeric(:, 1+(n_delim(i)>0):end), 2) & ~force_invalid;  % N.B. if there are multiple columns, the first column may be a time string so ignore it
    
    % strip invalid lines form the end (possibly weird stuff for the file end)
    data_end_line = find(valid_line, 1, 'last');
    valid_line_trim = valid_line(1:data_end_line);
    
    % now find the first valid line (hopefully the data start)
    data_start_line = find(~valid_line_trim, 1, 'last');
    if (numel(data_start_line) == 0)
        data_start_line = 0;
    end
    data_start_line = data_start_line + 1;
    
    % if we have enough valid lines we're happy
    n_valid = numel(valid_line_trim) - data_start_line + 1;
    if (n_valid > (numel(header_trim)/4) || ((n_valid > 5) && valid_line(end)))
        delim = delim_opts(i);
        data_set.dims = size(num_cell, 2);  % record dimensionality
        break;
    end
end

% change this to prompt the user one day...
if (numel(delim) == 0)
    if (numel(data_set.delim) == 0)
        error('Could not identify the delimiter in file %s:', data_set.file_name);
    else
        delim = data_set.delim;  % take its word for it
    end
end

% check this match's what's in the header
if numel(data_set.delim) && (data_set.delim ~= delim)
    error('Identified delimiter does not match the delimiter specified in the header');
else
    data_set.delim = delim;
    data_set.hlines = data_start_line + run_inds(1,i) - 2;  % don't confirm this with the header, there may be blank lines at the file's start
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now figure out if there's a time column
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fs = [];
has_t = false;
time_str_template = '';
if (~is_numeric(data_start_line, 1))
    
    % incidate the first column are times
    has_t = true;
    
    % assume this is a time string, grab them
    time_strs = str_cell(data_start_line:data_end_line, 1);
    
    % attempt to parse them
    try
        
        % convert times to date vectors
        times = cellfun(@(str)AmbigTimeStr(str, true), time_strs, 'uniformoutput', false); 
        times = cell2mat(times);  % make them matrices
        
        % the time in seconds between them
        dt = etime(times(2:end,:), times(1:end-1,:));
        
        % consider them consistent if they're within 1 percent
        if all(dt > 0) && all((abs(dt - dt(1)) / dt(1)) < .01)
            
            % get sampling rate
            fs = 1./mode(dt);
            
            % replace the time stamp from the header with the data time stamp
            data_set.tstamp = times(1,:);
        end
        
        
        
    catch
        time_str_template = time_strs{1};
        if (~isdeployed())
            warning('AmbigTimeStr.m could not parse the time string: %s', time_str_template);
        end
    end
    
else
    
    % see if the first column looks like times
    times = num_cell(data_start_line:data_end_line, 1);
    dt = diff(times);
    
    % consider them consistent if they're within 1 percent
    if all(dt > 0) && all((abs(dt - dt(1)) / dt(1)) < .01)
        data_set.time_col = true;
        has_t = true;
        fs = 1./mode(dt);
    end
end

% check has_t matches the header
if numel(data_set.time_col) && (has_t ~= data_set.time_col)
    error('A time column has been detected however the header indicates there shouldn''t be one');
else
    % allocate
    data_set.time_col = has_t;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Work out the sampling frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% check fs matches header and data
if numel(data_set.fs) && numel(fs) && ((abs(fs - data_set.fs) / data_set.fs) >= .01)
    error('The sampling frequency determined empirically does not match the value reported in the header (%s (header) vs %s (empirical)', FsString(data_set.fs), FsString(fs));
    
% if there's no way to determine sampling frequency, prompt the user    
elseif (numel(fs) == 0) && (numel(data_set.fs) == 0)
    
    % Can we retrieve it from the file name? (look for a number followed by Hz)
    fs = NaN;
    fs_str = regexpi(data_set.file_name, '\d+.?Hz', 'match', 'once');
    if numel(fs_str)
        try 
            fs = ParseFsStr(fs_str);
        end
    else
        % look for an Fs = line
        fs_str = regexpi(data_set.file_name, '(?<=Fs=)\d+', 'match', 'once');
        if numel(fs_str)
            fs = str2double(fs_str);
        end
    end
        
    % prompt the user if all else fails
    if isnan(fs)
        dlg_title =  'Failed to autodetect the sampling frequency';
        if numel(time_str_template)  % if there's an example of an unparseable time str, show the user
            dlg_title = sprintf('%s (uninterpretable format: %s)', dlg_title, time_str_template);
        end
        
        % prompt the user
        resp = inputdlg(sprintf('Please enter the sampling frequency (Hz)\nfor file: %s', data_set.file_name), dlg_title, 1, {'?'});
        
        % check for a valid response
        if (numel(resp))
            fs = str2double(resp{1});
        end
    end
    
    % something sensible?
    if (numel(fs) == 0) || (~isfinite(fs)) || (fs < 0)
        error('Invalid sampling frequency requested');
    else
        data_set.fs = fs;
    end
    
% use the value from the header, unless its not provided    
elseif (numel(data_set.fs) == 0)
    data_set.fs = fs;
end
    





