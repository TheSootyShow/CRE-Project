function tstamp = ACTIDateFormat(date, dformat)  
% function timestamp = ACTIDateFormat(date, dformat)
% function to make the acti date format Matlab compatible
% return the MATLAB date vector

% tokenize the format
[af,bf] = regexp(dformat, '\/', 'split', 'match');

% tokenize the date
[ad,bd] = regexp(date, '\/', 'split', 'match');

% recreate the date format
dformat = '';


if (numel(af) == numel(ad)) && (numel(bf) == numel(bd))

    for i = 1:numel(af)
        
        % the difference in the number of characters
        cd = numel(ad{i}) - numel(af{i});
        
        if (cd > 0)
            af{i}(end+1:end+cd) = af{i}(end);  % repeat the last char
        elseif (cd < 0)
            af{i} = af{i}(end+1:end+cd);       % trim off the end
        end
        
        % datenum doesnt seem to like single numbers, so pad them
        if (numel(af{i}) == 1)
            af{i}(2) = af{i}(1);
            ad{i} = ['0', ad{i}];
        end
        
        
        % update the new dformat
        if (i <= numel(bf))
            dformat = sprintf('%s%s%s', dformat, af{i}, bf{i});
        else
            dformat = sprintf('%s%s', dformat, af{i});
        end
    end
end

% and now we can convert
tstamp = datevec(date, dformat);
