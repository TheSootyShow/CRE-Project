function value_str = GetHeaderValue(str, keyword, delims, next_word)
% function value_str = GetHeaderValue(str, keyword, delims, next)
% this function attempts to pull a value for a keyword out of a string
% the returned value is the next word after the keyword (ending at the
% specified delimiter(s)).  Delimiters can be any regular expression
% and default to ',;\s'
%
% N.B. if teh keyword is not delimited, this function wraps it (i.e.
% assumes it should be a "whole" word so it start at end with \W or a line
% anchor). If this behaivour is not desired, add a '(.*)' to the start or
% end of keyword depending upon which side the value to return is



if (nargin < 4) || (numel(next_word) == 0)
    next_word = 1;
end

if (nargin < 3) || (numel(delims) == 0)
    delims = ',;\s';
end

% if the keyword look like a regular expression, check if it uses its own
% start and end delimiters around the keyword
delim_start = regexp(keyword, '^\s*\([^\)]*\)', 'match', 'once');
delim_end = regexp(keyword, '\([^\)]*\)\s*$', 'match', 'once');


if (numel(delim_start) == 0)
    delim_start = '(\W|^)';
else
    keyword = keyword(numel(delim_start)+1:end);  % peel it off
end
if (numel(delim_end) == 0)
    delim_end = '(\W|$)';
else
    keyword = keyword(1:end - numel(delim_end));  % peel it off
end

if (next_word) % get the next word
    
    % remove the $ from the delim end, its been causing problems
    delim_end = regexprep(delim_end, '(\s*\$\s*\||\|\s*\$\s*|\(\s*\$\s*\))', '');

    % build the expression
    expr = ['(?<=', delim_start, keyword, delim_end, repmat('+', 1, delim_end(end) ~= '+'), ')[^', delims, ']+'];
    
else % get the previous word
    
    % remove the ^ from the delim start, its been causing problems
    delim_start = regexprep(delim_start, '(\s*\^\s*\||\|\s*\^\s*|\(\s*\^\s*\))', '');
    
    % build the expression
    expr = ['[^', delims, ']+', '(?=', delim_start, repmat('+', 1, delim_start(end) ~= '+'), keyword, delim_end, ')'];

end

% and invoke
value_str = regexpi(str, expr, 'match', 'once');
% fprintf('string: %s\nexpr: %s\nresult: %s\n', str, expr, value_str);
if numel(value_str)
    value_str = strtrim(value_str);
end

