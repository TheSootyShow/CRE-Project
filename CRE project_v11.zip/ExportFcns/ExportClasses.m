function header_str = ExportClasses(data_set)
% function header_str = ExportClasses(data_set)
% function to build an export string describing classes


header_str = '';

for i = 1:size(data_set.class_info,1)
    
    % and print each classifier
    header_str = sprintf('%sClassifier: %s', header_str, data_set.class_info{i,1});
    
    % and its classes
    for j = 2:3:size(data_set.class_info,2)
        if numel(data_set.class_info{i,j})  % can be empty if one classifier has more classes than another
            header_str = sprintf('%s, %i - %s', header_str, data_set.class_info{i,j+1}, data_set.class_info{i,j});
            if numel(data_set.class_info{i,j+2})
                header_str = sprintf('%s (%0.2f)', header_str, data_set.class_info{i,j+2});
            else
                header_str = sprintf('%s (N/A)', header_str);
            end
        end
    end
    header_str = sprintf('%s\n', header_str);
end