function [export_set, runToEnd] = InitExportSet(data_set, settings)
% function [export_set, runToEnd] = InitExportSet(data_set, settings)
% function to create the header for an exported data set based on the
% export settings

% Initialise output
export_set = InitDataStruct();
export_set.view_type = 2;  % we're creating a full view

% what info is available in the settings structure?
hasExportInfo = isfield(settings, 'exportInfo') && numel(settings.exportInfo);
hasTimeInfo = isfield(settings, 'timeRange') && numel(settings.timeRange);
hasBinInfo = isfield(settings, 'binInfo') && numel(settings.binInfo);

% what are we creating?
if (isfield(settings, 'features') && numel(settings.features))
    export_set.set_type = 'features';
elseif (isfield(settings, 'classifier') && numel(settings.classifier))
    export_set.set_type = 'classified';
elseif (isfield(settings, 'rClassifier') && numel(settings.rClassifier))    
    export_set.set_type = 'classified';
else
    export_set.set_type = 'data';  % a straight export
end
  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up output feature set
% This part is common for all export types
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

copy_fields = {'type', 'dtype', 'device_type', 'device_serial'};  % copy these fields from th old data set
for i = 1:numel(copy_fields)
    export_set.(copy_fields{i}) = data_set.(copy_fields{i});
end
export_set.delim = ',';
export_set.ASCII_dec = GetExportPrecision(data_set);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Grab export info from the field if it exists
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (hasExportInfo)
    export_set.time_col = settings.exportInfo.time_col;
    export_set.file_name = settings.exportInfo.file_name;
    
else
    export_set.time_col = data_set.time_col;
    if (isfield(settings, 'rClassifier') && numel(settings.rClassifier))
        export_set.file_name = settings.export_name;  % stored here if its an R classifier
    else  
        export_set.file_name = data_set.file_name;    % append to existing if we're unsure
    end
end

% update the filename if it has the insert token in it
export_set.file_name = strrep(export_set.file_name, '$ds_name$', data_set.name);

% check it
export_set.file_name = SanitizeFileName(export_set.file_name, true, false);

% and set the export name
[tmp, export_set.name] = fileparts(export_set.file_name);                     


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Are we exporting a specific time range?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (hasTimeInfo) && (~settings.timeRange.full)
    export_set.tstamp = settings.timeRange.tstamp{1};
    relTime = TimeRangeToRelative(data_set, settings.timeRange.tstamp);
    runToEnd = false;
else
    export_set.tstamp = data_set.tstamp;  % full range
    relTime = [0, data_set.num_points / data_set.fs];
    runToEnd = data_set.view_type == 1;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output number of points and sampling frequency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% adjust to the desired place in the bin
if (hasBinInfo)
    if (settings.binInfo.use_bins) 
        export_set.fs = 1 / settings.binInfo.bin_duration;
        if (settings.binInfo.time_align(1) == 'c')
            add_time = settings.binInfo.bin_duration / 2;
        elseif (settings.binInfo.time_align(1) == 'e')
            add_time = settings.binInfo.bin_duration;
        else
            add_time = 0;
        end
        
        % update the time stamp
        export_set.tstamp = AddTimeToDateVec(export_set.tstamp, add_time);
        
        % how many bins?
        export_set.num_points = floor((relTime(2) - relTime(1)) / settings.binInfo.bin_duration);
        
    else
        bin_duration = relTime(2) - relTime(1) + (1.5 ./ data_set.fs);  % 1.5 to guarantee rounding
        export_set.fs = 1 / bin_duration;
        export_set.num_points = 1; % only 1 bin
    end
else
   
    % grab the new sampling rate
    if (hasExportInfo)
        export_set.fs = settings.exportInfo.export_fs;
    else
        export_set.fs = data_set.fs;
    end
    export_set.num_points = floor((relTime(2) - relTime(1)) * export_set.fs);
end









