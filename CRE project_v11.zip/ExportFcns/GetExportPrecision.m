function [dp, format] = GetExportPrecision(input_set)
% function [dp, format] = GetExportPrecision(input_set)
% function to get the precision to export the data set at

if (nargin == 0) || (numel(input_set.ASCII_dec) == 0)
    format =  '%0.6f';           % print at most 6 digits
    dp = 6;
else
    dp = input_set.ASCII_dec;
    format = ['%0.', num2str(dp), 'f'];
end
