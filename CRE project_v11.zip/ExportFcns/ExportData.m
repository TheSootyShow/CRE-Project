function [export_set, pret, data_set] = ExportData(data_set, exportSettings, order, opts, status_func)
% function [export_set, pret, data_set] = ExportData(data_set, exportSettings, order)
% function [export_set, pret, data_set] = ExportData(data_set, exportSettings, order, opts)
% function to export a data set.  
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set       - the data set structure to retrieve tha values from
%                  (see ImportCSV.m)
%
% exportSettings - a structure (subset of the feature settings structure,
%                  see InitFeatSettings) containing the export information,
%                  including timings, dimensions, output options etc
%
% order          - default order of the downsampling (low pass) filter
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% export_set - the data set for the down sampled data
%
% pret         - the percentage of power retained (i.e. that's still there
%                after downsampling).  The will be between 0 and 1
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!




max_up = 10;  % don't allow upsampling by more than this factor

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set default inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 5) 
    status_func = [];
end

if (nargin < 4) || (numel(opts) == 0)

    opts.max_lookup       = 1e3;  % the lookup table has this many entries at most
    opts.max_load_els     = 1e7;  % load the data in full if it has less than this many elements

end

if (nargin < 3) || (numel(order) == 0)
    order = 10;
end


% convert the dimenion info structure into a form where
% its easier to compute secondary dimensions
outputDims = ParseDimInfo(exportSettings.dimInfo, data_set);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up output feature set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

export_set = InitExportSet(data_set, exportSettings);

% the names of the output dimensions
[dim_names, selected] = GetAllDimensionNames(exportSettings.dimInfo);

% add it to the feature set structure
[export_set, write_format] = AddExportColumnInfo(export_set, dim_names(selected));

% turn the time to extract into indices
if (exportSettings.timeRange.full)
    indexs = [1, data_set.num_points];
    runToEnd = data_set.view_type < 2;  % the number of points in the file may be approximate, so run past the final index
else
    [relTime, indexs] = TimeRangeToRelative(data_set, exportSettings.timeRange.tstamp);
end
  





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up down sampling if required
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (exportSettings.exportInfo.export_fs ~= data_set.fs)

    % build the down-sampled rate base on the requested fs
    [up, down] = rat(exportSettings.exportInfo.export_fs / data_set.fs);
    if (up > max_up)
        [up, down] = MaxRat(exportSettings.exportInfo.export_fs, data_set.fs, max_up);  % don't allow it to do too much up-sampling
    end
    fs = (data_set.fs * up) / down;
else
    fs = data_set.fs;
    up = 1; down = 1;
end
export_set.fs = fs;     % precise version
dr = data_set.fs / fs;  % downsampling rate


% how many points are being exported in the up-sampled space?
up_points = indexs(2) - indexs(1) + 1;
export_set.num_points = 1 + floor(((up_points - 1) * up) / down);  % the first point is always copied


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now create the output file if needed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (numel(exportSettings.exportInfo.file_name) == 0)
    [path, fname, ext] = fileparts(data_set.file_name);
    if (dr ~= 1)
        fs_string = FsString(fs); fs_string(fs_string == '.') = 'p';  % change the decimal to a p to not create funny file names
        exportSettings.exportInfo.file_name = sprintf('%s_fs=%s%s', fullfile(path, fname), fs_string, ext);
    else
        exportSettings.exportInfo.file_name = sprintf('%s_aug%s', fullfile(path, fname), ext);  % add aud for augmented
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add the lookup table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% design the lookup table based on this
export_set.lookgap = max(ceil(export_set.num_points / (opts.max_lookup - 1)), 100);
export_set.lookup = zeros(1 + floor(export_set.num_points / export_set.lookgap), 1);

% retain all the data?
retain_all = (export_set.num_points * export_set.dims) <= opts.max_load_els;
if (retain_all)
    export_set.data = zeros(export_set.num_points, export_set.dims);
end




% build the filter
% user specified filter is now depricated
% if isfinite(fc) && (f_ord > 0)
%     
%     % filter the upsampled signal
%     [b,a] = butter(f_ord / 2, .5 / (up * fs / 2), 'low');  % cuttoff freq is relative to nyquist for butter.m, f_ord / 2 because filtfilt
%     
%     calculate filter group delay
%     gd = grpdelay(b,a,128);
%     
%     % overlap by twice this many samples for safety
%     overlap = 2 * ceil(max(abs(gd)));
%     
% else
%     b = []; a = [];
% end

% work out overlap
if (order) && (dr ~= 1)
    
    % build the filter resample will use
%    fc = 1/ 2 / max(up, down);
%    bta = 5;
    L = 2*order*max(up, down) + 1;
%    b = up * firls( L-1, [0 2*fc 2*fc 1], [1 1 0 0]).*kaiser(L,bta)';  % dont need to actually create it
    
    % include this many prior / post samples when available
    overlap = L + 1;
else 
    overlap = 0;
end

% include the extra points required for calulation inot the overlap
overlap = overlap + outputDims.extra_points * max(up, down);

% make sure it results in an integer number of samples to "prune"
if rem(overlap, down)
    overlap = overlap + down - rem(overlap, down);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create information to break data into blocks
% (for downsampling)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% process this over how many blocks
block_points = ceil(opts.max_load_els / (export_set.dims * up));

% ensure block points works with the downsampling rate
block_points = block_points -  rem(block_points, down);
n_blocks = ceil(up_points / block_points);

% size of the blocks at the output fs
block_points_down = block_points * up / down;

% get indexs ranges for the blocks
block_indexs = zeros(n_blocks, 2);
for i = 1:n_blocks
    block_indexs(i, :) = [(i-1) * block_points, i*block_points-1] + indexs(1);
end

if (~runToEnd)
    block_indexs(end, 2) = indexs(2);  % dont go over
end

% the gap between points at the new sampling rate
n_points = 0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Begin exporting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% begin try loop in case of unexpected error
try
    
    % open the pointer to the data sets file here so we don't do it over and
    % over again
    ds_open = data_set.file_ptr > 0;
    if (~ds_open)
        data_set.file_ptr = fopen(data_set.file_name, 'r');
        if (data_set.file_ptr <= 0)
            error('Could not read %s\nIs the file in use?', data_set.file_name);
        end
    end
    
    % check we're not doing any crazy overwrites
    CheckFileOverwrite(data_set, export_set, n_blocks);

    % write the header before this starts
    export_set = ExportHeader(export_set, exportSettings.exportInfo, true);
    
    % now process
    export_set.lookup(1) = export_set.hbytes;
    lookup_ind = 1;                               % the last filled lookup table entry
    next_lookup = export_set.lookgap;             % the next point that should have a lookup entry
    
    % this helps grab the data contiguously, by storing the "lastest" data
    % (overlap is normally symetric)
    lastOverlapX = [];
    
    % signal power in the two spaces
    sp = {0,0};
    
    % enable run to end mode
    i = 0;
    while ((i < n_blocks) || runToEnd) 
        
        i = i + 1;
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Down sampling part
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % check we have't run out of block indices
        if (i > size(block_indexs, 1))
            block_indexs(i, :) = [(i-1) * block_points, i*block_points-1] + indexs(1);
        end
        
        % Calculate the range to grab to account for overlap for filtering
        [frange, used_overlap, prune_samps] = CalculateOverlap(block_indexs(i, :), data_set.num_points, overlap, up, down);
        
        % can we use the last overlap data?
        use_buffer = (used_overlap(1) > 0) && (size(lastOverlapX,1) == used_overlap(1));
        
        % grab the original data (primary dimension only)
        grabInds = [frange(1) + use_buffer * size(lastOverlapX,1), frange(2)];
        [upX, data_set] = GetData(data_set, grabInds, false, outputDims.primary_dims);
        
        % check for end of file
        dSamps = size(upX,1) - (grabInds(2)-grabInds(1)+1);
        
        % check for end of file
        if (dSamps ~= 0)
            
            eof = true;  % end of file
            
            % recalculate used overlap and prune_samps
            [frange, used_overlap, prune_samps] = CalculateOverlap(block_indexs(i, :), data_set.num_points, overlap, up, down);  % N.B data_set.num_points is now correct
            grabInds = [frange(1) + use_buffer * size(lastOverlapX,1), frange(2)];
            
            % prune off upX if we grabbed too much
            dSamps = size(upX,1) - (grabInds(2)-grabInds(1)+1);
            
            if (dSamps > 0)
                upX(end-dSamps:end,:) = [];
            elseif (dSamps < 0)
                error('wut');
            end
        elseif (grabInds(2) == data_set.num_points)
            eof = true;
        end
        
        if (use_buffer)
            upX = [lastOverlapX; upX];  % if we were able to use the last overlap zone
        end
        lastOverlapX = upX(end-used_overlap(2)+1:end, :);  % store this
        
        % up / down sample with some filtering in between
        if (export_set.fs ~= data_set.fs)
            downX = resample(upX, up, down, order);
        else
            downX = upX;
        end
        
        if numel(downX)  % may be false if we hit the end of the file
        
            % calculate derived dimensions now
            downX = GetDerivedDims(downX, outputDims);
            
            % prune of the overlap samples
            if any(used_overlap)
                downX = downX(prune_samps(1)+1:end-prune_samps(2), :);
            end
            
            % Matlab's resample likes to add an extra samples
            % e.g. try resample(1:5, 2, 3, 0).  We choose block size
            % so it doesn't happen for a full block, but we need to check if
            % this isnt a full block
            % recalculate the size of the blocks at the output fs in casen the end of the file was reached
            if (eof)
                block_points_down = floor(size(upX,1) * up / down);
            end
            
            if (size(downX,1) ~= block_points_down)
                
                % how mant should there be?
                exp_points = 1 + floor((size(upX,1) - 1)* up / down) - sum(prune_samps);
                if (exp_points ~= size(downX,1))
                    downX(exp_points+1:end, :) = [];
                end
            end
            
            % keep track of the signal power
            sp{1} = sp{1} + sum(upX.* upX, 1);
            sp{2} = sp{2} + sum(downX .* downX,1);
        
        
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Add secondary dimensions part
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % store this in X if desired
            if (retain_all)
                
                % add storage if needed
                if (n_points + size(downX,1) > size(export_set.data,1))
                    export_set.data(n_points + size(downX,1) + max(5*lookgap, 1e5), :) = NaN;
                end
                
                export_set.data(n_points + 1:n_points + size(downX,1), :) = downX;
            end
            
            if (~exportSettings.exportInfo.time_col)
            
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % fast way - print the "lookup block" in one hit
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                downX = downX.';                 % need each dimension to be a row for fprintf
                cp = 0;                          % the number of points in this block already written
                lp = n_points + size(downX, 2);  % the "final" point in this block (relative to the whole file)
                while (cp + n_points < lp)
                    
                    ep = min(lp, next_lookup);  % the final point to write in this "chunk"
                    fprintf(export_set.file_ptr, write_format, downX(:, cp+1:ep-n_points));  % write it
                    
                    % update the last written point (relative to the block)
                    cp = ep - n_points;
                    
                    % and update the lookup if needed
                    if (ep == next_lookup)
                        
                        % record the lookup table entry
                        lookup_ind = lookup_ind + 1;

                        % add storage if needed
                        if (lookup_ind >= numel(export_set.lookup))
                            export_set.lookup(end + 1000) = 0;  % add 1000 elements at a time
                        end
                        
                        export_set.lookup(lookup_ind) = ftell(export_set.file_ptr);
                        next_lookup = next_lookup + export_set.lookgap;             % the next point that should have a lookup entry
                        
                        % update progress - its too slow to do here with large files
                        if (numel(status_func)) && (rem(lookup_ind, 10) == 0)
                            feval(status_func, lookup_ind-1, numel(export_set.lookup)-1);
                            drawnow();
                        end
                    end
                end
            
                % update where to start the next point from
                n_points = n_points + size(downX,2);  % dim 2 because it was transcribed
            
            else
                
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                % slow method - add a time column
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
                % write the down sampled data to file
                for j = 1:size(downX,1)
                    
                    % write the time
                    ct_str = ConvertTime((n_points + j - 1) / export_set.fs, export_set.tstamp, 2, true);
                    fprintf(export_set.file_ptr, '%s, ',  ct_str);
                    
                    % and the values
                    fprintf(export_set.file_ptr, write_format, downX(j, :));  % write it
                    
                    % and update the lookup if needed
                    if (n_points + j == next_lookup)
                        
                        % record the lookup table entry
                        lookup_ind = lookup_ind + 1;
                        export_set.lookup(lookup_ind) = ftell(export_set.file_ptr);
                        next_lookup = next_lookup + export_set.lookgap;             % the next point that should have a lookup entry
                        
                        % update progress - its too slow to do here with large files
                        if (numel(status_func)) && (rem(lookup_ind, 10) == 0)
                            feval(status_func, lookup_ind-1, numel(export_set.lookup)-1);
                            drawnow();
                        end
                    end
                end
                
                % update where to start the next point from
                n_points = n_points + size(downX,1);
            end
        end
        
        % break here if we have reached the end of the file
        if (eof)
            break;
        end
        
        % update progress
        if (numel(status_func)) && (numel(export_set.lookup) >= 200)
            feval(status_func, i, n_blocks);
            drawnow();
        end
    end
    
    % this should only happen if eof is encountered
    if (n_points ~= export_set.num_points) || (lookup_ind ~= numel(export_set.lookup))
        export_set.lookup = export_set.lookup(1:lookup_ind);
        export_set.num_points = n_points;
        if numel(export_set.data)
            export_set.data(n_points+1:end, :) = [];
        end
    end
    
    if (exportSettings.exportInfo.header > 0)
        UpdateDSHeader(export_set);  % always call this in case we output the lookup table
    end
    
    % calculate returned power
    sp{1} = sum(sp{1}(outputDims.primary_dims) / data_set.num_points);
    sp{2} = sum(sp{2}(outputDims.primary_dims) / export_set.num_points);
    pret = sp{2} / sp{1};
    
    % and close the file if it was open
    open = export_set.file_ptr > 0;
    if (open)
        fclose(export_set.file_ptr);
        export_set.file_ptr = -1;
    end
    if (~ds_open)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    
catch ME
    
    % catch error
    if (export_set.file_ptr > 0)
        fclose(export_set.file_ptr);
    end
    if (~ds_open)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    error('An unexpected error occurred while exporting file %s\n%s', data_set.file_name, ME.message);
    
    
    
end



function [up, down, fsd] = MaxRat(fs_req, fs, max_up)
% function [up, down, fsd] = rat(fs_req, fs, max_up)
% function to find the closest fs to the requested fs
% without it needing to upsample too much

up_opts = 1:max_up;                         % trial these values
down_opts = round(fs * up_opts / fs_req);   % which correspond to these integer down rates
fst = (fs * up_opts) ./ down_opts;          % which are these frequencies

% the closest of which is
[diff, ind] = min(abs(fs_req - fst));
up = up_opts(ind);
down = down_opts(ind);
fsd = fs * up / down;



function [frange, used_overlap, prune_samps] = CalculateOverlap(block_inds, max_points, overlap, up, down)
% function [frange, used_overlap, prune_samps] = CalculateOverlap(block_start, max_points, overlap, up, down)
% we want to grab point at the beginning and end to down sample in a non
% causal mannor.  The function returns the overlap to use in the upsampled
% space, as well as the number of samples to prune back in the down sampled
% space

% include an overlap zone
frange(1) = max(block_inds(1) - overlap, 1);
frange(2) = min(block_inds(2) + overlap, max_points);
used_overlap = [block_inds(1) - frange(1), frange(2) - min(block_inds(1,2), max_points)];

% ensure used overlap results in an integer number of samples being pruned
prune_samps = (used_overlap * up) / down;
if (prune_samps(1) ~= round(prune_samps(1)))
    red = rem(used_overlap(1), down);
    used_overlap(1) = used_overlap(1) - red;
    frange(1) = frange(1) + red;
    prune_samps(1) = floor(prune_samps(1));
end
if (prune_samps(2) ~= round(prune_samps(2)))
    red = rem(used_overlap(2), down);
    used_overlap(2) = used_overlap(2) - red;
    frange(2) = frange(2) - red;
    prune_samps(2) = floor(prune_samps(2));
end





% Defunct input option:
% fc            - filter cutoff for low pass filtering before down
%                 sampling, defaults to .45 * fs
%               - if no filtering is desired, set fc = NaN
% 
% 
% if (nargin < 5) || (numel(fc) == 0)
%     fc = .45 * fs_req;
% elseif (fc > .5*fs_req) || (fc <= 0)
%     error('DownSampleData:: Filter cutoff should be in the range fc = (0, fs/2]');
% end
% 
% 
% 
% depricated code for user specified filter
% % upsample it
% if (up ~= 1)
%     if (numel(b))
%         upX = upsample(upX, up);
%     else
%         upX = kron(upX, ones(up,1));
%     end
% end
% 
% % filter each dimension
% if (numel(b))
%     
%     for j = 1:data_set.dims
%         
%         % apply filter
%         upX(:, j) = up * filtfilt(b, a, upX(:, j));
%         
%     end
% end
% 
% % prune off the overlap
% if any(used_overlap)
%     upX = upX(used_overlap(1)*up + 1:end - used_overlap(2)*up, :);
% end
% 
% % now down sample
% downX = upX(fp:down:end, :);


