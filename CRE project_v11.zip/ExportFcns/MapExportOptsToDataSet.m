function exportInfo = MapExportOptsToDataSet(inputSettings, data_set)
% function exportInfo = MapExportOptsToDataSet(inputSettings.exportInfo, data_set)
% function to change export options from one data set to another


% time copy is a straight match
exportInfo.header = inputSettings.exportInfo.header;

% export header is a straight match
exportInfo.time_col = inputSettings.exportInfo.time_col;

% sanitize dimensions names
exportInfo.sanitize_dims = inputSettings.exportInfo.sanitize_dims;

% use the minimum here
exportInfo.export_fs = min(inputSettings.exportInfo.export_fs, data_set.fs);

% auto name it?
exportInfo.auto_name = inputSettings.exportInfo.auto_name;

% update the file name
if (exportInfo.auto_name)
    
    % call the automatic naming function
    exportInfo.file_name = AutoNameExportFeatures(data_set, inputSettings, true);

else

    % decompose
    [fpath, fname, fext] = fileparts(inputSettings.exportInfo.file_name);
    
    % does the data set name appear in it?
    if numel(regexpi(fname, inputSettings.dsName))
        fname = regexprep(fname, inputSettings.dsName, data_set.name, 'ignorecase'); % if so a straight replace
        exportInfo.file_name = sprintf('%s%s', fullfile(fpath, fname), fext);
    else
        % use an auto name in this case as well
        exportInfo.file_name = AutoNameExportFeatures(data_set, inputSettings, true);
    end
end
