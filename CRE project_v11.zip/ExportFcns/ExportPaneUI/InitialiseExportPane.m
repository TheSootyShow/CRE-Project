function InitialiseExportPane(exportInfo, handles)
% function InitialiseExportPane(dimInfo, handles)
% function to initialise the export pane

% set the export file name
set(handles.ebFileName, 'string', exportInfo.file_name);

% set the output time column check box
set(handles.cbTimeCol, 'value', exportInfo.time_col);

% set the output time column check box
set(handles.cbSanitizeDims, 'value', exportInfo.sanitize_dims);

% set the output header data check box
set(handles.cbExportHeader, 'value', exportInfo.header);
set(handles.cbExportHeader, 'tooltipstring', sprintf('If checked, this replaces all dimension name characters that aren''t letters or numbers with underscores.\nThis may increase compatibility with 3rd party applications.'));

if strcmpi(handles.data_set.set_type, 'batch')
    set([handles.ebFileName, handles.pbGetFile], 'tooltipstring', sprintf('File name must include the token $ds_name$ for batch sets.\nThis token will be replaced by the data set name.'));
else
    set([handles.ebFileName, handles.pbGetFile], 'tooltipstring', '');
end


