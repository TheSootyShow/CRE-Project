function handles = CopyExportTemplateToFigure(hDest, handles)
% function destHandles = CopyExportTemplateToFigure(hDest, destHandles)
% function to copy the updated version of the dimension panel onto an
% existing gui

% for debugging
set(hDest, 'visible', 'on');

% load the range template figure
figDir = fileparts(mfilename('fullpath'));
figName = fullfile(figDir, 'ExportPane.fig');
hSrc = hgload(figName);
srcRangePane = findobj(hSrc, 'tag', 'uiExport');

% remove all the pre-existing things from the uiRangePane panel
if ~isfield(handles, 'uiExport')
    error('The input figure does not have an export panel');
end

% ensure callbacks are correct
srcControls = findobj(hSrc, 'type', 'uiControl');
srcMenus = findobj(hSrc, 'type', 'uiMenu');
set([srcControls(:); srcMenus(:)], 'callback', @(hObject, event_data)ExportPaneCallbacks(hObject, event_data, guidata(hObject)));
set(srcControls(:), 'CreateFcn', @(hObject, event_data)Default_CreateFcn(hObject, event_data, guidata(hObject)));

% keep a record of the dim pane's parent
hParent = get(handles.uiExport, 'parent');

% find all children of the dim pane panel that have tags
hChildren = findall(allchild(handles.uiExport));
rmTags = get(hChildren, 'tag');
if iscell(rmTags)
    rmTags = rmTags(cellfun(@(x)(numel(x) > 0), rmTags));
end

% remove those tags and delete them
if numel(rmTags)
    handles = rmfield(handles, rmTags);
end

% now delete the old pane
delete(handles.uiExport);

% now copy on the new range pane
handles.uiExport = copyobj(srcRangePane, hParent);

% and add all tags to the handles
hChildren = findall(handles.uiExport);
addTags = get(hChildren, 'tag');
hasTag = cellfun(@(x)(numel(x) > 0), addTags);
addTags = addTags(hasTag);
hChildren = hChildren(hasTag);
for i = 1:numel(addTags)
    handles.(addTags{i}) = hChildren(i);
end

% make sure the uicontext menu gets copied
hContext = findobj(hSrc, 'type', 'uicontextmenu');
for i = 1:numel(hContext)
    
    % delete the old one if it exists
    tag = get(hContext(i), 'tag');
    if isfield(handles, tag)
        delete(handles.(tag));
    end
    
    % and copy over the new one
    handles.(tag) = copyobj(hContext(i), hDest);
    
    % now find all uiobjects that use it
    hUse = findobj(hSrc, 'uicontextmenu', hContext(i));
    for j = 1:numel(hUse)
        set(handles.(get(hUse(j), 'tag')), 'uicontextmenu', handles.(tag));
    end
end

delete(hSrc);







