function [hGrid,  hGap, vGap, sizes] = DefaultExportPaneLayout(handles, smallGap, normGap, largeGap)
% function [hGrid, h_gap, v_gap, sizes] = DefaultExportPaneLayout(handles, smallGap, normGap, largeGap)
% This function set up the default layout of the time range panels to use
% in guis (see RangeTemplate.fig).  All GUI handles should have the same name
% as in this template
%
% The output is compatible with ResizePaneFromGrid.m

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Build spacing constants if they aren't supplied
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 2)

    % build default gaps
   [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
end

% draw the edit box as 4 lines high
set(handles.ebFileName, 'Max', 1, 'units', 'pixels');
sHeight = GetPreferredSize(handles.ebFileName);
cPos = get(handles.ebFileName, 'position');
cPos(4) = 4*sHeight;
%set(handles.ebFileName, 'position', cPos);



set(handles.ebFileName, 'Max', 5);


hGrid = {handles.txtOutputFile, [];   ...
         'b',                   [];   ...
         handles.ebFileName,    handles.pbGetFile; ...
         handles.cbTimeCol,     [];
         handles.cbExportHeader,[]; ...
         handles.cbSanitizeDims,[]};
         

     
hGap = repmat(normGap, size(hGrid,1), size(hGrid,2) - 1);
vGap = repmat(normGap, size(hGrid,1)-1, size(hGrid,2));
vGap(1,:) = smallGap;

% get component sizes
sizes = PaneSizesFromGrid(hGrid);

% add space for extra lines in the text box
sizes{3,1}(2) = cPos(4);
