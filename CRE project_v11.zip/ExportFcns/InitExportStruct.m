function exportInfo = InitExportStruct(data_set, featSettings)
% function exportInfo = InitExportStruct()
% function exportInfo = InitExportStruct(data_set)
% this function initializes the export information structure


exportInfo = struct('file_name',      [],   ... % the output file name
                    'auto_name',      [],   ... % indicates if the file name should be auto updated 
                    'time_col',       [],   ... % include a time column in the output
                    'sanitize_dims',  [],   ... % true / false depending on whether  output dimensions can have , and ( in them
                    'header',         [],   ... % include header data in the output
                    'export_fs',      []);  ... % export sampling frequency (not used with features)
                    
                
if (nargin >= 1)
    
    % defaults
    exportInfo.auto_name = true;
    if numel(data_set.time_col)  % may not be filled in batch mode
        exportInfo.time_col = data_set.time_col;
    else
        exportInfo.time_col = false;
    end
    exportInfo.sanitize_dims = false;
    exportInfo.header = true;
    exportInfo.export_fs = data_set.fs;
    
    % generate an automatic name
    if (nargin == 1)
        featSettings = struct('exportInfo', exportInfo);
    else
        featSettings.exportInfo = exportInfo;
    end
    exportInfo.file_name = AutoNameExportFeatures(data_set, featSettings, true);
end
    