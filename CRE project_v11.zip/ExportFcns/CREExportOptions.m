function varargout = CREExportOptions(varargin)
%
% GUI is intended to be called as:
% [response, options] = CREExportOptions(data_set, use_time, use_hhmmss, relative_time, default_opts)
%
% CREEXPORTOPTIONS MATLAB code for CREExportOptions.fig
%      CREEXPORTOPTIONS, by itself, creates a new CREEXPORTOPTIONS or raises the existing
%      singleton*.
%
%      H = CREEXPORTOPTIONS returns the handle to a new CREEXPORTOPTIONS or the handle to
%      the existing singleton*.
%
%      CREEXPORTOPTIONS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CREEXPORTOPTIONS.M with the given input arguments.
%
%      CREEXPORTOPTIONS('Property','Value',...) creates a new CREEXPORTOPTIONS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CREExportOptions_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CREExportOptions_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
%

% Edit the above text to modify the response to help CREExportOptions

% Last Modified by GUIDE v2.5 12-Sep-2014 14:33:26

layout_fcn = GuiLayoutFunction('CREExportOptions');

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREExportOptions_OpeningFcn, ...
                   'gui_OutputFcn',  @CREExportOptions_OutputFcn, ...
                   'gui_LayoutFcn',  layout_fcn, ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

% ensure guis's always load visible
if (nargin == 0)
    varargin = {'visible', 'on'};
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CREExportOptions is made visible.
function CREExportOptions_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CREExportOptions (see VARARGIN)

set(handles.ebDesFs, 'KeyPressFcn', @(hObject,eventdata)Default_KeyPressFcn(hObject,eventdata,guidata(hObject)))

% get the input data set
handles.data_set = varargin{1};

% create a structure to output
if (numel(varargin) >= 5) && isstruct(varargin{5})
    handles.featSettings = PassFeaturesToDataSet(varargin{5}, handles.data_set);
else
    
    % N.B.  This should match InitFeatSettings.m
    handles.featSettings = struct('dsName',       [],  ... % keep a record 
                                  'timeRange',    [],  ... % has the time to start and stop the analysis (see InitTimeRangeStruct.m)
                                  'dimInfo',      [],  ... % which dimensions to build features from (see InitDimStruct)
                                  'exportInfo',   []); ... % export information
    
    % initialise each of them
    handles.featSettings.dsName = handles.data_set.name;
    handles.featSettings.timeRange = InitTimeRangeStruct(handles.data_set); 
    handles.featSettings.dimInfo = InitDimStruct(handles.data_set);
    handles.featSettings.exportInfo = InitExportStruct(handles.data_set, handles.featSettings);

end

% times or indices?
if (numel(varargin) >= 2) && (numel(varargin{2}) > 0)
    handles.featSettings.timeRange.is_time = varargin{2};
else
    handles.featSettings.timeRange.is_time = true;
end


% how to display times
if (numel(varargin) >= 3) && (numel(varargin{3}) > 0)
    handles.featSettings.timeRange.is_hhmmss = varargin{3};
else
    handles.featSettings.timeRange.is_hhmmss = true;
end

% show times as relative to the recordings start?
if (numel(varargin) >= 4) && (numel(varargin{4}) > 0)
    handles.featSettings.timeRange.is_relative = varargin{4};
else
    handles.featSettings.timeRange.is_relative = true;
end

% update the time range panel and export panels if developing
if (IsDeveloper())
    
    % update the range pane
    handles = CopyRangeTemplateToFigure(hObject, handles);
    
    % update the export pane
    handles = CopyExportTemplateToFigure(hObject, handles);
end

                     
% Initialise the gui                     
handles = InitialiseGui(handles);                     

% Choose default command line output for CREExportOptions
handles.output = {'Cancel', handles.featSettings};

% resize it
CREExportOptions_ResizeFcn(hObject, eventdata, handles)

% make a robot to process edit boxed on key press
handles.robot = java.awt.Robot;
handles.press_enter = java.awt.event.KeyEvent.VK_ENTER;

% if this is a feature set, update the "dimensions" to reflect they're
% features
if strcmpi(handles.data_set.set_type, 'features')
    set(handles.uiDimensions, 'title', 'Export Features');
    set(handles.pbAddDims, 'string', 'Add Post Features');
end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CREExportOptions wait for user response (see UIRESUME)
uiwait(handles.CREExportOptions);


% --- Outputs from this function are returned to the command line.
function varargout = CREExportOptions_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;
delete(hObject);


% --- Executes during object creation, after setting all properties.
function default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ebMinGrab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function handles = InitialiseGui(handles)
% function InitialiseGui(handles)
% function to update the gui based on the current selection

% allocate a blocking list for the "OK" button.  This list contains handles
% to objects who's value cant be sensibly interpreted
handles.block_list = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up dimensions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get all the dimension names
[names, selected, n_primary] = GetAllDimensionNames(handles.featSettings.dimInfo);
use = false(size(names));
use(1:n_primary) = true;
use(selected) = true;    % only show primary and selected to begin with

% add the names
set(handles.lbDimensions, 'string', names(use));
indexs = find(use);
set(handles.lbDimensions, 'userdata', indexs);  % keep track of their original indices in case of reordering

% then select them all
set(handles.lbDimensions, 'Max', max(numel(names), 2));
[tmp, subset] = ismember(find(selected), indexs);
set(handles.lbDimensions, 'Value', subset(tmp));

if (numel(selected) == 0)
    handles.block_list(end+1) = handles.lbDimensions;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set data range selection
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

handles = InitTimePanel(handles, handles.data_set, handles.featSettings.timeRange.is_time, handles.featSettings.timeRange.is_hhmmss, handles.featSettings.timeRange.is_relative);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up the export pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

InitialiseExportPane(handles.featSettings.exportInfo, handles);

% current sampling frequency
set(handles.txtOrigFs, 'string', FsString(handles.data_set.fs));

% set up default export fs
set(handles.ebDesFs, 'string', FsString(handles.featSettings.exportInfo.export_fs));
handles = ebDesFs_Callback(handles.ebDesFs, [], handles);


% update enabled status
EnableDisableOutput(handles);

% upload the handles
if (nargout == 0)
    guidata(handles.CREPlotOptions, handles);
end



% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% indicate OK
handles.featSettings.timeRange = UpdateStruct(handles.featSettings.timeRange, handles.timeInfo, false);
handles.output = {'OK', handles.featSettings};
guidata(hObject, handles);

% and close the gui
CREExportOptions_CloseRequestFcn(handles.CREExportOptions, eventdata, handles);



% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% indicate cancel
handles.featSettings.timeRange = UpdateStruct(handles.featSettings.timeRange, handles.timeInfo, false);
handles.output = {'Cancel', handles.featSettings};
guidata(hObject, handles);

% and close the gui
CREExportOptions_CloseRequestFcn(handles.CREExportOptions, eventdata, handles);




% --- Executes when user attempts to close CREExportOptions.
function CREExportOptions_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CREExportOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% remove the listener first (it can cause problems with debug mode)
% listener is no longer used
% if isappdata(handles.ebDesFs, 'textListener')
%     rmappdata(handles.ebDesFs,'textListener');  
% end

% Hint: delete(hObject) closes the figure
uiresume(hObject);  % this should trigger the output function


function handles = ebDesFs_Callback(hObject, eventdata, handles)
% hObject    handle to ebDesFs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebDesFs as text
%        str2double(get(hObject,'String')) returns contents of ebDesFs as a double


max_up = 10;  % this should match the maximum allowable upsampling rate defined in DownSampleData

fs_str = get(hObject, 'string');
fs = str2double(fs_str);

% can it be turned into a numeric?
if (isfinite(fs) && (fs > 0))
    
    % update handles
    handles.featSettings.exportInfo.export_fs = fs;
    
    % work out what fs will actually be used
    [up, down] = rat(fs / handles.data_set.fs);
    if (up > max_up)
        
        up_opts = 1:max_up;                                        % trial these values
        down_opts = round(handles.data_set.fs * up_opts / fs);     % which correspond to these integer down rates
        fst = (handles.data_set.fs * up_opts) ./ down_opts;        % these frequencies are

        % the closest of which is
        [diff, ind] = min(abs(fs - fst));
        up = up_opts(ind);
        down = down_opts(ind);

    end
    fs_act = (handles.data_set.fs * up) / down;
    
    % fill in the actual sampling frequency box
    set(handles.txtActFs, 'string', sprintf('Actual frequency: %s', FsString(fs_act)));
    
    % and the expected number of points of the new data set
    exp_points = 1 + floor((handles.data_set.num_points - 1) * up / down);
    
    % and fill this in
	if (handles.data_set.view_type == 2)
		approx_str = '';
	else
		approx_str = '(approx)';
	end
	
    set(handles.txtOutputPoints, 'string', sprintf('Output data points: %i %s', exp_points, approx_str));
    
    % update the name automatically if desired
    handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings, handles.featSettings.exportInfo.auto_name, handles.featSettings.exportInfo.file_name);
	
	% update with the new name
    handles = ExportPaneCallbacks(handles.ebFileName, handles.featSettings.exportInfo.file_name, handles);  
    
    % clear this
    handles.block_list = handles.block_list(handles.block_list ~= hObject);
    
elseif ~any(handles.block_list == handles.ebDesFs)
    
    % mark invalid
    set(handles.txtActFs, 'string', 'Actual frequency: ????');
    set(handles.txtOutputPoints, 'string', 'Output data points: ????');
    
    % add it to the block list if its not in there
    handles.block_list(end+1) = handles.ebDesFs;
    
end

% upload the handles
if (nargout == 0)
    
    guidata(hObject, handles);

    % update enabled status
    EnableDisableOutput(handles);
end



% --- Executes on selection change in lbDimensions.
function lbDimensions_Callback(hObject, eventdata, handles)
% hObject    handle to lbDimensions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbDimensions contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbDimensions

% get the indexes of selected dimensions
indexs = get(hObject, 'userdata');
indexs = indexs(get(hObject, 'value'));

% and set the visiblities in the structure
handles.featSettings.dimInfo = SetDimVisibility(handles.featSettings.dimInfo, indexs, true, true);

if (numel(indexs))
    
    % remove it from blocking if it was
    handles.block_list = handles.block_list(handles.block_list ~= hObject);
    
	
	% update the name automatically if desired
	handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings, handles.featSettings.exportInfo.auto_name, handles.featSettings.exportInfo.file_name);
	
	% update with the new name
	handles = ExportPaneCallbacks(handles.ebFileName, handles.featSettings.exportInfo.file_name, handles);  
        
    % clear this
    handles.block_list = handles.block_list(handles.block_list ~= hObject);
    
elseif ~any(handles.block_list == hObject)
    
    % add it as a blocking function
    handles.block_list(end+1) = hObject;
    
end

% update enabled status
EnableDisableOutput(handles);

% and update the handles for changes in blocklist
guidata(hObject, handles);



% --- Executes on button press in pbAddDims.
function pbAddDims_Callback(hObject, eventdata, handles)
% hObject    handle to pbAddDims (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Fire up the gui
[resp, dimInfo] = SelectDimsGui(handles.featSettings.dimInfo, handles.data_set);

% test the response
if strcmpi(resp, 'OK')
    
    % assign
    handles.featSettings.dimInfo = dimInfo;
    
    % update the pane
    % get all the dimension names
    [names, selected, n_primary] = GetAllDimensionNames(handles.featSettings.dimInfo);
    
    % add the names
    set(handles.lbDimensions, 'string', names);
    set(handles.lbDimensions, 'userdata', 1:numel(names));  % keep track of their original indices in case of reordering
    
    % then select them all
    set(handles.lbDimensions, 'Max', max(numel(names), 2));
    set(handles.lbDimensions, 'Value', find(selected));
    
    if (numel(selected) == 0)
        handles.block_list(end+1) = handles.lbDimensions;
    end
	
	% update the name automatically if desired
	handles.featSettings.exportInfo.file_name = AutoNameExportFeatures(handles.data_set, handles.featSettings, handles.featSettings.exportInfo.auto_name, handles.featSettings.exportInfo.file_name);
	
	% update with the new name
	handles = ExportPaneCallbacks(handles.ebFileName, handles.featSettings.exportInfo.file_name, handles);  
    
    % update enabled status
    EnableDisableOutput(handles);

    % and update the handles for changes in blocklist
    guidata(hObject, handles);
end



% --- Executes when CREExportOptions is resized.
function CREExportOptions_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to CREExportOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if (RunResizeFcn(hObject, handles))
    
	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);
    
    % to facilitate sizing
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    
    % define default gaps
    [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build a grid of ui components for the grab range pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [gRange, hGapRange, vGapRange, sizeRange] = DefaultRangePaneLayout(handles);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the dimensions pane is simple
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    gDims = {handles.lbDimensions, handles.lbDimensions; ...
        handles.pbAddDims, []};
    vGapDims = [];
    hGapDims = [];
    
    % get component sizes
    sizeDims = PaneSizesFromGrid(gDims);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build a grid of ui components for sampling frequency pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % the plot dimensions pane is simple
    gFs = {handles.txtOrigFsLabel; handles.txtOrigFs; handles.txtDesFs; handles.ebDesFs; ...
        handles.txtActFs; handles.txtOutputPoints};
    vGapFs = [smallGap; normGap; smallGap; smallGap; normGap];
    hGapFs = zeros(numel(gFs), 0);  % a single column so no gaps
    
    % get component sizes
    sizeFs = PaneSizesFromGrid(gFs);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % build a grid of ui components for sampling frequency pane
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [gExport,  hGapExport, vGapExport, sizeExport] = DefaultExportPaneLayout(handles, smallGap, normGap, largeGap);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % assemble it all
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hCell = {gRange, gFs, gDims; gExport, 'l', 'l'; handles.pbOK, [], handles.pbCancel};
    hGap = {hGapRange, hGapFs, hGapDims; hGapExport, [], []; [], [], []};
    vGap = {vGapRange, vGapFs, vGapDims; vGapExport, [], []; .5*ppcm, [], .5*ppcm};
    uiSizes = {sizeRange, sizeFs, sizeDims; sizeExport, [], []; [], [], []};
        
    
    % now call the resize function
    ResizeFigFromPanes(hCell, hGap, vGap, uiSizes, true);
    
    % a final tweak
    pos1 = get(handles.uiTimeInterp, 'position');
    pos2 = get(handles.pbAddDims, 'position');
    pos2(2) = pos1(2);
    set(handles.pbAddDims, 'position', pos2);
    
    % now turn off the resize option
    set(hObject, 'resize', 'off')
    set(handles.lbDimensions,'ListboxTop', 1);           % make sure these are at the top
    drawnow();
    
    
    % save the resized figure
    SaveResizedCREFigure(hObject);
end
