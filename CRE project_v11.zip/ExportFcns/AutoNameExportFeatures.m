function output_file = AutoNameExportFeatures(data_set, featSettings, autoname, currentname)
% function output_file = AutoNameExportFeatures(data_set, featSettings, autoname, currentname)
% function to create an automatic file name for the output feature set
%
% Inputs:
%
%   data_set      - input data_set
%   featSettings  - input feature settings
%   autoname      - if true, a full new name is calculated
%                 - otherwise, currentname is updated
%   currentname   - the name to update if autoname = false

if (nargin < 3)
    autoname = true;  % if false, know tags are still replaced
end
    
if (autoname)
    % work with the current file name
    [path, fname, ext] = fileparts(data_set.file_name);
    if strcmpi(data_set.set_type, 'batch')
        fname = '$ds_name$';
    end
    if (numel(path) == 0)
        path = pwd;
    end
else
    % base it off the current name
    [path, fname, ext] = fileparts(currentname);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% if there's a _indicator type in the file name, remove it
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% remove these tokens from the file name (these come from auto naming)
if (autoname)
    remTokens = {'_classifier=\w+';               ...
        '_augmented';                    ...
        '_classified';                   ...
        '_copy'};
    
    % and strip them
    for i = 1:numel(remTokens)
        fname = regexprep(fname, remTokens{i}, '', 'ignorecase');
    end
    
    
    % only remove these if the input data set isnt a featue set
    remFeatTokens = {'_Features-[bB]in=\d+([\.p]?\d+)?s\([sce])'; ...
        '_Features'                     };
    
    % and strip them
    if strcmpi(data_set.set_type, 'features')
        for i = 1:numel(remFeatTokens)
            fname = regexprep(fname, remFeatTokens{i}, '', 'ignorecase');
        end
    end
else
    % even though we aren't fully autonaming, replace these tokens anyway
    repFeatToken = '-[bB]in=\d+([\.p]?\d+)?s\([sce])';
    repFsToken = '_fs=\d+([\.p]?\d+)?Hz';
end
         

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now create a new name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isfield(featSettings, 'binInfo') && (featSettings.binInfo.use_bins)
    
    % a feature set
    post_string = FsString(featSettings.binInfo.bin_duration);
    post_string(post_string == '.') = 'p';  % change the decimal to a p to not create funny file names
    post_string = sprintf('-bin=%ss(%s)', post_string, featSettings.binInfo.time_align);
    
    % and create the output
    if (autoname)
        output_file = sprintf('%s_features%s%s', fullfile(path, fname), post_string, ext);
    else
        output_file = fullfile(path, [regexprep(fname, repFeatToken, post_string), ext]);
    end
    
elseif isfield(featSettings, 'classes') 
    
    if (autoname)
    
        % its actually a classifier
        classifier = featSettings;
        
        % and create the output
        if numel(classifier.name)
            output_file = sprintf('%s_classifier=%s%s', fullfile(path, fname), regexprep(classifier.name, '\s+', '_'), ext);
        else
            output_file = sprintf('%s_classified%s', fullfile(path, fname), ext);
        end
        
    else
        % remains unchanged
        output_file = fullfile(path, [fname, ext]);
    end
    
elseif isfield(featSettings, 'packages')
    
    if (autoname)
        
        % its actually a custom R classifier
        rClassifier = featSettings;
        
        % and create the output
        if numel(rClassifier.class_type)
            output_file = sprintf('%s_classifier=%s%s', fullfile(path, fname), regexprep(rClassifier.class_type, '\s+', '_'), ext);
        else
            output_file = sprintf('%s_classified%s', fullfile(path, fname), ext);
        end
        
    else
        % remains unchanged
        output_file = fullfile(path, [fname, ext]);
    end
   
else
    
    % a straight export
    post_string = '';
    
    % are new dimensions being used?
    if isfield(featSettings, 'dimInfo')
        
        % have any additional dimensions been selected?
        [names, selected, n_prim, n_secondary] = GetAllDimensionNames(featSettings.dimInfo);
        if any(selected(n_prim+1:end))
            post_string = '_augmented';
        end
    end
    
    fsString = '';
    if (featSettings.exportInfo.export_fs ~= data_set.fs)
        fsString = FsString(featSettings.exportInfo.export_fs);
        fsString(fsString == '.') = 'p';  % change the decimal to a p to not create funny file names
        fsString = sprintf('_fs=%sHz', fsString);
        post_string = sprintf('%s%s', post_string, fsString);
    end
    
    % dont overwrite by default
    if (numel(post_string) == 0)
        post_string = '_copy';
    end
    
    % and create the output
    if (autoname)
        output_file = sprintf('%s%s%s', fullfile(path, fname), post_string, ext);
    elseif numel(fsString)
        output_file = fullfile(path, [regexprep(fname, repFsToken, fsString), ext]);
    else
        % remains unchanged
        output_file = fullfile(path, [fname, ext]);
    end
end

% Sanitize the name
output_file = SanitizeFileName(output_file, true, false);

