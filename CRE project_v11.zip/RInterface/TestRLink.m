function valid = TestRLink()
% function valid = TestRLink()
% This function is used to check that the link to R
% is working as intended.  If it is not, a message box with instruction to
% properly link to R is created

global R_lInK_hANdle

try
    if (numel(R_lInK_hANdle) == 0)
        % Connect to an R Session if we haven't already
        [status, msg] = openR();
    end
   
    if (status)
        % A quick test
        putRdata('r_test_var', 1:10);
        x = getRdata('r_test_var');
        evalR('rm(r_test_var)');
        valid = true;
        
    elseif any(strcmpi(msg, 'license'))
        
        % this should mean the statconn license has expired
        txt_cell = cell(2,1);
        txt_cell{1,1} = sprintf('It appears the trial period for the the statconn COM server has expired');  
        txt_cell{2,1} = 'Please download a new version from:';
        
        % add the hyperlink
        hyperlink_target = 'http://rcom.univie.ac.at/download/current/statconnDCOM.latest.exe';
        txt_cell{end+1,1} = ['<HTML><a href="', hyperlink_target, '">', hyperlink_target, '</a></html>'];
        hyperlink_box = numel(txt_cell);
        
        if (isdeployed())
            txt_cell{end+1,1} = sprintf('(This program will need to be restarted for this to be detected)');
        else
            txt_cell{end+1,1} = sprintf('(Matlab will need to be restarted for this to be detected)');
        end
        txt_cell{end+1,1} = sprintf('error: %s', msg);
        
        % now display it
        [fh, txt_h] = CreateMsgBox('Statconn license', txt_cell);
        
        % enable the hyperlinks
        callbacks = handle(txt_h{hyperlink_box}, 'callbackproperties');
        set(callbacks, 'MousePressedCallback', @(varargin)web(hyperlink_target, '-browser'));
        set(callbacks, 'MouseEnteredCallback', @(varargin)set(fh,'Pointer','hand'));
        set(callbacks, 'MouseExitedCallback', @(varargin)set(fh,'Pointer','arrow'));
        valid = false;
    else
        RlinkRequirements();
        valid = false;
    end
catch
    
    %create a message box showing the user how to make this work
    RlinkRequirements();
    valid = false;
    
end





















