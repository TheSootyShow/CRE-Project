function RlinkRequirements()
% function Requirements()
% function to create txt_cell indicating how to properly get R linked to Matlab

% use this as the handle for the COM object
global R_lInK_hANdle

% start building the string to display
txt_cell = cell(0,1);

hyperlink_boxes  = [];
hyperlink_targets = {};

editor_boxes = [];
editor_targets = {};

% three possible status's
status = {'fail', 'unknown', 'verified'};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% does it appear that R is installed:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r_path = [];
r_version = [];
r_sdl = [];
r_installed = false;
if (ispc)
    try
        r_reg = winqueryreg('name', 'HKEY_LOCAL_MACHINE', 'Software\R-core\R');
        r_installed = numel(r_reg) > 0;
        if any(strcmpi(r_reg, 'InstallPath'))
            r_path = winqueryreg('HKEY_LOCAL_MACHINE', 'Software\R-core\R', 'InstallPath');
        end
        if any(strcmpi(r_reg, 'Current Version'))
            r_version = winqueryreg('HKEY_LOCAL_MACHINE', 'Software\R-core\R', 'Current Version');
        end
    catch
        
        % see if .rdata is attached to anything
        try
            r_reg = winqueryreg('name', 'HKEY_CLASSES_ROOT', '.Rdata');
            try
                r_reg = winqueryreg('HKEY_CLASSES_ROOT', 'Rworkspace\shell\open\command');
                r_installed = true;
                r_path = fileparts(r_reg(r_reg ~= '"'));
                
                % trim off past bin
                [tokens, tmp] = regexp(r_path, filesep, 'split', 'match');
                r_path = ''; i = 0;
                while (i < numel(tokens)) && ~strcmpi(tokens{i+1}, 'bin')
                    i = i+1;
                    r_path = fullfile(r_path, tokens{i});
                end
            end
        end
    end
end

% try to find R's user preferences
if numel(r_path)
    file = fullfile(r_path, 'etc', 'Rconsole');
else
    file = fullfile(r_path, 'C:\Program Files\R\R-3.0.2\etc\Rconsole');
end

% load it
sdi = 0;
if exist(file, 'file')
    fid = fopen(file, 'r');
    while ~feof(fid)
        line = fgetl(fid);
        ind = strfind(line, 'MDI');
        if (numel(ind) && ~any(line(1:ind-1) == '#'))
            % tokenize
            [tokens, other] = regexp(line, '=', 'split', 'match');
            if (numel(tokens) == 2) && strcmpi(strtrim(tokens{2}), 'no')
                sdi = 1;
            elseif (numel(tokens) == 2) && strcmpi(strtrim(tokens{2}), 'yes')
                sdi = -1;
            end
            break;
        end
    end
    fclose(fid);
end

txt_cell{end+1,1} = sprintf('1) Install R in SDI mode and with registry entries');
if (sdi == 1)
    txt_cell{end+1,1} = sprintf('\t1a) Is R installed in SDI window mode? (status = %s)', status{2 + sdi});
else
    txt_cell{end+1,1} = sprintf('\t1a) Is R installed in SDI window mode? (status = %s, check Edit -> GUI preferences in R)', status{2 + sdi});
end
txt_cell{end+1,1} = sprintf('\t1b) Does R have registry entries installed? (status = %s)', status{2 + r_installed});
txt_cell{end+1,1} = '';  % add a blank line

% check if the COM object is installed
statconn_installed = true;
if (numel(R_lInK_hANdle) == 0)
    try
        server = actxserver('StatConnectorSrv.StatConnector');
        delete(server);
    catch
        statconn_installed = false;
    end
end
    
txt_cell{end+1,1} = sprintf('2) Install the statconn COM server from: (status = %s)', status{1 + 2*statconn_installed});  % add a blank line
url = 'http://rcom.univie.ac.at/download/current/statconnDCOM.latest.exe';
txt_cell{end+1,1} = [sprintf('\t'), '<HTML><a href="', url, '">', url, '</a></html>'];
hyperlink_boxes(end+1) = numel(txt_cell);
if (isdeployed())
    txt_cell{end+1,1} = sprintf('\t(This program will need to be restarted for this to be detected)');
else
    txt_cell{end+1,1} = sprintf('\t(Matlab will need to be restarted for this to be detected)');
end
txt_cell{end+1,1} = sprintf('\tNote:  The above download is a trial and may need to be reinstalled if the trial period expires');
hyperlink_targets{end+1} = url;
txt_cell{end+1,1} = '';  % add a blank line

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% install the rscproxy package
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

txt_cell{end+1,1}  = '3) Run R (32 bit) as an administrator and install the the rcom library using the commands:';
txt_cell{end+1,1}  = sprintf('\tinstall.packages(c("rscproxy","rcom"),repos="http://rcom.univie.ac.at/download",lib=.Library)');
txt_cell{end+1,1}  = sprintf('\tlibrary(rcom)');
txt_cell{end+1,1}  = sprintf('\tcomRegisterRegistry()');
txt_cell{end+1,1} = '';  % add a blank line



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ensure this package always loads 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(r_path)
    file = fullfile(r_path, 'etc', 'Rprofile.site');
else
    file = fullfile(r_path, 'C:\Program Files\R\R-3.0.2\Rprofile.site');
end

% load it
lib_auto = 1;  % unknown
if exist(file, 'file')
    lib_auto = 0;  % false
    fid = fopen(file, 'r');
    while ~feof(fid)
        line = fgetl(fid);
        ind = strfind(line, 'library(rcom)');
        if numel(ind) && ~any(line(1:ind-1) == '#')
            lib_auto = 2;
            break;
        end
    end
    fclose(fid);
end

txt_cell{end+1,1}  = '4) Ensure R always loads the rcom library by adding the line:';
txt_cell{end+1,1}  = sprintf('\tlibrary(rcom)');
txt_cell{end+1,1}  = sprintf('\tto the file "Rprofile.site" (status = %s)', status{1 + lib_auto});

% if it exists, link to it
if exist(file, 'file') && (ispc)
    txt_cell{end+1,1}  = [sprintf('\t'), '<HTML><a href ="',file, '">', file, '</a></html>'];
    editor_boxes(end+1) = numel(txt_cell);
    editor_targets{end+1} = sprintf('explorer %s', file);
else
    txt_cell{end+1,1}  = sprintf('\t(expected location is %s)', file);
end
txt_cell{end+1,1} = [];

txt_cell{end+1,1} = 'More detailed information can be found at:';
url = 'http://homepage.univie.ac.at/erich.neuwirth/php/rcomwiki/doku.php?id=wiki:how_to_install';
txt_cell{end+1,1} = ['<HTML><a href="', url, '">', url, '</a></html>'];
hyperlink_boxes(end+1) = numel(txt_cell);
hyperlink_targets{end+1} = url;


% now display it
[fh, txt_h] = CreateMsgBox('Instructions for using R functions', txt_cell);

% enable the hyperlinks
for i = 1:numel(hyperlink_boxes)
   
    % and tell it to go to the url
    callbacks = handle(txt_h{hyperlink_boxes(i)}, 'callbackproperties');
    set(callbacks, 'MousePressedCallback', @(varargin)web(hyperlink_targets{i}, '-browser'));
    set(callbacks, 'MouseEnteredCallback', @(varargin)set(fh,'Pointer','hand'));
    set(callbacks, 'MouseExitedCallback', @(varargin)set(fh,'Pointer','arrow'));

   
   
end

for i = 1:numel(editor_boxes)
   
    % tell it to invoke the system editor
    callbacks = handle(txt_h{editor_boxes(i)}, 'callbackproperties');
    set(callbacks, 'MousePressedCallback', @(varargin)system(editor_targets{i}));
    set(callbacks, 'MouseEnteredCallback', @(varargin)set(fh,'Pointer','hand'));
    set(callbacks, 'MouseExitedCallback', @(varargin)set(fh,'Pointer','arrow'));
   
end