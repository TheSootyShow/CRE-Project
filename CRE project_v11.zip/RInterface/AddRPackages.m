function [valid, msg, rHistory] = AddRPackages(packages)
% function [valid, msg, rHistory] = AddRPackages(packages)
% this function add R packges to the R session
% R should be open before calling htis function

rHistory = '';
msg = [];
valid = zeros(size(packages));

% include libraries
for i = 1:numel(packages)
    [valid(i), eval_str] = AddRPackage(packages{i});
    rHistory = sprintf('%s%s\n', rHistory, eval_str);
end

if ~all(valid)
    
    libString = sprintf('\t%s\n', packages{~valid});
    Rver = evalR('R.version.string');
    Rarch = evalR('Sys.getenv("R_ARCH")');
    
    msg = sprintf(['Unable to load library(s):\n%s\nPlease install the packages manually on %s (%s).\n'...
                  'If the package(s) has already been installed, this indicates there is a problem with the interface to R.'], libString, Rver, Rarch);
end
valid = all(valid);