function [added,eval_str] = AddRPackage(package)
% function [added,eval_str] = AddRPackage(package)
% function to add a package to the library in R

if ~(IsRopen())
    if (~openR())
        RlinkRequirements();
        error('Could not open the connection to R');
    end
end

% check it works
eval_str = sprintf('require("%s")', package);
[resp, sts] = evalR(eval_str);
added = resp;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AWBS - getting the user to mnaully install packages so disable this
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

return;

% if it didnt work, try installing the package
if ((~sts) || (~resp))
    install_str = sprintf('install.packages("%s", repos="http://cran.csiro.au")', package);
    hSpinner = MCRSpinner(sprintf('Installing: %s',  package));
    drawnow();
    [~, sts] = evalR(install_str);
    if (sts)
        [resp, sts] = evalR(eval_str);
        eval_str = sprintf('%s\n%s',install_str,eval_str);
    end
    delete(hSpinner);
    drawnow();
    
    if (sts ~= 1) || (resp ~= 1)
        errordlg(sprintf('Unable to install package: %s\nPlease start R and install the package manually', package), 'Package installation error', 'modal');
        error('Unable to install package: %s', package);
    end

end
