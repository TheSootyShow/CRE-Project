function inputs = TokenizeFuncInputs(input_str)
% function inputs = TokenizeFuncInputs(input_str)
% function to tokenize a string representing inputs to a function
% its assumed function inputs are ','s, but ',' inside brackets will be
% ignored

% how many brackets are open?
open_count = max(cumsum(input_str == '(') - cumsum(input_str == ')'), 0);

% find commas where no brackets are open
token_inds = [0, find((input_str == ',') & (open_count == 0)), numel(input_str)+1];

% and tokenize
inputs = cell(1, numel(token_inds)-1);
for i = 1:numel(inputs)
    inputs{i} = strtrim(input_str(token_inds(i)+1:token_inds(i+1)-1));
end



