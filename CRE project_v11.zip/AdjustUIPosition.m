function pos = AdjustUIPosition(hObject, pos, width, height, leftmost, rightmost, vcent)
% function pos = AdjustUIPosition(hObject, pos, width, height, leftmost, rightmost, vcent)
% when the placement function have found the grid for this uicomponent /
% object, use this function to adjust withing this space

if (nargin < 5)
    vcent = true; % center text and radio buttons vertically
end

% what object is this?
type = get(hObject, 'type');
if strcmpi(type, 'uicontrol')
    type = get(hObject, 'style');
end

% keep the original size if its a push button or a table
if any(strcmpi(type, {'pushbutton', 'uitable'}))
    
    left = pos(1);
    right = pos(1) + pos(3);
    pos(3) = width;
    pos(4) = height;
    
    % if this is the right most column right align it, or
    % center if its in the middle
    if (leftmost)
        % do nothing
    elseif (rightmost)
        pos(1) = right - width;  % right align
    else
        pos(1) = left + floor((right - left - width)/2); % center align
    end
end


% vertically center text and radio buttons?
if (vcent && any(strcmpi(type, {'text', 'radiobutton'})))
    dx = (pos(4) - height) / 2;
    if (dx > 0)
        pos(2) = floor(pos(2) + dx);
        pos(4) = height;
    end

% should we make the object larger?    
elseif (pos(4) > (height))
    
    v_offset = (pos(4) - height);
    
    if strcmpi(get(hObject, 'type'), 'uipanel')
        
        % enlarge a uipanel, but keep its children in the same spot
        children = get(hObject, 'children');
        set(children, 'units', 'pixels')
        for k = 1:numel(children)
            child_pos = get(children(k), 'position');
            child_pos(2) = child_pos(2) + v_offset;
            set(children(k), 'position', child_pos);
        end
        
    elseif strcmpi(get(hObject, 'type'), 'listbox')
        
        % list boxes automatically get taller
        
        
    else
    
    
        % for anything else, if we've extended the grid spot verticaly, change the vertical
        % offset so it sits in the same place relative to the top of the box
        pos(2) = pos(2) + v_offset;
        pos(4) = pos(4) - v_offset;
        
    end
end
        
    