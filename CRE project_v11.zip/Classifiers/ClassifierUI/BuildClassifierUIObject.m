function [uiObject, handles, force_resize] = BuildClassifierUIObject(handles, tag, style, parent, string, value, callback, settings)
% function [handles, handles, force_resize] = BuildClassifierUIObject(handles, tag, style, parent, string, value, callback, settings)
% function to add uiObject to the gui if it doesnt exist already

% do we need to force the resize function?
force_resize = false;

% does it already exist?
uiObject = findobj(parent, 'tag', tag);
if (numel(uiObject) == 0)
    uiObject = uicontrol(parent, 'style', style, 'tag', tag, settings{:});
    handles.(tag) = uiObject; % assign to handles
    force_resize = true;
else
    set(uiObject, settings{:});
end
set(uiObject, 'string', string, 'callback', callback);
if numel(value)
    set(uiObject, 'value', value);
end
