function [handles, mapped, force_resize, ds_feats] = BuildClassifierFeatOpts(ds_feats, class_feats, mapped, callback, handles, force_resize)
% function [handles, mapped, force_resize, ds_feats] = BuildClassifierFeatOpts(ds_feats, class_feats, mapped, callback, handles, force_resize)
% function to allow the user to specify what feature from the data set (ds_feats) is what input to the
% classifier (class_feats)
%
%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%
%
% ds_feats      - the feature names from the data set
%
% class_feats   - feature names required by the classifier
%
% mapped        - data set features that are equivilent to the features
%                 required by the classifier (leave blank if unknown)
%
% callback      - function to execute when the user selects a different
%                 data set feature to match the classifier feature
%
% handles       - the handles of the parent gui
%
% force_resize  - indicates the parent gui needs a resize

% us a 5 x 2 grid
maxRows = 5;
maxCols = 2;

% add two time variants to the dimensions name
ds_feats = [ds_feats(:); 'Time (s from recording start)'; 'Time (s from midnight)'];
unused = 1:numel(ds_feats);


% how many pages will we need?
nInputs = numel(class_feats);
pageInputs = maxRows * maxCols;  
nPages = max(ceil(nInputs / pageInputs),1);
handles.nPages = nPages;  % store this

% how many pages are there currently?
cPages = numel(findobj(handles.uiFeatMatch, 'type', 'uitab'));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remove all mapped entries that dont match a data set feature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i = 1:numel(mapped)
    if (numel(mapped{i}) > 0) && ~any(strcmpi(mapped{i}, ds_feats))
        mapped{i} = [];
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% build the tab system?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nPages > 1) && (cPages == 0)
    
    % delete all of the current controls
    del_objs = get(handles.uiFeatMatch, 'children');
    
    % make sure the title handle isn't present
    hTitle = getTitleHandle(handles.uiFeatMatch);
    if numel(hTitle)
        del_objs = del_objs(del_objs ~= hTitle);
    end

    % and remove them
    if (numel(del_objs) > 0)
        del_tags = get(del_objs, 'tag');
        if ~iscell(del_tags)
            del_tags = {};
        end
        
        handles = rmfield(handles, del_tags(isfield(handles, del_tags)));
        delete(del_objs);
    end
    
    % build the tab group
    handles.tgFeatTabGroup = uitabgroup('parent', handles.uiFeatMatch, 'tag', 'tgFeatTabGroup'); 
     
    % add the tabs
    for i = 1:nPages
        
        % create the tab
        tag = sprintf('uiFeatTab%i', i);
        handles.(tag) = uitab(handles.tgFeatTabGroup, 'title', sprintf('Inputs: %i-%i', (i-1)*pageInputs+1, i*pageInputs));
        
        % with a child data frame
        frameTag = sprintf('uiTabFrame%i', i);
        handles.(frameTag) = uipanel('parent', handles.(tag), 'tag', frameTag);
        
    end
    force_resize = true;
elseif (nPages > 1) && (nPages ~= cPages)
    
    % add additional tabs that are needed
    for i = cPages+1:nPages
        tag = sprintf('uiFeatTab%i', i);
        handles.(tag) = uitab(handles.tgFeatTabGroup, 'title', sprintf('Features: %i-%i', (i-1)*pageInputs+1, i*pageInputs));
        
        % with a child data frame
        frameTag = sprintf('uiTabFrame%i', i);
        handles.(frameTag) = uipanel('parent', handles.(tag), 'tag', frameTag);
    end
    
    % remove extra tabs
    for i = nPages+1:cPages
        tag = sprintf('uiFeatTab%i', i);
        handles = DeleteTab(handles, tag);
    end
    force_resize = true;
    
elseif (nPages == 1) && (cPages > 0)
    
    % remove the tab system entirely
    for i = 1:cPages
        tag = sprintf('uiFeatTab%i', i);
        handles = DeleteTab(handles, tag);
    end
    delete(handles.tgFeatTabGroup);
    handles = rmfield(handles, 'tgFeatTabGroup');
    force_resize = true;
    
end
hGrid = cell(nPages, 1);

% how many rows / cols will we use?
if (nPages == 1)
    nCols = ceil(nInputs / maxRows);
    nRows = min(maxRows, nInputs);
    
    % special case
    if (nRows == 4) && (nCols == 1)
        nRows = 2;
        nCols = 2;
    end
else
    % always use the maximums
    nRows = maxRows;
    nCols = maxCols;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now build it all
%%%%%%%%%%%%%%%%%%%%%%%%%%

hTabs = zeros(nPages, 1);
for i = 1:nInputs  % always create a full tab
    
    % start a new page?
    pageNum = ceil(i/pageInputs);
    if (rem(i-1, pageInputs) == 0)
        resizePage = false;
        hGrid{pageNum} = cell(2*nRows, nCols);
        if (nPages == 1)
            parent = handles.uiFeatMatch;  % us the main frame
        else
            tag = sprintf('uiTabFrame%i', pageNum);
            parent = handles.(tag);  % the child frame of the tab
            hTabs(pageNum) = get(handles.(tag), 'parent');  % in case we need to resize
        end
    end
    
    % create a title for it
    [txtObj, handles, force(1)] = BuildClassifierUIObject(handles, sprintf('txtInput%i', i), 'text', parent, sprintf('Feature %i: %s', i, class_feats{i}), ...
        [], [], {'horizontalalignment', 'left', 'enable', 'on', 'visible', 'on'});
    
    % and a push menu
    [pmObj, handles, force(2)] = BuildClassifierUIObject(handles, sprintf('pmInput%i', i), 'popupmenu', parent, ds_feats, ...
        [], callback, {'enable', 'on', 'visible', 'on'});
    Default_CreateFcn(pmObj);
    
    % if its not filled, try to find a value for it
    if (numel(mapped{i}) == 0)
        matches = strncmpi(ds_feats, class_feats{i}, numel(class_feats{i}));
        index = find(matches, 1, 'first');
        
        % if it didn't match anything
        if (numel(index) == 0)
            if numel(unused)
                index = unused(1);
            else
                index = 1;
            end
        end
    else
        index = find(strcmpi(ds_feats, mapped{i}), 1, 'first');
    end
    set(pmObj, 'value', index, 'enable', 'on', 'visible', 'on');
    mapped{i} = ds_feats{index};      % keep track of current assignment
    unused = unused(unused ~= index);
    
    % and the sizing grid
    hGrid{pageNum}{(i-1)*2+1} = txtObj;
    hGrid{pageNum}{(i-1)*2+2} = pmObj;
    
    % does this panel need a resize?
    resizePage = resizePage || any(force);
    if ((rem(i, pageInputs) == 0) || (i == nInputs)) && resizePage
        if (pageNum == 1)
            force_resize = true;                   % need to resize the whole gui if the first page changes
            hGrid{pageNum} = ResizePage(hGrid{pageNum}, pageInputs, nRows);  % resize this page now
        else
            CopyPagePositions(handles, pageNum, pageInputs);
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% disable unused inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

count = nInputs + 1;
txtTag = sprintf('txtInput%i', count);
while (isfield(handles, txtTag))
    
    % blank the txt
    txtObj = handles.(txtTag);
    set(txtObj, 'string', 'Setting N/A', 'enable', 'off', 'visible', 'off');
    
    % and disable the menu
    pmTag = sprintf('pmInput%i', count);
    pmObj = handles.(pmTag);
    set(pmObj, 'enable', 'off', 'visible', 'off');
    
    % and process
    count = count + 1;
    txtTag = sprintf('txtInput%i', count);
    
end

% if the classifier wants more inputs than the data set has, warn the user
if (numel(class_feats) > numel(ds_feats))
    handles.warn_dlg = warndlg(sprintf('Warning: Classifier requires %i inputs, but the data set only has %i features', numel(class_feats), numel(ds_feats)));
else
    if (numel(handles.warn_dlg) && ishandle(handles.warn_dlg))
        delete(handles.warn_dlg); % remove old warnings
    end
    handles.warn_dlg = [];
end

function hGrid = ResizePage(hGrid, n_inputs, desRows)
% function hGrid = ResizePage(hGrid, n_inputs, desRows)
% function to resize the first page

[smallGap, normGap, largeGap] = DefaultPaneGaps();

desCols = ceil(n_inputs / desRows);
if (numel(hGrid) < 2*desRows*desCols)
    hGrid{2*desRows*desCols} = [];
end
hGrid = reshape(hGrid, 2*desRows, desCols);

% prune of all empty columns
emptyCol = all(cellfun(@(x)(numel(x) == 0), hGrid), 1);
hGrid = hGrid(:,1:find(~emptyCol, 1, 'last'));

% prune of all empty rows
emptyRow = all(cellfun(@(x)(numel(x) == 0), hGrid), 2);
hGrid = hGrid(1:find(~emptyRow, 1, 'last'), :);


% default spacings
hSpace = repmat(largeGap, size(hGrid,1), size(hGrid,2)-1);
vSpace = [repmat([smallGap; largeGap], size(hGrid,1)/2-1, size(hGrid,2)); ...
    repmat(smallGap, 1, size(hGrid,2))];

% and call the resize function
ResizePaneFromGrid(hGrid, hSpace, vSpace, false);


function CopyPagePositions(handles, pageNum, pageInputs)
% function CopyPagePositions(handles, pageNum, pageInputs)
% this function changes the sizes of everthing to match the sizes in the
% first tab

% get the first tab and all of its children
templateFrame = get(handles.uiFeatTab1, 'children'); % N.B should only be the frame
templateObjs = get(templateFrame, 'children');

% make sure the title handle isn't present
hTitle = getTitleHandle(templateFrame);
if numel(hTitle)
    templateObjs = templateObjs(templateObjs ~= hTitle);
end

% now copy the frame size / location
destFrame = get(handles.(['uiFeatTab', num2str(pageNum)]), 'children');
set(destFrame, 'units', get(templateFrame, 'units'), 'position', get(templateFrame, 'position'));

% and all of the uiobjects
for i = 1:numel(templateObjs)
    
    % get the tag for the equivilent object on the new page
    exp_tag = get(templateObjs(i), 'tag');
    objNum = regexp(exp_tag, '\d+', 'match', 'once');
    expNum = num2str((pageNum-1)*pageInputs + str2double(objNum));
    exp_tag = strrep(exp_tag, objNum, expNum);
    
    % and now copy the sizing
    if (isfield(handles, exp_tag) && ishandle(handles.(exp_tag)))
        set(handles.(exp_tag), 'units', get(templateObjs(i), 'units'), 'position', get(templateObjs(i), 'position'));
    end
end


function handles = DeleteTab(handles, tabTag)
% function handles = DeleteTab(handles, tabTag)
% function to delete a Tab

% get all children
frame = get(handles.(tabTag), 'children');  % this should be the frame
frame_kids = get(frame, 'children');         % might be necessary to recurse this

% all objects to delete
del_objs = [handles.(tabTag); frame; frame_kids];
del_tags = get(del_objs, 'tag');  % and their tags

% and remove them
handles = rmfield(handles, del_tags(isfield(handles, del_tags)));
delete(del_objs);









