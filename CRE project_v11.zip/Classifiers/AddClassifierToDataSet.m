function data_set = AddClassifierToDataSet(data_set, classifier)
% function data_set = AddClassifierToDataSet(data_set, classifier)
% function to add the classifier infor to the data set

% allocate space
data_set.class_info = cell(numel(classifier), 1 + 3 * 3);

% and do each one
for i = 1:numel(classifier)
    
    % fill in the first entry (no threshold for default)
    data_set.class_info{i,1} = classifier(i).name;
    data_set.class_info(i,2:4) = {classifier(i).classes{1}, classifier(i).class_enum(1), []};
    
    for j = 2:numel(classifier(i).classes)
        data_set.class_info{i,(1+(j-1)*3)+1} = classifier(i).classes{j}; 
        data_set.class_info{i,(1+(j-1)*3)+2} = classifier(i).class_enum(j);
        data_set.class_info{i,(1+(j-1)*3)+3} = classifier(i).thresh_select(j-1);
    end
end