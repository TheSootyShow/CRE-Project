function script = CreateRScript(rClassifier)
% function script = CreateRScript(rClassifier)
% this function producese the script that will be run when the
% R classifier is used

% us a blank template?
blank_template = (nargin < 1) || ~isstruct(rClassifier);

% initialise the output script
script = '';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% start by indicating the feature names used by the model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

script = AddSecHeader(script, '1) Declare the names of the features used by the classifier / predictor here\nN.B. Do NOT change the variable name from "feature_names"');
script = sprintf('%s# N.B. Matching the order used to create X in step 6 is beneficial\n', script);
if (blank_template)
    script = sprintf('%s# EDIT THE FOLLOWING:\n# e.g feature_names <- c("X_mean", "X_std")\n', script);
end
script = sprintf('%sfeature_names <- c(', script);
if (~blank_template)
    for i = 1:numel(rClassifier.feat_names)
        script = sprintf('%s%s"%s"', script, repmat(', ', 1, i > 1), rClassifier.feat_names{i});
    end
end
script = sprintf('%s)\n\n\n', script);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Include libraries
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

script = AddSecHeader(script, '2) Declare required packages');


% create the package list
packageList = 'libs';
script = sprintf('%srm(%s) # clear existing variable\n', script, packageList);
if (blank_template)
    script = sprintf('%s\n# EDIT THE FOLLOWING:\n# e.g %s <- c("rpart")\n', script, packageList);
else
    script = sprintf('%s\n# Create a list of required packages\n', script);
end
script = sprintf('%s%s <- c(', script, packageList);
if (~blank_template)
    for i = 1:numel(rClassifier.packages)
        script = sprintf('%s%s"%s"', script, repmat(', ', 1, i > 1), rClassifier.packages{i});
    end
end
script = sprintf('%s)\n\n\n', script);


script = AddSecHeader(script, '3) Load the required packages\n(No need to edit)');

% now load them detecting failure
script = sprintf('%sfor (i in 1:length(%s))\n{\n', script, packageList);

% install it if needed
script = sprintf('%s\t# Install the package if needed \n', script);
script = sprintf('%s\tif (!is.element(%s[i], .packages()))\n\t{', script, packageList);
script = sprintf('%s\tloaded <- install.packages(%s[i])', script,packageList);    
script = sprintf('%s\t};\n', script);    % close the first package if

% now add the require
script = sprintf('%s\n\t# Add the library \n', script);
script = sprintf('%s\tloaded <- require(%s[i], character.only = TRUE);\n', script,packageList);               % try loading it

% trigger an R error if it failed
script = sprintf('%s\n\t# Throw an error if it failed \n', script);
script = sprintf('%s\t# if (!loaded)\n\t# {\n', script);      
script = sprintf('%s\t#\terrorMsg <- paste("Could not load package: ", %s[i])\n', script, packageList);      
script = sprintf('%s\t#\tstop(errorMsg)\n\t#};\n', script);      

% close the for loop
script = sprintf('%s}\n', script);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load the classifier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

script = sprintf('%s\n\n\n\n', script);
script = AddSecHeader(script, '4) Load the classifier, and store it''s R variable name in "rClassifier"');

% R likes double slashes
if (~blank_template)
    sep = ['\', filesep];
    class_file = regexprep(rClassifier.file_name, [sep, '{1,}'], repmat(sep,1,2));

    % load the model
    script = sprintf('%srClassifier <- load("%s")\n', script, class_file);
    
else
    
    script = sprintf('%s\n# ADD CODE TO LOAD THE CLASSIFIER HERE:\n# e.g rClassifier <- load("%s")\n\n', script, 'C:\\SVM_classifier.rdata');
    
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pass the data set to R!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

script = sprintf('%s\n\n\n\n', script);
script = AddSecHeader(script, '5) Import data set\nDo NOT edit !!!');
script = sprintf('%s# Start do not edit import (these commands aren''t meant for R)\n', script);

% Now pass each column to R
rVarStr = '';
if (~blank_template)
    for i = 1:numel(rClassifier.feat_names)
        script = sprintf('%s# putRdata(%s, DATASET->%s)\n', script, rClassifier.feat_names{i}, rClassifier.feats_mapped{i});
        rVarStr = sprintf('%s%s%s', rVarStr, repmat(', ', 1, i > 1), rClassifier.feat_names{i});
    end
end

% also pass the sampling freqency
script = sprintf('%s\n# Store the data set sampling frequency in fs\n', script);
script = sprintf('%s# putRdata(fs, DATASET->fs)\n\n', script);

script = sprintf('%s# End do not edit import - R should now have data set variables %s and the sampling frequency fs defined now\n', script, rVarStr);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Build the R data frame from the variables
% exported from matlab
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

script = sprintf('%s\n\n\n\n', script);
if (~blank_template)

    
    script = AddSecHeader(script, 'Store the predictors in a single object named X');
    script = sprintf('%s%s', script, CreateDataAmalgString(rClassifier));
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Perform predictions
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    script = sprintf('%s\n\n\n\n', script);
    script = AddSecHeader(script, '6) Perform predictions (predictions must be stored in variable Y)');
    script = sprintf('%s%s\n', script, CreatePredictorString(rClassifier));

else
    script = AddSecHeader(script, '6) Insert your own code to generate predictions,\nand ensure they''re stored in variable "Y"');
    script = sprintf('%s# (At this point all variables in the list "feature_names"\n# are available in the R workspace)\n', script);
    script = sprintf('%s\n# ADD CODE TO ADD GENERATE CLASSIFIER PREDICTIONS HERE:\n', script);
    script = sprintf('%s# e.g.\n', script);
    script = sprintf('%s# X <- data.frame(X_mean, X_std) # X_mean and X_std are the feature names from part 1\n', script);
    script = sprintf('%s# Y <- predict(sed.decisiontree, X, type="class")\n', script);
    
end
 
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Perform predictions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

script = sprintf('%s\n\n\n\n', script);
script = AddSecHeader(script, '7) Export predictions\nDo NOT edit!!!');

script = sprintf('%s# Start do not edit export (these commands aren''t meant for R)\n\n', script);
script = sprintf('%s# DATASET->CLASSIFIED = getRdata(''Y'')\n\n', script);
script = sprintf('%s# End do not edit export \n', script);




        

function script = AddSecHeader(script, comment)
% function script = AddSecHeader(script, comment)
% function to insert a section header

tokens = regexp(comment, '\\n', 'split');
max_len = max(cellfun(@numel, tokens));

delim_str = repmat('#', 1, max_len+4);
script = sprintf('%s%s\n', script, delim_str);
for i = 1:numel(tokens)
    if (numel(tokens{i}) < max_len)
        tokens{i} = [tokens{i}, repmat(' ', 1, max_len - numel(tokens{i}))];
    end
    script = sprintf('%s# %s #\n', script, tokens{i});
end
script = sprintf('%s%s\n\n', script, delim_str);

