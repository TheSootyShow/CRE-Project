function rString = CreatePredictorString(rClassifier)
%function rString = CreatePredictorString(rClassifier)
% this function creates the string cmd to send to R to make the
% classifer perfrom predictions on input X

if (nargin == 0)
    rString = 'predict(%classifier_var%, %data%, type="class")';
    return;
end

% use default if unspecified
if (numel(rClassifier.predict_func) == 0)
    rClassifier.predict_func = CreatePredictorString();  % use default
end

% create an arbitary variable name if unspecified
if (numel(rClassifier.var_name) == 0)
    rClassifier.var_name = 'sed.decisiontree';
end

rString = regexprep(rClassifier.predict_func, '%classifier_var%', rClassifier.var_name);
rString = regexprep(rString, '%data%', 'X');
rString = sprintf('Y <- %s', rString);
