function rString = CreateDataAmalgString(rClassifier)
% function rString = CreateDataAmalgString(rClassifier)
% this function creates the string cmd to send to R to turn the 
% individual features into X data set 

if (nargin == 0)
    rString = 'data.frame(%feat_names%)';  % a query for the default
    return;
end

% use default if unspecified
if (numel(rClassifier.data_storage) == 0)
    rClassifier.data_storage = CreateDataAmalgString();  % use default
end

% create some dummy feature names if unspecified
if (numel(rClassifier.feat_names) == 0)
    rClassifier.feat_names = {'feature_1', 'feature_2', '...', 'feature_n'};
end

% build the comma seperated feature list
featList = sprintf('%s', rClassifier.feat_names{1});
for i = 2:numel(rClassifier.feat_names)
    featList = sprintf('%s, %s', featList, rClassifier.feat_names{i});
end
rhs = regexprep(rClassifier.data_storage, '%feat_names%', featList);

% and make the string
rString = sprintf('X <- %s', rhs);

