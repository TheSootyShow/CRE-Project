function varargout = CREClassifierGUI(varargin)
%  classSettings = CREClassifierGUI(data_set, classSettings)
%  classSettings = CREClassifierGUI(data_set, classifier, exportInfo)
% creates the classifier UI object

% use this to try and load a version that's already been resized
layout_fcn = GuiLayoutFunction('CREClassifierGUI');

% Last Modified by GUIDE v2.5 14-Jan-2015 03:49:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREClassifierGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @CREClassifierGUI_OutputFcn, ...
                   'gui_LayoutFcn',  layout_fcn, ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before creclassifiergui is made visible.
function CREClassifierGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to creclassifiergui (see VARARGIN)

% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);

% attached warning for the gui
handles.warn_dlg = [];

% the data set input
handles.data_set = varargin{1};

% the classifer input can be a string for a default type.  Check this
if ischar(varargin{2})
    varargin{2} = InitClassifier(varargin{2});
end

% call it "featSettings for compatibility" with the standardised export pane
if (nargin == 3)
    
    handles.featSettings = struct('classifier', varargin{2}, ...
                                  'exportInfo', varargin{3});

elseif isfield(varargin{2}, 'classes')
    
    % only the classifier part if provided
    handles.featSettings = struct('classifier', varargin{2}, ...
                                  'exportInfo', InitExportStruct(handles.data_set, varargin{2}));
    
else
    % the full input structre
    handles.featSettings = varargin{2};
end
   


% update the time range panel if needed
if (~isdeployed && IsDeveloper())
    
    % and the export processing pane
    handles = CopyExportTemplateToFigure(hObject, handles);

end

% Initialise the GUI
handles = InitialiseGUI(hObject, eventdata, handles);

% commit
guidata(hObject, handles);

% Make the GUI modal
% set(handles.CREClassifierGUI,'WindowStyle','modal');

% UIWAIT makes creclassifiergui wait for user response (see UIRESUME)
uiwait(handles.CREClassifierGUI);

function handles = InitialiseGUI(hObject, eventdata, handles)
% function handles = InitialiseGUI(hObject, eventdata, handles)
%function to initialise this gui

% resize existing panes?
resize = RunResizeFcn(hObject, handles);

% Build the setting options
[handles, force_resize(1)] = BuildSettingsOpts(handles, resize);

% Build the class options
[handles, force_resize(2)] = BuildClassOpts(handles, resize);

% Build the feature options
[handles, force_resize(3)] = BuildFeatOpts(handles, resize);

% force a resize?
force_resize = any(force_resize);

% Initialise output blocking
handles.block_list = [];

% Initialise the export pane
InitialiseExportPane(handles.featSettings.exportInfo, handles);

% call the resize function
handles = CREClassifierGUI_ResizeFcn(hObject, force_resize, handles);

% if there's a warning dialog, make sure its the focus
if (numel(handles.warn_dlg) == 1) && ishandle(handles.warn_dlg)
    figure(handles.warn_dlg);
end

% default output
handles.output = {'Cancel', handles.featSettings};

if (nargout == 0)
    guidata(hObject);
end



% --- Outputs from this function are returned to the command line.
function varargout = CREClassifierGUI_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output(1:nargout);

% The figure can be deleted now
delete(handles.CREClassifierGUI);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% response
handles.output = {get(hObject, 'string'), handles.featSettings};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CREClassifierGUI);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% response
handles.output = {get(hObject, 'string'), handles.featSettings};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CREClassifierGUI);




% --- Executes on key press over creclassifiergui with no controls selected.
function CREClassifierGUI_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to creclassifiergui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
char = get(hObject,'CurrentKey');
close_gui = false;
if isequal(char,'escape')
    
    % escape is treated as "Cancel"
    close_gui = true;
    
    % response
    handles.output = {get(handles.pbCancel, 'string'), handles.featSettings};


elseif isequal(char,'return')
    
    % return is treated as "OK"
    close_gui = true;
    handles.output = {get(handles.pbOK, 'string'), handles.featSettings};
    
end

% Closing the UI?
if (close_gui)
    guidata(hObject, handles);
    uiresume(handles.CREClassifierGUI);
end    


% --- Executes when user attempts to close creclassifiergui.
function CREClassifierGUI_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to creclassifiergui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end



function [handles, force_resize] = BuildSettingsOpts(handles, force_resize)
% function [handles, force_resize] = BuildSettingsOpts(handles, force_resize)
% function to build the settings panel

% ensure the options list is allocated
n_dims = numel(handles.featSettings.classifier.dims);
if (numel(handles.featSettings.classifier.dim_selections) ~= n_dims)
    handles.featSettings.classifier.dim_selections{n_dims} = [];
    handles.featSettings.classifier.dim_selections(n_dims+1:end) = [];
end

% shortcut
classifier = handles.featSettings.classifier;

% and build
hGrid = cell(2*numel(classifier.dims),1);
for i = 1:numel(classifier.dims)
    
    % create a title for it
    [hGrid{(i-1)*2+1}, handles, force(2)] = BuildClassifierUIObject(handles, sprintf('txtSettings%i', i), 'text', handles.uiSettings, sprintf('%s:', classifier.dim_titles{i}), ...
        [], [], {'horizontalalignment', 'left', 'enable', 'on', 'visible', 'on'});
    
    % set its value if we can
    selected = classifier.dim_selections{i};
    select_val = 1; match = [];
    if numel(selected)
        match = find(cellfun(@(x)isequal(x, selected), classifier.dims{i}, 'uniformoutput', true));
        if (numel(match))
            select_val = match(1);
        end
    end
    
    % and a push menu
    [pmObj, handles, force(1)] = BuildClassifierUIObject(handles, sprintf('pmSettings%i', i), 'popupmenu', handles.uiSettings, classifier.dims{i}, ...
        select_val, @(hObject, event_data)(SettingsChange(hObject, event_data, guidata(hObject))), {'enable', 'on', 'visible', 'on'});
    Default_CreateFcn(pmObj);
    hGrid{(i-1)*2+2} = pmObj;
    
    % is a resize required?
    force_resize = force_resize | any(force);
        
    % if this is device, try to select the value from the data set
    if ~numel(match) && numel(handles.data_set.device_type) && strcmpi(classifier.dim_titles{i}, 'device')
        index = find(strcmpi(classifier.dims{i}, handles.data_set.device_type));
        if numel(index)
            set(pmObj, 'value', index);
        end
    end
    handles.featSettings.classifier.dim_selections{i} = classifier.dims{i}{get(pmObj, 'value')};

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% disable unused inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

count = numel(classifier.dims)+1;
txtTag = sprintf('txtSettings%i', count);
while (isfield(handles, txtTag))
    
    % blank the txt
    txtObj = handles.(txtTag);
    set(txtObj, 'string', 'Setting N/A', 'enable', 'off', 'visible', 'off');
    
    % and disable the menu
    pmTag = sprintf('pmSettings%i', count);
    pmObj = handles.(pmTag);
    set(pmObj, 'enable', 'off', 'visible', 'off');
    
    % and process
    count = count + 1;
    txtTag = sprintf('txtSettings%i', count);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Resize this pane?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (force_resize)

    % spacing patterns
    [smallGap, normGap, largeGap] = DefaultPaneGaps();
    hSpace = zeros(size(hGrid,1), size(hGrid,2)-1);
    vSpace = [repmat([smallGap; 2*largeGap], numel(classifier.dims)-1, 1); smallGap];
    
    % and space it
    ResizePaneFromGrid(hGrid, hSpace, vSpace, false);
    
end


function [handles, force_resize] = BuildFeatOpts(handles, force_resize)
% function [handles, force_resize] = BuildFeatOpts(handles, force_resize)
% function to allow the user to specify what feature is what input to the
% classifier

% ensure the input list is allocated
n_inputs = numel(handles.featSettings.classifier.def_inputs);
if (numel(handles.featSettings.classifier.inputs) > n_inputs)
    handles.featSettings.classifier.inputs(n_dims+1:end) = [];
elseif (numel(handles.featSettings.classifier.inputs) < n_inputs)
    handles.featSettings.classifier.inputs{n_dims} = [];
end

% shortcuts
ds_feats = handles.data_set.dim_names;

% insert mappings where needed
for i = 1:n_inputs
    if (numel(handles.featSettings.classifier.inputs{i}) == 0)
        handles.featSettings.classifier.inputs{i} = handles.featSettings.classifier.def_inputs{i};  % N.B. BuildClassifierFeatOpts will remove ones that aren't in the data set
    end
end

% and call the populate function
[handles, handles.featSettings.classifier.inputs, force_resize, ds_feats] = BuildClassifierFeatOpts(ds_feats, handles.featSettings.classifier.def_inputs, handles.featSettings.classifier.inputs, ...
    @(hObject, event_data)(FeatChange(hObject, event_data, guidata(hObject))), handles, force_resize);

% and store which columns the mapped features are in the data set
[tmp, handles.featSettings.classifier.input_cols] = ismember(handles.featSettings.classifier.inputs, ds_feats);




function [handles, force_resize] = BuildClassOpts(handles, force_resize)
% function [handles, force_resize] = BuildClassOpts(handles, force_resize)
% function to build the class options

% shortcut
classifier = handles.featSettings.classifier;

% the settings we are already on
dimIndex = GetChangeIndex(handles);
cellIndex(2:numel(dimIndex)+1) = num2cell(dimIndex);

% for panel placement
hPane = cell(3,2);
hGrid = cell(numel(classifier.dims),1);

% and build
for i = 1:numel(classifier.classes)
    
    % create a pane for it
    uiTag = sprintf('uiClass%i', i);
    paneObj = findobj(handles.uiClasses, 'tag', uiTag);
    if (numel(paneObj) == 0)
        paneObj = uipanel(handles.uiClasses);
        handles.(uiTag) = paneObj; % assign to handles
    end
    set(paneObj, 'title', sprintf('Class: %i', classifier.class_enum(i)))
    
    % create a title for it
    [hPane{1,1}, handles, force(1)] = BuildClassifierUIObject(handles, sprintf('txtClass%i', i), 'text', paneObj, sprintf('Descrip: %s', classifier.classes{i}), ...
        [], [], {'horizontalalignment', 'left', 'enable', 'on', 'visible', 'on'});
    
    % and the threshold
    [hPane{2,1}, handles, force(2)] = BuildClassifierUIObject(handles, sprintf('txtThresh%i', i), 'text', paneObj, 'Threshold :', ...
        [], [], {'horizontalalignment', 'left', 'enable', 'on', 'visible', 'on'});
    
    % and the modifiable threshold
    [threshEbObj, handles, force(3)] = BuildClassifierUIObject(handles, sprintf('ebThresh%i', i), 'text', paneObj, '', ...
        [], [], {'horizontalalignment', 'left', 'enable', 'on', 'visible', 'on'});
    Default_CreateFcn(threshEbObj);
    hPane{3,1} = threshEbObj;
    
    % and the units
    [hPane{3,2}, handles, force(4)] = BuildClassifierUIObject(handles, sprintf('txtUnits%i', i), 'text', paneObj,  classifier.thresh_units, ...
        [], [], {'horizontalalignment', 'left', 'enable', 'on', 'visible', 'on'});
    
    % set the edit boxes value
    if (i > 1)  % can't modify the "default" class
        cellIndex{1} = i-1;
        value = classifier.thresholds(sub2ind(size(classifier.thresholds), cellIndex{:}));
        set(threshEbObj, 'string', num2str(value));
        set(threshEbObj, 'userdata', value);
        set(threshEbObj, 'callback', @(hObject, event_data)(ThresholdChange(hObject, event_data, guidata(hObject))));
        handles.featSettings.classifier.thresh_select(1,i-1) = value;
    else
        set(threshEbObj, 'string', 'N/A', 'enable', 'off');
    end
    
    force_resize = force_resize || any(force);
    
    % Create spacing for this pane
    hGrid{i} = hPane;
        
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% disable unused panes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

count = numel(classifier.classes) + 1;
paneTag = sprintf('uiClass%i', count);
while (isfield(handles, paneTag))
    
    % make the pane invisible
    set(handles.(paneTag), 'visible', 'off', 'title', 'class: Unused');
        
    % and process
    count = count + 1;
    paneTag = sprintf('uiClass%i', count);
    
end

% force a resize due to reshaping the layout?
nRows = 3 + (numel(hGrid) > 6);
nCols = ceil([numel(hGrid), count-1] / nRows);
force_resize = force_resize || (nCols(1) ~= nCols(2));
nCols = nCols(1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Resize this pane?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (force_resize)
    
    % change the number of columns?
    paneSize = cell(numel(classifier.dims),1);
    
    % do each pane
    smallGap = DefaultPaneGaps();
    hGap = zeros(3, 0);
    vGap = repmat(smallGap, 2, 2);

    % resize the individual panes
    for i = 1:numel(hGrid)
        [hGrid{i}, paneSize{i}] = ResizePaneFromGrid(hGrid{i}, hGap, vGap, false);
    end
    
    % and adjust for the column layout
    if (nRows * nCols) > numel(hGrid)
        hGrid{nRows * nCols} = [];
        paneSize{nRows * nCols} = [];
    end
    hGrid = reshape(hGrid, nRows, nCols);
    paneSize = reshape(paneSize, nRows, nCols);
    
    % and resize it
    ResizePaneFromGrid(hGrid, [], [], paneSize);

    
end



function [dimIndex, classIndex] = GetChangeIndex(handles, threshObj)
% function [dimIndex, classIndex] = GetChangeIndex(threshObj, handles)
% find where we are in the threshold index

% which dims we're on
dimIndex = zeros(1, numel(handles.featSettings.classifier.dims));
for i = 1:numel(dimIndex)
    tag = sprintf('pmSettings%i', i);  % the tag of the relevant control
    dimIndex(i) = get(handles.(tag), 'value');
end

% which class we're in
if (nargin == 2)
    classIndex = str2double(regexp(get(threshObj, 'tag'), '\d+', 'match', 'once'));
end


function ThresholdChange(hObject, event_data, handles)
% function ThresholdChange(hObject, event_data, handles)
% function to change things as the threshold changes

% set it?
value = str2double(get(hObject, 'string'));
if ~isnan(value)

    % which index in the threshold matrix to modify?
    [dimIndex, classIndex] = GetChangeIndex(handles, hObject);
    cellIndex = [{classIndex-1}, num2cell(dimIndex)];
    index = sub2ind(size(handles.featSettings.classifier.thresholds), cellIndex{:});
    handles.featSettings.classifier.thresholds(index) = value;
    handles.featSettings.classifier.thresh_select(classIndex-1) = value;
    set(hObject, 'userdata', value);
    
    % remove form the block list
    handles.block_list = handles.block_list(handles.block_list ~= hObject);
    
elseif ~any(handles.block_list == hObject)
    handles.block_list(end+1) = hObject;
end

% set gui output availability
EnableDisableOutput(handles);

% and assign
guidata(hObject, handles);


function FeatChange(hObject, event_data, handles)
% function ThresholdChange(hObject, event_data, handles)
% function to change things as the threshold changes

% set it?
dim_index = get(hObject, 'value');
dim_names = get(hObject, 'string');

% which feature input?
input = str2double(regexp(get(hObject, 'tag'), '\d+', 'match', 'once'));

% update the structure
handles.featSettings.classifier.inputs{input} = dim_names{dim_index};  % not a time
if (dim_index <= numel(handles.data_set.dim_names))
    handles.featSettings.classifier.input_cols(input) = dim_index;
else
    handles.featSettings.classifier.input_cols(input) = -1;
end
    


% and store
guidata(hObject, handles);





function SettingsChange(hObject, event_data, handles)
% function SettingsChange(hObject, event_data, handles)
% function to change things as the threshold changes

% which one is this?
settingIndex = str2double(regexp(get(hObject, 'tag'), '\d+', 'match', 'once'));
list = get(hObject, 'string');
handles.featSettings.classifier.dim_selections{settingIndex} = list{get(hObject, 'value')};

% the settings we are already on
dimIndex = GetChangeIndex(handles);
cellIndex(2:numel(dimIndex)+1) = num2cell(dimIndex);

for i = 2:numel(handles.featSettings.classifier.classes)  % first one isn't modifiable
    
    % update all edit boxes
    threshEbTag = sprintf('ebThresh%i', i);
    threshEbObj = handles.(threshEbTag);
    
    % update value
    cellIndex{1} = i-1;
    value = handles.featSettings.classifier.thresholds(sub2ind(size(handles.featSettings.classifier.thresholds), cellIndex{:}));
    set(threshEbObj, 'string', num2str(value));
    set(threshEbObj, 'userdata', value);
    handles.featSettings.classifier.thresh_select(i-1) = value;
    
    % remove form the block list
    handles.block_list = handles.block_list(handles.block_list ~= threshEbObj);
    
end

% set gui output availability
EnableDisableOutput(handles);

% and assign
guidata(hObject, handles);
 
 


function handles = CREClassifierGUI_ResizeFcn(hObject, force, handles)
% function ClassifierGUI_ResizeFcn(hObject, force, handles)
% function to make the gui look pretty

% resize it for change of screen?
resize = RunResizeFcn(hObject, handles);
if (resize || force)

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);

	% run the layout function on the export pane
	[exportGrid,  hGap, vGap, exportSizes] = DefaultExportPaneLayout(handles);

	% and resize it
	ResizePaneFromGrid(exportGrid, hGap, vGap, exportSizes);

	% now layout the whole thing
	hGrid = {handles.uiSettings, handles.uiFeatMatch, handles.uiClasses; ...
        handles.uiExport,    'l',                 'l'; ...
        handles.pbCancel, [], handles.pbOK};

	% and resize    
	ResizeFigFromPanes(hGrid, [], [], true);

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% save the resized figure if applicable
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (resize)
        handles = SaveResizedCREFigure(hObject, [], handles);
    end

end

% --------------------------------------------------------------------
function mlFile_Callback(hObject, eventdata, handles)
% hObject    handle to mlFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function miSave_Callback(hObject, eventdata, handles)
% hObject    handle to miSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_save;

if numel(last_save)
	last_save = DataSaveDir();
end

% where to save it
[file_name, path] = uiputfile('*.mat', 'Save classifier settings to:', last_save);
if numel(file_name) && ischar(file_name)
    classOpts = handles.featSettings;  % called featSettings for compatibility with the export pane
    last_save = fullfile(path, file_name);
    save(last_save, 'classOpts', '-mat');
    msgbox(sprintf('Classifier settings saved to: %s', last_save), 'Classifier Saved');
	
end


% --------------------------------------------------------------------
function miLoad_Callback(hObject, eventdata, handles)
% hObject    handle to miLoad (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


persistent last_load

if (numel(last_load) == 0)
    last_load = DataLoadDir();
end

[file_name, path] = uigetfile('*.mat', 'Load classifier settings from:', last_load);
if numel(file_name) && ischar(file_name)
    
    % load the first var in the file
    load_file = fullfile(path, file_name);
    try
        tmp = load(load_file, '-mat');
        fnames = fieldnames(tmp);
        classOpts = tmp.(fnames{1});
    catch ME
        errordlg(sprintf('Could not load %s\nIs it a valid "mat" file?', load_file));
    end
    
    % expected fields of the classifier structure
    expected_fields = fieldnames(InitClassifier());    
    
    % check it has the right fields
    if isfield(classOpts, 'classifier') && isfield(classOpts, 'exportInfo') && all(ismember(expected_fields, fieldnames(classOpts.classifier)))
        
        % we names this feat settings for compatibility
        handles.featSettings = classOpts;
        
        % set the gui for the new state
        InitialiseGUI(handles.CREClassifierGUI, eventdata, handles);
		
		% record the location
		last_load = load_file;
        
    else
        errordlg(sprintf('File: %s does not contain valid classifier data', load_file));
    end
end
