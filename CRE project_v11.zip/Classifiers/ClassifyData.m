function  [class_set, data_set] = ClassifyData(data_set, classSettings, opts, status_func)
% function [class_set, data_set] = ClassifyData(data_set, classSettings)
% function [class_set, data_set] = ClassifyData(data_set, classSettings, opts)
% function to down sample a data set.  
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set       - the data set structure to retrieve tha values from
%                  (see ImportCSV.m)
%
% classSettings  - a structure containing the classification and export information,
%                  (see CREClassifierGUI)
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% class_set    - the classified data set
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set default inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (nargin < 4) 
    status_func = [];
end

if (nargin < 3) || (numel(opts) == 0)

    opts.max_lookup       = 1e3;  % the lookup table has this many entries at most
    opts.max_load_els     = 1e7;  % load the data in full if it has less than this many elements

end

opts.max_load_els = 1e4;  % for testing

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up output feature set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[class_set, runToEnd] = InitExportSet(data_set, classSettings);

% add classifier info to the export set
class_set = AddClassifierToDataSet(class_set, classSettings.classifier);
n_classifiers = numel(classSettings.classifier);

% the names of the output dimensions
n_primary = numel(data_set.dim_names);
col_names = [data_set.dim_names(:); ClassifierColumnName(class_set.class_info(:,1))];
col_names = reshape(col_names, 1, numel(col_names));

% add column names to the export set
[class_set, write_format] = AddExportColumnInfo(class_set, col_names);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now create the output file if needed
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (numel(classSettings.exportInfo.file_name) == 0)
    [path, fname, ext] = fileparts(data_set.file_name);
    classSettings.exportInfo.file_name = sprintf('%s_classified%s', fullfile(path, fname), ext);  % add aud for augmented
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add the lookup table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% design the lookup table based on this
class_set.lookgap = max(ceil(class_set.num_points / (opts.max_lookup - 1)), 100);
class_set.lookup = zeros(1 + floor(class_set.num_points / class_set.lookgap), 1);

% retain all the data?
retain_all = (class_set.num_points * class_set.dims) <= opts.max_load_els;
if (retain_all)
    class_set.data = zeros(class_set.num_points, class_set.dims);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create information to break data into blocks
% (for downsampling)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% process this over how many blocks
block_points = ceil(opts.max_load_els / class_set.dims);
n_blocks = ceil(class_set.num_points / block_points);

% get indexs ranges for the blocks
block_indexs = zeros(n_blocks, 2);
for i = 1:n_blocks
    block_indexs(i, :) = [(i-1) * block_points + 1, i*block_points];
end
if (~runToEnd)
    block_indexs(end, 2) = class_set.num_points;  % dont go over
end

% check we're not doing any crazy overwrites
CheckFileOverwrite(data_set, class_set, n_blocks);


% time offset between the recording start and midnight
% (in case time is a required input to the classifier)
day_start = data_set.tstamp;
day_start(4:end) = 0;
tOffset = etime(data_set.tstamp, day_start);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Begin exporting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% begin try loop in case of unexpected error
try
    
    % open the pointer to the data sets file here so we don't do it over and
    % over again
    ds_open = data_set.file_ptr > 0;
    if (~ds_open)
        data_set.file_ptr = fopen(data_set.file_name, 'r');
        if (data_set.file_ptr <= 0)
            error('Could not read %s\nIs the file in use?', data_set.file_name);
        end
    end

    % write the header before this starts
    class_set = ExportHeader(class_set, classSettings.exportInfo, true);
    
    % now process
    class_set.lookup(1) = class_set.hbytes;
    lookup_ind = 1;                               % the last filled lookup table entry
    next_lookup = class_set.lookgap;             % the next point that should have a lookup entry
    
    % a metric for progress updates
    prog_update = round((numel(class_set.lookup) - 1) / 20);  % update every 5%
    
    % keep track of the number of points
    n_points = 0;
    eof = false;
    
    i = 0;
    while (i < class_set.num_points) || (runToEnd)
        
        i = i + 1;  % move along
        
        % check we have't run out of block indices
        if (i > size(block_indexs, 1))
            block_indexs(i, :) = [(i-1) * block_points + 1, i*block_points];
        end
       
        % grab the original data (primary dimension only)
        [X, data_set] = GetData(data_set, block_indexs(i,:), false);
        
        % check for end of file
        dSamps = block_points - size(X,1);
        
        % check for end of file
        if (dSamps ~= 0)
            eof = true;  % end of file
            block_indexs(i,2) = block_indexs(i,2) - dSamps;
        end
        
        % allocate space for classification results
        X(end, class_set.dims) = X(end, end);  % use this to allocate
        
        % and run each classifier
        for j = 1:n_classifiers
            
            % get the ordered data
            isTime = (classSettings.classifier(j).input_cols < 1);
            if ~any(isTime)
                tmpX = X(:, classSettings.classifier(j).input_cols);
            else
                % Put times in
                tmpX = zeros(size(X,1), numel(classSettings.classifier(j).input_cols));  % pre allocate
                time = (block_indexs(i,1)-1:block_indexs(i,2)-1) / data_set.fs;
                time = time(:);
                tmpX(:, ~isTime) = X(:, classSettings.classifier(j).input_cols(~isTime));
                for k = find(isTime)
                    if numel(regexpi(classSettings.classifier(j).inputs{k}, 'midnight', 'match', 'once'))
                        time_midnight = time + tOffset;
                        time_midnight = rem(time_midnight, 24*60*60);  % in case it goes for more than 1 day
                        tmpX(:, k) = time_midnight;
                    else
                        tmpX(:, k) = time;
                    end
                end
            end
            
            % and feed it to the classifier
            X(:, n_primary+j) = feval(classSettings.classifier(j).evalfcn, tmpX, classSettings.classifier(j).thresh_select, classSettings.classifier(j).extra_args{:});
            
        end
        
        % store this in X if desired
        if (retain_all)
            if all(block_indexs(i,:) == [1, class_set.num_points])
                class_set.data = X;
            else
                class_set.data(block_indexs(i,1):block_indexs(i,2), :) = X;
            end
        end
        
        % and write the results
        if (~classSettings.exportInfo.time_col)
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % fast way - print the "lookup block" in one hit
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
            X = X.';                         % need each dimension to be a row for fprintf
            cp = 0;                          % the number of points in this block already written
            lp = n_points + size(X, 2);      % the "final" point in this block (relative to the whole file)
            while (cp + n_points < lp)
                
                ep = min(lp, next_lookup);  % the final point to write in this "chunk"
                fprintf(class_set.file_ptr, write_format, X(:, cp+1:ep-n_points));  % write it
                
                % update the last written point (relative to the block)
                cp = ep - n_points;
                
                % and update the lookup if needed
                if (ep == next_lookup)
                    
                    % record the lookup table entry
                    lookup_ind = lookup_ind + 1;
                    class_set.lookup(lookup_ind) = ftell(class_set.file_ptr);
                    next_lookup = next_lookup + class_set.lookgap;             % the next point that should have a lookup entry
                    
                    % update progress - its too slow to do here with large files
                    if (numel(status_func)) && (rem(lookup_ind, prog_update) == 0)
                        feval(status_func, lookup_ind-1, numel(class_set.lookup)-1);
                        drawnow();
                    end
                end
            end
            
            % update where to start the next point from
            n_points = n_points + size(X,2);  % dim 2 because it was transcribed
            
        else
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % slow method - add a time column
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % write the down sampled data to file
            for j = 1:size(X,1)
                
                % write the time
                ct_str = ConvertTime((n_points + j - 1) / class_set.fs, class_set.tstamp, 2, true);
                fprintf(class_set.file_ptr, '%s, ',  ct_str);
                
                % and the values
                fprintf(class_set.file_ptr, write_format, X(j, :));  % write it
                
                % and update the lookup if needed
                if (n_points + j == next_lookup)
                    
                    % record the lookup table entry
                    lookup_ind = lookup_ind + 1;
                    class_set.lookup(lookup_ind) = ftell(class_set.file_ptr);
                    next_lookup = next_lookup + class_set.lookgap;             % the next point that should have a lookup entry
                    
                    % update progress - its too slow to do here with large files
                    if (numel(status_func)) && (rem(lookup_ind, prog_update) == 0)
                        feval(status_func, lookup_ind-1, numel(class_set.lookup)-1);
                        drawnow();
                    end
                end
            end
            
            % update where to start the next point from
            n_points = n_points + size(X,1);
        end
        
        % update progress
        if (numel(status_func)) && (numel(class_set.lookup) >= 200)
            feval(status_func, i, n_blocks);
            drawnow();
        end
        
        % break if we ran out of file
        if (eof)
            break;
        end
    end
    
    
    
    % sanity check
    if (n_points ~= class_set.num_points) || (lookup_ind ~= numel(class_set.lookup))
        class_set.lookup = class_set.lookup(1:lookup_ind);
        class_set.num_points = i;
    end
    
    if (classSettings.exportInfo.header > 0)
        UpdateDSHeader(class_set);  % always call this in case we output the lookup table
    end
    
    % and close the file if it was open
    open = class_set.file_ptr > 0;
    if (open)
        fclose(class_set.file_ptr);
        class_set.file_ptr = -1;
    end
    if (~ds_open)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    
catch ME
    
    % catch error
    if (class_set.file_ptr > 0)
        fclose(class_set.file_ptr);
    end
    if (~ds_open)
        fclose(data_set.file_ptr);
        data_set.file_ptr = -1;
    end
    error('An unexpected error occurred during classification of file %s\n%s', data_set.file_name, ME.message);
    
    
    
end









