function classifier = CreateENMOClassifier()
% function classifier = CreateENMOClassifier()
% build a thresholds strcuture for the classifier

% Initialise the default classifier structure
classifier = InitClassifier();
                                
% output classes                
classifier.name       = 'ENMO';
classifier.classes    = {'sedentary', 'moderate', 'vigourous'};                
classifier.class_enum = [0; 1; 2];
classifier.def_inputs = {'enmo'};  % find an enmo feature

% fill these when we know what we're using
classifier.inputs = cell(size(classifier.def_inputs));
classifier.input_cols = zeros(size(classifier.def_inputs));

% titles for dimensions
classifier.dim_titles = {'Device', 'Location', 'Age'};

% get dimensions names for the tresholds
classifier.dims = cell(1, 3);
classifier.dims{1} = {'ActiGraph'; 'Geneactive'};
classifier.dims{2} = {'Hip';   'Wrist'};
classifier.dims{3} = {'Adult'; 'Child'};

% table for the adult data (cols are AG / GA, rows are class)
adult_thresh = [69.1,  68.7;  ... % hip
                258.7, 266.8; ... % hip
                100.6, 428.8; ... % wrist
                93.2,  418.3];    % wrist
adult_thresh = reshape(adult_thresh, [2,2,2]);            


% table for the child data (cols are AG / GA, rows are class)
child_thresh = [142.6, 152.8; ... % hip
                464.6, 514.3; ... % hip
                201.4, 191.6; ... % wrist
                707.0, 695.8];    % wrist
child_thresh = reshape(child_thresh, [2,2,2]);

classifier.thresh_units = 'mg''s';

% assemble adult and child
classifier.thresholds = cat(4, adult_thresh, child_thresh);

% and supply the evaluation function
classifier.evalfcn = @EvalENMO;


function Y = EvalENMO(X, thresholds, varargin)
% function Y = EvalENMO(X, thresholds, varargin)
% function to apply ENMO classification

% simple classifier
Y =  sum(bsxfun(@gt, X, thresholds * 1e-3),2);  % convert from milli'gs to g's 




