function [X, data_set] = GetRawData(data_set, indexs, is_time)
% function [X, data_set] = GetRawData(data_set, indexs, false)
% function [X, data_set] = GetRawData(data_set, times, true)
% this function retrieves a block of data from the data set
% this function differs from GetData as this function returns the "raw"
% values as strings
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set - the data set structure to retrieve tha values from
%            (see ImportCSV.m)
%
% indexs   - a two element vector specifying the first and last data point
%            to grab (1 based indexing).  Defaults to all data
%
% times    - a two element vector specifying the times of the first and last 
%            data point to grab in seconds.  Time 0 is the first data point.
%            Times are rounded to the nearest index
%
% is_time  - if false, interpret the second input as indexes (default)
%          - if true,  interpret the second input as time stamps
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% X        - an n x dims cell array where n is the number of data points and d
%            is the dimensionality of the data
%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!

% supply defaults
if (nargin < 3) || (numel(is_time) == 0)
    is_time = false;
end

if (nargin < 2) || (numel(indexs) == 0)
    is_time = false;
    indexs = [1, data_set.num_points];
end

% convert times to indexs if desired
if (is_time)
    indexs = round(data_set.fs * indexs) + 1;
end

% sanity check
if any(indexs ~= round(indexs))
    error('GetData:: Non integer index supplied');
elseif any((indexs < 1) | (indexs > data_set.num_points))
    error('GetData:: indexs / times requested are beyond the range of the data set');
end

% in case a scalar is requested
if (numel(indexs) == 1)
    indexs = repmat(indexs, 1, 2);
end

if (indexs(2) < indexs(1))

    % grabbing no data?
    X = cell(0, data_set.dims);

elseif (numel(data_set.data))         % if the data is preloaded
    
    % check its actually there
    valid = CheckDataSetStore(data_set, indexs);
    
    % now grab it
    if all(valid)
        if (indexs(1) == 1) && (indexs(2) == data_set.num_points) && isequal(dims(:), (1:data_set.dims).')
            X = data_set.data;  % saves a full copy
        else
            X = data_set.data(indexs(1):indexs(2), dims);
        end
    
    else
        % make sure this section has been "discovered"
        [data_set, X] = DiscoverBlock(data_set, indexs);
    end
    
    % turn them into raw values
    X = num2cell(X);
    X = cellfun(@num2str, X, 'UniformOutput', false);
    
elseif ~strcmpi(data_set.type, 'ASCII')
    
    error('Reading Binary files has not been implemented yet');
    
else % use the lookup table to read ASCII files
    
    % if the file pointer isnt open open it
    f_open = (data_set.file_ptr > 0);
    if (~f_open)
        data_set.file_ptr = fopen(data_set.file_name, 'r');
        if (data_set.file_ptr < 0)
            error('GetData:: Could not open %s', data_set.file_name);
        end
    end
    
    try 
        
        % the start block to use
        start_block = ((indexs(1) - 1) / data_set.lookgap) + 1;
        end_block = ceil(((indexs(2) - 1) / data_set.lookgap)) + 1;
        
        % make sure this section has been "discovered"
        if (data_set.view_type == 1) && isnan(data_set.lookup(end_block))
            [data_set, X] = DiscoverBlock(data_set, indexs);
            
            % turn them into raw values
            X = num2cell(X);
            X = cellfun(@num2str, X, 'UniformOutput', false);
            return;
        end
        
        % preallocate X
        X = cell(indexs(2) - indexs(1) + 1, data_set.dims + data_set.time_col);
        cr = 0;  % the last row of X assigned
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % if we start in the middle of a block skip the 
        % first points
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        if ((start_block) ~= round(start_block))
            
            % get the start of the block
            start_block = floor(start_block);
            
            % and the number of lines to ignore
            ignore_points = indexs(1) - ((start_block - 1) * data_set.lookgap + 1);
            
            % now start grabbing
            fseek(data_set.file_ptr, data_set.lookup(start_block), 'bof');
            
            % ignore points
            for i = 1:ignore_points
                line = fgetl(data_set.file_ptr); 
            end
            
        else
            fseek(data_set.file_ptr, data_set.lookup(start_block), 'bof');
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % now grab the rest
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        for cp = indexs(1): indexs(2)
            
            % grab the line
            line = fgetl(data_set.file_ptr);  % grab the line
            
            % process it
            [tokens, other] = regexp(line, data_set.delim, 'split', 'match');
            
            cr = cr + 1;
            X(cr, 1:numel(tokens)) = tokens;
            
        end
        
        % remove time stamps if they were included
        if (data_set.time_col)
            X = X(:, 2:end);
        end
        
        % return the file pointer to its original status
        if (~f_open)
            fclose(data_set.file_ptr);
            data_set.file_ptr = -1;
        end
        
    catch ME
        
        fclose(data_set.file_ptr);
        error('An error occurred reading %s indexes %i : %i-> %s', file_name, indexs(1), indexs(2), ME.message);
        data_set.file_ptr = -1;
        
    end
    
end

    










