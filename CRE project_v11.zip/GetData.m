function [X, data_set] = GetData(data_set, indexs, is_time, dims)
% function [X, data_set] = GetData(data_set, indexs, false, dims)
% function [X, data_set] = GetData(data_set, times, true, dims)
% this function retrieves a block of data from the data set
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set - the data set structure to retrieve tha values from
%            (see ImportCSV.m)
%
% indexs   - a two element vector specifying the first and last data point
%            to grab (1 based indexing).  Defaults to all data
%
% times    - a two element vector specifying the times of the first and last 
%            data point to grab in seconds.  Time 0 is the first data point.
%            Times are rounded to the nearest index
%
% is_time  - if false, interpret the second input as indexes (default)
%          - if true,  interpret the second input as time stamps
%
% dims     - a vector of the dimensions to grab
%          - Defaults to all: dims = 1:data_set.dims
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% X        - an n x dims matrix where n is the number of data points and d
%            is the requested number of dimensions
%
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!


% keep track of where we are in a given file
persistent read_state

% initialise the persistent structure
if (numel(read_state) == 0)
    read_state = struct('file_name', '', ...
                        'index',     -1, ...  % where we are in samples
                        'fpos',      -1);     % where we are in in terms of characters through the file
    
end

% supply defaults
if (nargin < 4) || (numel(dims) == 0)
    dims = 1:data_set.dims;
elseif any((dims ~= round(dims)) | (dims < 1) | (dims > data_set.dims))
    error('GetData:: Invalid dimensions requested');
end

if (nargin < 3) || (numel(is_time) == 0)
    is_time = false;
end

if (nargin < 2) || (numel(indexs) == 0)
    is_time = false;
    indexs = [1, data_set.num_points];
end

% convert times to indexs if desired
if (is_time)
    indexs = round(data_set.fs * indexs) + 1;
end

% sanity check
if any(indexs ~= round(indexs))
    error('GetData:: Non integer index supplied');
elseif any((indexs < 1) | (any(indexs > data_set.num_points) && (data_set.view_type == 2)))  % only enforce max points if the size is known
    error('GetData:: indexs / times requested are beyond the range of the data set');
end

% update the read string to match the requested dims
[ASCII_read, used_dims, dim_map] = UpdateReadStr(data_set.ASCII_read, dims);

% in case a scalar is requested
if (numel(indexs) == 1)
    indexs = repmat(indexs, 1, 2);
end

if (indexs(2) < indexs(1))

    % grabbing no data?
    X = zeros(0, numel(dims));

elseif (numel(data_set.data))         % if the data is preloaded
    
    % check its actually there
    valid = CheckDataSetStore(data_set, indexs);
    
    % now grab it
    if all(valid)
        if (indexs(1) == 1) && (indexs(2) == data_set.num_points) && isequal(dims(:), (1:data_set.dims).')
            X = data_set.data;  % saves a full copy
        else
            X = data_set.data(indexs(1):indexs(2), dims);
        end
    
    else
        % make sure this section has been "discovered"
        [data_set, X] = DiscoverBlock(data_set, indexs);
        if ~isequal(dims(:), (1:data_set.dims).')
            X = X(:, dims);
        else
            X = data_set.data(indexs(1):indexs(2), dims);
        end
    end
    
    % reorder / replicate dimensions as desired
    if numel(dim_map)
        X = X(:, dim_map);
    end
    
elseif ~strcmpi(data_set.type, 'ASCII')
    
    error('Reading Binary files has not been implemented yet');
    
else % use the lookup table to read ASCII files
    
    % if the file pointer isn't open open it
    f_open = (data_set.file_ptr > 0);
    if (~f_open)
        data_set.file_ptr = fopen(data_set.file_name, 'r');
        if (data_set.file_ptr < 0)
            error('GetData:: Could not open %s', data_set.file_name);
        end
        
        % move to the data start
        fseek(data_set.file_ptr, data_set.lookup(1), 'bof');
        
        % update the read state
        read_state.file_name = data_set.file_name;
        read_state.index = 1;
        read_state.fpos = ftell(data_set.file_ptr);

    end
    
    try 
        
        % the start block to use
        start_block = ((indexs(1) - 1) / data_set.lookgap) + 1;
        end_block = floor((indexs(2) - 1) / data_set.lookgap) + 1;
        
        % make sure this section has been "discovered"
        if (isnan(data_set.lookup(end_block)))
            [data_set, X] = DiscoverBlock(data_set, indexs);
            if ~isequal(dims(:), (1:data_set.dims).')
                X = X(:, dims);
            end
        else
        
            % how many points to grab
            n_points = indexs(2) - indexs(1) + 1;
            
            % preallocate X
            X = zeros(n_points, numel(unique(dims)));
            cr = 0;  % the last row of X assigned
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % if we start in the middle of a block skip the
            % first points
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if ((start_block) ~= round(start_block))
                
                % get the start of the block
                start_block = floor(start_block);
                
                % what index is the start of this block?
                block_index = ((start_block - 1) * data_set.lookgap + 1);
                
                
                % are we already at the correct location in the file?
                if strcmp(read_state.file_name, data_set.file_name) && (read_state.index >= block_index) && (read_state.index <= indexs(1)) && (ftell(data_set.file_ptr) == read_state.fpos)
                    
                    % how many points to skip?
                    jump_points = indexs(1) - read_state.index; % how many lines to jump in the file relative to the current file pointer location
                    
                else
                    
                    % and the number of lines to ignore
                    jump_points = indexs(1) - block_index;      % how many lines to jump in the file relative to the start of the block
                    
                    % got to the start of the block
                    fseek(data_set.file_ptr, data_set.lookup(start_block), 'bof');
                    
                end
                
                % the number of points at the start of this block that we don't want
                offset_points = indexs(1) - block_index;
                
                % are there any to skip over?
                if numel(jump_points)
                    
                    % no need to interpret the first ignore_points points, so skip this many lines
                    textscan(data_set.file_ptr, '%s', jump_points, 'delimiter', sprintf('\n'), 'MultipleDelimsAsOne', true);
                    
                end
                
                % now grab the data
                grab_size = [used_dims, min(data_set.lookgap - offset_points, n_points)];
                values = fscanf(data_set.file_ptr, ASCII_read, grab_size);  % min in case n_points < data_set.lookgap
                
                if ~all(size(values) == grab_size)
                    error('Unexpected error reading lines %i -> %i of %s', data_set.hlines + indexs(1) + [0, grab_size(2)], data_set.file_name);
                end
                
                % validate it
                %             if any(~isfinite(values(:)))
                %                 [r,c] = find(~isfinite(values(:)), 1, 'first');
                %                 error('Unable to process and / or interpret data as numeric at data point %i', (start_block - 1) * data_set.lookgap + c);
                %             end
                
                % and assign
                cr =  size(values,2);
                X(1:cr,:) = values.';
                
                % how many points left?
                n_points = n_points - cr;
                
                % Note -> the previous call to fscanf ends once it finds the
                % desired number of values.  The lookup table was created
                % grabbing each line as a string so its value is past the new
                % line / carriage returns.  So to perform a sanity check, grab
                % the characters in between ftell(data_set.file_ptr) and
                % data_set.lookup(start_block+1) and check they're all white
                % space / formatting.  In future versions when the sanity check
                % is no longer used, set fseek(data_set.file_ptr, data_set.lookup(start_block), 'bof');
                % to skip past formatting / spaces
                if (n_points > 0)  % N.B. if the remaining points is zero, we probably didnt read until the end of the block.  Also they'll be data if there are unretrieved dimensions at the end
                    fpos = ftell(data_set.file_ptr);
                    if (fpos < data_set.lookup(start_block+1))
                        gap_chars = fread(data_set.file_ptr, data_set.lookup(start_block+1) - fpos, 'uchar');
                        if (max(dims) == data_set.dims) && ~all(isstrprop(gap_chars, 'wspace'))
                            error('The lookup table appears incorrectly aligned');
                        end
                    elseif (fpos > data_set.lookup(start_block+1))
                        error('The lookup table appears incorrectly aligned');
                    end
                elseif (dims(end) ~= data_set.dims)
                    
                    % always read past the un-returned dimensions so that the file
                    % pointer is at the start of the next time point
                    textscan(data_set.file_ptr, '%s', 1, 'delimiter', {'\n','\r'}, 'MultipleDelimsAsOne', true);
                    
                end
            else
                fseek(data_set.file_ptr, data_set.lookup(start_block), 'bof');
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % now grab the rest
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if (n_points > 0)
                
                values = fscanf(data_set.file_ptr, ASCII_read, [used_dims, n_points]);
                
                if ~all(size(values) == [used_dims, n_points])
                    error('Unexpected error reading lines %i -> %i of %s', data_set.hlines + indexs, data_set.file_name);
                end
                
                % validate it
                %             if any(~isfinite(values(:)))
                %                 [r,c] = find(~isfinite(values(:)), 1, 'first');
                %                 error('Unable to process and / or interpret data as numeric at data point %i', (start_block - 1) * data_set.lookgap + c);
                %             end
                
                % and assign
                X(cr+1:end, :) = values.';
                
                % always read past the un-returned dimensions so that the file
                % pointer is at the start of the next time point
                if (dims(end) ~= data_set.dims)
                    textscan(data_set.file_ptr, '%s', 1, 'delimiter', {'\n','\r'}, 'MultipleDelimsAsOne', true);
                end
            end
        end
        
        % update the read state
        read_state.file_name = data_set.file_name;
        read_state.index = indexs(2)+1;  % its ready for the next one
        read_state.fpos = ftell(data_set.file_ptr);
        
        % return the file pointer to its original status
        if (~f_open)
            fclose(data_set.file_ptr);
            data_set.file_ptr = -1;
            read_state.file_name = '';
            read_state.index = -1;
            read_state.fpos = -1;
        end
        
        % reorder / replicate dimensions as desired
        if numel(dim_map)
            X = X(:, dim_map);
        end
        
    catch ME
        
        if (~f_open)
            fclose(data_set.file_ptr);
        end
        read_state.index = -1;
        read_state.fpos = -1;
        if (isdeployed)
            error('An error occurred reading %s indexes %i : %i-> %s', data_set.file_name, indexs(1), indexs(2), ME.message);
        else
            rethrow(ME);
        end
        data_set.file_ptr = -1;
        
    end
    
end

    

function [ASCII_read, used_dims, dim_map] = UpdateReadStr(ASCII_read, dims)
% function [ASCII_read, used_dims, dim_map] = UpdateReadStr(ASCII_read, dims)
% this function updates the read string to ignore unwanted dimensions

% where is each dimension in the read string
dim_inds = strfind(ASCII_read, '%g');

% use a bool format now for simplisity (reorder / replicate with dim_map)
bool_dims = false(1, numel(dim_inds));
bool_dims(dims) = true;
ommit_dims = find(~bool_dims);
used_dims = sum(bool_dims);

% and adjust the string to reflect this
for i = numel(ommit_dims):-1:1
    ASCII_read = [ASCII_read(1:dim_inds(ommit_dims(i))-1), '%*g', ASCII_read(dim_inds(ommit_dims(i))+2:end)];
end

% build a dimension map if needed
dim_map = [];
s_dims = sort(unique(dims));
if (numel(dims) ~= numel(s_dims)) || any(s_dims ~= dims)
    
    % this map contains the correspond dimension in s_dims
    % (the data is retrieved as though s_dims was desired)
    dim_map = zeros(1, numel(dims));
    for i = 1:numel(dims)
        dim_map(i) = find(dims(i) == s_dims, 1, 'first');
    end
end









