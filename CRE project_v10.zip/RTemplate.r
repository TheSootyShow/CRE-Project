################################################################################
# 1) Declare the names of the features used by the classifier / predictor here #
# N.B. Do NOT change the variable name from "feature_names"                    #
################################################################################

# EDIT THE FOLLOWING:
# e.g feature_names = c("X_mean", "X_std")
feature_names = c()


################################
# 2) Declare required packages #
################################

rm(libs) # clear existing variable

# EDIT THE FOLLOWING:
# e.g libs = c("rpart")
libs = c()


#################################
# 3) Load the required packages #
# (No need to edit))            #
#################################

for (i in 1:length(libs))
{
	# Install the package if needed 
	if (!is.element(libs[i], .packages()))
	{	loaded = install.packages(libs[i])	};

	# Add the library 
	loaded = require(libs[i], character.only = TRUE);

	# Throw an error if it failed 
	# if (!loaded)
	# {
	#	errorMsg = paste("Could not load package: ", libs[i])
	#	stop(errorMsg)
	#};
}




######################################################
# 4) Load the classifier into variable "rClassifier" #
######################################################


# ADD CODE TO LOAD THE CLASSIFIER HERE:
# e.g rClassifier <- load("C:\\SVM_classifier.rdata")





######################
# 5) Import data set #
# Do NOT edit !!!    #
######################

# Start do not edit import (these commands aren't meant for R)

# Store the data set sampling frequency in fs
# putRdata(fs, DATASET->fs)

# End do not edit import - R should now have data set variables  and the sampling frequency fs defined now




####################################################
# 6) Insert your own code to generate predictions, #
# and ensure they're stored in variable "Y"        #
####################################################

# (At this point all variables in the list "feature_names"
# are available in the R workspace)

# ADD CODE TO ADD GENERATE CLASSIFIER PREDICTIONS HERE:
# e.g.
# X <- data.frame("X_mean", "X_std") # X_mean and X_std are the feature names from part 1
# Y <- predict(sed.decisiontree, X, type="class")




#########################
# 7) Export predictions #
# Do NOT edit!!!        #
#########################

# Start do not edit export (these commands aren't meant for R)

# DATASET->CLASSIFIED = getRdata('Y')

# End do not edit export 
