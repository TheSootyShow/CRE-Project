function varargout = CREgui(varargin)
% CREGUI MATLAB code for CREgui.fig
%      CREGUI, by itself, creates a new CREGUI or raises the existing
%      singleton*.
%
%      H = CREGUI returns the handle to a new CREGUI or the handle to
%      the existing singleton*.
%
%      CREGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CREGUI.M with the given input arguments.
%
%      CREGUI('Property','Value',...) creates a new CREGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CREgui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to CREgui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CREgui

% Last Modified by GUIDE v2.5 19-May-2015 18:10:55

% use this to try and load a version that's already been resized
layout_fcn = GuiLayoutFunction('CREgui');

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREgui_OpeningFcn, ...
                   'gui_OutputFcn',  @CREgui_OutputFcn, ...
                   'gui_LayoutFcn',  layout_fcn, ...
                   'gui_Callback',   []);

isCallback = false;
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
    isCallback = (nargin >= 4) && isstruct(varargin{4});
    isCallback = isCallback && numel(regexpi(varargin{1}, 'callback', 'match', 'once')) > 0;
    isCallback = isCallback && ~numel(regexpi(varargin{1}, 'null', 'match', 'once')) > 0;
    if (isCallback)
        EnableDisableFig(varargin{4}.CREgui, 'off');
    end
end

if (~IsDeveloper)
    try % AWBS - well this can't be a good idea....
        if nargout
            [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
        else
            gui_mainfcn(gui_State, varargin{:});
        end
    catch ME
        
        % deal with the error
        ProcessCREGuiError(ME);
    end
else
    % use actual errors in developer mode
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
end

if (isCallback)
    EnableDisableFig(varargin{4}.CREgui, 'on');
end

% End initialization code - DO NOT EDIT


% --- Executes just before CREgui is made visible.
function CREgui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CREgui (see VARARGIN)

% Ensure Java AWT is enabled
if (~isdeployed)
    error(javachk('awt'));
else
    ME = javachk('awt');
    if numel(ME) && numel(ME.message)
        errordlg(ME.message, 'Java AWT is not being used!', 'modal');
    end
end

% Choose default command line output for CREgui
handles.output = hObject;

% Ensure the Gui Functions are in the path
if ~isfield(handles, 'added_paths')
    handles.added_paths = {};
    if ~(isdeployed)
        handles.added_paths = AddCREDirs();
    end
end

% attach the data set to the handles
handles.data_set      = [];
handles.ds_index      = -1;                              % index of the current data set in handles.storedData
handles.storedData    = repmat(InitDataStruct, 0, 1);      % records all data sets used in this project
handles.featSettings  = {};

% Can we connect to R?
handles.rLinkOpen = IsRopen();                           

% Insert default maximum load sizes
handles.opts = InitOptions();

% turn off things that shouldn't be seen yet
set(handles.uiTable, 'visible', 'off');
set(handles.sldTable, 'visible', 'off');
set(handles.sldTable, 'enable', 'off');
SetAxisVisible(handles.axPlot, 'off');
set(handles.uiPlot, 'visible', 'on');
set(get(handles.uiProcessing, 'children'), 'enable', 'off');

% set defaults for viewing time
set(handles.miTimeHHMMSS, 'checked', 'on');
set(handles.miTimeSeconds, 'checked', 'off');
set(handles.miTimeRel, 'checked', 'off');
set(handles.miDayMatch, 'checked', 'on');

% set flags for these
handles.HHMMSS = double(strcmpi(get(handles.miTimeHHMMSS, 'checked'), 'on'));
handles.rel_time = strcmpi(get(handles.miTimeRel, 'checked'), 'on');
handles.day_match = strcmpi(get(handles.miDayMatch, 'checked'), 'on');
handles.opts.view_type = 1 + strcmpi(get(handles.miPreload, 'checked'), 'on');

% define routines to convert time from numeric to string
handles = UpdateTimeStrFcns(handles);

% clear old feature settings
pbFeatures_Callback();

% store defaults for ploting
handles.default_cols = 'bkmgcr';

% a handle for the status bar.  
handles.status_bar = [];

% set the list boxes empty
set(handles.lbFeats, 'string', {}, 'value', []);
set(handles.lbDims, 'string', {}, 'value', []);

% add a listner to the vertical slider so it updates when being dragged
h_prop = findprop(handle(handles.sldTable),'Value');  % a schema.prop object
h_listener = handle.listener(handles.sldTable, h_prop, 'PropertyPostSet',  @(null, eventdata)(sldTable_Callback(handles.sldTable, 'listener', guidata(handles.sldTable))));
setappdata(handles.sldTable,'sliderListener',h_listener);  
set(handles.sldTable, 'callback', []);  % this will double up with the listener

% make it modal?
handles.ismodal = false;  % never for now

% make sure its resized and resizeable
% if strcmpi(get(hObject, 'Resize'), 'off')
%     set(hObject, 'ResizeFcn', @(hObject, event_data)CREgui_ResizeFcn(hObject, eventdata, guidata(hObject)));
%     set(hObject, 'Resize', 'on');
% else
handles = CREgui_ResizeFcn(hObject, eventdata, handles);
%end

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CREgui wait for user response (see UIRESUME)
if (handles.ismodal)
    uiwait(handles.CREgui);  % make it modal in deployed versions
end

% --- Outputs from this function are returned to the command line.
function varargout = CREgui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

if 0 && (handles.ismodal)
    delete(hObject);
end


% --------------------------------------------------------------------
function miExit_Callback(hObject, eventdata, handles)
% hObject    handle to miExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call the close request function
hFig = ancestor(hObject,'figure');
CREgui_CloseRequestFcn(hFig, eventdata, handles);


% --- Executes when user attempts to close CREgui.
function CREgui_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CREgui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% remove added paths form the path
if ~(isdeployed) && isfield(handles, 'added_paths')
    for i = 1:numel(handles.added_paths)
        rmpath(handles.added_paths{i});
    end
end

% remove the listener we added (seems to cause problems with debugging)
if isappdata(handles.sldTable, 'sliderListener');
    rmappdata(handles.sldTable, 'sliderListener');
end

% close the R Link if its open
if (isdeployed) && IsRopen()
    closeR();
end

% deployed version is modal
if (handles.ismodal)
    uiresume(hObject);  
else
    % Hint: delete(hObject) closes the figure
    delete(hObject);
end



% --------------------------------------------------------------------
function null_Callback(hObject, eventdata, handles)
% hObject    handle to anything that doesn't need a callback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
% I use this instead of setting callbacks to NULL directly


% --------------------------------------------------------------------
function allLB_Callback(hObject, eventdata, handles)
% hObject    handle to anything that doesn't need a callback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
% This callback is used for listboxes to ensure everything is always
% selected no matter what the user does

strings = get(hObject, 'string');
if ~iscell(strings)
    strings = {strings};
end
set(hObject, 'value', 1:numel(strings));


% --- Executes during object creation, after setting all properties.
function default_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sldTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function handles = UpdateTimeStrFcns(handles)
% function handles = UpdateTimeStrFcns(handles)
% function to set up conversion from numeric to string times


% Define a function to convert times to strings
handles.TimeStrFcn = @(time, handles)ConvertTime(time, handles.data_set.tstamp, handles.HHMMSS, ~handles.rel_time);

% Define a function to convert strings to times
handles.TimeFcn = @(time_str, handles)ConvertTime(time, handles.data_set.tstamp, handles.HHMMSS, ~handles.rel_time);


% --------------------------------------------------------------------
function miLoadCSV_Callback(hObject, eventdata, handles)
% hObject    handle to miLoadCSV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

last_dir = DataLoadDir();

% user prompt
[file_name, dir_name] = uigetfile('*.csv', 'Select a CSV file to import', last_dir);


% successful
if ischar(file_name)
    
    % Disable the figure while processing takes place
    % EnableDisableFig(handles.CREgui, false); % now handled in the gui main function
    
	% record the directory
    DataLoadDir(dir_name);
	
	% file name
    file_name = fullfile(dir_name, file_name);

    % in case it hasn't been created
    if (numel(handles.status_bar) == 0)
        handles.status_bar = tooltipwaitbar(handles.txtStatus, 0, '', false);
    end
    
    % provide a handle to indicate progress
    file_data = dir(file_name);
    status_func =  @(idx, n)StatusUpdate(handles.txtStatus, handles.status_bar, sprintf('Loading %i data points (approx).  File size: %0.2f mb', n, file_data.bytes*1e-6), idx, n);
    
    % call the load data function
    data_set = ImportCSV(file_name, handles.opts, status_func);
    
    % and update the status
    StatusUpdate(handles.txtStatus, handles.status_bar, sprintf('Finished loading (%i data points)', data_set.num_points), 1, 1);
    
    % and make the status bar invisible (just delete it)
    delete(handles.status_bar);
    handles.status_bar = [];
    
    % add an options to switch to this data set
    handles = AddDataSetToDSMenu(data_set, handles, true);
    
    % Update handles structure now so callbacks can grab the data_set
    guidata(hObject, handles);
    
    
    set(handles.miSaveBatchSet, 'enable', 'off');
    
    % Re-enable the figure
    % EnableDisableFig(handles.CREgui, true);  % now handled in the gui main function
    
    
end

% --- Executes on button press in pbFeatures.
function pbFeatures_Callback(hObject, eventdata, handles)
% hObject    handle to pbFeatures (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_features

% just clear it?
if (nargin == 0)
    last_features = [];
    return;
end

% if numel(last_features)
%     last_features.timeRange.match_daytime = handles.day_match;  % update time matching criteria
% end

% call the feature extraction GUI
try 
    [resp, featSettings] = CREFeatureGui(handles.data_set, true, handles.HHMMSS, handles.rel_time, last_features);
catch ME
    errordlg(ME.message);
    resp = [];
end

% ensure focus is returned
figure(handles.CREgui);

if (numel(resp) && strcmpi(resp, 'OK'))

    % store the feastures the user requested
    handles.featSettings{handles.ds_index} = featSettings;
    
    % update the list box showing the used features
    disp_features = FeatureDisplayNames(featSettings);
    set(handles.lbFeats, 'string', sort(disp_features));
    set(handles.lbFeats, 'max', max(numel(disp_features), 2));
    set(handles.lbFeats, 'value', 1:numel(disp_features));
    
    
    % update the list box showing the used dimensions
    dimInfo = ParseDimInfo(featSettings.dimInfo, handles.data_set);  % easier to show this structure
    disp_dims = [dimInfo.primary_name(dimInfo.primary_disp), dimInfo.derived_name(dimInfo.derived_disp)];
    disp_dims = ApplyKnownDimAliases(disp_dims,featSettings.dimInfo.aliases);
    set(handles.lbDims, 'string', disp_dims);
    set(handles.lbDims, 'max', numel(disp_dims));
    set(handles.lbDims, 'value', 1:numel(disp_dims));
    
    % and show the bin duration
    if (featSettings.binInfo.use_bins)
        set(handles.txtBinDur, 'string', sprintf('Bin duration: %ss (%s)', FsString(featSettings.binInfo.bin_duration), featSettings.binInfo.time_align));
    else
        set(handles.txtBinDur, 'string', 'Bin duration: All');
    end
    
    % now enable the feature extraction - if we have features
    if numel(disp_features) && numel(disp_dims)
        set(handles.pbExtractFeatures, 'enable', 'on');  
        set(handles.miExtractFeatures, 'enable', 'on');
    else
        set(handles.pbExtractFeatures, 'enable', 'off');
        set(handles.miExtractFeatures, 'enable', 'off');
    end
    
    % record the last set of features
    last_features = featSettings;
    
    % store the new handles
    guidata(hObject, handles);

end

% --- Executes on button press in pbExtractFeatures.
function [feature_set, handles] = pbExtractFeatures_Callback(hObject, eventdata, handles)
% hObject    handle to pbExtractFeatures (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% shortcut
featSettings = handles.featSettings{handles.ds_index};

% Disable the figure while processing takes place
% EnableDisableFig(handles.CREgui, false); % now handled in the gui main function

% set up a status bar if it hasn't already been
if (numel(handles.status_bar) == 0)
    handles.status_bar = tooltipwaitbar(handles.txtStatus, 0, '', false);
end

% running this on a data set or a featuer set
if strcmpi(handles.data_set.set_type, 'batch')
    
    % batch set, invoke the batch running architecture
    [feature_set, handles] = BatchModeArch(@(handles)pbExtractFeatures_Callback(hObject, eventdata, handles), [], [], handles);
    
else
    
    % build a status update function
    status_func =  @(idx, n)StatusUpdate(handles.txtStatus, handles.status_bar, sprintf('Calculating Features'), idx, n);
    feval(status_func, 0, 1);
    drawnow();

    % and perform feature extraction!
    tic;
    [feature_set, handles.data_set] = ExtractFeatures(handles.data_set, featSettings, handles.opts, status_func);
    time = toc;
    
    message = sprintf('Features saved as %s.  Ellapse time: %i seconds', feature_set.file_name, round(time));
    StatusUpdate(handles.txtStatus, handles.status_bar, message, 1, 1);
    
end

% only execute the below if this was a 'top level' call to the function
% (i.e. not if its part of the batch mode architecture)
if (nargout == 0)

    % and make the status bar invisible (just delete it)
    delete(handles.status_bar);
    handles.status_bar = [];
    drawnow();
    
    % ask the user which data set to continue working with
    response = questdlg('Continue working with which data set?','Data set selection', 'Data set', 'Feature set', 'Data set');
    switch_ds = ischar(response) && strcmpi(response, 'Feature set');  % in this case switch to the resampled data
    
    % add an option to switch to this data set later
    handles = AddDataSetToDSMenu(feature_set, handles, switch_ds);
    
    % Update handles structure now so callbacks can grab the data_set
    guidata(hObject, handles);
    
    % save it if its a batch set
    if strcmpi(feature_set.set_type, 'batch')
        resp = questdlg('Save the newly created batch feature set?', 'Save batch set', 'Yes', 'No', 'No');
        if strcmpi(resp, 'Yes')
            SaveBatchSet(feature_set);
        end
    end

end





% --------------------------------------------------------------------
function [new_data_set, handles] = miExportDataSet_Callback(hObject, eventdata, handles)
% hObject    handle to miExportDataSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent export_opts

% prompt the user
if (nargout == 0)
    [response, exportSettings] = CREExportOptions(handles.data_set, true, handles.HHMMSS, handles.rel_time, export_opts);
else
    % being called as part of the batch mode architecture
    exportSettings = export_opts;
    response = 'OK';
end

% do it?
if (ischar(response) && strcmpi(response, 'OK'))
    
    export_opts = exportSettings;  % store it
    
    % set up a status bar if it hasn't already been
    if (numel(handles.status_bar) == 0)
        handles.status_bar = tooltipwaitbar(handles.txtStatus, 0, '', false);
    end
    
    % batch mode or normal?
    if ~strcmpi(handles.data_set.set_type, 'batch')
        
        %%%%%%%%%%%%%%%%%%%%%%
        % normal processing
        %%%%%%%%%%%%%%%%%%%%%%
    
        % turn the time to extract into indices
        if (exportSettings.timeRange.full)
            indexs = [1, handles.data_set.num_points];
        else
            [rel_time, indexs] = TimeRangeToRelative(handles.data_set, exportSettings.timeRange.tstamp);
        end
        export_points = diff(indexs) + 1;
        
        % are we down sampling?
        downsampled = (exportSettings.exportInfo.export_fs ~= handles.data_set.fs);
        
        % create the status function
        displayStrs = DisplayTimeRange(exportSettings.timeRange, handles.data_set.fs);
        msg = sprintf('Exporting %i points in the range: %s - %s', export_points, displayStrs{1}, displayStrs{2});
        if (downsampled)
            msg = sprintf('%s at %s Hz', msg, FsString(exportSettings.exportInfo.export_fs));
        end
        status_func =  @(idx, n)StatusUpdate(handles.txtStatus, handles.status_bar, msg, idx, n);
        feval(status_func, 0, export_points);
        drawnow();
        
        % and export
        [new_data_set, pret, handles.data_set] = ExportData(handles.data_set, exportSettings, [], handles.opts, status_func);
        
        % and update the status
        message = sprintf('Exported %i points in the range: %s - %s', export_points, displayStrs{1}, displayStrs{2});
        if (downsampled)
            message = sprintf('%s at %s Hz. Retained %0.2f%% of the signal power', message, FsString(new_data_set.fs), pret * 100);
        end
        StatusUpdate(handles.txtStatus, handles.status_bar, message, 1, 1);
        
    else
        
        % use the batch mode architecture
       [new_data_set, handles] = BatchModeArch(@(handles)miExportDataSet_Callback(hObject, eventdata, handles), [], [], handles);
        
    end
    
    if (nargout == 0)  % execute this block if its not part of the batch mode architecture
        
        % and make the status bar invisible (just delete it)
        delete(handles.status_bar);
        handles.status_bar = [];
        drawnow();
        
        % ask the user which data set to continue working with
        response = questdlg('Continue working with which data set?','Dataset selection', 'Original', 'New', 'Original');
        switch_ds = ischar(response) && strcmpi(response, 'New');  % in this case switch to the resampled data
        
        % add an option to switch to this data set later
        handles = AddDataSetToDSMenu(new_data_set, handles, switch_ds);
        
        % Update handles structure now so callbacks can grab the data_set
        guidata(hObject, handles);
        
        % save it if its a batch set
        if strcmpi(new_data_set.set_type, 'batch')
            resp = questdlg('Save the newly created batch set?', 'Save batch set', 'Yes', 'No', 'No');
            if strcmpi(resp, 'Yes')
                SaveBatchSet(new_data_set);
            end
        end

    end
    
end


function handles = UpdateGuiForDataSet(handles)
% function handles = UpdateGuiForDataSet(handles)
% this function update the guis whenever a new data set is loaded


% use default dimension names where we can
if (numel(handles.data_set.dim_names) == 0)
    handles.data_set = InsertDefaultDimNames(handles.data_set);
end

% set the gui name
if ~strcmpi(handles.data_set.set_type, 'batch')
    set(handles.CREgui, 'name', sprintf('CRE Project - %s', handles.data_set.name));
else
    set(handles.CREgui, 'name', sprintf('CRE Project - %s (Viewing: %s)', handles.data_set.name, handles.data_set.ds_headers(GetActiveSetIndex(handles.data_set)).name));
end

% now show information about the data set
ShowDataSetInfo(handles.uiDatasetFrame, handles.data_set, handles.HHMMSS);

% allow the batch set to be saved
if strcmpi(handles.data_set.set_type, 'batch')
    set(handles.miSaveBatchSet, 'enable', 'on');
else
    set(handles.miSaveBatchSet, 'enable', 'off');
end

% set up visualization options
set(get(handles.mlVisualize, 'children'), 'enable', 'on');    % allow the user to select them
set(get(handles.mlVisualize, 'children'), 'checked', 'off');  % turn them all off
SetAxisVisible(handles.axPlot, 'off');                        % make sure the graph isn't visible
set(handles.miExportDataSet, 'enable', 'on');                 % can export the data set
set(handles.miExportFigure, 'enable', 'off');                 % no current graph to export
set(handles.miRawView, 'checked', 'on');


% set up data set function options
set(get(handles.uiProcessing, 'children'), 'enable', 'on');
set(handles.miSelectFeatures, 'enable', 'on');
set(handles.pbExtractFeatures, 'enable', 'off');  % dont enable this yet
set(handles.miExtractFeatures, 'enable', 'off');  % dont enable this yet

% remove any currently displayed features
set(handles.lbFeats, 'string', '');
set(handles.lbDims, 'string', '');
set(handles.txtBinDur, 'string', 'Bin duration:');
  

% now display it
handles.data_set = DisplayData(handles.uiTable, handles.sldTable, 1, handles.data_set, handles.HHMMSS, handles.rel_time, true);

% and update the data displayed
set(handles.uiTable, 'visible', 'on');                         % make sure the graph isn't visible
set(handles.sldTable, 'visible', 'on');
set(handles.sldTable, 'enable', 'on');
set(handles.miExportDataSet, 'enable', 'on');

% enanble classification if its a feature set
if (1)  % allow it to run on any type of data
    set(handles.mlClassify, 'enable', 'on');
else
    set(handles.mlClassify, 'enable', 'off');
end

% Enable the R custom classifier
if (handles.rLinkOpen)
    set(handles.miRCustom, 'enable', 'on');
end

% update handles if desired
if (nargout < 1)
    guidata(handles.uiTable, handles);
end


% --------------------------------------------------------------------
function PlotData_Callback(hObject, eventdata, handles)
% hObject    handle to miFreqPlot / or miTimePlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent plot_opts

if (1) 
    
    % display the active set if this is batch mode
    is_batch = strcmpi(handles.data_set.set_type, 'batch');
    if (is_batch)
        
        % which one is active?
        idx = GetActiveSetIndex(batch_set);
        data_set = handles.data_set.ds_headers(idx);
    else
        data_set = handles.data_set;
    end

    
    % work out if this is a time or frequency plot
    type = regexpi(get(hObject, 'tag'), '(?<=mi).+(?=plot)', 'match', 'once');
    freq_plot = strcmpi(type, 'freq');
    
    % create the gui that prompts the user for plotting values
    [response, options] = CREPlotOptions(data_set, freq_plot, true, handles.HHMMSS, handles.rel_time, plot_opts);
    figure(handles.CREgui);  % return focus
    
    % if it worked
    if (ischar(response) && strcmpi(response, 'OK'))
        
        % make the axis invisible during processing
        SetAxisVisible(handles.axPlot, 'on');
    
        % uncheck all the others
        set(get(handles.mlVisualize, 'children'), 'checked', 'off');
        set(hObject, 'checked', 'on');
        
        % store the desired plotting values
        plot_opts = options;
        
        % clear what's currently on the axis
        ResetAxis(handles.axPlot);
        
        % set up a status bar if it hasn't been
        if (numel(handles.status_bar) == 0)
            handles.status_bar = tooltipwaitbar(handles.txtStatus, 0, '', false);
        end
        
        % turn the time to extract into indices
        [rel_time, indexs] = TimeRangeToRelative(data_set, options.timeRange.tstamp);
        
        % set a progress bar
        displayStrs = DisplayTimeRange(options.timeRange, data_set.fs);
        status_func =  @(idx, n)StatusUpdate(handles.txtStatus, handles.status_bar, sprintf('Loading %i data points in the range %s - %s', diff(indexs+1), displayStrs{1}, displayStrs{2}), idx, n);
        feval(status_func, 0, 1);
        drawnow();
        
        % call the plotting function
        if (freq_plot)
            type = 'frequencies';
            [line_h, pxx, data_set] = PlotDataSpectrum(data_set, options, handles.axPlot, handles.default_cols, handles.opts, status_func);
        else
            
            type = 'points';
            
            % call the plotting function
            [line_h, data_set] = PlotDataSet(data_set, options, handles.axPlot, handles.default_cols, handles.opts, status_func);
        
        end
        
        % turn the table invisible
        set(handles.uiTable, 'visible', 'off');
        set(handles.sldTable, 'visible', 'off');
        
        % and redraw
        CRERedrawAxis(handles.axPlot, handles.uiPlot);
        
        % mkae the axis visible
        SetAxisVisible(handles.axPlot, 'on');                        
        
        % and update the status
        StatusUpdate(handles.txtStatus, handles.status_bar, sprintf('Displaying %s from the time range: %s - %s', type, displayStrs{1}, displayStrs{2}), 1, 1);
        
        % and make the status bar invisible (just delete it)
        delete(handles.status_bar);
        handles.status_bar = [];
        drawnow();
        
        % enable the export of this figure
        set(handles.miExportFigure, 'enable', 'on');
        
        % now put the updated data set back in the handles
        if (is_batch)
            handles.data_set.ds_headers(idx) = data_set;
        else
            handles.data_set = data_set;
        end
        
        % Update handles structure now so the callbacks can grab the data_set
        guidata(hObject, handles);

    end
    
end



% --------------------------------------------------------------------
function miRawView_Callback(hObject, eventdata, handles)
% hObject    handle to miRawView (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if 1 || ~strcmpi(get(handles.miRawView, 'checked'), 'on');

    % uncheck all the others
    set(get(handles.mlVisualize, 'children'), 'checked', 'off');
    set(hObject, 'checked', 'on');
    
    % make sure the graph isn't visible
    SetAxisVisible(handles.axPlot, 'off');                        
    
    % turn the table visible
    set(handles.uiTable, 'visible', 'on');
    set(handles.sldTable, 'visible', 'on');
    
    % update the display
    user_data = get(handles.uiTable, 'userdata');
    DisplayData(handles.uiTable, handles.sldTable, user_data{2}, handles.data_set, handles.HHMMSS, handles.rel_time, true);
    
    % can't export the table...
    set(handles.miExportFigure, 'enable', 'off');
    
    % reset status
    set(handles.txtStatus, 'string', '');
    
end


% --------------------------------------------------------------------
function cmSeekIndex_Callback(hObject, eventdata, handles)
% hObject    handle to cmSeekIndex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% prompt the user
user_data = get(handles.uiTable, 'userdata');
c_row = user_data{2};
resp = inputdlg('Data point index:', 'Go to data point', 1, {num2str(c_row)});
if numel(resp)
    des_index = str2double(resp{1});
    if (isfinite(des_index))
        
        des_index = max(min(des_index, handles.data_set.num_points), 1);
        
        % update the slider position (it's max is at the top so reverse it)
        limits = [get(handles.sldTable, 'min'), get(handles.sldTable, 'max')];
        pos = limits(2) - des_index + 1;
        pos = min(max(pos, limits(1)), limits(2));
        
        % update
        set(handles.sldTable, 'value', pos); 
        
        
    end
end


% --------------------------------------------------------------------
function cmSeekTime_Callback(hObject, eventdata, handles)
% hObject    handle to cmSeekTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% prompt the user
user_data = get(handles.uiTable, 'userdata');
c_row = user_data{2}; 

% the time at the current row
curr_time = ((c_row - 1) / handles.data_set.fs);

% create the time string for where we are currently
[time_str, format] = feval(handles.TimeStrFcn, curr_time, handles);

% prompt the user
resp = inputdlg(sprintf('Time (%s):', format), 'Go to time', 1, {time_str});

if (numel(resp))

    % convert back to a time
    des_time = feval(handles.TimeFcn, resp{1}, handles);
    
    % if it valid?
    if (isfinite(des_time))
        
        des_index = 1 + round(des_time * handles.data_set.fs);
        des_index = max(min(des_index, handles.data_set.num_points), 1);
        
        % update the slider position (it max is at the top so reverse it)
        limits = [get(handles.sldTable, 'min'), get(handles.sldTable, 'max')];
        pos = min(max(limits(2) - (des_index - limits(1)), limits(1) + eps(limits(1))), limits(2) - eps(limits(2)));
        set(handles.sldTable, 'value', pos);  % this will trigger the sliders callback
        
    end
end


% --- Executes on slider movement.
function sldTable_Callback(hObject, eventdata, handles)
% hObject    handle to sldTable (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% if ischar(eventdata)
%     fprintf('%s\n', eventdata);
% else
%     fprintf('unknown\n');
% end

pos = get(hObject,'Value');

% pos has the maximum at the top of the slider, so reverse it
limits = [get(hObject, 'min'), get(hObject, 'max')];
disp_row = limits(2) - pos + 1;
disp_row = max(disp_row, 1);
disp_row = min(disp_row,  handles.data_set.num_points);

% now display it
n_points = handles.data_set.num_points;
handles.data_set = DisplayData(handles.uiTable, handles.sldTable, floor(disp_row), handles.data_set, handles.HHMMSS, handles.rel_time, false);

% in case the number of pointe is better defined now
if (n_points ~= handles.data_set.num_points)
    ShowDataSetInfo(handles.uiDatasetFrame, handles.data_set, handles.HHMMSS);  % re-render this
end
guidata(hObject, handles);


% --------------------------------------------------------------------
function miTimeHHMMSS_Callback(hObject, eventdata, handles)
% hObject    handle to miTimeHHMMSS (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.miTimeHHMMSS, 'checked', 'on');
set(handles.miTimeSeconds, 'checked', 'off');
set(handles.miTimeRel, 'enable', 'on');

% is it actually a change?
if (handles.HHMMSS == 0)
    
    % mark it
    handles.HHMMSS = 1;  
    
    % update time conversion functions
    handles = UpdateTimeStrFcns(handles);

    
    % always redraw the data set info
    ShowDataSetInfo(handles.uiDatasetFrame, handles.data_set, handles.HHMMSS);

    % if its currently visible
    if strcmpi(get(handles.uiTable, 'visible'), 'on')
        
        % get the current display row
        user_data = get(handles.uiTable, 'userdata');
        DisplayData(handles.uiTable, handles.sldTable, user_data{2}, handles.data_set, handles.HHMMSS, handles.rel_time, true);
        
    end
    
    % update the handles
    guidata(hObject, handles);
end


% --------------------------------------------------------------------
function miTimeSeconds_Callback(hObject, eventdata, handles)
% hObject    handle to miTimeSeconds (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


set(handles.miTimeHHMMSS, 'checked', 'off');
set(handles.miTimeSeconds, 'checked', 'on');
set(handles.miTimeRel, 'enable', 'off');
set(handles.miTimeRel, 'checked', 'on');
handles.rel_time = true;

% is it actually a change?
if (handles.HHMMSS > 0)
    
    handles.HHMMSS = 0;  % mark it as changed
    
    % update time conversion functions
    handles = UpdateTimeStrFcns(handles);
    
    % always redraw the data set info
    ShowDataSetInfo(handles.uiDatasetFrame, handles.data_set, handles.HHMMSS);

    % if its currently visible
    if strcmpi(get(handles.uiTable, 'visible'), 'on')
        
        % get the current display row
        user_data = get(handles.uiTable, 'userdata');
        DisplayData(handles.uiTable, handles.sldTable, user_data{2}, handles.data_set, handles.HHMMSS, handles.rel_time, true);
        
    end
    
    % update the handles
    guidata(hObject, handles);
end



% --------------------------------------------------------------------
function miMemoryOptions_Callback(hObject, eventdata, handles)
% hObject    handle to miMemoryOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% prompt the user
handles.opts = OptionsQuery(handles.opts);

% and store
guidata(hObject, handles);


% --- Executes when CREgui is resized.
function handles = CREgui_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to CREgui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% does the gui need a resize?
isSaved = (numel(modUserData(hObject, 'get', 'Size')) > 0);
if (~isSaved) || (RunResizeFcn(hObject, handles))

	% tell the gui we are resining to the current size
	CheckGuiSize(hObject);
    
	% run the resize function
    CREGuiLayout(hObject, eventdata, handles);
    
    % save it if its at the default size
    if (~isSaved) || (IsDeveloper())
        handles = SaveResizedCREFigure(hObject, [], handles);
    end
    
    if (nargout == 0)
        guidata(hObject, handles);
    end
    
end

% --------------------------------------------------------------------
function miTimeRel_Callback(hObject, eventdata, handles)
% hObject    handle to miTimeRel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% flip it
if strcmpi(get(hObject, 'checked'), 'on')
    handles.rel_time = false;
    set(hObject, 'checked', 'off')
else 
    handles.rel_time = true;
    set(hObject, 'checked', 'on')
end

% update time conversion functions
handles = UpdateTimeStrFcns(handles);

% update the display if needed
if strcmpi(get(handles.uiTable, 'visible'), 'on');
    user_data = get(handles.uiTable, 'userdata');
    c_row = user_data{2}; 
    DisplayData(handles.uiTable, handles.sldTable, c_row, handles.data_set, handles.HHMMSS, handles.rel_time, true);
end

% and update the gui
guidata(hObject, handles);

function handles = ChangeDataSet(hObject, event_data, handles)
% function handles = ChangeDataSet(hObject, event_data, handles)
% this function executes when the user changes the current data set

% which data set do we want to look at?
ds_index = get(hObject, 'UserData');

% if we're not looking at it already
if (handles.ds_index ~= ds_index)
    
    % get all the menu items
    allMenus = get(handles.miDataSet, 'children');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Shut and store the old data set
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    if isstruct(handles.data_set)
        
        % close open file pointers, and remove any stored data
        handles.data_set.data = [];
        is_prevBatch = strcmpi(handles.data_set.set_type, 'batch');
        if (~is_prevBatch)
            
            % normal data set version
            if (handles.data_set.file_ptr > 0)
                fclose(handles.data_set.file_ptr);
                handles.data_set.file_ptr = -1;
            end
        else
            % batch set version
            for i = 1:numel(handles.data_set.ds_headers)
                if (handles.data_set.ds_headers(i).file_ptr > 0)
                    fclose(handles.data_set.ds_headers(i).file_ptr);
                    handles.data_set.ds_headers(i).file_ptr = -1;
                end
                handles.data_set.ds_headers(i).data = [];
            end
            
            % find its menu item, and delete the children
            hasKids = cellfun(@(x)(numel(get(x, 'children')) > 0), num2cell(allMenus));
            prevMenuItem = allMenus(hasKids);
            delete(get(prevMenuItem, 'children'));
            set(prevMenuItem, 'Callback', @(hObject,eventdata)ChangeDataSet(hObject,eventdata, guidata(hObject)));  % and restore the callback
            
        end
        
        % update the storage in case the data set was updated
        handles.storedData(handles.ds_index) = handles.data_set;
        
    end

    
    % change which one is ticked
    set(allMenus(allMenus ~= hObject), 'Checked', 'off');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Switch to the new data set
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    set(hObject, 'Checked', 'on');
    
    % the data set to view
    handles.data_set = handles.storedData(ds_index);
    handles.ds_index = ds_index;
    
    % is this a batch mode set?
    is_batch = strcmpi(handles.data_set.set_type, 'batch');
    
    % if this is batch mode, add the ability to change which data set is being viewed
    if (is_batch)
        set(hObject, 'Callback', []);  % no callback for mouse over
        subMenuItems = zeros(1, numel(handles.data_set.ds_headers));
        for i = 1:numel(subMenuItems)
            subMenuItems(i) = uimenu(hObject, 'Label', handles.data_set.ds_headers(i).name, 'UserData', i);
        end
        set(subMenuItems, 'Callback', @(hObject,eventdata)ChangeActiveSet(hObject,eventdata, guidata(hObject)));
        set(subMenuItems(GetActiveSetIndex(handles.data_set)), 'checked', 'on');
    end
    
    % change what we're looking at
    handles = UpdateGuiForDataSet(handles);
   
    % store changes to the handles
    if (nargout == 0)
        guidata(hObject, handles);
    end
    
end

function ChangeActiveSet(hObject, event_data, handles)
% function ChangeActiveSet(hObject, event_data, handles)
% this function executes when the user changes the current data set within
% a batch set

% which data set do we want to look at?
dsmenu = get(hObject, 'parent');  % menu item to change to the parent batch set
ds_index = get(dsmenu, 'UserData');
set_index = get(hObject, 'UserData');

% update what's checked
subMenus = get(dsmenu, 'children');
set(subMenus(subMenus ~= hObject), 'checked', 'off');
set(hObject, 'checked', 'on');

% update which data set is listed as active
if (handles.ds_index ~= ds_index)

    handles.storedData(ds_index) = SetBatchActiveSet(handles.storedData(ds_index), set_index);
    
    % exectue the data set change
    ChangeDataSet(dsmenu, event_data, handles);
    
else
    
    % update in the current data set as well
    handles.data_set = SetBatchActiveSet(handles.data_set, set_index);
    
    % update the view
    handles = UpdateGuiForDataSet(handles);
    
    % store changes to the handles
    guidata(hObject, handles);
    
end
    





function handles = AddDataSetToDSMenu(data_set, handles, is_current)
% function handles = AddDataSetToDSMenu(data_set, handles, is_current)
% function to update the data set menu item to include the data set at
% index ds_index


% is the incoming one a batch set?
is_batch = strcmpi(data_set.set_type, 'batch');

% check if this data set uses the same file name as an existing once
addIndex = numel(handles.storedData) + 1;
replace = false;
if (addIndex > 1)
    
    % always maych based off of name
    match_name = data_set.name;
    existing_files = {handles.storedData(:).name};
    match = find(strcmpi(match_name, existing_files), 1, 'first');
    
    % found a match
    if numel(match)
        addIndex = match;
        replace =  true;
        repLabel = handles.storedData(addIndex).name;  % the menu item has this label
    end
end

% add the data set to the list of stored data sets
handles.storedData(addIndex) = data_set;    % records all data sets used in this project
handles.storedData(addIndex).data = [];        % dont store the data
handles.featSettings{addIndex} = [];           % room to store its feature options

% build the new menu item if needed
if (~replace)
    uiMenuItem = uimenu(handles.miDataSet, 'Label', data_set.name); 
    set(uiMenuItem, 'Callback', @(hObject,eventdata)ChangeDataSet(hObject,eventdata, guidata(hObject)));
    set(uiMenuItem, 'UserData', numel(handles.storedData));
else
    uiMenuItem = findobj(handles.miDataSet, 'Label', repLabel);
end

% now check on the ordering (batch sets (3) -> feature sets (2) -> data sets (1) is the order)
allItems = get(handles.miDataSet, 'children');
set_type = zeros(1 , numel(allItems));
for i = 1:numel(allItems)
    type_name = handles.storedData(get(allItems(i), 'userdata')).set_type;
    set_type(i) = 1 + 2*strcmpi(type_name, 'batch') + strcmpi(type_name, 'features');
end

% reorder them?
order = [find(set_type == 3), find(set_type == 2), find(set_type == 1)];
allItems = allItems(order);
set_type = set_type(order);
set(handles.miDataSet, 'children', allItems);
set(allItems, 'Separator', 'off');
dtype = find(diff(set_type) ~= 0);
set(allItems(dtype), 'Separator', 'on'); %#ok<FNDSB>

% it has children so enable it now
if ~strcmpi(get(handles.miDataSet, 'enable'), 'on');
    set(handles.miDataSet, 'enable', 'on');
end

% assign the data set
if (is_current)
    
    % and change to the newly created menu item
    handles = ChangeDataSet(uiMenuItem, [], handles);
    
end

% update the gui handles if we aren't returning them
if (nargout == 0)
    guidata(handles.CREgui, handles);
end

% --------------------------------------------------------------------
function miExportFigure_Callback(hObject, eventdata, handles)
% hObject    handle to miExportFigure (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% function to export a plot from the gui

% create an figure as an export target
hFig = figure();
set(hFig, 'units', 'pixels', 'numbertitle', 'off', 'name', handles.data_set.name);
fig_pos = get(handles.uiPlot, 'position');
gui_pos = get(handles.CREgui, 'position');
fig_pos(1:2) = fig_pos(1:2) + gui_pos(1:2);
set(hFig, 'position', fig_pos);

% copy the axis to the figure
hAxis = copyobj(handles.axPlot, hFig);

% also copy the legend if it exists
hLegend = findobj(handles.uiPlot, 'tag', 'legend');
if numel(hLegend)
    nLegend = copyobj(hLegend, hFig);
    set(nLegend, 'position', get(hLegend, 'position'));  % no idea why this doesnt copy
end

% create a name for it
file_name = handles.data_set.name;
path_name = fileparts(handles.data_set.file_name);

% for debugging
file_name = sprintf('%s_%s', handles.data_set.device_type, file_name);

% put it togther
file_name = fullfile(path_name, file_name);

% set the figure name
set(hFig, 'filename', file_name);


% --------------------------------------------------------------------
function miFeatHelp_Callback(hObject, eventdata, handles)
% hObject    handle to miFeatHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

FeatureGuiAbout();


% --------------------------------------------------------------------
function miDayMatch_Callback(hObject, eventdata, handles)
% hObject    handle to miDayMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% flip it
if strcmpi(get(hObject, 'checked'), 'on')
    set(hObject, 'checked', 'off')
else
    set(hObject, 'checked', 'on')
end
    

handles.day_match = strcmpi(get(hObject, 'checked'), 'on');
guidata(hObject, handles);


% --------------------------------------------------------------------
function mlClassify_Callback(hObject, eventdata, handles)
% hObject    handle to mlClassify (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function [new_data_set, handles] = RunClassifier(hObject, eventdata, handles)
% function RunClassifier(hObject, eventdata, handles)
% function to perform classification

% first work out what classifier if desired
tag = get(hObject, 'tag');
type = regexp(tag, '(?<=uiClass).+', 'match', 'once');

% Initiate the user selection
if (numel(eventdata) == 0)
    [response, classSettings] = CREClassifierGUI(handles.data_set, type);
else
    % recursive call
    response = 'OK';
    classSettings = eventdata;
end

% do it?
if (ischar(response) && strcmpi(response, 'OK'))
        
   
    % set up a status bar if it hasn't already been
    if (numel(handles.status_bar) == 0)
        handles.status_bar = tooltipwaitbar(handles.txtStatus, 0, '', false);
    end
    
    % normal data set or a batch set?
    if ~strcmpi(handles.data_set.set_type, 'batch')
    
        % create the status function
        status_str =  sprintf('Classifying %i data points', handles.data_set.num_points);
        status_func =  @(idx, n)StatusUpdate(handles.txtStatus, handles.status_bar, status_str, idx, n);
        feval(status_func, 0, handles.data_set.num_points);
        drawnow();
        
        % and classify
        [new_data_set, handles.data_set] = ClassifyData(handles.data_set, classSettings, handles.opts, status_func);
        
        % and update the status
        message = sprintf('Classified %i data points', new_data_set.num_points);
        StatusUpdate(handles.txtStatus, handles.status_bar, message, 1, 1);
    
    else
    
        % use the batch mode architecture
        [new_data_set, handles] = BatchModeArch(@(handles)RunClassifier(hObject, classSettings, handles), [], [], handles);
    
    end
    
    % if this is the "top level" call
    if (nargout == 0)
    
        % and make the status bar invisible (just delete it)
        delete(handles.status_bar);
        handles.status_bar = [];
        drawnow();
        
        % ask the user which data set to continue working with
        response = questdlg('Continue working with which data set?','Dataset selection', 'Original', 'Classified', 'Classified');
        switch_ds = ischar(response) && strcmpi(response, 'Classified');  % in this case switch to the resampled data
        
        % add an option to switch to this data set later
        handles = AddDataSetToDSMenu(new_data_set, handles, switch_ds);
        
        % save it if its a batch set
        if strcmpi(new_data_set.set_type, 'batch')
            resp = questdlg('Save the newly created batch feature set?', 'Save batch set', 'Yes', 'No', 'No');
            if strcmpi(resp, 'Yes')
                SaveBatchSet(new_data_set);
            end
        end
        
        % Update handles structure now so callbacks can grab the data_set
        guidata(hObject, handles);
        
    end
    
end


% --------------------------------------------------------------------
function miInitRLink_Callback(hObject, eventdata, handles)
% hObject    handle to miInitRLink (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if (~ispc)
    msgbox('Connecting to R is only available on PC''s');
else
    % Test the link
    valid = TestRLink();
    
    % Eanble the use of custom classifiers
    if (valid)
        handles.rLinkOpen = true;
        if numel(handles.data_set)
            set(handles.miRCustom, 'enable', 'on');
        end
        msgbox('The connection to R has been established', 'Connected to R');
    end
end


% --------------------------------------------------------------------
function [new_data_set, handles] = miRCustom_Callback(hObject, eventdata, handles)
% hObject    handle to miRCustom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent rClassifierPersist


% Initiate the user selection
if (numel(eventdata) == 0)
    
    % Launch the custom classifier
    [resp, rClassifier, exportInfo, handles.data_set] = CustomRGui(handles.data_set, rClassifierPersist);

else
    % recursive call
    resp = 'OK';
    rClassifier = eventdata{1};
    exportInfo = eventdata{2};
end


% did the user say to proceed?
if ischar(resp) && any(strcmpi(resp, {'OK', 'Classify'}))

    % Store this
    rClassifierPersist = rClassifier;
    
    % Disable the figure while processing takes place
    % EnableDisableFig(handles.CREgui, false); % now handled in the gui main function
    
    % set up a status bar if it hasn't already been
    if (numel(handles.status_bar) == 0)
        handles.status_bar = tooltipwaitbar(handles.txtStatus, 0, '', false);
    end
    
    % normal data set or a batch set?
    if ~strcmpi(handles.data_set.set_type, 'batch')
    
        % create the status function
        status_str =  sprintf('Classifying %i data points', handles.data_set.num_points);
        status_func =  @(idx, n)StatusUpdate(handles.txtStatus, handles.status_bar, status_str, idx, n);
        feval(status_func, 0, handles.data_set.num_points);
        drawnow();
        
        % and classify
        [new_data_set, handles.data_set] = RunRClassifier(handles.data_set, rClassifier, exportInfo, handles.opts, status_func);
                
        % and update the status
        message = sprintf('Classified %i data points', new_data_set.num_points);
        StatusUpdate(handles.txtStatus, handles.status_bar, message, 1, 1);
        
    else
        
        % use the batch mode architecture
        [new_data_set, handles] = BatchModeArch(@(handles)miRCustom_Callback(hObject, {rClassifier, exportInfo}, handles), [], [], handles);
        
    end
    
    % if this is the "top level" call
    if (nargout == 0)
    
        % and make the status bar invisible (just delete it)
        delete(handles.status_bar);
        handles.status_bar = [];
        drawnow();
        
        % ask the user which data set to continue working with
        response = questdlg('Continue working with which data set?','Dataset selection', 'Original', 'Classified', 'Classified');
        switch_ds = ischar(response) && strcmpi(response, 'Classified');  % in this case switch to the resampled data
        
        % add an option to switch to this data set later
        handles = AddDataSetToDSMenu(new_data_set, handles, switch_ds);
        
        % save it if its a batch set
        if strcmpi(new_data_set.set_type, 'batch')
            resp = questdlg('Save the newly created batch feature set?', 'Save batch set', 'Yes', 'No', 'No');
            if strcmpi(resp, 'Yes')
                SaveBatchSet(new_data_set);
            end
        end
    end
end

% Update handles structure now so callbacks can grab the data_set
if (nargout == 0)
    guidata(hObject, handles);
end



% --- Executes during object creation, after setting all properties.
function CREgui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CREgui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% use the java properties to set a callback for when this figure gains focus

% N.B.  The below code is commented out because CREgui does not gain focus
% as expected when a called modal dialog exits

% Get the underlying Java reference
% warning('off', 'MATLAB:HandleGraphics:ObsoletedProperty:JavaFrame');
% jFig = get(hObject, 'JavaFrame');
% jAxis = jFig.getAxisComponent;
%  
% % Set the focus event callback
% warning('off', 'MATLAB:hg:PossibleDeprecatedJavaSetHGProperty');
% set(jAxis, 'FocusGainedCallback', {@CREguiFocusGained, hObject});
% warning('on', 'MATLAB:hg:PossibleDeprecatedJavaSetHGProperty');
% 
% 
% 
% function CREguiFocusGained(jAxis, jEventData, hFig)
% % function CREguiFocusGained(hFig)
% % this function ensures that any error dialogs get focused before CREgui
% 
% hErrDlgs = findobj('type', 'figure', 'tag', 'Msgbox_Error Dialog');
% if numel(hErrDlgs)
%     figure(hErrDlgs(1));
% end
% 


% --------------------------------------------------------------------
function miVersion_Callback(hObject, eventdata, handles)
% hObject    handle to miVersion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

version_str = strrep(CRE_version(), '_', '.');
msgbox(sprintf('Version: %s', version_str), 'CRE version', 'modal');


% --------------------------------------------------------------------
function miCreateBatchSet_Callback(hObject, eventdata, handles)
% hObject    handle to miCreateBatchSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[resp, batch_set] =  CREBatchSet();
if strcmpi(resp, 'OK') && numel(batch_set)
    miLoadBatchset_Callback(hObject, batch_set, handles);
end


% --------------------------------------------------------------------
function miLoadBatchset_Callback(hObject, eventdata, handles)
% hObject    handle to miLoadBatchset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call save routine
if (numel(eventdata) == 0)
    batch_set = LoadBatchSet();
    figure(handles.CREgui);  % restore focus
else
    batch_set = eventdata;  % passed through by miCreateBatchSet_Callback
end
if numel(batch_set)
    
    % ask the user which data set to continue working with
    if 0 && (numel(handles.data_set) > 0)
        response = questdlg('Continue working with which data set?','Data set selection', 'Batch set', 'Data set', 'Batch set');
        switch_ds = ischar(response) && strcmpi(response, 'Batch set');  % in this case switch to the resampled data
    else
        switch_ds = true;
    end

    % add an option to switch to this data set later
    handles = AddDataSetToDSMenu(batch_set, handles, switch_ds);

    % and update teh handles
    guidata(hObject, handles);
end


% --------------------------------------------------------------------
function miSaveBatchSet_Callback(hObject, eventdata, handles)
% hObject    handle to miSaveBatchSet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% call save routine
SaveBatchSet(handles.data_set);
figure(handles.CREgui);  % restore focus


% --------------------------------------------------------------------
function miPreload_Callback(hObject, eventdata, handles)
% hObject    handle to miPreload (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if strcmpi(get(hObject, 'checked'), 'on')
    set(hObject, 'checked', 'off')
else 
    set(hObject, 'checked', 'on')
end
handles.opts.view_type = 1 + strcmpi(get(hObject, 'checked'), 'on');
guidata(hObject, handles);
