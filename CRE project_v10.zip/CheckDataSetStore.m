function [valid, blockPoints] = CheckDataSetStore(data_set, indexs)
% function [valid, blockPoints] = CheckDataSetStore(data_set, indexs)
% this checks for nans in data_set.data in the specified index ranges
% not data_set.data should always be loaded in full blocks

empty = (numel(data_set.data) == 0);
if (empty)
    data_set.data = NaN(data_set.num_points, data_set.dims);  % allocate
end

% the block the first index starts in
indexStartBlock = floor((indexs(1)-1) / data_set.lookgap) + 1;
indexEndBlock = floor((indexs(2)-1) / data_set.lookgap) + 1;

% corresponding points
indexStartBlockPoint = (indexStartBlock-1) * data_set.lookgap + 1;
indexEndBlockPoint = indexEndBlock * data_set.lookgap;

% grab first an last point from each block
blockPoints = indexStartBlockPoint:data_set.lookgap:indexEndBlockPoint;
blockPointsEnd = blockPoints+data_set.lookgap-1;
blockPointsEnd(end) = min(blockPointsEnd(end), data_set.num_points);

% check the first and last point in the block aren't all NaNs
valid = ~all(isnan(data_set.data(blockPoints, :)),2) & ~all(isnan(data_set.data(blockPointsEnd, :)),2);