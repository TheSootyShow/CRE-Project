function dir = GetSettingsDir()
% function dir = GetSettingsDir()
% function to get the resource directory location
% returns empty if it can't be used

persistent settings_dir;

% first time we are using it
if (numel(settings_dir) == 0)
    
    if ~(isdeployed)
        settings_dir = fullfile(fileparts(mfilename('fullpath')), 'Settings');
    else
        % have a look where the executable is (might save some figs)
        [status, exec_dir] = system('path');
        if status == 0
            exec_dir = char(regexpi(exec_dir, 'Path=(.*?);', 'tokens', 'once'));
        end
        settings_dir = fullfile(exec_dir, 'Settings');
    end

    % if the resource directory doesn't exist, create it
    if ~exist(settings_dir, 'dir')
        try
            mkdir(settings_dir);  % may not be able to make it without admin privileges
        catch
            settings_dir = -1;  % indicates we can't use it
        end
    end
    
    % check we have write permission
    if ischar(settings_dir)
        % atrribs = fileattrib(settings_dir);  % not on this version
        test_file = fullfile(settings_dir, 'tmp_creproject.txt');
        fid = fopen(test_file, 'w');
        if (fid > 0)
            fclose(fid);
            delete(test_file);
        else
            settings_dir = -1;  % indicates we can't use it
        end
    end
end

if ischar(settings_dir) && exist(settings_dir, 'dir')
    dir = settings_dir;
else
    dir = [];
end


