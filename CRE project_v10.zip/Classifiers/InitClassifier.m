function classifier = InitClassifier(type)
% function classifier = InitClassifier()
% function classifier = InitClassifier(type)
% function to initlaise the classifier structure

% create it
if (nargin == 0)
    
classifier = struct('name',           '',   ...  % the name of the classifier
                    'thresholds',     [],   ...  % storage for different threshold values for the different dims settings
                                            ...  % rows are the class (num classes - 1 thesholds), the rest of the 
                                            ...  % dimensions match classifier.dims
                    'thresh_units',   '',   ...  % the units of threshold
                    'dim_titles',     {{}}, ...  % titles for each dimensions of thresholds (sex / age / device / etc)
                    'dims',           {{}}, ...  % a cell array of options for each dimension (male / female, 'ActiGraph' / 'Geneactive' etc)
                    'dim_selections', {{}}, ...  % selected dimensions
                    'thresh_select',  [],   ...  % selected thresholds
                    'classes',        {{}}, ...  % output classes
                    'class_enum',     [],   ...  % numeric code for each output class
                    'def_inputs',     {{}}, ...  % default input feature names the classifier uses
                    'inputs',         {{}}, ...  % selected feature input names used by the data set
                    'input_cols',     [],   ...  % which columns the inputs are in the data set
                    'extra_args',     {{}}, ...  % extra inputs to evalfcn
                    'prepfcn',        [],   ...  % extra function for preproccessing.  gets call as feval(prepfcn, X(:,classifier.input_cols))
                    'evalfcn',        []);       % evaluate the data (function should output a single column).  If prepfcn is empty, 
                                                 % its called as feval(evalfcn, Xin, classifier.thresh_select, classifier.extra_args{:})
                                                 % where Xin is X(:,classifier.input_cols) if prepfcn empty, 
                                                 % or the output of prepfcn
% create a default version if desired                                                 
else
    if strcmpi(type, 'enmo')
        classifier = CreateENMOClassifier();
    else
        error('Error: unknown classifier: %s', type);
    end
end