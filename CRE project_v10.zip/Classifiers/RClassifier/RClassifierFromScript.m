function [rClassifier, parsed, msg] = RClassifierFromScript(file_name)
% function [rClassifier, parsed, msg] = RClassifierFromScript(file_name)
% function to initialise an R Classifier based on a custom script
% the custom script must have the same basic function as 

% Initialise the classifier structure
rClassifier = InitRClassStruct();
rClassifier.rscript_file = file_name;
    
% check it can parsed
[sections, msg] = DecomposeCustomRScript(rClassifier.rscript_file);

% successfully parsed?
parsed = (numel(sections) == 2);
    
if (parsed)
    
    % add this
    rClassifier.rscript = sections;
    
    % scan the sections for inputs and libraries and the classifier name
    for i = 1:numel(sections{1})

        % is this the inputs line?
        if (numel(regexp(sections{1}{i}, '^\s*feature_names\s*(=|<-)', 'match', 'once')) > 0)
            
            rClassifier.feat_names = ParseRConcat(sections{1}{i});
        
        % is this the libraries line?    
        elseif (numel(regexp(sections{1}{i}, '^\s*libs\s*(=|<-)', 'match', 'once')) > 0)
            
            rClassifier.packages = ParseRConcat(sections{1}{i});
            rClassifier.packages = rClassifier.packages(:);
        
        % is this the classifier loading line?        
        elseif (numel(regexp(sections{1}{i}, '^\s*rClassifier\s*(=|<-)', 'match', 'once')) > 0)
            
            % assume the file name will be in ""s
            rClassifier.file_name = regexp(sections{1}{i}, '(?<=").+(?=")', 'match', 'once');
            
            % success?
            if (numel(rClassifier.file_name) > 0)
            
                % replace occurances of double file seperators
                fs = filesep();
                if (fs == '\')
                    fs = repmat(fs, 1, 2);  % a literal for the regexp expression below
                end
                rClassifier.file_name = regexprep(rClassifier.file_name, repmat(fs, 1, 2), fs);
            
                % does it exist as a file?
                if exist(rClassifier.file_name, 'file')
                    
                    rClassifierLoaded = LoadRClassifier(rClassifier.file_name);
                    
                    % fill all fields that are currently blank
                    fnames = fieldnames(rClassifierLoaded);
                    for j = 1:numel(fnames)
                        if (numel(rClassifier.(fnames{j})) == 0)
                            rClassifier.(fnames{j}) = rClassifierLoaded.(fnames{j});
                        end
                    end
                else
                    hWarn = warndlg(sprintf('The classifier file:\n    %s\ncould not be located.\n\nThe script may need to be updated.', rClassifier.file_name), 'Classifier file', 'modal');
                end
            end
        end
    end
    
    % try to fill in the data amalgamation and prediction methods
    rClassifier.data_storage = 'Unknown';
    rClassifier.predict_func = 'Unknown';
    for i = 1:numel(sections{2})
        
        % is this where the features are merged into a single object?
        Xstr = regexp(sections{2}{i}, '(?<=^\s*X\s*(=|<-)).+', 'match', 'once');
        if (numel(Xstr) > 0) && (numel(rClassifier.feat_names) > 0)
           
            % build the comma seperated feature list (sanitizing for regexp)
            featList = sprintf('%s', LiteralRegExp(rClassifier.feat_names{1}));
            for j = 2:numel(rClassifier.feat_names)
                featList = sprintf('%s%s%s', featList, '\s*,\s*', LiteralRegExp(rClassifier.feat_names{j}));
            end
            
            % is it in there?
            if (numel(regexp(Xstr, featList)) > 0)
                rClassifier.data_storage = strtrim(regexprep(Xstr, featList, '%feat_names%'));
            end
            
        end
        
        % is this where the predictions are made
        Ystr = regexp(sections{2}{i}, '(?<=^\s*Y\s*(=|<-)).+', 'match', 'once');
        if ((numel(Ystr) > 0) && numel(rClassifier.var_name > 0))
        
            % look for the classifier name and X in there
            varNameSan = LiteralRegExp(rClassifier.var_name);
            if (numel(regexp(Ystr, varNameSan)) > 0) && (numel(regexp(Ystr, '\<X\>')) == 1)
                Ystr = regexprep(Ystr, varNameSan, '%classifier_var%');
                rClassifier.predict_func = strtrim(regexprep(Ystr, '\<X\>', '%data%'));
            end
        end
    end
end







function tokens = ParseRConcat(line)
% function array = ParseRConcat(line)
% function to tokenize the r conactinate array

% get the middle of the concatinate
text = regexp(line, '(?<=c\().+(?=\))', 'match', 'once');

if numel(text)
    
    % tokenize it
    tokens = regexp(text, ',', 'split');
    
    % strip any quotes from the tokens
    for i = 1:numel(tokens)
        tmp = regexp(tokens{i}, '(?<=^\s*").+(?="\s*$)', 'match', 'once');
        if numel(tmp)
            tokens{i} = tmp;
        end
        
        % and deblank
        tokens{i} = tokens{i}(~isstrprop(tokens{i}, 'wspace'));
    end
else
    tokens = {};
end
    