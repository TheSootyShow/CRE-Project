function [class_set, data_set] = RunRClassifier(data_set, rClassifier, exportInfo, opts, status_func)
% function [class_set, data_set] = RunRClassifier(data_set, rClassifier, exportInfo, opts, status_func)
% function to run a custom R classifier over the data in data set 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set       - the data set structure to retrieve tha values from
%                  (see ImportCSV.m)
%
% rClassifier    - structure with the R classifier file details
%                  (See CustomRGui.m)
%
% exportInfo     - contains the export settings (e.g. file name etc)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% class_set     - the classified data set
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Notes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set may be modified if its in partial view mode (data_set.view_type = 1)
% so always return it!


% supply defaults
if (nargin < 5) 
    status_func = [];
end

if (nargin < 4) || (numel(opts) == 0)

    opts.max_lookup       = 1e3;  % the lookup table has this many entries at most
    opts.max_load_els     = 1e7;  % load the data in full if it has less than this many elements

end

% create an animate gif while we load the data (since we dont know how long
% it will wait)
tic;
hSpinner = MCRSpinner('Loading data');
drawnow();

% export the entire time range
indexs = [1, data_set.num_points];
    
% Now load all of the data
[X, data_set] = GetData(data_set, indexs, false);
while (indexs(2) < data_set.num_points)  % in case the total point are unknown
    indexs = [indexs(2)+1, data_set.num_points];
    [Xl, data_set] = GetData(data_set, indexs, false);
    X = [X; Xl];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set up output feature set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[class_set, runToEnd] = InitExportSet(data_set, struct('rClassifier', rClassifier, 'exportInfo', exportInfo));

% keep the current dimension names and add a classification column
ouput_cols = [data_set.dim_names, 'Class'];

% add it to the feature set structure
[class_set, write_format] = AddExportColumnInfo(class_set, ouput_cols);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Work out which columns to load
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[exists, col_index] = ismember(rClassifier.feats_mapped, data_set.dim_names);
exists = exists | strncmpi(rClassifier.feats_mapped, 'Time', 4);  % time wont get counted in the above
if ~all(exists)
    
    % time entires will sho up as missing, so remove them and deal with
    % them later
    missing_list = rClassifier.feat_names(~exists);
    if numel(missing_list)
        missing_str = missing_list{1};
        for i = 2:numel(missing_list)
            missing_str = sprintf('%s, %s', missing_str, missing_list{i});
        end
        error('Could not find the source locations for feature(s): %s', missing_str);
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add the lookup table to the output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% design the lookup table based on this
class_set.lookgap = max(ceil(class_set.num_points / (opts.max_lookup - 1)), 100);
class_set.lookup = zeros(1 + floor(class_set.num_points / class_set.lookgap), 1);

% always retain all of the data (need to send it to R)?
class_set.data = zeros(class_set.num_points, class_set.dims);

    
% and call on the classifier
set(hSpinner, 'name', 'Issuing R commands');
drawnow();


% use auto functions or a custom script?
rHistory = '';
if numel(rClassifier.rscript_file)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Custom script approach
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % try to reload it
    try 
        if exist(rClassifier.rscript_file, 'file')
            
            [tmpClass, parsed] = RClassifierFromScript(rClassifier.rscript_file);
            if (~parsed)
                error('Could not parse the script in file: %s\nIs it a valid classification script? (its recommended to edit an auto-generated script)', rClassifier.rscript_file);
            else
                rSections = tmpClass.rscript;
            end
        elseif (numel(rClassifier.rscript) == 2)
            rSections = rClassifier.rscript;
        else
            error('Could not locate R script file: %s', rClassifier.rscript_file);
        end
                
        % and execute
        for i = 1:numel(rSections{1})
            [~, success, msg] = evalR(rSections{1}{i});
            if (~success)
                error('Error: %s\n executing command: %s\nwith command history:\n%s', msg, rSections{1}{i}, rHistory);
            end
            rHistory = sprintf('%s\n%s\n', rHistory, rSections{1}{i});
        end
    catch ME
        delete(hSpinner);
        rethrow(ME);
    end
    
else
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Auto approach
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % include libraries
    [valid, msg, rPackHistory] = AddRPackages(rClassifier.packages);
    if (~valid)
        delete(hSpinner);
        error(msg);
    end
    rHistory = sprintf('%s%s', rHistory, rPackHistory);
    
    % Load the model
    eval_str = sprintf('rClassifier <- load("%s")', rClassifier.file_name);
    [rClassifier.var_name, valid, msg] = evalR(eval_str);
    if (~valid)
        delete(hSpinner);
        error(msg);
    end
    rHistory = sprintf('%s%s\n', rHistory, eval_str);

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now pass data to R - common for both methods
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i = 1:numel(col_index)
    
    if (col_index >= 1)
        status = putRdata(rClassifier.feat_names{i}, X(:, col_index(i)));  % not a time
    else
        time = (0:data_set.num_points-1) / data_set.fs;
        if numel(regexpi(rClassifier.feats_mapped{i}, 'midnight', 'match', 'once'))
            day_start = data_set.tstamp;
            day_start(4:end) = 0;
            tOffset = etime(data_set.tstamp, day_start);
            time = time + tOffset;
            time = rem(time, 24*60*60);  % in case it goes for more than 1 day
        end
        status = putRdata(rClassifier.feat_names{i}, time(:));  % put the time in the R workspace
    end
    if (~status)
        delete(hSpinner);
        error('Failed to create vector: %s from MATLAB vector %s\nafter command history:\n%s', rClassifier.feat_names{i}, rClassifier.feats_mapped{i}, rHistory);
    end
    rHistory = sprintf('%s\n%s <- MATLAB(%s)\n', rHistory, rClassifier.feat_names{i}, rClassifier.feats_mapped{i});  % add a fake version for the command history
end

% now execute the rest
set(hSpinner, 'name', 'Calculating predictions');  % can be timely
drawnow();

if numel(rClassifier.rscript_file)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Custom script approach
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for i = 1:numel(rSections{2})
        try
            evalR(rSections{2}{i});
            rHistory = sprintf('%s%s\n', rHistory, rSections{2}{i});
        catch ME
            delete(hSpinner);
            error('Error: %s\n executing command: %s\nwith command history:\n%s', ME.message, rSections{2}{i}, rHistory);
        end
    end
    
    
else
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Auto approach
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % And build the data frame
    datastore_str = CreateDataAmalgString(rClassifier);
    [res, valid, msg] = evalR(datastore_str);
    rHistory = sprintf('%s\n%s\n', rHistory, datastore_str);
    if (~valid)
        delete(hSpinner);
        error('Failed to calculate predictions with command: %s\nMessage: %s\n\nwith command history:\n%s', predict_str, msg, rHistory);
    end
    
        
    % replace the variable name tag
    predict_str = CreatePredictorString(rClassifier);
    [res, valid, msg] = evalR(predict_str);
    rHistory = sprintf('%s\n%s\n', rHistory, predict_str);
    if (~valid)
        delete(hSpinner);
        error('Failed to calculate predictions with command: %s\nMessage: %s\n\nwith command history:\n%s', predict_str, msg, rHistory);
    end
end

% now get the classifier results (both methods do this)
Y = double(getRdata('Y'));

% and check size
if (numel(Y) ~= size(X,1))
    delete(hSpinner);
    error('Expected the calculated predictions to have %i elements, instead it has %i elements\nafter using command history:\n%s', size(X,1), numel(Y), rHistory);
end
    
% append the classification results to the data
X = [X, Y(:)];

% delete the spinner
gif_end = toc;
if (gif_end < 1)
    pause(1-gif_end); % leave the spinner up for 1s
end
delete(hSpinner);
drawnow();
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now export the predictions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% write the header before this starts
class_set = ExportHeader(class_set, exportInfo, true);

% now process
class_set.lookup(1) = class_set.hbytes;
lookup_ind = 1;                               % the last filled lookup table entry
next_lookup = class_set.lookgap;             % the next point that should have a lookup entry
n_points = 0;

% a metric for progress updates
prog_update = round((numel(class_set.lookup) - 1) / 20);  % update every 5%

if (~exportInfo.time_col)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % fast way - print the "lookup block" in one hit
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    X = X.';                         % need each dimension to be a row for fprintf
    cp = 0;                          % the number of points in this block already written
    lp = n_points + size(X, 2);      % the "final" point in this block (relative to the whole file)
    while (cp + n_points < lp)
        
        ep = min(lp, next_lookup);  % the final point to write in this "chunk"
        fprintf(class_set.file_ptr, write_format, X(:, cp+1:ep-n_points));  % write it
        
        % update the last written point (relative to the block)
        cp = ep - n_points;
        
        % and update the lookup if needed
        if (ep == next_lookup)
            
            % record the lookup table entry
            lookup_ind = lookup_ind + 1;
            class_set.lookup(lookup_ind) = ftell(class_set.file_ptr);
            next_lookup = next_lookup + class_set.lookgap;             % the next point that should have a lookup entry
            
            % update progress 
            if (numel(status_func)) && (rem(lookup_ind, prog_update) == 0)
                feval(status_func, lookup_ind-1, numel(class_set.lookup)-1);
                drawnow();
            end
        end
    end
    
    % update where to start the next point from
    n_points = n_points + size(X,2);  % dim 2 because it was transcribed
    
    % store it in the data set
    class_set.data = X.';
    
else
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % slow method - add a time column
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % write the down sampled data to file
    for j = 1:size(X,1)
        
        % write the time
        ct_str = ConvertTime((n_points + j - 1) / class_set.fs, class_set.tstamp, 2, true);
        fprintf(class_set.file_ptr, '%s, ',  ct_str);
        
        % and the values
        fprintf(class_set.file_ptr, write_format, X(j, :));  % write it
        
        % and update the lookup if needed
        if (n_points + j == next_lookup)
            
            % record the lookup table entry
            lookup_ind = lookup_ind + 1;
            class_set.lookup(lookup_ind) = ftell(class_set.file_ptr);
            next_lookup = next_lookup + class_set.lookgap;             % the next point that should have a lookup entry
            
            % update progress 
            if (numel(status_func)) && (rem(lookup_ind, prog_update) == 0)
                feval(status_func, lookup_ind-1, numel(class_set.lookup)-1);
                drawnow();
            end
            
            
        end
    end
    
    % update where to start the next point from
    n_points = n_points + size(X,1);
    
    % store it in the data set
    class_set.data = X;
    
end

% sanity check
if (n_points ~= class_set.num_points) || (lookup_ind ~= numel(class_set.lookup))
    error('RunRClassifier: Unexpected output size');
end
    
% and close the file if it was open
open = class_set.file_ptr > 0;
if (open)
    fclose(class_set.file_ptr);
    class_set.file_ptr = -1;
end
    
    



