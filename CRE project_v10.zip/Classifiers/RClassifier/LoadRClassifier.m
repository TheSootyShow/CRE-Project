function [classInfo, rHistory] = LoadRClassifier(class_file, packages)
% function [classInfo, rHistory] = LoadRClassifier(class_file, packages)
% this function load an R classifier from file,
% and returns the classifier name.  The R link should be open before
% calling this

% output file structure
classInfo = InitRClassStruct();
rHistory = '';                   

% default libraries (load anything we could possible need)
if (nargin < 2)
    packages = {'pryr',   ...  % needed fo querying object type
                'rpart',  ...
                'rattle', ...
                ...% svm related
                'kernlab', ...
                ...
                ...% forest related
                'randomForest'  ...
                };
end
classInfo.packages = packages;

% strip the string '(required)' from package names (its for display)
for i = 1:numel(classInfo.packages)
    classInfo.packages{i} = regexprep(classInfo.packages{i}, '\(\s*required\s*)', '');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load required packages before doing anything
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[valid, msg, rPackHistory] = AddRPackages(classInfo.packages);
if (~valid)
    error(msg);
end
rHistory = sprintf('%s%s\n', rHistory, rPackHistory);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load the classifier
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% check the file exists
if ~exist(class_file, 'file')
    error('File: %s does not exist', class_file);
end

% R likes double slashes - so update the filename
sep = filesep();
if (sep == '\')
    sep = ['\', sep];  % literal for regexp
end
classInfo.file_name = regexprep(class_file, [sep, '{1,}'], repmat(sep,1,2));


eval_str = sprintf('rClassifier <- load("%s")', classInfo.file_name);
[classInfo.var_name, valid, msg] = evalR(eval_str);
if (~valid)
    error('Could not load the classifier file\n(Failed command: %s\n after command history:\n%s)', eval_str, rHistory);
end
rHistory = sprintf('%s%s\n', rHistory, eval_str);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the classifier object type
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% what sort of object is it?
eval_str = sprintf('otype(%s)', classInfo.var_name);
[classInfo.obj_type, valid, msg] = evalR(eval_str);
rHistory = sprintf('%s%s\n', rHistory, eval_str);
if (~valid)
    error('Could not retrieve the type of object (S3 vs S4)\n(Failed command: %s\n after command history:\n%s)', eval_str, rHistory);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the classifier type
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eval_str = sprintf('class(%s)', classInfo.var_name);
[classInfo.class_type, valid, msg] = evalR(eval_str);
while iscell(classInfo.class_type)
    classInfo.class_type = classInfo.class_type{end};
end
rHistory = sprintf('%s%s\n', rHistory, eval_str);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% try to get feature names
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% try to do it via terms
if strcmpi(classInfo.obj_type, 'S3')
    eval_str = sprintf('labels(terms(%s))', classInfo.var_name);
    [labels, valid, msg] = evalR(eval_str);
    if (valid)
        classInfo.feat_names = labels(:);
        rHistory = sprintf('%s%s\n', rHistory, eval_str);
    end
   
elseif strcmpi(classInfo.obj_type, 'S4')
    eval_str = sprintf('labels(%s@terms)', classInfo.var_name);
    [labels, valid, msg] = evalR(eval_str);
    if (valid)
        classInfo.feat_names = labels(:);
        rHistory = sprintf('%s%s\n', rHistory, eval_str);
    end
    
end


% use default data storage except in known cases
classInfo.data_storage = CreateDataAmalgString();
classInfo.predict_func = CreatePredictorString();

% special case for prediction strings
if (numel(regexpi(classInfo.class_type, 'svm')) > 0)
    % svm
    classInfo.predict_func = 'predict(%classifier_var%, %data%, type="response")';
elseif (numel(regexpi(classInfo.class_type, 'randomforest')) > 0)
    % random forest
    classInfo.predict_func = 'predict(%classifier_var%, %data%, type="response")';
end
    
    













