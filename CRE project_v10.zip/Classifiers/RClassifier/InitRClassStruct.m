function rClass = InitRClassStruct()
% function rClass = InitRClassStruct()
% function to store the R classifier

rClass = struct('file_name',     '',    ...  % file name of the r classifier
                'var_name',      '',    ...  % variable name of the classifier in R
                'obj_type',      '',    ...  % the object type of the classifier (S3 or S4)
                'class_type',    '',    ...  % the classifier type
                'data_storage',  '',    ...  % data storage function (e.g. data frame, matrix etc)
                'predict_func',  '',    ...  % prediction function
                'packages',      {{}},  ...  % libraries required by the classifier
                'feat_names',    {{}},  ...  % feature names (in R) to the classifier
                'feats_mapped',  {{}},  ...  % the names used for the R features by the data set
                'rscript',       '',    ...  % the r script to run
                'rscript_file',  '');   ...  % file location of the R script
                
    