function varargout = CustomRGui(varargin)
% function varargout = CustomRGui(data_set, rClassifier)
% CUSTOMRGUI MATLAB code for CustomRGui.fig
%      CUSTOMRGUI by itself, creates a new CUSTOMRGUI or raises the
%      existing singleton*.
%
%      H = CUSTOMRGUI returns the handle to a new CUSTOMRGUI or the handle to
%      the existing singleton*.
%
%      CUSTOMRGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CUSTOMRGUI.M with the given input arguments.
%
%      CUSTOMRGUI('Property','Value',...) creates a new CUSTOMRGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before CustomRGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All feat_names are passed to CustomRGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CustomRGui

% Last Modified by GUIDE v2.5 22-May-2015 15:18:59

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CustomRGui_OpeningFcn, ...
                   'gui_OutputFcn',  @CustomRGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if (~IsDeveloper)
    try % AWBS - well this can't be a good idea....
        if nargout
            [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
        else
            gui_mainfcn(gui_State, varargin{:});
        end
    catch ME
        
        % deal with the error
        ProcessCREGuiError(ME);
        
    end
else
    % use actual errors in developer mode
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
end
% End initialization code - DO NOT EDIT

% --- Executes just before CustomRGui is made visible.
function CustomRGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CustomRGui (see VARARGIN)


% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);

% attached warning for the gui
handles.warn_dlg = [];

% no pages of feature names yet
handles.nPages = 0;

% add the input data set to the handles
handles.data_set = varargin{1};

% update the time range panel if needed
if (~isdeployed && IsDeveloper())
    
    % cover it to prevent epillepsy
    hCover = CoverFig(hObject);
   
    % and the export processing pane
    handles = CopyExportTemplateToFigure(hObject, handles);
    
    % delete the cover
    delete(hCover);

end

% Use this to indicate unset settings
handles.block_list = [];

% resize if needed
handles = CustomRGui_ResizeFcn(hObject, eventdata, handles);

% update push menus with default values
set(handles.pmPredStorage, 'string', {CreateDataAmalgString()});
set(handles.pmPredictFunc, 'string', {CreatePredictorString()});

if (nargin == 2) && exist(varargin{2}.file_name, 'file')
    handles.rClassifier = varargin{2};
else
    handles.rClassifier = InitRClassStruct();
end
handles = UpdateForClassifier(handles);

% Initialise export settings
handles.featSettings.exportInfo = InitExportStruct(handles.data_set, handles.rClassifier);
handles.featSettings.exportInfo.header = false;  % assume the user won't want this
InitialiseExportPane(handles.featSettings.exportInfo, handles);

% Choose default command line output for CustomRGui
handles.output = {'Cancel', handles.rClassifier, handles.featSettings.exportInfo, handles.data_set};

% Update handles structure
guidata(hObject, handles);

% Make the GUI modal
% set(handles.CustomRGui,'WindowStyle','modal')

% UIWAIT makes CustomRGui wait for user response (see UIRESUME)
uiwait(handles.CustomRGui);

% --- Outputs from this function are returned to the command line.
function varargout = CustomRGui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout = handles.output;

% The figure can be deleted now
delete(handles.CustomRGui);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% run the classifier
handles.output = {get(hObject,'String'), handles.rClassifier, handles.featSettings.exportInfo, handles.data_set};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CustomRGui);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.output = {get(hObject,'String'), handles.rClassifier, handles.featSettings.exportInfo, handles.data_set};

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CustomRGui);


% --- Executes when user attempts to close CustomRGui.
function CustomRGui_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CustomRGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over CustomRGui with no controls selected.
function CustomRGui_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to CustomRGui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
if isequal(get(hObject,'CurrentKey'),'escape')
    
    % User said no by hitting escape
    handles.output = {'Cancel', handles.rClassifier, handles.featSettings.exportInfo};
    
    % Update handles structure
    guidata(hObject, handles);
    
    uiresume(handles.CustomRGui);
end    
    
if isequal(get(hObject,'CurrentKey'),'return')
    uiresume(handles.CustomRGui);
end 


% --- Executes on button press in pbSelClassifier.
function pbSelClassifier_Callback(hObject, eventdata, handles)
% hObject    handle to pbSelClassifier (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_file

if (numel(last_file) == 0)
    last_file =  DataLoadDir();
end

% now prompt the user
[file_name, path_name] = uigetfile('*.rdata', 'Select the rdata file containing the R classifier', last_file);

if numel(file_name) && ischar(file_name)
    
    % assemble the file name
    last_file = fullfile(path_name, file_name);
    
    % try to get the feat_names of the classifier
    old_feat_names = handles.rClassifier.feat_names;
    old_maps = handles.rClassifier.feats_mapped;
    packages = get(handles.lbPackages, 'string');
    if ~iscell(packages)
        packages = {packages};
    end
    
    % load it
    handles.rClassifier = LoadRClassifier(last_file, packages);
    
    % adjust the input mapping
    handles.rClassifier.feats_mapped = cell(size(handles.rClassifier.feat_names));
    
    % if any of the old feat_names match the new ones, copy their mapped feat_names
    [present, idx] = ismember(old_feat_names, handles.rClassifier.feat_names);
    handles.rClassifier.feats_mapped(idx(idx>0)) = old_maps(idx(idx>0));
    
    % now update the gui for progress
    handles = UpdateForClassifier(handles);
    
    % enable messing around with custom scripts
    set(get(handles.mlCustomScript, 'children'), 'enable', 'on');
    
    % and store the handles
    guidata(hObject, handles);
end



% --- Executes on selection change in lbPackages.
function lbPackages_Callback(hObject, eventdata, handles)
% hObject    handle to lbPackages (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbPackages contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbPackages

packages = get(hObject, 'string');
if ~iscell(packages)
    packages = {packages};
end
handles.rClassifier.packages = packages(get(hObject, 'value'));
guidata(hObject, handles);


% --- Executes on button press in pbAddPackage.
function pbAddPackage_Callback(hObject, eventdata, handles)
% hObject    handle to pbAddPackage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% ask the user
resp = inputdlg('Enter the name of the R library',  'Library Select', 1);
if numel(resp)
    
    % open the r link
    new_package = resp{1};
    
    % added the package
    added = AddRPackage(new_package);
    if (added)

        % now add it
        packages = get(handles.lbPackages, 'string');
        if ~iscell(packages)
            packages = {packages};
        end
        selected = get(handles.lbPackages, 'value');
        packages = [packages(:); {new_package}];
        selected(end+1) = numel(packages);
        
        % order it
        [packages, order] = sort(packages);
        [tmp, idx] = ismember(selected, order);
        set(handles.lbPackages, 'max', numel(packages)+1);
        set(handles.lbPackages, 'string', packages);
        set(handles.lbPackages, 'value', idx);
        
        % and save the ammendment
        handles.rClassifier.packages = packages(idx);
        guidata(hObject, handles);
    
    else
        msgbox(sprintf('Could not add package: %s', new_package));
    end
    
end


% --------------------------------------------------------------------
function miLoadClass_Callback(hObject, eventdata, handles)
% hObject    handle to miLoadClass (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_load

if (numel(last_load) == 0)
    last_load = DataLoadDir();
end

[file_name, path] = uigetfile('*.mat', 'Load R classifier settings from:', last_load);
if numel(file_name) && ischar(file_name)
    
    % load the first var in the file
    load_file = fullfile(path, file_name);
    try
        tmp = load(load_file, '-mat');
        fnames = fieldnames(tmp);
        classOpts = tmp.(fnames{1});
    catch ME
        errordlg(sprintf('Could not load %s\nIs it a valid "mat" file?', load_file));
    end
    
    % check it has the right fields
    expected_fields = fieldnames(InitRClassStruct());
    
    % check it has the right fields
    if isfield(classOpts, 'rClassifier') && isfield(classOpts, 'exportInfo') && all(ismember(expected_fields, fieldnames(classOpts.rClassifier)))
        
        % Grab the new values
        handles.rClassifier = UpdateStruct(handles.rClassifier, classOpts.rClassifier, false);
        
        % and export settings
        handles.featSettings.exportInfo = classOpts.exportInfo;
        
        % generated from a custom script?
        if numel(handles.rClassifier.rscript)
            set(handles.miUseCustom, 'checked', 'on');
        end
        
        % And update the gui
        handles = UpdateForClassifier(handles);
        
        % And the export pane
        InitialiseExportPane(handles.featSettings.exportInfo, handles);
		
		% record the directory
		last_load = load_file;
        
        % Store the result
        guidata(hObject, handles);
        
    else
        errordlg(sprintf('File: %s does not contain valid R classifier data', load_file));
    end
    
end


% --------------------------------------------------------------------
function miSave_Callback(hObject, eventdata, handles)
% hObject    handle to miSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_save

if (numel(last_save) == 0)
    last_save = fullfile(DataSaveDir(), 'Rclass.mat');
end

% where to save it
[file_name, path] = uiputfile('*.mat', 'Save R classifier settings to:', last_save);
if numel(file_name) && ischar(file_name)
    rClassOpts.rClassifier = handles.rClassifier;
    rClassOpts.exportInfo = handles.featSettings.exportInfo;
    last_save = fullfile(path, file_name);
    save(last_save, 'rClassOpts', '-mat');
    msgbox(sprintf('Classifier settings saved to: %s', last_save), 'R Classifier Saved');
end



% --- Executes on button press in pbOutput.
function pbOutput_Callback(hObject, eventdata, handles)
% hObject    handle to pbOutput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[file_name, path_name] = uiputfile({'*.csv'}, 'Select the output CSV file name', handles.rClassifier.export_name);
if numel(file_name) && ischar(file_name)
    handles.rClassifier.export_name = fullfile(path_name, file_name);
    set(handles.ebOutFile, 'string', handles.rClassifier.export_name);
    guidata(hObject, handles);
end

function ebOutFile_Callback(hObject, eventdata, handles)
% hObject    handle to ebOutFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ebOutFile as text
%        str2double(get(hObject,'String')) returns contents of ebOutFile as a double

handles.rClassifier.export_name = get(hObject,'String');

% can't really test if the file name is valid
if numel(handles.rClassifier.export_name)
    handles.block_list = handles.block_list(handles.block_list ~= handles.txtClassFile);
elseif ~any(handles.block_list == handles.txtClassFile)
    handles.block_list(end+1) = handles.txtClassFile;
end
set(handles.ebOutFile, 'string', handles.rClassifier.export_name);

guidata(hObject, handles);

function InputFeatChange(hObject, event_data, handles)
% function InputFeatChange(hObject, event_data, handles)
% function exectute on change associated with a dimension select list

% which input
index = str2double(regexp(get(hObject, 'tag'), '\d+', 'match', 'once'));
value = get(hObject, 'value');
if (value <= numel(handles.data_set.dim_names))
    handles.rClassifier.feats_mapped{index} = handles.data_set.dim_names{value};
else
    % this is a time
    dims = get(hObject, 'string');
    handles.rClassifier.feats_mapped{index} = dims{value};
end
guidata(hObject, handles);



function handles = UpdateForClassifier(handles)
% function handles = UpdateForClassifier(handles)
% function to update the gui for the classifier stored in 
% handles.rClassifier



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the R classifier file name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   
if (numel(handles.rClassifier.rscript) == 2)
    
    % doesn't need the file name for custom R scripts
    handles.block_list = handles.block_list(handles.block_list ~= handles.txtClassFile);
    set([handles.pmPredStorage, handles.pmPredictFunc, handles.miGenerateRScript], 'enable', 'off');
    
elseif numel(handles.rClassifier.file_name)
    
    % if it doesn't exist, give the user a chance to update the location
    if ~exist(handles.rClassifier.file_name, 'file')
        [path, name] = uigetfile({'*.RData', sprintf('Unable to locate %s.  Please select an alternate location', handles.rClassifier.file_name)});
        if (numel(path) && ischar(path))
            handles.rClassifier.file_name = fullfile(path, name);
        end
    end
    
    % check it exists
    if (exist(handles.rClassifier.file_name, 'file'))
        [path, name, ext] = fileparts(handles.rClassifier.file_name);
        set(handles.txtClassFile, 'string', textwrap(handles.txtClassFile, {[name, ext]}));
        set(handles.txtClassFile, 'TooltipString', handles.rClassifier.file_name);
        handles.block_list = handles.block_list(handles.block_list ~= handles.txtClassFile);
        set([handles.pmPredStorage, handles.pmPredictFunc, handles.miGenerateRScript], 'enable', 'on');
    else
        handles.rClassifier.file_name = [];
        handles = UpdateForClassifier(handles);
        return;
    end


elseif ~any(handles.block_list == handles.txtClassFile)
    set([handles.pmPredStorage, handles.pmPredictFunc, handles.miGenerateRScript], 'enable', 'off');
    handles.block_list(end+1) = handles.txtClassFile;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the classifier variable name
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(handles.rClassifier.var_name)
    set(handles.txtRVarName, 'string', handles.rClassifier.var_name);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the classifier variable type
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(handles.rClassifier.class_type)
    set(handles.txtClassType, 'string', handles.rClassifier.class_type);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% R object type
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if numel(handles.rClassifier.obj_type)
    set(handles.txtRObjType, 'string', handles.rClassifier.obj_type);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data storage format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% current options
store_types = get(handles.pmPredStorage, 'string');
if ~iscell(store_types)
    store_types = {store_types};
end
[present, idx] = ismember(handles.rClassifier.data_storage, store_types);
if (~present)
    if numel(handles.rClassifier.data_storage)
        store_types{end+1} = handles.rClassifier.data_storage;
        set(handles.pmPredStorage, 'string', store_types);
        idx = numel(store_types);
    else
        idx = 1;
    end
end
set(handles.pmPredStorage, 'value', idx);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Prediction format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% current options
pred_funcs = get(handles.pmPredictFunc, 'string');
if ~iscell(pred_funcs)
    pred_funcs = {pred_funcs};
end
[present, idx] = ismember(handles.rClassifier.predict_func, pred_funcs);
if (~present)
    if numel(handles.rClassifier.predict_func)
        pred_funcs{end+1} = handles.rClassifier.predict_func;
        set(handles.pmPredictFunc, 'string', pred_funcs);
        idx = numel(pred_funcs);
    else
        idx = 1;
    end
end
set(handles.pmPredictFunc, 'value', idx);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the libraries
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

packages = get(handles.lbPackages, 'string');
if ~iscell(packages)
    packages = {packages};
end

% strip the string '(required)' from package names (its for display)
packages_act = packages;
isRequired = false(1, numel(packages_act));
for i = 1:numel(packages_act)
    if (numel(regexp(packages{i}, '\(\s*required\s*)')) > 0)
        isRequired(i) = true;
        packages_act{i} = strtrim(regexprep(packages{i}, '\(\s*required\s*)', ''));
    end
end



% are the libraries filled?
if numel(handles.rClassifier.packages)
    
    % where do the map to
    [present, idx] = ismember(handles.rClassifier.packages, packages_act);
    
    % add ones not currently in the list
    if any(~present)
        
        % add it
        packages = [packages(:); handles.rClassifier.packages(~present)];
        packages_act = [packages_act(:); handles.rClassifier.packages(~present)];
        isRequired(numel(packages)) = false;
        
        % and add
        [packages, index] = sort(packages);
        packages_act = packages_act(index);
        isRequired = isRequired(index);
        
        % and update
        set(handles.lbPackages, 'string', packages);
        [present, idx] = ismember(handles.rClassifier.packages, packages_act);
        set(handles.lbPackages, 'max', max(numel(packages), 2));
    end
    
    % make sure all required packages are included
    use = isRequired;
    use(idx) = true;
    set(handles.lbPackages, 'value', find(use));
else
    handles.rClassifier.packages = packages_act(get(handles.lbPackages, 'value'));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Build the dimensions pane
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

handles = BuildFeatPane(handles);

% enable or disable based on the result
EnableDisableOutput(handles);

% make sure the warning dialog is at the top level
if numel(handles.warn_dlg)
    figure(handles.warn_dlg);
end

function [handles, force_resize] = BuildFeatPane(handles)
% function [handles, force_resize] = BuildFeatPane(handles)
% function to build the feature selection pane

% shortcuts
class_feats = handles.rClassifier.feat_names;
mapped = handles.rClassifier.feats_mapped;
ds_feats = handles.data_set.dim_names;

% keep track of whether we need a resize
force_resize = false;

% the callback for each list to use
callback = @(hObject, event_data)InputFeatChange(hObject, event_data, guidata(hObject));

% call the funciton to populate it
[handles, mapped, force_resize] = BuildClassifierFeatOpts(ds_feats, class_feats, mapped, callback, handles, force_resize);

% update this
handles.rClassifier.feats_mapped = mapped;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% are the feat_names filled?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (numel(class_feats) > 0)
    handles.block_list = handles.block_list(handles.block_list ~= handles.uiFeatMatch);
    set(handles.miSave, 'enable', 'on');  % allow saving
elseif ~any(handles.block_list == handles.uiFeatMatch)
    handles.block_list(end+1) = handles.uiFeatMatch;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% execute the resize if needed 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (force_resize)
    
    % resize if needed
    handles = CustomRGui_ResizeFcn(handles.CustomRGui, 3, handles);
    
end





% --------------------------------------------------------------------
function miGenerateRScript_Callback(hObject, eventdata, handles)
% hObject    handle to miGenerateRScript (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_file

if numel(handles.rClassifier.rscript_file)
    last_file = handles.rClassifier.rscript_file;
end
if (numel(last_file) == 0)
    last_file = fullfile(DataSaveDir(), regexprep(strrep(handles.rClassifier.file_name, '.', '_'), '_Rdata', '_custom.r', 'ignorecase'));
end

% prompt the user for the path
[file_name, path_name] = uiputfile('*.r', 'Please enter the file name for the custom script', last_file);

if (numel(file_name) && ischar(file_name))
    file_name = fullfile(path_name, file_name);
    last_file = file_name;
    try
        
        % try to auto generate it
        script = CreateRScript(handles.rClassifier);

        % save it
        fid = fopen(file_name, 'w');
        if (fid <= 0)
            errordlg(sprintf('Unable to open file: %s.  Is it in use?', file_name));
            return;
        end
        fprintf(fid, '%s', script);
        fclose(fid);
        
        % open it for the user
        if (ispc)
            winopen(file_name);
        end        
    
    catch ME
        if (~IsDeveloper())
            errordlg('Unable to create a custom script for the classifier (Unknown Error)');
            return;
        else
            rethrow(ME);
        end
    end
end

% --------------------------------------------------------------------
function miBlankTemplate_Callback(hObject, eventdata, handles)
% hObject    handle to miBlankTemplate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% create the blank R script
persistent last_file

if (numel(last_file) == 0)
    last_file = fullfile(DataSaveDir(), 'RTemplate.r');
end

% prompt the user for the path
[file_name, path_name] = uiputfile('*.r', 'Please enter the file name for the custom script', last_file);

if (numel(file_name) && ischar(file_name))
    file_name = fullfile(path_name, file_name);
    last_file = file_name;
    try
        
        % try to auto generate it
        script = CreateRScript();

        % save it
        fid = fopen(file_name, 'w');
        if (fid <= 0)
            errordlg(sprintf('Unable to open file: %s.  Is it in use?', file_name));
            return;
        end
        fprintf(fid, '%s', script);
        fclose(fid);
        
        % open it for the user
        if (ispc)
            winopen(file_name);
        end
    
    catch ME
        if (~IsDeveloper())
            errordlg('Failed to create a template script (Unknown Error)');
            return;
        else
            rethrow(ME);
        end
    end
end


% --------------------------------------------------------------------
function handles = miLoadRScript_Callback(hObject, eventdata, handles)
% hObject    handle to miLoadRScript (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

persistent last_path

if (numel(last_path) == 0)
    last_path = DataLoadDir();
end

if (nargin == 1)
    last_path = hObject;
    return;
end
    
% prompt the user
[file_name, path_name] = uigetfile('*.r', 'Please select the custom script to load', last_path);

if (numel(file_name) && ischar(file_name))
    
    file_name = fullfile(path_name, file_name);
    [handles.rClassifier, parsed, msg] = RClassifierFromScript(file_name);
        
    % check it was parsed
    if (~parsed)
        errordlg(sprintf('%s\nin file: %s,\nIs it a valid classification script?', msg, handles.rClassifier.rscript_file));
        return;
    elseif (numel(handles.rClassifier.feat_names) == 0) % and that the input list was found
        errordlg(sprintf('Could not find the definition of "feature_names" in file: %s\nIs it a valid classification script?', handles.rClassifier.rscript_file));
        return;
    else
        % looking good
        
        % adjust the input mapping
        handles.rClassifier.feats_mapped = cell(size(handles.rClassifier.feat_names));
        
        % now update the gui for progress
        handles = UpdateForClassifier(handles);
        set(handles.miUseCustom, 'checked', 'on');
        
        if (nargout == 0)
            guidata(hObject, handles);
        end
    end
end


% --------------------------------------------------------------------
function miUseCustom_Callback(hObject, eventdata, handles)
% hObject    handle to miUseCustom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if strcmpi(get(hObject, 'checked'), 'on')
    set(hObject, 'checked', 'off');
    handles.rClassifier.rscript_file = [];
    guidata(hObject, handles);
else
    miLoadRScript_Callback(hObject, eventdata, handles);
end
    



function handles = CustomRGui_ResizeFcn(hObject, eventdata, handles)
% function handles = CustomRGui_ResizeFcn(hObject, eventdata, handles)
% resize function for the gui

% is this the call during creation?
first = (numel(eventdata) == 0);  % event data is used to comminate change to the feat_names panel

% is there a need to run it?
if (~first) || (RunResizeFcn(hObject, handles))

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);

	% if the figure is visible, cover it to prevent epilepsy
	hCover = [];
	if strcmpi(get(hObject, 'visible'), 'on')
		hCover = CoverFig(hObject);
	end

	% default gaps
	[smallGap, normGap, largeGap] = DefaultPaneGaps();

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% build the grid for the classifier description
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	if (first)

		hClassifier = {handles.txtClassFileDescrip,    handles.txtClassFile,    handles.txtClassFile;        ...
                       handles.txtVarNameDescrip,      handles.txtRVarName,     handles.txtRVarName;         ...
                       handles.txtObjTypeDescrip,      handles.txtRObjType,     handles.txtRObjType;         ...
                       handles.txtClassTypeDescrip,    handles.txtClassType,    handles.txtClassType;        ...
					   handles.txtPredStorageDescrip,  'h=.1cm',                 handles.pmPredStorage;       ...     
                       handles.txtPredFuncDescrip,     'h=.1cm',                 handles.pmPredictFunc;       ...     
					   handles.pbSelClassifier,        handles.pbSelClassifier, handles.pbSelClassifier};    ...
    
		vGapClassifier = repmat(normGap, size(hClassifier,1)-1, size(hClassifier,2));
		hGapClassifier = repmat(smallGap, size(hClassifier,1), size(hClassifier,2)-1);
    
	else
		hClassifier = handles.uiClassifier;
		vGapClassifier = [];
		hGapClassifier = [];
	end
    

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% build the grid for the libraries
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	vGapLibs = [];
	if (first)
		hLibs = {handles.lbPackages, handles.pbAddPackage};
		hGapLibs = [];
	else
		hLibs = handles.uiRLibrarys;
		hGapLibs = normGap;
    
	end

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% build the grid for the export file
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	if (first)

		% use the default layout
		[hExport,  hGapExport, vGapExport] = DefaultExportPaneLayout(handles, smallGap, normGap, largeGap);
    
	else
		hExport = handles.uiExport;
		hGapExport = [];
		vGapExport = [];
	end

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% build the grid for the feat_names
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if (first)
        hfeat_names = handles.uiFeatMatch;
        hGapfeat_names = [];
        vGapfeat_names = [];
    else
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % resize the tab group now if needed
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % is this the tabbed version?
        if isfield(handles, 'tgFeatTabGroup') && ishandle(handles.tgFeatTabGroup)
            
            % grab the tabs
            hTabs = findobj(handles.tgFeatTabGroup, 'type', 'uitab');
            
            % get the size of the child frame of each tab
            % (should all be the same)
            panelSizes = zeros(numel(hTabs), 2);
            for i = 1:numel(hTabs)
                pos = get(get(hTabs(i), 'child'), 'position');
                panelSizes(i,:) = pos(3:4);
            end
            
            % and resize
            [tgSize, tabSize] = setTabGroupSize(hTabs, panelSizes);
            hfeat_names = {handles.tgFeatTabGroup};
            
        else
            hfeat_names = handles.uiFeatMatch;
        end
        hGapfeat_names = [];
        vGapfeat_names = [];
        
    end

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% Assemble it all
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	hGrid = {hClassifier,       'b';      ...
			 hLibs,             hfeat_names;  ...
			 hExport,           'l';      ...
			 handles.pbCancel,  handles.pbOK};
	hGap =  {hGapClassifier, []; hGapLibs, hGapfeat_names; hGapExport, 'l'; [], []};
	vGap =  {vGapClassifier, []; vGapLibs, vGapfeat_names; vGapExport, 'l'; [], []};
    
    % remove push string (don't want to expand this)
    dataList = get(handles.pmPredStorage, 'string');
    predictList = get(handles.pmPredictFunc, 'string');
    set(handles.pmPredStorage, 'string', repmat({' '}, size(dataList)));
    set(handles.pmPredictFunc, 'string', repmat({' '}, size(predictList)));

	% and resize    
	ResizeFigFromPanes(hGrid, hGap, vGap, false);
    
    % update push menus 
    set(handles.pmPredStorage, 'string', dataList);
    set(handles.pmPredictFunc, 'string', predictList);
    
	% % move the list down to the bottom of the classisifer pane
	% hMove = [handles.lbPackages,handles.pbAddPackage];
	% set(hMove, 'units', 'pixels');
	% pos = get(handles.lbPackages, 'position');
	% 
	% % what's the normal gap?
	% [paneGap, paneBorder] = DefaultGuiBorders();
	% dy = pos(2) - paneBorder(2);
	% 
	% % and move it all
	% for i = 1:numel(hMove)
	%     pos = get(hMove(i), 'position');
	%     pos(2) = pos(2) - dy;
	%     set(hMove(i), 'position', pos);
	% end


	% finally delete the cover if there was one
	if numel(hCover)
		delete(hCover);
	end

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	% save the resized figure if applicable
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % and save it
    if (handles.nPages < 2)  % dont save if it has tabs in it
        handles = SaveResizedCREFigure(hObject, [], handles);
    end
	
end


% --- Executes on selection change in pmPredStorage.
function pmPredStorage_Callback(hObject, eventdata, handles)
% hObject    handle to pmPredStorage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmPredStorage contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmPredStorage

% which method are we after?
contents = cellstr(get(hObject,'String'));
handles.rClassifier.data_storage = contents{get(hObject,'Value')};
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function pmPredStorage_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmPredStorage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pmPredictFunc.
function pmPredictFunc_Callback(hObject, eventdata, handles)
% hObject    handle to pmPredictFunc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pmPredictFunc contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pmPredictFunc


% which method are we after?
contents = cellstr(get(hObject,'String'));
handles.rClassifier.predict_func = contents{get(hObject,'Value')};
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function pmPredictFunc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmPredictFunc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function miModify_Callback(hObject, eventdata, handles)
% hObject    handle to miModify (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

uiObject = gco;
uiContTag = get(uiObject, 'tag');

if strcmpi(uiContTag, 'pmPredStorage')
    updateField = 'data_storage';
    reqTokens = {'%feat_names%'};
    dlgPrompt = sprintf('Insert custom predictor storage command.\nThis must contain the token %s, and be syntactically valid in R', reqTokens{1});
    dlgTitle = 'Predictor storage command';
    
else
    updateField = 'predict_func';
    reqTokens = {'%data%', '%classifier_var%'};
    dlgPrompt = sprintf('Insert custom prediction function.\nThis must contain the tokens %s and %s, and be syntactically valid in R', reqTokens{1}, reqTokens{2});
    dlgTitle = 'Prediction command';
end

% prompt the user
response = inputdlg(dlgPrompt, dlgTitle, 1,{handles.rClassifier.(updateField)});
                   
% user said OK
if numel(response)
    
    % check required tokens
    valid = true;
    for i = 1:numel(reqTokens)
        valid = valid && numel(strfind(response{1}, reqTokens{i}));
        if (~valid)
            warndlg(sprintf('Command does not contain the required token: %s\nand cannot be used', reqTokens{i}), 'Invalid command', 'modal');
            break;
        end
    end
    
    % if it was valid
    if (valid)
        handles.rClassifier.(updateField) = response{1};
        
        % now update the gui for progress
        handles = UpdateForClassifier(handles);
        
        % update the handles
        guidata(hObject, handles);
        
    end
end



% --------------------------------------------------------------------
function miAbout_Callback(hObject, eventdata, handles)
% hObject    handle to miAbout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

uiObject = gco;
uiContTag = get(uiObject, 'tag');

if strcmpi(uiContTag, 'pmPredStorage')
    
    % build the example string
    exString = CreateDataAmalgString(handles.rClassifier);
    
    % create the help text
    help_str = sprintf('%s\n%s\n%s\n\n%s\n\n    %s\n\n%s\n%s', ...
                                                'This controls the way the features are combined into a single object in R,', ...
                                                'and should be set to match the object type the classifier expects for the data.', ...
                                                'The token %feat_names% must be include, and will be replaced at run time by a comma sperated list of the features names', ...
                                                'Using current settings, the data will be combined in R using the command:', ...
                                                exString, ...
                                                'Which must be syntactically valid in R.', ...
                                                'If the method required to combine the features does not fit within this framework, a custom R script must be used.');

    % and create
    hHelp = helpdlg(help_str, 'Predictor storage function');
    
else
    
    % build the example string
    exString = CreatePredictorString(handles.rClassifier);
    
    % create the help text
    help_str = sprintf('%s\n%s\n%s\n\n%s\n\n    %s\n\n%s\n%s', ...
                                                'This controls the method used by the classifier to make predictions on the data.', ...
                                                'The token %data% must be included, and will be replaced at run time by the predictor data X (see predictor storage)', ...
                                                'The token %classifier_var% must be included, and will be replaced at runtime by the name of the variable used for the classifier', ....
                                                'Using current settings, predictions will be calculated in R using the command:', ...
                                                exString, ...
                                                'Which must be syntactically valid in R.', ...
                                                'If the method required generate predictions does not fit within this framework, a custom R script must be used.');
    
    % and create
    hHelp = helpdlg(help_str, 'Predictor function');
    
end
hTxt = findobj(hHelp, 'type', 'text');
set(hTxt, 'fontname', 'arial');
set(hHelp, 'windowstyle', 'modal');
    
    
    
    
