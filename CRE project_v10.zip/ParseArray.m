function array = ParseArray(array_str)
% function array = ParseArray(array_str)
% function to parse a string containing an ASCII representation of a cell array or a matrix
% columns are seperated by ',', rows by ';'.  Cells are encapusulated
% withing {}, matrices within []

% alwasy deblank it
%array_str

[tmp, array_start] = regexp(array_str, '^\s*[\[\{]');  % find the first bracket
array_end =  regexp(array_str,'[\]\}]\s*$');    % find the last bracket bracket

% maybe its just a scalar / char array?
if (numel(array_start) == 0) || (numel(array_end) == 0)
    
    % try to parse
    array = str2double(array_str);
    
    % check validity
    if isnan(array) && ~strcmpi(strtrim(array_str), 'NaN')
        array = strtrim(array_str);
    end
    
% maybe its empty    
elseif all(isstrprop(array_str(array_start+1:array_end-1), 'wspace'))
    if (array_str(array_end) == '}')
        array = {};  % empty cell
    else
        array = [];  % empty matrix
    end
else
    
    % type = 1 is a cell
    type = array_str(array_end) == '}';  
    
    % how many potential delimiters?
    delims = ',;';
    max_delims = sum(array_str == ',') + sum(array_str == ';');
    
    % find the ones not inside brackets
    delim_inds = zeros(1, max_delims);
    n_delims = 0; % reset
    
    % dont treat delimiters inside any of these
    pre_ignore = '([{';
    post_ignore = ')]}';
    ignore_count = zeros(1, numel(pre_ignore));
    
    for i = (array_start+1:array_end-1)
        
        % is this the beginning of an ignore section?
        ignore_count((array_str(i) == pre_ignore)) = ignore_count((array_str(i) == pre_ignore)) + 1;
        
        % is this the end of an ignore section?
        ignore_count((array_str(i) == post_ignore)) = max(ignore_count((array_str(i) == post_ignore)) - 1, 0);
        
        % otherwise, is this a delimiter?
        if any(array_str(i) == delims) && all(ignore_count == 0)
            n_delims = n_delims + 1;
            delim_inds(n_delims) = i;
        end
    end
    
    % trim back delim_inds
    delim_inds = delim_inds(1 : n_delims);
    
    % break this into rows and columns
    row_change = find(array_str(delim_inds) == ';');
    n_rows = numel(row_change) + 1;  % output array size
    
    % these should be uniformly spaced
    if any(row_change)
        
        % how many column in the first row?
        if numel(row_change >= 2)
            nc = diff(row_change);
        else
            nc = row_change(1);
        end
        
        % check consistency
        if (nc ~= row_change(1)) || any(nc ~= nc(1)) || (nc ~= (n_delims - row_change(end) + 1))
            error('Inconsistent columns in the string: %s', array_str);
        end
        n_cols = dx(1);
    else
        n_cols = n_delims + 1;
    end
        
    % now build the output
    array = cell(n_rows, n_cols);
    
    % reformat the indexs
    indexs  = reshape([delim_inds, array_end], n_rows, n_cols);
    indexs  = [[array_start; indexs(2:end,end)], indexs];
    
    % and fill it
    for i = 1:n_rows
        for j = 1:n_cols
            term = array_str(indexs(i,j)+1:indexs(i,j+1)-1);
            array{i,j} = ParseArray(term);
        end
    end
    
    % is it supposed to be a matrix?
    if (type == 0)
        is_numeric = cellfun(@(x)(islogical(x) || isnumeric(x)), array);
        is_scalar = cellfun(@(x)(numel(x) == 1), array);
        if all(is_numeric(:) & is_scalar(:))
            array = cell2mat(array);
        else
            error('Data string: %s should encode a matrix; however elements within it are either not numeric or not scalar', array_str);
        end
    end
end