################################################################################
# 1) Declare the names of the features used by the classifier / predictor here #
# N.B. Do NOT change the variable name from "feature_names"                    #
################################################################################

feature_names = c("X_Mean", "X_SD")


################################
# 2) Declare required packages #
################################

rm(libs) # clear existing variable

# Create a list of required packages
libs = c("rpart")


#################################
# 3) Load the required packages #
# (No need to edit))            #
#################################

for (i in 1:length(libs))
{
	# Install the package if needed 
	if (!is.element(libs[i], .packages()))
	{	loaded = install.packages(libs[i])	};

	# Add the library 
	loaded = require(libs[i], character.only = TRUE);

	# Throw an error if it failed 
	# if (!loaded)
	# {
	#	errorMsg = paste("Could not load package: ", libs[i])
	#	stop(errorMsg)
	#};
}




######################################################
# 4) Load the classifier into variable "rClassifier" #
######################################################

rClassifier <- load("C:\\CRE project\\data\\sed.dt.wrist.RData")




######################
# 5) Import data set #
# Do NOT edit !!!    #
######################

# Start do not edit import (these commands aren't meant for R)
# putRdata(X_Mean, DATASET->X)
# putRdata(X_SD, DATASET->Y)

# Store the data set sampling frequency in fs
# putRdata(fs, DATASET->fs)

# End do not edit import - R should now have data set variables X_Mean, X_SD and the sampling frequency fs defined now




##################################
# Build the data frame (named X) #
##################################

X <- data.frame(X_Mean, X_SD)



#####################################################################
# 6) Perfrom predictions (predictions must be stored in variable Y) #
#####################################################################

Y <- predict(sed.decisiontree, X, type="class")




#########################
# 7) Export predictions #
# Do NOT edit!!!        #
#########################

# Start do not edit export (these commands aren't meant for R)

# DATASET->CLASSIFIED = getRdata('Y')

# End do not edit export 
