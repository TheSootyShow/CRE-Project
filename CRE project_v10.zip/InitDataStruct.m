function data_struct = InitDataStruct()
% function data_struct = InitDataStruct()
% this function initialises a data structure for accelerometer data


data_struct = struct('name',            [],  ... % the name of the data set
                     'file_name',       [],  ... % the name of the current file
                     'set_type',        [],  ... % the type of data set, can be 'data', 'features', 'classified', or 'batch'
                     'file_ptr',        -1,  ... % file pointer to the current file
                     'hbytes',          [],  ... % byte size of the header
                     'hlines',          [],  ... % total lines in the header
                     'view_type',       -1,  ... % how much of the file is being viewed (-1 = unitialised, 0 = none, 1 = partial lookup, 2 = full lookup)
                                             ... % num points is only accurate if view_style == 2
                     'dims',            [],  ... % data set dimensionality
                     'num_points',      [],  ... % the number of points in this data set
                     'dim_names',       [],  ... % dimension name where available
                     'time_col',        [],  ... % indicates the first column is the sample time
                     'data',            [],  ... % loaded data matrix (for small files)
                     'lookup',          [],  ... % the byte offset for selected data points (from the file start)
                                             ... % lookup(1) is the file pointer for the first data point
                                             ... % lookup(n) is the file pointer for data point (n-1)*lookgap + 1 
                     'lookgap',         [],  ... % each lookup table entry is this many data points apart
                     'delim',           [],  ... % delimiter for the csv 
                     'type',            [],  ... % ascii or binary file
                     'ASCII_read',      [],  ... % a string for reading a line in ASCII
                     'ASCII_dec',       [],  ... % the maximum number of decimal places used in the source file
                     'dtype',           [],  ... % data type if binary (matlab interpretable string)
                     'tstamp',          [],  ... % date vector for the data set start [Y, M, D, H, M, S]
                     'device_type',     [],  ... % ACTIgraph etc
                     'device_serial',   [],  ... % serial number for the device
                     'class_info',      [],  ... % store information about the classifier classes (each element is 
                                             ... % {'column_title', class1 name, class1 code, class 1 threshold, 
                                             ... % classn name, classn code, class n threshold})
                     'fs',              [],  ... % data set sampling frequency
                                             ... 
                     'ds_headers',      []);     % headers for each data set if (only used if this is a batch set)
                     

