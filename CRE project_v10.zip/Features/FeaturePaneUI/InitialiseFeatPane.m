function [handles, fRange] = InitialiseFeatPane(featSettings, handles)
% function [handles, fRange] = InitialiseFeatPane(featSettings, handles)
% function to initialise the feature pane given the featues in featStruct

% shortcuts
featStruct = featSettings.features; 
fRange = featSettings.freqRange;
binPeriod = featSettings.binInfo.bin_duration;
useBins = featSettings.binInfo.use_bins;

% ensure user data for auto correlation is correct
unit_list = get(handles.pmACorrUnits, 'string');
sel = get(handles.pmACorrUnits, 'value');
if strncmpi(unit_list{sel}, 'samples', 7)
    ustr = get(handles.lbACorr, 'string');
    udata = cellfun(@str2num, ustr);
    udata = (udata / handles.data_set.fs) * 1e3;  % milliseconds
    udata = {udata, []};
    set(handles.lbACorr, 'userdata', udata);
end


% clear the selection on these
hListBox = findobj(handles.uiFeatures, 'style', 'listbox');
for i = 1:numel(hListBox)
    
    % ensure maximum range is correct
    opts = get(hListBox(i), 'String');
    set(hListBox(i), 'max', max(numel(opts),2), 'value', []);
    
    % check the user data storage is up to date
    % the second cell should be the last selected values
    data = get(hListBox(i), 'userdata');
    if (numel(data) == 0)
        data = {str2num(opts), []};
    elseif ~iscell(data)
        data = {data, []};
    end
    set(hListBox(i), 'userdata', data);
end

% get the various frequency ranges of interest
[freqRanges, feat_indexs] = FreqRangesFromFeatures(featStruct);
if (numel(freqRanges) == 0)
    freqRanges = [0, handles.data_set.fs/2];
end
fRange.fbounds = freqRanges;
fRange.fbounds(:,2) = min(fRange.fbounds(:,2), handles.data_set.fs/2);

% need to ensure these pane's exist (

% ensure the frequency range panes are suitable
handles = SetFreqRangePanes(freqRanges, handles);

% assert the validity of input options by using the callbacks
% for i = 1:size(freqRanges,1)
%     minTag = sprintf('ebMinFreq%i', i);
%     maxTag = sprintf('ebMaxFreq%i', i);
%     ebMinFreq_Callback(handles.(minTag), [], handles);
%     ebMaxFreq_Callback(handles.(maxTag), [], handles);
% end


% now set features
feat_handles = findobj(handles.uiFeatures, 'style', 'radiobutton'); % handles to the feature radion buttons
feat_tags = get(feat_handles, 'tag');                               % their tags
checked = false(size(feat_handles));
for i = 1:numel(featStruct)
    
    % a display one?
    if (~featStruct(i).prereq_only)
        
        % the expected name of the radio button
        if (feat_indexs(i) == 0)
            exp_name = sprintf('rb%s', featStruct(i).name);  % they're radio buttons
        else
            exp_name = sprintf('rb%s%i', featStruct(i).name, feat_indexs(i));  % they're radio buttons
        end
        exp_name = exp_name(~isstrprop(exp_name, 'wspace'));        % remove spaces
        index = find(strcmpi(feat_tags, exp_name));
        
        % use an an alternative name if it wasn't found
        if (numel(index) ~= 1)
            
            if (feat_indexs(i) == 0)
                exp_name = sprintf('rb%s', regexpi(featStruct(i).label_str, '^[^/(]+', 'match', 'once'));  % they're radio buttons
            else
                exp_name = sprintf('rb%s%i', regexpi(featStruct(i).label_str, '^[^/(]+', 'match', 'once'), feat_indexs(i));  % they're radio buttons
            end
            index = find(strcmpi(feat_tags, exp_name));
        end
        
        % if its still not found, its probably a listbox
        if (numel(index) ~= 1)
            arg = featStruct(i).input_args{1};
            if strcmpi(featStruct(i).name, 'percentile')                            % special case for the list box percentiles
                hUpdate = [handles.miAddPercentile, handles.lbPercentile];
            elseif strcmpi(featStruct(i).name, 'auto correlation')                  % special case for auto correlation
                hUpdate = [handles.miAddLag, handles.lbACorr];
            elseif strcmpi(featStruct(i).name, 'dominant frequency')                % special case for dominant frequency
                hUpdate = [handles.miAddDomFreq, handles.(sprintf('lbDomFreq%i', feat_indexs(i)))];
            elseif strcmpi(featStruct(i).name, 'dominant frequency magnitude')      % special case for dominant frequency magnitude
                hUpdate = [handles.miAddDomFreq, handles.(sprintf('lbDomFreqMag%i', feat_indexs(i)))];
            elseif strcmpi(featStruct(i).name, 'dominant frequency power ratio')    % special case for dominant frequency ratio
                hUpdate = [handles.miAddDomFreq, handles.(sprintf('lbDomFreqRat%i', feat_indexs(i)))];
            else
                error('Couldn''t find a radio button for feature: %s', featStruct(i).name);
            end
            
            % call the add function to ensure the value is in the list
            FeaturePaneCallbacks(hUpdate(1), {num2str(arg), hUpdate(2)}, handles);
            
            % now make sure the value is selected
            SelectListBox(hUpdate(2), arg);
            
        else
            checked(index) = true;
        end
    end
end

% and set them all
for i = 1:numel(feat_handles)
    set(feat_handles(i), 'value', checked(i));
end


% the minimum possible resolution
if (useBins)
    binSamps = floor(binPeriod * handles.data_set.fs);
else
    binSamps = SamplesFromTimeRange(featSettings.timeRange);
end
minRes = handles.data_set.fs / binSamps;
set(handles.txtMinFFTres, 'string', num2str(minRes));

% set the fft resolution
set(handles.ebFFTres, 'userdata', fRange.fres);
set(handles.ebFFTres, 'string', num2str(fRange.fres));
set(handles.txtFs,  'string', num2str(handles.data_set.fs));





% store the handles
if (nargout == 0)
    guidata(handles.CREFeatureGui, handles);
end


function SelectListBox(hList, value)
% function SelectListBox(hList, value)
% function to ensure set a list box entry to selected

uData = get(hList, 'userdata');
prevSelect = sort([uData{2}(:); value]);
[exists, idx] = ismember(prevSelect, uData{1});
if ~all(exists)
    error('Could not find a matching value in list box: %s', get(hList, 'tag'));
else
    set(hList, 'value', idx)
    uData{2} = prevSelect;
    set(hList, 'userdata', uData);
end



function handles = SetFreqRangePanes(freqRanges, handles)
% function handles = SetFreqRangePanes(freqRanges, handles)
% function to set the frequency range panes


% Note - RestoreDefaultFeatures need the frequency freatures tabs to exist
% (they are remove when the feature pane is not active because of a
% visibilty bug in Matlab)
[restored, hCover, handles] = RestoreFreqPaneTabs(handles);

% get all of the panes
hTabs = get(handles.tgFreqTabs, 'children');
types = get(hTabs, 'type');
hTabs = hTabs(strcmpi(types, 'uitab'));

% one less than this available (save one for "new")
n_avail = numel(hTabs) - 1;
n_needed = size(freqRanges,1);

% make more?
if (n_avail < n_needed)
    
    % add them
    handles = AddFreqRangeTab(handles, n_needed - n_avail);
    
elseif (n_avail > n_needed)
    
    % remove them
    handles = DeleteFreqRangeTab(handles, n_needed + 1:n_avail);
    
end

% now update frequencies and title
for i = 1:n_needed
    set(handles.(sprintf('tabFrange%i', i)), 'title', sprintf('%0.2g-%0.2g', freqRanges(i,1), freqRanges(i,2)));
    set(handles.(sprintf('ebMinFreq%i', i)), 'string', num2str(freqRanges(i,1)));
    set(handles.(sprintf('ebMinFreq%i', i)), 'userdata', freqRanges(i,1));
    set(handles.(sprintf('ebMaxFreq%i', i)), 'string', num2str(freqRanges(i,2)));
    set(handles.(sprintf('ebMaxFreq%i', i)), 'userdata', freqRanges(i,2));
end


% ensure the tab group has the correct callback
set(handles.tgFreqTabs, 'SelectionChangeCallback', @(hObject, eventdata)NewFreqRangePane(hObject, eventdata, guidata(hObject)));

% remove any tabs we restored above
if (restored)
    handles = RemoveFreqPaneTabs(handles, hCover);
end


function [restored, hCover, handles] = RestoreFreqPaneTabs(handles)
% function [restored, hCover, handles] = RestoreFreqPaneTabs(handles)
% this function makes sure the frequency domain tabs exist
% before we modify them

freqTabGroup = findobj(handles.uiFreqDomain, 'tag', 'tgFreqTabs');
restored = (numel(freqTabGroup) == 0);
hCover = [];
if (restored)
    
    % cover it first to stop screen flashing
    hCover = CoverFig(ancestor(handles.uiFreqDomain, 'figure'));
    drawnow();
    
    % get all tabs
    hTabGroup = tgAncestor(handles.uiFreqDomain, 'uitabgroup');
    hTabs = get(hTabGroup, 'children');
    hTabs = hTabs(strcmpi(get(hTabs, 'type'), 'uitab'));

    % break them into selected and other
    hSelected = double(get(hTabGroup, 'SelectedTab'));

    % the non-selected ones
    hOther = hTabs(hTabs ~= hSelected);

    % restore "sub tabs" in unselected panes
    for i = 1:numel(hOther)
        tabGroupTag = sprintf('TabInfo_%s', get(hOther(i), 'tag'));
        tab_info = modUserData(hTabGroup, 'get', tabGroupTag);
        if numel(tab_info)
            modUserData(hTabGroup, 'remove', tabGroupTag);
            handles = RestoreFigureTabs(hTabGroup, handles, tab_info);
        end
    end
end

function handles = RemoveFreqPaneTabs(handles, hCover)
% function handles = RemoveFreqPaneTabs(handles, hCover)
% this function remove frequency tabs if the feature tab is not the 
% active tab of the parent tab group

% get all tabs
hTabGroup = tgAncestor(handles.uiFreqDomain, 'uitabgroup');
hTabs = get(hTabGroup, 'children');
hTabs = hTabs(strcmpi(get(hTabs, 'type'), 'uitab'));

% break them into selected and other
hSelected = double(get(hTabGroup, 'SelectedTab'));

% the non-selected ones
hOther = hTabs(hTabs ~= hSelected);

% remove "sub tabs" in unselected panes
for i = 1:numel(hOther)
    tabGroupTag = sprintf('TabInfo_%s', get(hOther(i), 'tag'));
    [tab_info, handles] = RemoveFigureTabs(hOther(i), handles);
    if numel(tab_info)
        modUserData(hTabGroup, 'add', tabGroupTag, tab_info);
    end
end

if numel(hCover)
    delete(hCover);
end






