function NewFreqRangePane(hObject, eventdata, handles)
% hObject    handle to the current object (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% is the current selction the new pane?
title = get(get(hObject, 'SelectedTab'), 'title');
if strcmpi(title, 'New')
    
    % add a new pane
    handles = AddFreqRangeTab(handles, 1);
    
    % if there's more than 1 range tab, ensure the user can delete them
    allTabs = get(handles.tgFreqTabs, 'children');
    types = get(allTabs, 'type');
    allTabs = allTabs(strcmpi(types, 'uitab'));
    newTab = findobj(allTabs, 'title', 'New');
    actTabs = allTabs(allTabs ~= newTab);
    
    if (numel(actTabs) > 1)
        set(actTabs, 'uicontextmenu', handles.uiFreqTabs);
    else
        set(actTabs, 'uicontextmenu', []);
    end
    
    % and update the handles
    guidata(hObject, handles);
end
