function featStruct = FeaturesFromPanel(handles)
% function featStruct = FeaturesFromPanel(handles)
% this function builds the output feature list

% initialise the feature structure
featStruct = CREFeatures();
featStruct = featStruct(1:0);  % empty it


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time domain features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get the selected time domain feature radio buttons
rb_buttons = findobj(handles.uiTimeDomain, 'style', 'radiobutton', 'value', 1);

% and process them
for i = 1:numel(rb_buttons)
    
    % get its tag
    tag = get(rb_buttons(i), 'tag');
    
    % strip the "rb" from it
    type = regexpi(tag, '(?<=^rb)\w+$', 'match', 'once');
    
    % any extra parameters?
    params = get(rb_buttons(i), 'userdata');
    if ~iscell(params)
        params = {};
    end
    
    % and create it
    features(end+1) = CREFeatures(type, params{:});
    
end

% for time domain features, also do the lag box
values = cellfun(@(x)(str2double(x)), get(handles.lbLag, 'String'));  % get all values
values = values(get(handles.lbLag, 'Value'));                         % but use only those selected

% which units are we working in?
unit_list = cellstr(get(handles.pmACorrUnits,'string'));
unit = unit_list{get(handles.pmACorrUnits,'value')};

% convert it to samples if needed
if strncmpi(unit, 'samples', 7)
    values = (values / 1000) * handles.data_set.fs;  % convert to samples
end

for i = 1:numel(values)
    features(end+1) = CREFeatures('acorr', values(i), handles.data_set.fs);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Frequency domain features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% go through each of the different frequency panes
hTabs = get(handles.tgFreqTabs, 'children');
types = get(hTabs, 'type');
hTabs = hTabs(strcmpi(types, 'uitab'));

if isfield(handles, 'data_set') && numel(handles.data_set)
    fs = handles.data_set.fs;
else
    fs = 30;  % for testing
end

% go through each one
for i = 1:(numel(hTabs) - 1) % N.B. the last tab is the "new" pane

    % get the frequency ranges to examine
    fl = str2double(get(handles.(sprintf('ebMinFreq%i', i)), 'string'));
    fh = str2double(get(handles.(sprintf('ebMaxFreq%i', i)), 'string'));

    % get the selected frequencey domain feature radio buttons
    rb_buttons = findobj(hTabs(i), 'style', 'radiobutton', 'value', 1);

    % and process them
    for j = 1:numel(rb_buttons)
        
        % get its tag
        tag = get(rb_buttons(j), 'tag');
        
        % strip the "rb" and the tab it comes from
        type = regexpi(tag, '(?<=^rb)[a-zA-Z_]+', 'match', 'once');
        
        % any extra parameters?
        %     params = get(rb_buttons(i), 'userdata');
        %     if ~iscell(params)
        %         params = {};
        %     end
        params = {fl, fh, fs};
        
        % and create it
        features(end+1) = CREFeatures(type, params{:});
        
    end

    % for frequency domain features also do the dominant frequency boxes
    list_boxes = findobj(hTabs(i), 'style', 'listbox');
    for j = 1:numel(list_boxes)
        
        % get selected values
        values = cellfun(@(x)(str2double(x)), get(list_boxes(j), 'String'));  % get all values
        values = values(get(list_boxes(j), 'Value'));                         % but use only those selected
        
        % get its tag
        tag = get(list_boxes(j), 'tag');
        
        % strip the "lb" from it
        type = regexpi(tag, '(?<=^lb)[a-zA-Z_]+', 'match', 'once');
        
        % and add each one
        for k = 1:numel(values)
            params = {values(k), fl, fh, fs};
            features(end+1) = CREFeatures(type, params{:});
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ranking features
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% get the selected time domain feature radio buttons
rb_buttons = findobj(handles.uiRanking, 'style', 'radiobutton', 'value', 1);

% and process them
for i = 1:numel(rb_buttons)
    
    % get its tag
    tag = get(rb_buttons(i), 'tag');
    
    % strip the "rb" from it
    type = regexpi(tag, '(?<=^rb)\w+$', 'match', 'once');
    
    % any extra parameters?
    params = get(rb_buttons(i), 'userdata');
    
    % and create it
    features(end+1) = CREFeatures(type, params{:});
    
end

% for ranking features, also do the percentiles box
values = cellfun(@(x)(str2double(x)), get(handles.lbPercentiles, 'String'));  % get all values
values = values(get(handles.lbPercentiles, 'Value'));                         % but use only those selected
for i = 1:numel(values)
    features(end+1) = CREFeatures('percentile', values(i));
end


% if any frequency features are used, make sure the prerequisite fft
% function knows the maximum resolution to use
preq_names = [features(:).prereq_name];
if any(strcmpi(preq_names, 'fft'))
    features(end+1) = CREFeatures('fft', fs, handles.featSettings.freqRange.fres);
    features(end).prereq_only = true;
end
