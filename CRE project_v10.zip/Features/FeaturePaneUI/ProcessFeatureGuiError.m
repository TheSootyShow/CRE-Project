function ProcessFeatureGuiError(ME)
% function ProcessFeatureGuiError(ME)
% function to catch errors that mat occur in this GUI

% check if this is the current figure
hFig = get(0, 'currentfigure');
if numel(hFig) && strcmpi(get(hFig, 'tag'), 'CREFeatureGui')
    
    % disable the gui during this process
    EnableDisableFig(hFig, 'off');
    
    % retrieve the current handles
    handles = guidata(hFig);
    
    % try to restore the gui to match the handles state
    try
       
        handles = CREFeatureGui('InitialiseGui', handles);
        guidata(hFig, handles);

        % let the user know what happened
        hErr = errordlg('An unexpected error occurred - the GUI has been reverted to its previous state');
        
        % wait for the user to close it
        while ishandle(hErr)
            pause(.2);
        end
        
        % re-enable the gui
        EnableDisableFig(hFig, 'on');
        
        % tell me about it
        if (isdeployed())
            error_txt = ME.getReport('extended', 'hyperlinks','off');
            errordlg(error_txt, 'Error detected', 'modal')
            EmailMe(error_txt);
        else
            % rethrow(ME);
        end
        
        % make it the current focus
        figure(hFig);
        
    catch
        
        % try to save the current settings
        try
            save_file = fullfile(getuserdir(), 'recovery_settings.mat'); 
            CREFeatureGui('miSave_Callback', hFig, save_file, handles);
            hErr = errordlg(sprintf('An unexpected error occurred and feature selection needs to exit\nAn attempt was made to save current settings to:\n%s', save_file), 'Unexpected Error', 'modal');
        catch 
            hErr = errordlg('An unexpected error occurred and feature selection needs to exit', 'Unexpected Error', 'modal');
        end
        
        % wait for the user to close it
        while ishandle(hErr)
            pause(.2);
        end
        
        % tell me about it
        if (isdeployed())
            error_txt = ME.getReport('extended', 'hyperlinks','off');
            errordlg(error_txt, 'Error detected', 'modal')
            EmailMe(error_txt);
        else
            % rethrow(ME);
        end
        
        % now close the gui
        handles.output = {'Cancel', handles.inputSettings};
        guidata(hFig, handles);

        % and close the gui
        CREFeatureGui('CREFeatureGui_CloseRequestFcn', hFig, [], handles);
        drawnow();
        
    end
else
    
    % do nothing
    
end
