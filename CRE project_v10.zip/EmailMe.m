function EmailMe(txt)
% function EmailMe(txt)
% function to email me some text

if (nargin < 1)
    txt = 'It worked!';
end

% Modify these two lines to reflect
% your account and password.
myaddress = 'awbsmith@gmail.com';
mypassword = 'Nope';

setpref('Internet','E_mail',myaddress);
setpref('Internet','SMTP_Server','smtp.gmail.com');
setpref('Internet','SMTP_Username',myaddress);
setpref('Internet','SMTP_Password',mypassword);

props = java.lang.System.getProperties;
props.setProperty('mail.smtp.auth','true');
props.setProperty('mail.smtp.socketFactory.class', ...
                  'javax.net.ssl.SSLSocketFactory');
props.setProperty('mail.smtp.socketFactory.port','465');

% add info to the header
date = datestr(now, 'yyyy-mm-dd HH:MM:SS');

[tmp, comp_name] = system('hostname');
comp_name = comp_name(isstrprop(comp_name, 'alphanum'));  % matlab seems to like add newlines in the name

% and send the email
try
    sendmail(myaddress, sprintf('CRE Project Error - %s (%s) ', comp_name, date), txt);
end