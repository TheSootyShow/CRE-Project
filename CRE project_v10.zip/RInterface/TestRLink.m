function valid = TestRLink()
% function valid = TestRLink()
% This function is used to check that the link to R
% is working as intended.  If it is not, a message box with instruction to
% properly link to R is created

global R_lInK_hANdle

valid = true;
try
    if (numel(R_lInK_hANdle) == 0)
        % Connect to an R Session if we haven't already
        openR();
    end
    putRdata('r_test_var', 1:10);
    x = getRdata('r_test_var');
    evalR('rm(r_test_var)');
catch
    
    %create a message box showing the user how to make this work
    RlinkRequirements();
    valid = false;
    
end





















