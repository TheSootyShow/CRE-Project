function [valid, msg, rHistory] = AddRPackages(packages)
% function [valid, msg, rHistory] = AddRPackages(packages)
% this function add R packges to the R session
% R should be open before calling htis function

rHistory = '';
msg = [];

% include libraries
for i = 1:numel(packages)
    [valid, eval_str] = AddRPackage(packages{i});
    if (~valid)
        msg = sprintf('Could not include library: %s\n(Failed to evaluate the R command: %s)', packages{i}, eval_str);
        return;
    end
    rHistory = sprintf('%s%s\n', rHistory, eval_str);
end