function [added,eval_str] = AddRPackage(package)
% function [added,eval_str] = AddRPackage(package)
% function to add a package to the library in R

if ~(IsRopen())
    if (~openR())
        RlinkRequirements();
        error('Could not open the connection to R');
    end
end

% check it works
eval_str = sprintf('require("%s")', package);
[~, sts] = evalR(eval_str);

% if it didnt work, try installing the package
if (~sts)
    install_str = sprintf('install.packages("%s")', package);
    [~, sts] = evalR(install_str);
    if (sts)
        [~, sts] = evalR(eval_str);
        eval_str = sprintf('%s\n%s',install_str,eval_str);
    end
end
added = sts;