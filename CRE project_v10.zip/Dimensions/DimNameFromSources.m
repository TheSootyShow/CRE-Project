function name = DimNameFromSources(primary_names, tag, sources, args)
% function name = DimNameFromSources(primary_names, tag, sources, args)
% function to create a name for a derived dimension
% does not use argument info
%
% primary_names - the names of the primary dimensions
% tag           - the type of derived dim this is
% sources       - see InitDerivedDim.m

% build the list of all sources
source_names = primary_names(sources{1,2});
source_names = [source_names(:); sources{1,3}(:)];


% now build the name
name = CreateDimName(tag, source_names, varargin, args{:});
