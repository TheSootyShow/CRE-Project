function varargout = CRE_version(version_str)
% this function returns the current version of the project:
% [version_str, version_vec] = CRE_version();
% or translates a version string into a 3 element vector:
% [version_vec, is_current] = CRE_version(version_str);

% current version
current_vers = [0, 1, 0];

if (nargin == 1) && numel(version_str) && ischar(version_str)
    
    % convert the string to a 3 element vector
    version_vec = regexp(version_str, '_', 'split');
    version_vec = cellfun(@str2double, version_vec);
    if (numel(version_vec) < 3)
        version_vec = [zeros(1, 3 - numel(version_vec)), version_vec];
    end
    
    % first difference from the current version
    df = find(current_vers ~= version_vec, 1, 'first');
    is_current  = (numel(df) == 0) || (current_vers(df) < version_vec(df));
    
    % assign outputs
    varargout{1} = version_vec;
    varargout{2} = is_current;
    
else
    
    % current version
    version_vec = current_vers;
    
    % string form
    version_str = sprintf('%i_%i_%i', current_vers(1), current_vers(2), current_vers(3));
    
    % assign outputs
    varargout{1} = version_str;
    varargout{2} = version_vec;
    
    
end
