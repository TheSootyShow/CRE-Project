function [line_h, data_set] = PlotDataSet(data_set, plotOptions, hAxis, cols, opts, status_func)
% function [line_h, data_set] = PlotDataSet(data_set, plotOptions, hAxis, cols)
% function [line_h, data_set] = PlotDataSet(data_set, times, is_time, dims, hAxis, cols)
% this function retrieves a block of data from the data set
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% data_set      - the data set structure to retrieve tha values from
%                 (see ImportCSV.m)
%
% plotOptions   - strcuture containing the plot options (see
%                 CREPlotOptions.m)
%
% hAxis         - handle of the axis to plot onto.  Default is to create a new
%                 figure
%
% col           - colour of the plot (default is 'bkmgcr').  One colour is
%                 needed per dimension
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% line_h   - a vector containing the handle to each plotted line (1 element
%            per dimension)


% default colour order
def_cols = 'bkmgcr';


% supply defaults
if (nargin < 6)
    status_func = [];
end


if (nargin < 5) || (numel(opts) == 0)

    % these should match ImportCSV.m
    opts.max_load_els     = 1e6;  % load the data in full if it has less than this many elements
    opts.max_plot_els     = 1e4;  % limit each line to 10,000 points per line
    
elseif ~isfield(opts, 'max_plot_els')

    opts.opts.max_plot_els     = 1e4;  % limit each line to 10,000 points per line
    
end

if (nargin < 4) || (numel(cols) == 0)
    cols = def_cols;
end

if (nargin < 3) || (numel(hAxis) == 0)
    figure;
    hAxis = gca;
    set(hAxis, 'xgrid', 'on');
    set(hAxis, 'ygrid', 'on');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% turn he time range to plot into indices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[rel_time, indexs] = TimeRangeToRelative(data_set, plotOptions.timeRange.tstamp);
n_points = indexs(2) - indexs(1) + 1;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the dimensions to plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% convert the dimenion info structure into a form where
outputDims = ParseDimInfo(plotOptions.dimInfo, data_set);


% do we need to down sample points for the lines?
if (n_points > opts.max_plot_els)
    dr = ceil(n_points / opts.max_plot_els);
    n_plot = 1 + floor((n_points-1) / dr);
else
    dr = 1;  % no down sampling
    n_plot = n_points;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% do we need to grab the data in multiple blocks?
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

block_points = ceil(opts.max_load_els / outputDims.n_dims);
n_blocks = ceil(n_points / block_points);

% get indexs ranges for the blocks
block_indexs = zeros(n_blocks, 2);
for i = 1:n_blocks
    block_indexs(i, :) = [(i-1) * block_points, i*block_points-1] + indexs(1);
end
block_indexs(end, 2) = indexs(2);




%%%%%%%%%%%%%%%%%%%%%%%%%%
% grab the data
%%%%%%%%%%%%%%%%%%%%%%%%%%

pX = zeros(n_plot, outputDims.n_display);  % allocate space
cp = 0;
cs = 1;
for i = 1:n_blocks
    
    % X data from this block
    bX = GetDerivedDims(data_set, block_indexs(i, 1), block_indexs(i, 2), outputDims); 
    
    % down sample if needed
    if (dr > 1)
        bX = bX(cs:dr:end, :);
        cs = cs + size(bX,1)*dr - block_points;
    end
    
    % and store
    pX(cp+1:cp+size(bX,1), :) = bX;
    cp = cp + size(bX,1);
    
    % update the status
    if numel(status_func)
        feval(status_func, cp, n_plot);
    end
    
end

% sanity check
if (n_plot ~= size(pX,1))
    error('PlotDataSet::Unexpected number of points to plot');
end


% create time vector for the plot
if (plotOptions.timeRange.is_time)
    t = linspace(rel_time(1), rel_time(2), size(pX,1));  % in relative seconds for now
else
    t = indexs(1) : dr : indexs(2);
end


% get the display name for each dimenions
[dim_names, selected] = GetAllDimensionNames(plotOptions.dimInfo);
dim_names = dim_names(selected);

% and plot it
line_h = zeros(1, outputDims.n_display);
leg_txt = cell(1, outputDims.n_display);

astate = get(hAxis, 'nextplot');
set(hAxis, 'nextplot', 'add');
for i = 1:outputDims.n_display
    line_h(i) = plot(hAxis, t(:), pX(:, i), cols(rem(i-1, numel(cols))+1));
    leg_txt{i} = dim_names{i};
end
set(hAxis, 'xgrid', 'on');
set(hAxis, 'ygrid', 'on');
set(hAxis, 'nextplot', astate);

% add a legend
legend(hAxis, line_h, leg_txt);

% now mess with all the ticks if we dont want the output by index or
% reltive time in seconds
% if we are after time in anything but seconds, update now
if (plotOptions.timeRange.is_time) && ((plotOptions.timeRange.is_hhmmss > 0) || (~plotOptions.timeRange.is_relative))
    
    % get the tick locations
    x_ticks = get(hAxis, 'xtick');
    x_tick_labels = cell(size(x_ticks));
    for i = 1:numel(x_ticks)
        [x_tick_labels{i}, format] = ConvertTime(x_ticks(i), data_set.tstamp, plotOptions.timeRange.is_hhmmss, ~plotOptions.timeRange.is_relative);
    end
    
    % replace the labels
    set(hAxis, 'xticklabel', x_tick_labels);
    
    % and rotate them 45 degrees
    rotateticklabel(hAxis, 45);
    
    xlabel(sprintf('Time (%s)', format));
    
elseif (plotOptions.timeRange.is_time)
    xlabel(hAxis, 'Time (s)');
else
    xlabel(hAxis, 'Index');
end



% delete the y label if it exists
y_label = get(hAxis, 'ylabel');
if numel(y_label)
    delete(y_label);
end






