function varargout = CREListDlg(varargin)
% CREListDlg(list_cell, keyword, keyval)
% create a list box style selection gui
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% list_cell - a cell array of strings to populate teh list box with
%
% keywords:
% 'title'        - sets the title for the gui to be the corresponding string in keyval   
% 'list_title'   - sets the title for the list box to be the corresponding string in keyval
% 'list_select'  - default list box selection
% 'list_multi'   - enable multiple selections (default true)
% 'txt_title'    - if this options is used, a text input is created under the list box
%                  with the specified title.  If this is a cell array, the
%                  corresponding number of text input boxes are created
% 'default_txt'  - if this options is used, a text input is created under the list box
%                  with the specified default answer. If this is a cell array, the
%                  corresponding number of text input boxes dialogs are created


% Last Modified by GUIDE v2.5 03-Apr-2014 01:24:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CREListDlg_OpeningFcn, ...
                   'gui_OutputFcn',  @CREListDlg_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before CREListDlg is made visible.
function CREListDlg_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to CREListDlg (see VARARGIN)

% Choose default command line output for CREListDlg
handles.output = 'Cancel';

% Update handles structure
guidata(hObject, handles);

% Determine the position of the dialog - centered on the callback figure
% if available, else, centered on the screen
FigPos=get(0,'DefaultFigurePosition');
OldUnits = get(hObject, 'Units');
set(hObject, 'Units', 'pixels');
OldPos = get(hObject,'Position');
FigWidth = OldPos(3);
FigHeight = OldPos(4);
if isempty(gcbf)
    ScreenUnits=get(0,'Units');
    set(0,'Units','pixels');
    ScreenSize=get(0,'ScreenSize');
    set(0,'Units',ScreenUnits);

    FigPos(1)=1/2*(ScreenSize(3)-FigWidth);
    FigPos(2)=2/3*(ScreenSize(4)-FigHeight);
else
    GCBFOldUnits = get(gcbf,'Units');
    set(gcbf,'Units','pixels');
    GCBFPos = get(gcbf,'Position');
    set(gcbf,'Units',GCBFOldUnits);
    FigPos(1:2) = [(GCBFPos(1) + GCBFPos(3) / 2) - FigWidth / 2, ...
                   (GCBFPos(2) + GCBFPos(4) / 2) - FigHeight / 2];
end
FigPos(3:4)=[FigWidth FigHeight];
set(hObject, 'Position', FigPos);
set(hObject, 'Units', OldUnits);

% get the options list
list_string = varargin{1};  % this always exists
set(handles.lbOptions, 'string', list_string);
set(handles.lbOptions, 'max', numel(list_string));
set(handles.lbOptions, 'units', 'centimeters');

% process other inputs
txt_titles = {};
txt_answers = {};
for i = 2:2:numel(varargin)
    if strcmpi(varargin{i}, 'title')
        set(hObject, 'name', varargin{i+1});
    elseif strcmpi(varargin{i}, 'list_title')
        set(handles.txtListText, 'string', varargin{i+1});
    elseif strcmpi(varargin{i}, 'txt_title')
        if iscell(varargin{i+1})
            txt_titles = varargin{i+1};
        else
            txt_titles = varargin(i+1);
        end
    elseif strcmpi(varargin{i}, 'default_txt')
        if iscell(varargin{i+1})
            txt_answers = varargin{i+1};
        else
            txt_answers = varargin(i+1);
        end
    elseif strcmpi(varargin{i}, 'list_multi')
        if (~varargin{i+1})
            set(handles.lbOptions, 'max', 1);
        end
    elseif strcmpi(varargin{i}, 'list_select')
        set(handles.lbOptions, 'value', varargin{i+1});
    end
end

% how many text input boxes?
handles.n_txt = max(numel(txt_titles), numel(txt_answers));

% create them all
handles.txt_title_h = zeros(handles.n_txt, 1);
handles.txt_resp_h = zeros(handles.n_txt, 1);
list_pos = get(handles.txtListText, 'position');
for i = 1:handles.n_txt
    
    % create the title
    handles.txt_title_h(i) = uicontrol(hObject, 'style', 'text');
    set(handles.txt_title_h(i), 'horizontalalignment', 'left');
    if (numel(txt_titles) >= i)
        set(handles.txt_title_h(i), 'string', txt_titles{i});
    end
    
    % create the response
    handles.txt_resp_h(i) = uicontrol(hObject, 'style', 'edit');
    
    % make its size the same width as the list box
    set(handles.txt_resp_h(i), 'units', get(handles.txtListText, 'units'));
    pos = get(handles.txt_resp_h(i), 'position');
    pos(3) = list_pos(3);
    set(handles.txt_resp_h(i),  'position', pos);
    set(handles.txt_resp_h(i), 'horizontalalignment', 'left');
    set(handles.txt_resp_h(i), 'backgroundcolor', 'white')
        
    % and set default text
    if (numel(txt_answers) >= i)
        set(handles.txt_resp_h(i), 'string', txt_answers{i});
    end
end

% commit
guidata(hObject, handles);

% and resize
CREListDlg_ResizeFcn(hObject, eventdata, handles);


% Make the GUI modal
set(handles.CREListDlg,'WindowStyle','modal');

% UIWAIT makes CREListDlg wait for user response (see UIRESUME)
uiwait(handles.CREListDlg);

% --- Outputs from this function are returned to the command line.
function varargout = CREListDlg_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

resp = handles.output;

% add the rest of the outputs
handles.output = cell(1, 2 + numel(handles.txt_resp_h));
handles.output(1:2) = {[], get(handles.lbOptions, 'value')};
text_resp = cell(1, numel(handles.txt_resp_h));
for i = 1:numel(handles.txt_resp_h)
    text_resp{i} = get(handles.txt_resp_h(i), 'string');
end
handles.output{3} = text_resp;

% add the response
if numel(resp) && ischar(resp) && strcmpi(resp, get(handles.pbOK,'String'))
    handles.output{1} = resp;
else
    handles.output{1} = get(handles.pbCancel,'String');
end
   

% Get default command line output from handles structure
varargout = handles.output(1:nargout);

% The figure can be deleted now
delete(handles.CREListDlg);

% --- Executes on button press in pbOK.
function pbOK_Callback(hObject, eventdata, handles)
% hObject    handle to pbOK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% response
handles.output = get(hObject, 'string');

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CREListDlg);

% --- Executes on button press in pbCancel.
function pbCancel_Callback(hObject, eventdata, handles)
% hObject    handle to pbCancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% response
handles.output = get(hObject, 'string');

% Update handles structure
guidata(hObject, handles);

% Use UIRESUME instead of delete because the OutputFcn needs
% to get the updated handles structure.
uiresume(handles.CREListDlg);


% --- Executes when user attempts to close CREListDlg.
function CREListDlg_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to CREListDlg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isequal(get(hObject, 'waitstatus'), 'waiting')
    % The GUI is still in UIWAIT, us UIRESUME
    uiresume(hObject);
else
    % The GUI is no longer waiting, just close it
    delete(hObject);
end


% --- Executes on key press over CREListDlg with no controls selected.
function CREListDlg_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to CREListDlg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Check for "enter" or "escape"
char = get(hObject,'CurrentKey');
close_gui = false;
if isequal(char,'escape')
    
    % escape is treated as "Cancel"
    close_gui = true;
    handles.output = get(handles.pbCancel,'String');

elseif isequal(char,'return')
    
    % return is treated as "OK"
    close_gui = true;
    handles.output = get(handles.pbOK,'String');
    
end

% Closing the UI?
if (close_gui)
    
    guidata(hObject, handles);
    uiresume(handles.CREListDlg);
end    


% --- Executes on selection change in lbOptions.
function lbOptions_Callback(hObject, eventdata, handles)
% hObject    handle to lbOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lbOptions contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lbOptions


% --- Executes during object creation, after setting all properties.
function lbOptions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lbOptions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when CREListDlg is resized.
function CREListDlg_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to CREListDlg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (RunResizeFcn(hObject, handles))

	% tell the gui we are resizing to the current size
	CheckGuiSize(hObject);
    
    % standardized gaps between objects
    [smallGap, normGap, largeGap] = DefaultPaneGaps();
    
    % intersperse the title and text boxes
    if (handles.n_txt)
        txt_mixed = [handles.txt_title_h, handles.txt_resp_h].';
    else
        txt_mixed = [];
    end

    % build the structure of this gui
    pane_grid = [handles.txtListText; handles.lbOptions; txt_mixed(:)]; 
    pane_grid = [repmat(pane_grid, 1, 2); handles.pbCancel, handles.pbOK];
    
    % to facilitate sizing
    ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
    ppcm = ppi / 2.54;                                          % pixels per centimeter
    
    % verical spacing
    v_space_lb = smallGap; % space between list and title
    v_space_b = largeGap;  % space between buttons and whatever is above them
    if (numel(txt_mixed) > 0)
        v_space_txt = [largeGap; repmat([smallGap; normGap], size(txt_mixed,2)-1); smallGap];
    else
        v_space_txt = [];
    end
    v_space = repmat([v_space_lb; v_space_txt; v_space_b],1,2);
    
    % horizontal spaceing
    h_space = zeros(size(pane_grid,1),1);
    h_space(end) = ppcm;  % 1cm at least between buttons
    
    % and call the resize
    ResizePaneFromGrid(num2cell(pane_grid), h_space, v_space);
    
    % dont allow it to be resized again
    set(hObject, 'Resize', 'off');
        
end
    
