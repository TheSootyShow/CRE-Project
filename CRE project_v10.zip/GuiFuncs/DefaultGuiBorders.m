function [paneGap, paneBorder, figBorder] = DefaultGuiBorders()
% function [paneGap, paneBorder, figBorder] = DefaultGuiBorders()
% function to define default spacing between ui panels in a figure

paneGap    = [.2, .2];                 % leave .gap bewteen each pane [left, bottom]
paneBorder = [.2, .2, .25, .35];       % leave between ui object withing the pane and the pane border [left, bottom, right, top]
figBorder  = [.1,.1, .2, .25];         % leave .1 cm between pane and figure (only used if a template is created) [left, bottom, right, top]

% add extra distance from the frame to the text
ppi = get(0, 'ScreenPixelsPerInch');                        % pixels per inch
ppcm = ppi / 2.54;                                          % pixels per centimeter
paneBorder = ceil(paneBorder * ppcm);                    % left bottom right top
paneGap = ceil(paneGap * ppcm);
figBorder = ceil(figBorder * ppcm);                      % left bottom right top