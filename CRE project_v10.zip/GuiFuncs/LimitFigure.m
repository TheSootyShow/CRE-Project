function LimitFigure(hFig)
% function LimitFigure(hFig)
% function to limit the size of the figure to the maximum allowable
% size

% its current size
old_units = get(hFig, 'units');
set(hFig, 'units', 'pixels');
fPos = get(hFig, 'position');

% the maximum usable position
usablePos = GetUsableScreenSize('pixels', hFig);

% horizontally
if (fPos(3) > usablePos(3))
    fPos([1,3]) = usablePos([1,3]);
else
    fPos(1) = max(fPos(1), usablePos(1));
end

% vertically
if (fPos(4) > usablePos(4))
    fPos([2,4]) = usablePos([2,4]);
else
    fPos(2) = max(fPos(2), usablePos(2));
end
  
% update
set(hFig, 'position', fPos);
set(hFig, 'units', old_units);
setappdata(hFig, 'AWBSOnscreen', true);  % matlab's move gui function loves shifting the gui offscreen.  movegui.m has been changed to do nothing when this is set
