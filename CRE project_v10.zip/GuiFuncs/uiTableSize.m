function [prefSize, tlx, tly] = uiTableSize(uiTable)
% function [prefSize, tlx, tly] = uiTableSize(uiTable)
% function to turn a uitable into a comapct form

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% place it in a unique location for now
% so findjobj will work
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(uiTable, 'units', 'pixels');
opos = get(uiTable, 'Position');
pos = [-opos(3) - round(100*rand(1)), opos(2:end)];
set(uiTable, 'Position', pos);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find the java objects
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% size them with java
jScrollPane = findjobj(uiTable);

% never display the scrolls
set(jScrollPane,'VerticalScrollBarPolicy', javax.swing.JScrollPane.VERTICAL_SCROLLBAR_NEVER);    
set(jScrollPane,'HorizontalScrollBarPolicy', javax.swing.JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);  

% get the viewport and the table
jViewPort = jScrollPane.getViewport;  % get the view portion object
jTable = jViewPort.getView;   % get access to the java table from this

% are there row and column labels?
hasColLabels = numel(get(uiTable, 'ColumnName')) > 0;
hasRowLabels = numel(get(uiTable, 'RowName')) > 0;

% record the locations of each vertex in the table grid
[tlx, tly] = deal(zeros(jTable.getRowCount + hasColLabels + 1, jTable.getColumnCount + hasRowLabels + 1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the total width
%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% row labels are in a seperate viewport to the main table
width = 0;
if (hasRowLabels)
    width = width + jScrollPane.getRowHeader.getWidth() + jTable.getRowMargin(); %assumes jTable.getRowMArgin is the same as the gap between the two tables
    tlx(:,2) = width;
end


% width = jTable.getColumnModel().getTotalColumnWidth;
for i = 1:jTable.getColumnCount
    width = width + jTable.getColumnModel().getColumn(i-1).getWidth;
    tlx(:,i+1+hasRowLabels) = width;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% get the total height
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% and add space for column headers
height = 0;
if (hasColLabels)
    height = height + jTable.getTableHeader.getHeight;
    tly(2,:) = height;
end

% get row heights
for i = 1:jTable.getRowCount
    height = height + jTable.getRowHeight(i-1);
    tly(i+1+hasColLabels, :) = height;
end

% return tly as matlab style (0 at the bottom)
tly = height - tly;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% now set the position
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prefSize = [width, height];
pos = [opos(1:2), prefSize];
set(uiTable, 'Position', pos);





