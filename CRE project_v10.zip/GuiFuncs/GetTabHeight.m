function tabHeight = GetTabHeight()
%  function tabHeight = GetTabHeight()
% function to find the height of the selectable region of tabs

persistent tabHeightStatic


if (numel(tabHeightStatic) == 0)

    % test it empirically (create the figure as visible but offscreen)
    hFig = figure('units', 'centimeters', 'position', [-10, 1, 5 5], 'visible', 'on');
    
    % the tab group
    hGroup = uitabgroup('parent', hFig, 'tag', 'tgMainTab', 'units', 'pixels');
    
    % make a tab
    hTab = uitab(hGroup, 'tag', 'tmTimeTab', 'title', 'Tab 1');
    hTabPane = uipanel(hTab, 'units', 'pixels');
    
    % make a copy of that panel
    hFig(2) = figure('units', get(hFig, 'units'), 'position', get(hFig, 'position'), 'visible', get(hFig, 'visible'));
    hCopy = copyobj(hTabPane, hFig(2));
    
    % and find the height
    gPos = get(hGroup, 'position');
    tPos = get(hCopy, 'position');
    close(hFig);
    tabHeight = gPos(4) - (tPos(2) + tPos(4) - 1);
    tabHeightStatic = tabHeight;
    
else
    tabHeight = tabHeightStatic;
end