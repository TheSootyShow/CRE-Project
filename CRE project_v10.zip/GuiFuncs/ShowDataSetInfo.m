function txt_h = ShowDataSetInfo(frame_h, data_set, hhmmss)
% function ShowDataSetInfo(frame_h, data_set, hhmmss)
% this function displays data set information
% returns the handles of all used text boxes

% if there's no data set - dont do anything
if (numel(data_set) == 0)
    return;
end

% get the height and handle of the frame's title
[title_height, hTitle] = GetPanelTextHeight(frame_h, true);

% delete the old version
old_txt = findobj(frame_h, 'type', 'hgjavacomponent');
delete(old_txt);

% get the screen resolution
pix_cm = (get(0, 'ScreenPixelsPerInch')) / 2.54;  % pixels per centimeter
bgap = ceil(.2 * pix_cm);  % .2 cm gap to borders
cgap = ceil(.5 * pix_cm);  % .5 cm gap to bewteen columns
vgap = ceil(.01 * pix_cm);  % .01 cm gap between rows

% the three columns here are:
% [display name, reference field, display function]
% so the final text wil look like:
% 'display name: display function(data_set.reference field)
display = {'Name:'        'name',        []; ...
        'File:',          'file_name',   @(file)GetFileName(file, data_set); ...
        'Device:',        'device_type', []; ...
        'Time:',          'tstamp',      @(t)TimeStr(data_set); ...
        'Duration:',      'fs',          @(t)DurationStr(data_set, hhmmss); ...
        '#Points:',       'num_points',  @(n)NumPoints(data_set, n); ...
        'Dims:',          'dims',        []; ...
        'Sampling:',      'fs',          @(fs)sprintf('%s (Hz)', num2str(fs));
        'In Memory:',     'data',        @(x)MemString(data_set)};

% font info to use by default
font = javax.swing.plaf.FontUIResource('Calibri', 0, 11);
       
       
%  new way -  a text box for all
label_width = 0;  % maximum size in pixels of the descriptors
def_height = 0;
txt_h = NaN(size(display,1), 2);
disp_values = cell(size(display,1), 2);
for i = 1:size(display,1)
    
    % does it need converting?
    if numel(display{i,3})
        disp_values{i} = feval(display{i,3}, data_set.(display{i,2}));
    elseif numel(data_set.(display{i,2}))
        disp_values{i} = data_set.(display{i,2});
    else
        disp_values{i} = 'N/A';
    end
    
    % convert to a string
    if ~ischar(disp_values{i})
        disp_values{i} = num2str(disp_values{i});
    end
    
    % use a jlabel (for consistency with below)
    % txt_h(i,1) = uicontrol('style', 'text', 'string', display{i,1}, 'FontName', 'FixedWidth', 'HorizontalAlignment', 'left', 'visible', 'off', 'units', 'pixels' , 'parent', frame_h);
    [jText, txt_h(i,1)] = javacomponent({'javax.swing.JLabel', ['<html>', display{i,1},'</html>']}, [], frame_h);
    
    % update appearance
    jText.setFont(font);
    jText.setOpaque(false);
    jText.setVerticalAlignment(javax.swing.JLabel.BOTTOM);
    
    % record how big we need the first 'column' to be
    def_height = max(jText.getPreferredSize.height, def_height);
    label_width = max(label_width, jText.getPreferredSize.width);
       
end

% how much space to work with?
old_units = get(frame_h, 'units');
set(frame_h, 'units', 'pixels');
frame_pos = get(frame_h, 'position');
frame_width = frame_pos(3);
set(frame_h, 'units', old_units);

% get the position of the pushbutton
hButton = findobj(frame_h, 'style', 'pushbutton');
set(hButton, 'units', 'pixels');
pbPos = get(hButton, 'position');
pbHeight = pbPos(2) + pbPos(4);


% now we have the maximum width of we can use for text boxes,
% start placing things
avail_width = frame_width - 2*bgap - cgap - label_width;
cheight = frame_pos(4) - bgap - title_height;  % height at the top of this row
for i = 1:size(display,1)
   
    % set the label first
    set(txt_h(i,1), 'position', [bgap, cheight - def_height, label_width, def_height]);
    
    % create a jLabel
    % html_str = strrep(['<html>',disp_values{i},'</html>'], '=', '&#61');
    html_str = ['<html>',disp_values{i},'</html>'];
    [jText, txt_h(i,2)] = javacomponent({'javax.swing.JLabel', html_str}, [], frame_h);
    %jText = javaObjectEDT('javax.swing.JLabel', ['<html>', disp_values{i},'</html>']);

    % update appearance
    jText.setFont(font);
    jText.setOpaque(false);
    jText.setVerticalAlignment(javax.swing.JLabel.BOTTOM);

    % give it the fixed width
    jObjFixedWidth(jText, avail_width, avail_width);       % add left because when me move to the left the right edge dos
    pref_size = java.awt.Dimension(avail_width, jText.getPreferredSize.height());
    jText.setPreferredSize(pref_size);
    jText.setMaximumSize(pref_size);
    jText.setMinimumSize(pref_size);
        
    % add it to the panel
    des_height = pref_size.height + 5;
    set(txt_h(i,2), 'parent', frame_h);
    set(txt_h(i,2), 'position', [label_width + cgap, cheight - pref_size.height, avail_width, des_height]);
    % set(txt_h(i,2), 'position', [label_width + cgap, cheight, avail_width, des_height]);
    
    % and update the height for the next entry
    cheight = cheight - des_height - vgap;
    
    if (cheight < pbHeight)
        set(txt_h(i,:), 'visible', 'off');
    end
    
    

    
%     giving up on this since I can't get text wrap to work    
    % set the width using pixels
%     txt_h(i,2) = uicontrol('style', 'text', 'string', disp_values{i}, 'FontName', 'FixedWidth', 'HorizontalAlignment', 'left', 'visible', 'off', 'units', 'pixels' , 'parent', frame_h);
%     pos = get(txt_h(i,2), 'position');
%     pos(3) = avail_width - 1;
%     pos(4) = 10 * def_height;
%     set(txt_h(i,2), 'position', pos);
%     
%     % and find out how wide this is in characters
%     set(txt_h(i,2), 'units', 'characters');
%     pos_chars = get(txt_h(i,2), 'position');
%     set(txt_h(i,2), 'units', 'pixels');
%     
%     % use textwrap to multiline it 
%     [disp_str, des_pos] = textwrap(txt_h(i,2), {get(txt_h(i,2), 'string')}, floor(pos_chars(3)));
%     des_pos(1) = label_width + cgap;
%     des_pos(2) = cheight - des_pos(4);
%     des_pos(3) = pos(3);
%     set(txt_h(i,2), 'string', disp_str);
%     set(txt_h(i,2), 'position', des_pos);
%     
%     % and update the height for the next entry
%     cheight = cheight - des_pos(4) - vgap;
    
end

% finally make it all visible
set(txt_h, 'visible', 'on');


       
       
       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Old Way
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % pad the first column of display so they're all the same width
% max_els = max(cellfun(@numel, display(:,1)));
% 
% % the display string
% disp_str = ''; % old way
%        
% % use this to create the display string in cell form
% display_vals = cell(size(display,1), 1);
% for i = 1:size(display,1)
%     
%     % does it need converting?
%     if numel(display{i,3})
%         display_vals{i} = feval(display{i,3}, data_set.(display{i,2}));
%     else
%         display_vals{i} = data_set.(display{i,2});
%     end
%     
%     % convert to a string
%     if ~ischar(display_vals{i})
%         display_vals{i} = num2str(display_vals{i});
%     end
%     
%     % apply padding to the displayed value when putting it together
%     disp_str = sprintf('%s%s:%s %s\n', disp_str, display{i,1}, repmat(' ', 1, max_els - numel(display{i,1})), display_vals{i});
% end
% disp_str(end) = [];  % dont need the final line break
% 
% % and set the text box
% set(txt_h, 'FontName', 'FixedWidth');
% set(txt_h, 'HorizontalAlignment', 'left');
% set(txt_h, 'String', disp_str);



function file_name = GetFileName(file_name, data_set)       
% function str = GetFileName(file_name)       
% function to remove the directory from file name

if ~strcmpi(data_set.set_type, 'batch')
    [dir, file_name, ext] = fileparts(file_name);
    file_name = [file_name, ext];
else
    file_name = sprintf('%i file(s) in batch set', numel(data_set.ds_headers));
end
       
       
function str = MemString(data_set)       
% function str = MemString(data_set)       
% creates a string to display the memory

if ~strcmpi(data_set.set_type, 'batch')
    mem_req = (data_set.num_points * data_set.dims) * 8;  % bytes (8 per double)
    mem_req = mem_req / 1e6;                              % mb
    
    if numel(data_set.data)
        str = sprintf('Yes (%0.2f mb)', mem_req);
    else
        str = sprintf('No (%0.2f mb required)', mem_req);
    end
else
    str = 'No';
end


function str = TimeStr(data_set)     
% function str = TimeStr(data_set)     
% convetr the timestamp to a string

if ~strcmpi(data_set.set_type, 'batch')
    str = datestr(data_set.tstamp, 'HH:MM:SS dd/mm/yyyy');
else
    str = 'N/A';
end
       
function str = DurationStr(data_set, hhmmss)     
% function str = DurationStr(t, hhmmss)     
% function to build a duration string

if ~strcmpi(data_set.set_type, 'batch') || (data_set.num_points > 0)

    % get the duration
    t = (data_set.num_points - 1) * 1 / data_set.fs;
    
    % if its in hh:mm:ss prune off decimals
    if (hhmmss)
        t = ceil(t);
    end
    
    % convert it to a string
    [str, format] = ConvertTime(t, 0, hhmmss, false);
    
    str = sprintf('%s (%s)', str, format);
    
else
    str = 'N/A';
end

function str = NumPoints(data_set, n) 
% function str = NumPoints(data_set, n)

if ~strcmpi(data_set.set_type, 'batch') || (data_set.num_points > 0)
    str = num2str(n);
    if (data_set.view_type == 1)
        str = [str, ' (approx)'];
    end
else
    str = 'N/A';
end    


    



