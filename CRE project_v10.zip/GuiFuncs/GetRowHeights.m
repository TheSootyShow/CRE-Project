function [row_heights, ext_min, ext_max] = GetRowHeights(hGrid, heights, vert_copies, horz_copies, vspace, allow_leak)
% function [row_heights, ext_min, ext_max] = GetRowHeights(hGrid, heights, vert_copies, horz_copies, vspace, allow_leak)
% this function determines the minimum columns heights for a grid of objects
% with heights specified in "heights".  
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% hGrid         - a list of the handles to the uicomponents.  NaN if the
%                space is empty, repeated if its desired to stretch the
%                component
%
% heights       - the width of the object
% 
% vert_copies   - the number of rows an object is spread over. 
%
% horz_copies   - the number of columns an object is spread over. 
%
% allow_leak - if true, objects are allowed to "leak" into unpopulated
%                parts of the grid

% the size of the inputs
[n_rows, n_cols] = size(hGrid);

% which ones are filled and which are actually handles?
is_filled = cellfun(@(x)(numel(x) > 0), hGrid);
is_handle = cellfun(@(x)((numel(x) > 0) && isnumeric(x) && ishandle(x)), hGrid);


% pad out the heights so each ui object that only uses one row has a height
heights_pad = heights;
vert_copies_pad = vert_copies;
[r, c] = find(horz_copies > 1);
for i = 1:numel(r)
    % adjust these columns
    c_adj = c(i):c(i)+horz_copies(r(i), c(i))-1;
    heights_pad(r(i), c_adj) = heights(r(i), c(i));
    vert_copies_pad(r(i), c_adj) = vert_copies(r(i), c(i));
end
    
% the "pure" height (i.e. only objects with 1 copy per column)
use = (vert_copies_pad == 1);
if (allow_leak)
   use(2:end, :)   =  use(2:end, :) & is_filled(1:end-1, :);
   use(1:end-1, :) =  use(1:end-1, :) & is_filled(2:end, :);
end
height_adj  = heights_pad .* use;


% add the vertical gap (but ignore it if there're two things the same next
% to each other, i.e. a repeated uiobject)
ignore_mask_v = cellfun(@(x,y)((numel(x) == 0) || ~isnumeric(x) || (numel(y) == 0) || ~isnumeric(y) || isequal(x,y)), hGrid(1:end-1, :), hGrid(2:end, :));    
height_net = [height_adj(1,:); (~ignore_mask_v) .* vspace + height_adj(2:end, :)];
gap = height_net - height_adj;  % individual gaps

% heights based on only the "pure" ones
row_heights = max(height_net, [], 2);

% remember the row gap between rows
row_gap = min(repmat(row_heights, 1, n_cols) - height_adj, [], 2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create a map of how things spread over the columns
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pre_height = zeros(size(heights));
post_height = zeros(size(heights));

% keep track of how much we have spread into a column
used_leakage = zeros(size(heights));

% now check ones with repeated columns will fit


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Do the undetermined ones in two stages
% stage 1 are ui components that can't leak
% stage 2 are ui components that do leak
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this is convenient for processing leaked sections
vspace = [zeros(1, n_cols); vspace; zeros(1, n_cols)];

processed = use | (vert_copies == 0);
for s = 1:(1+allow_leak)
    
    
    if (s == 1)  % first stage, do ones that stretch but dont leak
        
        if (allow_leak)
            
            % find the ones that are stretch but don't leak
            [r,c] = find(vert_copies > 1);
            stretch = true(1, numel(r));
            for i = 1:numel(r)
                                
                % look at these rows
                r_adj = r(i)-vert_copies(r(i), c(i))+1:r(i);
    
                % look at the columns
                c_adj = c(i):c(i)+horz_copies(r(i), c(i))-1;
                
                % height already allocated
                alloc_height = sum(row_heights(r_adj));
                
                % does it already have enough space
                if (alloc_height < heights(r(i), c(i)))
                    
                    % nope - check if it can leak
                    if (r_adj(1) > 1) && all(~is_filled(r_adj(1)-1, c_adj))
                        stretch(i) = false;
                    elseif (r_adj(end) < n_rows) && all(~is_filled(r_adj(end)+1, c_adj))
                        stretch(i) = false;
                    end
                end
            end
            r = r(stretch);
            c = c(stretch);
            
        else
            
            % all of them in this case
            [r,c] = find(~processed);
        end
    else
        
        % stage two -  do the one that leak
        [r,c] = find(~processed);
        req_space = zeros(1, numel(r));
        
        % do the ones that are closest to fitting first
        for i = 1:numel(r)
            
            % look at these rows
            r_adj = r(i)-vert_copies(r(i), c(i))+1:r(i);
            
            % look at the columns
            c_adj = c(i):c(i)+horz_copies(r(i), c(i))-1;
            
            % height already allocated
            alloc_height = sum(row_heights(r_adj));
            
            % height already allocated to the above leak zone
            top = r_adj(1)-1;
            while (top >= 1) && all(~is_filled(top, c_adj))
                alloc_height = alloc_height + row_heights(top);
                top = top - 1;
            end
            bottom = r_adj(end)+1;
            while (bottom <= n_rows) && all(~is_filled(bottom, c_adj))
                alloc_height = alloc_height + row_heights(bottom);
                bottom = bottom + 1;
            end
                
            % how much extra space is required (can be over allocated already)
            req_space(i) = heights(r(i), c(i)) - alloc_height;
            
        end
        
        % order them - do the ones that require the minimum changes first
        [vals, order] = sort(req_space);
        r = r(order);
        c = c(order);
        
    end

    for i = 1:numel(r)
        
        % check the usable height
        spread_inds = [r(i) - vert_copies(r(i),c(i)) + 1, r(i)];
        
        % the component is spread across these rows
        spread_rows = spread_inds(1):spread_inds(2);
        useable_height = sum(row_heights(spread_rows)) - row_gap(spread_rows(1));
        gdiff = max(gap(spread_inds(1), c(i)) - row_gap((spread_rows(1))), 0);
        req_height = heights(r(i),c(i)) + gdiff;
        
        % if it doesn't fit already
        if (req_height > useable_height)
            
            % check - if this is the first things with height in the row
            % assign its entire height to the current row (ordered above so
            % doing this makes sense)
            tmp_heights = row_heights(spread_rows);
            empty_rows = spread_rows((tmp_heights == 0) | (tmp_heights == row_gap(spread_rows)));
            if any(empty_rows)
                
                % add how much height to each?
                add_height = ceil((heights(r(i),c(i)) - useable_height) / numel(empty_rows));
                row_heights(empty_rows) = row_heights(empty_rows) + add_height;
                useable_height = heights(r(i),c(i));
                
                % add the gaps
                if (empty_rows(1) > 1) && (row_heights(empty_rows(1)-1) > 0) && (row_gap(empty_rows(1)) == 0)
                    row_heights(empty_rows(1)) = row_heights(empty_rows(1)) + vspace(r(i), c(i));
                    row_gap(empty_rows(1)) = vspace(r(i), c(i));
                end
                if (empty_rows(end) < n_rows) && (row_heights(empty_rows(end)+1) > 0) && (row_gap(empty_rows(end)+1) == 0)
                    row_heights(empty_rows(end)+1) = row_heights(empty_rows(end)+1) + vspace(r(i)+1, c(i));
                    row_gap(empty_rows(end)+1) = vspace(r(i)+1, c(i));
                end
                
            elseif (allow_leak)
                        
                % "leak" into other rows
                allow = [true, true];
                while any(allow) && (heights(r(i),c(i)) > useable_height)
                    
                    % try and go up
                    extra = zeros(2,1);
                    if allow(1) && (spread_inds(1) > 1) && ~is_filled(spread_inds(1)-1, c(i))
                        spread_inds(1) = spread_inds(1) - 1;
                        extra(1) = row_heights(spread_inds(1)) - used_leakage(spread_inds(1), c(i));
                    else
                        allow(1) = false;
                    end
                    
                    if allow(2) && (spread_inds(2) < size(heights,1)) && ~is_filled(spread_inds(2)+1, c(i))
                        spread_inds(2) = spread_inds(2) + 1;
                        extra(2) = row_heights(spread_inds(2)) - used_leakage(spread_inds(2), c(i));
                    else
                        allow(2) = false;
                    end
                    
                    % special case here if it can leak into a row with zero height
                    % just fill that row
                    is_empty = allow(:) & (row_heights(spread_inds) == 0);
                    empty_rows = spread_inds(is_empty);
                    
                    if (numel(empty_rows)) && (heights(r(i),c(i)) - useable_height - sum(extra)) > 0
                        
                        % add how much height to each?                     
                        add_height = ceil((heights(r(i),c(i)) - useable_height - sum(extra)) / numel(empty_rows));
                        row_heights(empty_rows) = row_heights(empty_rows) + add_height;
                        useable_height = heights(r(i),c(i));
                        
                        % add the gaps
                        if (is_empty(1))
                            row_heights(empty_rows(1)) = row_heights(empty_rows(1)) + vspace(r(i), c(i));
                            row_gap(empty_rows(1)) = vspace(r(i), c(i));
                            post_height(r(i), c(i)) = post_height(r(i), c(i)) + add_height;    % extra space above
                        end
                        if (is_empty(2))
                            row_heights(empty_rows(end)+1) = row_heights(empty_rows(end)+1) + vspace(r(i)+1, c(i)+1);
                            row_gap(empty_rows(end)+1) = vspace(r(i)+1, c(i)+1);
                            pre_height(r(i), c(i)) = pre_height(r(i), c(i)) + add_height;  % extra space below
                        end
                        
                    elseif any(extra) % did we find space?
                        
                        % leak proportionally
                        needed = heights(r(i),c(i)) - useable_height;
                        avail = sum(extra);
                        if (avail < needed)
                            % fill them both
                            leak_quant = extra;
                            used_leakage(spread_inds, c(i)) = used_leakage(spread_inds, c(i)) + extra + vspace(spread_inds, c(i)) .* (leak_quant > 0);  % add the gap in case something else "leaks" into it
                            useable_height = useable_height + sum(extra);
                        else
                            % spread proportionally
                            leak_quant = (needed / avail) * extra;
                            used_leakage(spread_inds, c(i)) = used_leakage(spread_inds, c(i)) + leak_quant + vspace(spread_inds, c(i));                 % add the gap in case something else "leaks" into it
                            useable_height = heights(r(i),c(i));
                        end
                        post_height(r(i), c(i)) = post_height(r(i), c(i)) + leak_quant(1);  % extra space below
                        pre_height(r(i), c(i)) = pre_height(r(i), c(i)) + leak_quant(2);    % extra space above
                    end
                end
            end
        elseif (gdiff > 0)
            % ensure the current column gap is sufficient
            row_heights(spread_inds(end)) = row_heights(spread_inds(end)) + gdiff;
            row_gap(spread_inds(end)) = gap(spread_inds(2), c(i));
        end
        
        % can we fit it in now - if not, dont increase the size of the leakage rows
        if (req_height > useable_height)
           
            % insert extra height into the rows the control is spread across equally
            spread_rows = spread_inds(1):spread_inds(2);
            add_height = ceil((heights(r(i),c(i)) - useable_height) / numel(spread_rows));
            row_heights(spread_rows) = row_heights(spread_rows) + add_height;
            dgap = sum(row_heights(spread_rows)) - row_gap(spread_rows(end)) - heights(r(i), c(i));
            if (dgap < 0)
                row_gap(spread_rows(end)) = row_gap(spread_rows(end)) - dgap;
            end
            
        end
    end
    processed(r + n_rows * (c - 1)) = true;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now build a map of the (maximum) extent of each object
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

row_start = flipud(cumsum([0; flipud(row_heights)]));  % start at the bottom
ext_min = zeros(size(hGrid));
ext_max = zeros(size(hGrid));

for i = n_rows:-1:1
    for j = 1:n_cols
        
        % only do the "original"
        if ((vert_copies(i,j) > 0) && (horz_copies(i,j) > 0))
            
            % starts here
            ext_min(i,j) = row_start(i+1) - pre_height(i,j);
            
            % stops here
            erow = i - vert_copies(i,j) + 1;
            ext_max(i,j) = row_start(erow+1) + row_heights(erow) + post_height(i,j) - (~allow_leak || ((erow > 1) && is_handle(erow-1,j))) * row_gap(erow);
           
        end
    end
end


