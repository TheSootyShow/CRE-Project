function ProcessCREGuiError(ME, h_fig)
% function ProcessCREGuiError(ME, h_fig)
% this function is called when unexpected errors are
% encountered in CREgui
% ME is the matlab exception that caused the error

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ensure the gui is still usable (i.e. not disabled)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

set(0, 'showhiddenhandles', 'on');  % show hidden handles so we can find a handle to it
if (nargin < 2)
    h_fig = findobj('tag', 'CREgui');
end
set(0, 'showhiddenhandles', 'off');

% did we find the figure?
if (numel(h_fig))
    
    % make sure the figure is enabled
    EnableDisableFig(h_fig, true);

    
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % stop blocking the resize function
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     
%     resize_func = get(h_fig, 'ResizeFcn');
%     feval(resize_func, h_fig, 'unblock');
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % remove the status bar if it was there
    % and if its CREgui
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    if strcmpi(get(h_fig, 'tag'), 'CREgui')
        handles = guidata(h_fig);
        status_bar = [];
        if isfield(handles, 'status_bar') && numel(handles.status_bar)
            status_bar = handles.status_bar;
        elseif isfield(handles, 'uiStatus')
            % try to find it manually
            kids = findall(findall(handles.uiStatus));
            tags = get(kids, 'tag');
            if ~iscell(tags)
                tags = {tags};
            end
            status_bar = kids(~ismember(tags, {'uiStatus'; 'txtStatus'}));
        end
        if numel(status_bar)
            delete(status_bar);
            handles.status_bar = [];
            guidata(h_fig, handles);
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% and report the error
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (isdeployed())
    error_txt = ME.getReport('extended', 'hyperlinks','off');
    errordlg(error_txt, 'Error detected', 'modal')
    EmailMe(error_txt);
else
    rethrow(ME);
end