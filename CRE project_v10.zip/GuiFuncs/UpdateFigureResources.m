function UpdateFigureResources()
% function UpdateFigureResources()
% this function copies newer "original" figure's from the figure resource 
% directory inot the appropriate places in the directory structure

% the location of the figure srcFiles
path = CreateFigureResourceDir();

% get all of the original figure srcFiles in this directory
srcFiles = cellstr(ls(fullfile(path, '*.fig')));

% remove any that have the version naming string
verStrs = regexpi(srcFiles, '\d+_\d+_\d+', 'match', 'once');
srcFiles = srcFiles(cellfun(@(x)(numel(x) == 0), verStrs));

% now find these in their original locations
baseDir = regexp(path, filesep, 'split');
baseDir = fullfile(baseDir{1:end-1});  % root is one level above the figure resource dir

% find all subdirectories of baseDir
allDirs = RecurseDir(baseDir);
allDirs = allDirs(~strcmpi(allDirs, path));  % exclude the figure resouce directory

% now find all figure files in these dirs
figFiles = cell(30, 2); % {dir, file}
count = 0;
for i = 1:numel(allDirs)
    localFiles = cellstr(ls(fullfile(allDirs{i}, '*.fig')));
    if (numel(localFiles{1}))  % above line returns {''} if there are no fig files
        figFiles(count+1:count+numel(localFiles),1) = allDirs(i);
        figFiles(count+1:count+numel(localFiles),2) = localFiles(:);
        count = count + numel(localFiles);
    end
end
figFiles(count+1:end,:) = [];

% now match the files
[found, idx] = ismember(srcFiles, figFiles(:,2));
if any(~found)
    error('Could not locate the original directory for: %s', srcFiles{find(~found, 1, 'first')});
end

% and replace them
for i = 1:numel(idx)
    src = fullfile(path, srcFiles{i});
    dest = fullfile(figFiles{idx(i), :});
    copyfile(src, dest);
    fprintf('Copied: %s -> %s\n', src, dest);
end





