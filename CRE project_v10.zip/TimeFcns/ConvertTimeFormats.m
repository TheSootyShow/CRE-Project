function [output, format, input_dv] = ConvertTimeFormats(input, in_date_vec, in_hhmmss, in_relative, out_date_vec, out_hhmmss, out_relative)
% function [output, format, input_dv] = ConvertTimeFormats(input, in_date_vec, in_hhmmss, in_relative, out_date_vec, out_hhmmss, out_relative)
% function to convert an input time with the specified format to another
% format
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% input         - input representation of the time.  Its format is
%                 specified below
%
% in_date_vec   - a Matlab date vector [Y, M, D, h, m, s]  (see datevec.m)
%               - if the input uses "relative time", the input time is
%                 treated as the time ellapsed from this date stamp
%
% in_hhmmss     - if 0, the input should be a representation of
%                 the time in seconds
%               - if 1, the input is a string with the format 'HH:MM:SS'
%                 (or 'yyyy-mm-dd HH:MM:SS')
%               - if 2, the input is a string with the format 'HH:MM:SS:MS'
%                 (or 'yyyy-mm-dd HH:MM:SS:MS') wher MS is milliseconds
%
% in_relative   - if true, the input is treated as the time ellapsed
%                 since the date stamp
%               - if false, the input is treated as the time ellapsed
%                 since 0 AD (the time since the date vector  [0,0,0,0,0,0])
%
% out_date_vec  - a Matlab date vector [Y, M, D, h, m, s]  (see datevec.m)
%               - if the output  uses "relative time", the output time is
%                 treated as the time ellapsed from this date stamp
%
% out_hhmmss    - if 0, the output should be a representation of the 
%                 time seconds
%               - if 1, the output is a string with the format 'HH:MM:SS'
%                 (or 'yyyy-mm-dd HH:MM:SS' if out_relative == false)
%               - if 2, the output is a string with the format 'HH:MM:SS:MS'
%                 (or 'yyyy-mm-dd HH:MM:SS:MS' if out_relative == false) where MS is milliseconds
%
% out_relative  - if true, the output is treated as the time ellapsed
%                 since the date stamp in_date_vec
%               - if false, the output is treated as the time ellapsed
%                 since 0 AD (the time since the date vector  [0,0,0,0,0,0])
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% output        - the time converted to the desired format
%
% format        - a string representation of the output format
%
% input_dv      - the output as a date vector (never relative to the input
%                 date vector)


h_format = 'HH:MM:SS';
h_format_ms = 'HH:MM:SS:MS';
d_format = 'yyyy-mm-dd';


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Turn the input into a date vector
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% convert the input into a date vector
input_dv = zeros(1,6);

% is the input in string format?
if ischar(input)

    % does it contain a date and time?
    space_ind = find(input == ' ', 1, 'first');
    if (numel(space_ind))
        date_str = strtrim(input(1:space_ind-1));
        time_str = strtrim(input(space_ind+1:end));
    end
    
    % correct order?
    if any(date_str == ':') || any(time_str == '-')
        [date_str, time_str] = deal(time_str, date_str);
    end
    
    % initialise the current time
    if (numel(time_str))

        % in hours mins and seconds or just seconds
        if (in_hhmmss > 0)
            
            [tokens, other] = regexp(time_str, ':', 'split');
            if (numel(tokens) ~= (3 + (hhmmss == 2)))
                error('String: %s does not match the specified format');
            end
            
            % convert tokens to numerics
            values = cellfun(@str2double, tokens);
            if any(isnan(values))
                error('Error converting time string %s to time', time_str);
            end
            
            % change to a time in seconds
            time_s = 0;
            for i = 1:3
                time_s = time_s + values(i) * 60^(3-i);
            end
            
            % include ms
            if (numel(values) == 4)
                time_s = time_s + values(4) * 1e-3;
            end
            
        else
            time_s = str2double(time_str);
        end
        
        % check the conversion was valid
        if isnan(time_s)
            error('Error converting time string: %s to time', time_str);
        end
        
        % add to date can't handle fractional seconds, so remove them
        frac_secs = rem(time_s,1);
        time_s = floor(time_s);
        if (frac_secs < 0)
            frac_secs = 1 + frac_secs;  % N.B. this is why we took the "floor" above not "fix"
        end
            
        % now create the time vector
        input_dv = datevec(addtodate(0, time_s, 'second'));
        input_dv(end) = input_dv(end) + frac_secs;
    end
    
    % now add the date to this time
    if numel(date_str)
        input_dv = AddDateVectors(input_dv, datevec(date_str, d_format));
    end
else
    
    % the input is numeric
    frac_secs = rem(input,1);
    input = floor(input);     % N.B. this is why we took the "floor" above not "fix"
    if (frac_secs < 0)
        frac_secs = 1 + frac_secs;
    end
    input_dv = datevec(addtodate(0, input, 'second'));
    input_dv(end) = input_dv(end) + frac_secs;
    
end

% and add the time stamp
if (in_relative)
    input_dv = AddDateVectors(input_dv, in_date_vec);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Now turn the input date vector into the desired format
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% create the output date format
if (out_hhmmss == 1) && (~out_relative)
    format = sprintf('%s %s', d_format, h_format);
elseif (out_hhmmss == 2) && (~out_relative)
    format = sprintf('%s %s', d_format, h_format_ms);
elseif (out_hhmmss == 1)
    format = h_format;
elseif (out_hhmmss == 2)
    format = h_format_ms;
elseif (~out_relative)
    format = sprintf('%s s', d_format); 
else
    format = 's';
end


if (out_relative)
    
    % remove the input date
    output_dv = AddDateVectors(input_dv, -out_date_vec);  % subtract the output date vector
    output_str = '';
else
    output_dv = input_dv;
    output_str = date_str([output_dv(1:3), zeros(1,3)], d_format);
    output_dv(1:3) = 1:3;  % now represented
end

% matlab doesn't do well with fractional seconds
frac_secs = rem(output_dv(end),1);
output_dv(end) = floor(output_dv(end));     % N.B. this is why we took the "floor" above not "fix"
if (frac_secs < 0)
    frac_secs = 1 + frac_secs;
end

if (out_hhmmss == 0)
    
    % how many seconds are left?
    output = etime(output_dv, zeros(1,6));
    
    if (out_relative)
        output = output + frac_secs;
    else
        output = sprintf('%s %s', output_str, FsString(output+frac_secs));
    end
    
elseif all(output_dv(1:3) == 0)
    
    % no messy days to worry about
    output = sprintf('%s %s', output_str, datestr(output_dv, h_format));
    
    if (out_hhmmss == 1)
        frac_sec_str = FsString(frac_secs);
        output = sprintf('%s%s', output, frac_sec_str(find(frac_sec_str == '.',1,'first'):end));
    else
        millisecs = frac_secs * 1000;
        millisec_str = FsString(millisecs);  % in ms this time
        ns = log10(millisecs);               % how many numbers above zero?
        add_zeros = min(3 - ceil(ns) - (ns == ceil(ns)), 2);      % mnin because FsString will always return with a leading zero
        output = sprintf('%s:%s%s', output, repmat('0',1,add_zeros), millisec_str);
    end
end






    
